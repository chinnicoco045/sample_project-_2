import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import React from 'react';
import { ThemeProvider, createTheme } from '@mui/material';
import { FreyrLibraryProvider } from '../../context/FreyrLibraryContext';

const queryClient = new QueryClient();
const theme = createTheme();

export const WithWrapper = Story => {
  return (
    <ThemeProvider theme={theme}>
      <QueryClientProvider client={queryClient}>
        <FreyrLibraryProvider>
          <Story />
        </FreyrLibraryProvider>
      </QueryClientProvider>
    </ThemeProvider>
  );
};
