import { TJsonSchemaData } from '../type';
import * as z from 'zod';
import { produce } from 'immer';
import { RJSFSchema, UiSchema } from '@rjsf/utils';
import { cloneDeep } from 'lodash';

export const mockJsonData: Array<PrettifiedTFormInput> = [
  {
    type: 'text',
    field: 'text_field',
    required: true,
    label: 'Basic Text',
    labelKey: 'basicText.name',
    order: 0,
    description: 'description of basic text',
    placeholder: 'type basic text here',
    minLen: 3,
    maxLen: 50,
    pattern: '[\\S]',
    field_xs: 12,
    field_md: 6,
    field_lg: 12,
    field_xl: 12,
    size: 'small',
  },
  {
    type: 'text',
    field: 'textarea_field',
    required: false,
    label: 'Basic Textarea',
    labelKey: 'basicTextarea.name',
    order: 1,
    description: 'description of basic textarea',
    placeholder: 'type here',
    minLen: 0,
    maxLen: 500,
    textArea: true,
    maxRows: 3,
    field_lg: 12,
    field_md: 12,
    field_xl: 12,
    field_xs: 12,
    size: 'small',
  },
  {
    type: 'number',
    field: 'number_field',
    required: true,
    label: 'Basic Count',
    labelKey: 'count.name',
    order: 2,
    description: 'count of product',
    placeholder: 'type count of product here',
    min: 1,
    max: 10,
    field_lg: 6,
    field_md: 6,
    field_xl: 6,
    field_xs: 12,
    size: 'small',
  },
  {
    type: 'date',
    field: 'date_field',
    required: true,
    label: 'Basic Date Input',
    labelKey: 'data.name',
    order: 3,
    // hide: false,
    // keepValue: true,
    placeholder: 'DD/MM/YYYY',
    field_lg: 6,
    field_md: 6,
    field_xl: 6,
    field_xs: 12,
    size: 'small',
    minDate: '2023/10/10',
  },
  {
    type: 'select',
    field: 'select_single_field',
    required: true,
    label: 'Product Country (Single)',
    labelKey: 'country.name',
    order: 4,
    placeholder: 'select product country',
    multiple: false,
    options: [
      { label: 'China', value: 1 },
      { label: 'US', value: 2 },
    ],
    // asyncConfig: {
    //   url: '/api/country/list/{groupId}/{productId}',
    //   params: [
    //     {
    //       store: 'EditItem',
    //       valuePath: 'data.countryGroup',
    //       fieldName: 'groupId',
    //     },
    //     {
    //       store: 'formState',
    //       valuePath: 'product',
    //       fieldName: 'productId',
    //     },
    //   ],
    //   dependencies: ['product'],
    //   labelPath: 'name',
    //   valuePath: 'id',
    // },
  },
  {
    type: 'select',
    field: 'select_multi_field',
    required: true,
    label: 'Product Country (Multiple)',
    labelKey: 'country.name',
    order: 5,
    placeholder: 'select product country',
    multiple: true,
    options: [
      { label: 'China', value: "1" },
      { label: 'US', value: "2" },
    ],
  },
  {
    type: 'chips',
    field: 'chips_field1',
    required: true,
    label: 'Tags With Chips',
    order: 6,
    max: 5,
    placeholder: 'type and enter here',
    field_xs: 12,
    field_md: 12,
    field_lg: 12,
    field_xl: 12,
    size: 'small',
    catchInputValAsChipOnBlur: true,
  },
  {
    type: 'select',
    field: 'chips_field2',
    required: true,
    label: 'Tags With Multi Select Chips(Recommend And Type Ahead)',
    order: 7,
    placeholder: 'type and enter here',
    field_xs: 12,
    field_md: 12,
    field_lg: 12,
    field_xl: 12,
    size: 'small',
    multiple: true,
    multipleChip: true,
    options: [
      { label: 'QRD', value: 'QRD' },
      { label: 'SmPC', value: 'SmPC' },
      { label: 'Labelling and PIL', value: 'Labelling and PIL' },
      {
        label: 'Product Development Report (PDR)',
        value: 'Product Development Report (PDR)',
      },
      {
        label: 'Canadian Product Monograph(PM)',
        value: 'Canadian Product Monograph(PM)',
      },
    ],
  },
  {
    type: "radio",
    field: 'radio_field',
    required: true,
    label: 'Basic Radio',
    order: 8,
    placeholder: 'type and enter here',
    field_xs: 12,
    field_md: 12,
    field_lg: 12,
    field_xl: 12,
    size: 'small',
    options: [
      { label: 'QRD', value: 'QRD' },
      { label: 'SmPC', value: 'SmPC' },
    ],
  },
  {
    type: "view",
    field: 'view_field',
    required: true,
    label: 'Basic View',
    order: 9,
    placeholder: 'type and enter here',
    field_xs: 12,
    field_md: 12,
    field_lg: 12,
    field_xl: 12,
    size: 'small',
  },
  {
    type: 'checkboxGroups',
    field: 'checkbox_field1',
    required: true,
    label: 'Checkbox Group',
    order: 10,
    placeholder: '',
    field_xs: 12,
    field_md: 12,
    field_lg: 12,
    field_xl: 12,
    size: 'small',
    multiple: true,
    options: [
      { label: 'Gilad Gray', value: 'gilad' },
      { label: 'Jason Killian', value: 'jason' },
      { label: 'Antoine Llorca', value: 'antoine ' },
    ],
  },
  {
    type: 'checkbox',
    field: 'checkbox_field2',
    required: false,
    label: 'Checkbox boolean',
    order: 11,
    placeholder: '',
    field_xs: 12,
    field_md: 12,
    field_lg: 12,
    field_xl: 12,
    size: 'small',
  },
];

type convertFunction<T extends PrettifiedTFormInput['type'] = 'text'> = (
  schema: TJsonSchemaData,
  data: Prettify<PrettifiedTFormInput & { type: T }>,
  forceDisable?: boolean
) => TJsonSchemaData | void;

type JsonConfig<T> = {
  jsonSchema: Array<{
    prop: keyof RJSFSchema;
    key: keyof T;
  }>;
  uiSchema: Array<{
    prop: keyof UiSchema;
    key: keyof T;
  }>;
  zodSchems?: Array<{
    prop: keyof RJSFSchema;
    key: keyof T;
  }>;
};

export const convertCommonInfo = (
  schema: TJsonSchemaData,
  data: PrettifiedTFormInput
) => {
  console.log('convertCommonInfo==', schema);
  if (!data || !data?.field) {
    return;
  }
  // if (data?.required) {
  //   schema["jsonSchema"]["required"]?.push(data.field);
  //   schema["uiSchema"][data.field] = {
  //     ...(schema["uiSchema"][data.field] ?? {}),
  //     "ui:size": "small",
  //   };
  // }
  // if (data?.placeholder) {
  //   schema["uiSchema"][data.field] = {
  //     ...(schema["uiSchema"][data.field] ?? {}),
  //     "ui:placeholder": data?.placeholder,
  //   };
  // }
};

export const convertTextSchema: convertFunction<'text'> = (
  schema,
  data,
  forceDisable = false
) => {
  // console.log("convertTextSchema", data);
  if (!data || !data?.field) {
    return schema;
  }
  let fieldJsonSchema: RJSFSchema = { type: 'string' };
  const fieldUiSchema: Record<string, unknown> = {
    'ui:size': 'small',
  };
  let fieldZodSchema: any = z.string({
    required_error: '',
  });
  // parse the json schema
  // if (data?.readonly) fieldJsonSchema["readOnly"] = true;
  fieldJsonSchema['title'] = data?.label || data?.originlabel;
  if (data?.description) fieldJsonSchema['description'] = data?.description;
  // parse the zodSchema
  if (data?.minLen !== undefined)
    fieldZodSchema = fieldZodSchema.min(
      data?.minLen,
      `no less than ${data?.minLen}`
    );
  if (data?.maxLen)
    fieldZodSchema = fieldZodSchema.max(
      data?.maxLen,
      `no longer than ${data?.maxLen}`
    );
  if (data?.pattern)
    fieldZodSchema = fieldZodSchema.refine((str: string) => {
      const reg = new RegExp(data.pattern as string, 'g');
      return reg.test(str);
    }, 'format error');
  if (!data?.required) fieldZodSchema = fieldZodSchema.optional().nullable();
  // parse the uiSchema
  if (data?.disabled || forceDisable) fieldUiSchema['ui:disabled'] = true;
  // if (data?.description) fieldUiSchema["ui:description"] = data.description;
  if (data?.placeholder) fieldUiSchema['ui:placeholder'] = data.placeholder;
  if (data?.size) fieldUiSchema['ui:size'] = data?.size;
  if (data?.textArea) fieldUiSchema['ui:widget'] = 'textarea';
  if (data?.maxRows) fieldUiSchema['ui:rows'] = data?.maxRows;
  if (data?.field_xs) fieldUiSchema['ui:field_xs'] = data?.field_xs;
  if (data?.field_xl) fieldUiSchema['ui:field_xl'] = data?.field_xl;
  if (data?.field_md) fieldUiSchema['ui:field_md'] = data?.field_md;
  if (data?.field_lg) fieldUiSchema['ui:field_lg'] = data?.field_lg;
  if (data?.minLen) fieldUiSchema['ui:minLen'] = data?.minLen;
  if (data?.maxLen) fieldUiSchema['ui:maxLen'] = data?.maxLen;
  if (data?.icon) fieldUiSchema['ui:icon'] = data?.icon;
  if (data?.labelKey) {
    fieldUiSchema['ui:labelKey'] =
      !data?.label || data?.label === data?.originlabel ? data?.labelKey : '';
  }
  if (data?.readonly) fieldUiSchema['ui:readonly'] = data?.readonly;

  const producer = produce<TJsonSchemaData>(draft => {
    draft.zodSchema = draft.zodSchema?.merge(
      z.object({ [data.field]: fieldZodSchema })
    );
    if (draft.jsonSchema.properties && fieldJsonSchema) {
      draft.jsonSchema.properties[data.field] = {
        ...(cloneDeep(draft.jsonSchema.properties[data.field] as RJSFSchema) ??
          {}),
        ...fieldJsonSchema,
      };
    }
    if (fieldUiSchema) {
      draft.uiSchema = {
        ...draft.uiSchema,
        [data.field]: fieldUiSchema,
      };
    }
    if (data?.required) {
      draft.jsonSchema.required?.push(data.field);
    }
  });
  const nextSchema = producer(schema);
  // console.log("nextSchema", nextSchema);
  return nextSchema;
};

export const convertChipsSchema: convertFunction<'chips'> = (
  schema,
  data,
  forceDisable = false
) => {
  // console.log("convertTextSchema", data);
  if (!data || !data?.field) {
    return schema;
  }
  let fieldJsonSchema: RJSFSchema = {
    type: ['string', 'array', 'object', 'number'],
    items: {
      type: ['string', 'object', 'number'],
      properties: {
        value: {
          type: 'number',
        },
        label: {
          type: 'string',
        },
      },
    },
    properties: {
      value: {
        type: 'number',
      },
      label: {
        type: 'string',
      },
    },
  };
  const fieldUiSchema: Record<string, unknown> = {
    'ui:size': 'small',
    'ui:widget': 'CustomChipsInput',
  };
  let fieldZodSchema: any = z
    .undefined({ required_error: '' })
    .or(z.number({ required_error: '' }))
    .or(z.string({ required_error: '' }))
    .or(z.object({}))
    .or(
      z.array(z.string().or(z.object({})), {
        required_error: '',
      })
    );
  // parse the json schema
  // if (data?.readonly) fieldJsonSchema["readOnly"] = true;
  fieldJsonSchema['title'] = data?.label || data?.originlabel;
  if (data?.description) fieldJsonSchema['description'] = data?.description;
  // parse the zodSchema
  if (data?.max !== undefined) {
    fieldZodSchema = fieldZodSchema.refine((vals: string[]) => {
      return vals?.length <= (data?.max as number);
    }, 'over max limits');
  }
  if (!data?.required) fieldZodSchema = fieldZodSchema.optional().nullable();
  // parse the uiSchema
  if (data?.options && data?.options?.length > 0) {
    // console.log("chips convert: ", data?.options);
    fieldUiSchema['ui:customOptions'] = data?.options;
  }
  if (data?.disabled || forceDisable) fieldUiSchema['ui:disabled'] = true;
  // if (data?.description) fieldUiSchema["ui:description"] = data.description;
  if (data?.placeholder) fieldUiSchema['ui:placeholder'] = data.placeholder;
  if (data?.size) fieldUiSchema['ui:size'] = data?.size;
  if (data?.max) fieldUiSchema['ui:max'] = data?.max;
  if (data?.field_xs) fieldUiSchema['ui:field_xs'] = data?.field_xs;
  if (data?.field_xl) fieldUiSchema['ui:field_xl'] = data?.field_xl;
  if (data?.field_md) fieldUiSchema['ui:field_md'] = data?.field_md;
  if (data?.field_lg) fieldUiSchema['ui:field_lg'] = data?.field_lg;
  if (data?.icon) fieldUiSchema['ui:icon'] = data?.icon;
  if (data?.labelKey) {
    fieldUiSchema['ui:labelKey'] =
      !data?.label || data?.label === data?.originlabel ? data?.labelKey : '';
  }
  if (data?.readonly) fieldUiSchema['ui:readonly'] = data?.readonly;
  if (data?.catchInputValAsChipOnBlur)
    fieldUiSchema['ui:catchInputValAsChipOnBlur'] =
      data?.catchInputValAsChipOnBlur;

  const producer = produce<TJsonSchemaData>(draft => {
    draft.zodSchema = draft.zodSchema?.merge(
      z.object({ [data.field]: fieldZodSchema })
    );
    if (draft.jsonSchema.properties && fieldJsonSchema) {
      draft.jsonSchema.properties[data.field] = {
        ...(cloneDeep(draft.jsonSchema.properties[data.field] as RJSFSchema) ??
          {}),
        ...fieldJsonSchema,
      };
    }
    if (fieldUiSchema) {
      draft.uiSchema = {
        ...draft.uiSchema,
        [data.field]: fieldUiSchema,
      };
    }
    if (data?.required) {
      draft.jsonSchema.required?.push(data.field);
    }
  });
  const nextSchema = producer(schema);
  // console.log("nextSchema", nextSchema);
  return nextSchema;
};

export const convertNumberSchema: convertFunction<'number'> = (
  schema,
  data,
  forceDisable = false
) => {
  if (!data || !data?.field) {
    return;
  }
  const config: JsonConfig<TNumberInput> = {
    jsonSchema: [
      { prop: 'title', key: 'label' },
      { prop: 'minimum', key: 'min' },
      { prop: 'maximum', key: 'max' },
      // { prop: "default", key: "default" },
    ],
    uiSchema: [
      { prop: 'ui:disabled', key: 'disabled' },
      { prop: 'ui:readonly', key: 'readonly' },
      { prop: 'ui:description', key: 'description' },
      { prop: 'ui:size', key: 'size' },
      { prop: 'ui:placeholder', key: 'placeholder' },
      { prop: 'ui:field_xl', key: 'field_xl' },
      { prop: 'ui:field_lg', key: 'field_lg' },
      { prop: 'ui:field_md', key: 'field_md' },
      { prop: 'ui:field_xs', key: 'field_xs' },
      { prop: 'ui:icon', key: 'icon' },
      { prop: 'ui:labelKey', key: 'labelKey' },
    ],
  };
  let fieldJsonSchema: RJSFSchema = {
    type: 'number',
  };
  let fieldUiSchema: UiSchema = {};
  let fieldZodSchema: any = z.number({
    required_error: '',
  });
  if (data?.min !== undefined)
    fieldZodSchema = fieldZodSchema.min(data.min, `no less than ${data.min}`);
  if (data?.max)
    fieldZodSchema = fieldZodSchema.max(
      data.max,
      `no longer than ${data?.max}`
    );
  if (!data?.required) {
    fieldZodSchema = fieldZodSchema.optional().nullable();
  }
  // jsonSchema
  for (let item of config.jsonSchema) {
    if (data[item.key]) {
      fieldJsonSchema = {
        ...fieldJsonSchema,
        [item.prop]: data[item.key],
      };
    }
  }
  // uiSchema
  for (let item of config.uiSchema) {
    if (data[item.key]) {
      fieldUiSchema = {
        ...fieldUiSchema,
        [item.prop]: data[item.key],
      };
    }
  }
  fieldJsonSchema['title'] = data?.label || data?.originlabel;
  if (forceDisable) {
    fieldUiSchema = {
      ...fieldUiSchema,
      'ui:disabled': true,
    };
  }
  if (data?.labelKey) {
    fieldUiSchema['ui:labelKey'] =
      !data?.label || data?.label === data?.originlabel ? data?.labelKey : '';
  }
  const producer = produce<TJsonSchemaData>(draft => {
    draft.zodSchema = draft.zodSchema?.merge(
      z.object({ [data.field]: fieldZodSchema })
    );
    if (draft.jsonSchema.properties && fieldJsonSchema) {
      draft.jsonSchema.properties[data.field] = {
        ...(cloneDeep(draft.jsonSchema.properties[data.field] as RJSFSchema) ??
          {}),
        ...fieldJsonSchema,
      };
    }
    if (fieldUiSchema) {
      draft.uiSchema = {
        ...draft.uiSchema,
        [data.field]: fieldUiSchema,
      };
    }
    if (data?.required) {
      draft.jsonSchema.required?.push(data.field);
    }
  });
  const nextSchema = producer(schema);
  return nextSchema;
};

export const convertDateSchema: convertFunction<'date'> = (
  schema,
  data,
  forceDisable = false
) => {
  if (!data || !data?.field) {
    return;
  }
  const config: JsonConfig<TDateInput> = {
    jsonSchema: [
      { prop: 'title', key: 'label' },
      // { prop: "default", key: "default" },
    ],
    uiSchema: [
      { prop: 'ui:disabled', key: 'disabled' },
      { prop: 'ui:readonly', key: 'readonly' },
      { prop: 'ui:description', key: 'description' },
      { prop: 'ui:size', key: 'size' },
      { prop: 'ui:placeholder', key: 'placeholder' },
      { prop: 'ui:field_xl', key: 'field_xl' },
      { prop: 'ui:field_lg', key: 'field_lg' },
      { prop: 'ui:field_md', key: 'field_md' },
      { prop: 'ui:field_xs', key: 'field_xs' },
      { prop: 'minDate', key: 'minDate' },
      { prop: 'maxDate', key: 'maxDate' },
      { prop: 'ui:icon', key: 'icon' },
      { prop: 'ui:labelKey', key: 'labelKey' },
    ],
  };
  let fieldJsonSchema: RJSFSchema = {
    type: 'string',
    format: 'date',
  };
  let fieldUiSchema: UiSchema = {
    'ui:widget': 'CustomDateWidget',
  };

  // let fieldZodSchema: any = z.date({ required_error: "" });
  let fieldZodSchema: any = z
    .undefined()
    .or(z.string({ required_error: '' }))
    .or(z.date({ required_error: '' }));

  // jsonSchema
  for (let item of config.jsonSchema) {
    if (data[item.key]) {
      fieldJsonSchema = {
        ...fieldJsonSchema,
        [item.prop]: data[item.key],
      };
    }
  }
  fieldJsonSchema['title'] = data?.label || data?.originlabel;
  // uiSchema
  for (let item of config.uiSchema) {
    if (data[item.key]) {
      fieldUiSchema = {
        ...fieldUiSchema,
        [item.prop]: data[item.key],
      };
    }
  }
  if (forceDisable) {
    fieldUiSchema = {
      ...fieldUiSchema,
      'ui:disabled': true,
    };
  }
  if (data?.labelKey) {
    fieldUiSchema['ui:labelKey'] =
      !data?.label || data?.label === data?.originlabel ? data?.labelKey : '';
  }
  const producer = produce<TJsonSchemaData>(draft => {
    draft.zodSchema = draft.zodSchema?.merge(
      z.object({ [data.field]: fieldZodSchema })
    );
    if (draft.jsonSchema.properties && fieldJsonSchema) {
      draft.jsonSchema.properties[data.field] = {
        ...(cloneDeep(draft.jsonSchema.properties[data.field] as RJSFSchema) ??
          {}),
        ...fieldJsonSchema,
      };
    }
    if (fieldUiSchema) {
      draft.uiSchema = {
        ...draft.uiSchema,
        [data.field]: fieldUiSchema,
      };
    }
    if (data?.required) {
      draft.jsonSchema.required?.push(data.field);
    }
  });
  const nextSchema = producer(schema);
  return nextSchema;
};

export const convertViewSchema: convertFunction<'view'> = (
  schema,
  data,
  forceDisable = false
) => {
  if (!data || !data?.field) {
    return schema;
  }
  let enumOptions = undefined;
  let enumNames = undefined;
  if ('options' in data && Array.isArray(data.options)) {
    enumNames = data.options?.map(el => el?.label) ?? [];
    enumOptions = data.options?.map(el => ({
      name: el?.label,
      value: el?.value,
    }));
  }
  const config: JsonConfig<TView> = {
    jsonSchema: [
      { prop: 'title', key: 'label' },
      // { prop: "default", key: "default" },
    ],
    uiSchema: [
      { prop: 'ui:disabled', key: 'disabled' },
      { prop: 'ui:readonly', key: 'readonly' },
      { prop: 'ui:description', key: 'description' },
      { prop: 'ui:size', key: 'size' },
      { prop: 'ui:placeholder', key: 'placeholder' },
      { prop: 'ui:field_xl', key: 'field_xl' },
      { prop: 'ui:field_lg', key: 'field_lg' },
      { prop: 'ui:field_md', key: 'field_md' },
      { prop: 'ui:field_xs', key: 'field_xs' },
      // { prop: "minDate", key: "minDate" },
      // { prop: "maxDate", key: "maxDate" },
      { prop: 'ui:icon', key: 'icon' },
      { prop: 'ui:labelKey', key: 'labelKey' },
    ],
  };
  let fieldJsonSchema: RJSFSchema = {
    type: 'string',
    enumNames: enumNames,
    enum: enumOptions,
  };
  let fieldUiSchema: UiSchema = {
    'ui:widget': 'CustomViewWidget',
  };

  Object.entries(data).forEach(([key, value]) => {
    !!value && (fieldUiSchema[`ui:${key}`] = value);
  });

  let fieldZodSchema: any = z
    .undefined()
    .or(z.string({ required_error: '' }))
    .or(z.date({ required_error: '' }));

  // jsonSchema
  for (let item of config.jsonSchema) {
    if (data[item.key]) {
      fieldJsonSchema = {
        ...fieldJsonSchema,
        [item.prop]: data[item.key],
      };
    }
  }
  fieldJsonSchema['title'] = data?.label || data?.originlabel;
  // uiSchema
  for (let item of config.uiSchema) {
    if (data[item.key]) {
      fieldUiSchema = {
        ...fieldUiSchema,
        [item.prop]: data[item.key],
      };
    }
  }
  if (forceDisable) {
    fieldUiSchema = {
      ...fieldUiSchema,
      'ui:disabled': true,
    };
  }
  if (data?.labelKey) {
    fieldUiSchema['ui:labelKey'] =
      !data?.label || data?.label === data?.originlabel ? data?.labelKey : '';
  }
  const producer = produce<TJsonSchemaData>(draft => {
    draft.zodSchema = draft.zodSchema?.merge(
      z.object({ [data.field]: fieldZodSchema })
    );
    if (draft.jsonSchema.properties && fieldJsonSchema) {
      draft.jsonSchema.properties[data.field] = {
        ...(cloneDeep(draft.jsonSchema.properties[data.field] as RJSFSchema) ??
          {}),
        ...fieldJsonSchema,
      };
    }
    if (fieldUiSchema) {
      draft.uiSchema = {
        ...draft.uiSchema,
        [data.field]: fieldUiSchema,
      };
    }
    if (data?.required) {
      draft.jsonSchema.required?.push(data.field);
    }
  });
  const nextSchema = producer(schema);
  return nextSchema;
};

export const convertSelectSchema: convertFunction<'select' | 'multi-select'> = (
  schema,
  data,
  forceDisable = false
) => {
  // console.log("convertTextSchema", data);
  if (!data || !data?.field) {
    return schema;
  }
  const staticOption = data?.options?.map(el => ({
    name: el?.label,
    value: el?.value,
  }));
  let fieldJsonSchema: RJSFSchema = {
    type: ['string', 'array', 'object', 'number'],
    items: {
      type: ['string', 'object', 'number'],
      properties: {
        value: {
          type: 'number',
        },
        label: {
          type: 'string',
        },
      },
    },
    enumNames: data?.options?.map(el => el?.label) ?? [],
    enum: staticOption?.length ? staticOption : undefined,
    properties: {
      value: {
        type: 'number',
      },
      label: {
        type: 'string',
      },
    },
  };
  const fieldUiSchema: Record<string, unknown> = {
    'ui:size': 'small',
    'ui:widget': 'CustomSelectWidget',
  };
  let fieldZodSchema: any = z
    .undefined({ required_error: '' })
    .or(z.number({ required_error: '' }))
    .or(z.string({ required_error: '' }))
    .or(z.object({}))
    .or(
      z.array(z.string().or(z.object({})), {
        required_error: '',
      })
    );
  // parse the json schema
  // if (data?.readonly) fieldJsonSchema["readOnly"] = true;
  fieldJsonSchema['title'] = data?.label || data?.originlabel;
  if (data?.description) fieldJsonSchema['description'] = data?.description;
  // if (data?.options && data?.options?.length > 0)
  //   fieldJsonSchema["anyOf"] = data.options?.map((el) => ({
  //     const: el?.value,
  //     title: `${el?.label}`,
  //   }));
  // parse the zodSchema
  if (!data?.required) fieldZodSchema = fieldZodSchema.optional().nullable();
  // parse the uiSchema
  if (data?.disabled || forceDisable) fieldUiSchema['ui:disabled'] = true;
  // if (data?.description) fieldUiSchema["ui:description"] = data.description;
  if (data?.placeholder) fieldUiSchema['ui:placeholder'] = data.placeholder;
  if (data?.size) fieldUiSchema['ui:size'] = data?.size;
  if (data?.multiple) fieldUiSchema['ui:multiple'] = true;
  if (data?.multipleChip) fieldUiSchema['ui:multipleChip'] = true;
  if (data?.field_xs) fieldUiSchema['ui:field_xs'] = data?.field_xs;
  if (data?.field_xl) fieldUiSchema['ui:field_xl'] = data?.field_xl;
  if (data?.field_md) fieldUiSchema['ui:field_md'] = data?.field_md;
  if (data?.field_lg) fieldUiSchema['ui:field_lg'] = data?.field_lg;
  if (data?.labelKey) {
    fieldUiSchema['ui:labelKey'] =
      !data?.label || data?.label === data?.originlabel ? data?.labelKey : '';
  }
  if (data?.asyncConfig) fieldUiSchema['ui:asyncConfig'] = data?.asyncConfig;
  if (data?.icon) fieldUiSchema['ui:icon'] = data?.icon;
  if (data?.readonly) fieldUiSchema['ui:readonly'] = data?.readonly;

  const producer = produce<TJsonSchemaData>(draft => {
    draft.zodSchema = draft.zodSchema?.merge(
      z.object({ [data.field]: fieldZodSchema })
    );
    if (draft.jsonSchema.properties && fieldJsonSchema) {
      draft.jsonSchema.properties[data.field] = {
        ...(cloneDeep(draft.jsonSchema.properties[data.field] as RJSFSchema) ??
          {}),
        ...fieldJsonSchema,
      };
    }
    if (fieldUiSchema) {
      draft.uiSchema = {
        ...draft.uiSchema,
        [data.field]: fieldUiSchema,
      };
    }
    if (data?.required) {
      draft.jsonSchema.required?.push(data.field);
    }
  });
  const nextSchema = producer(schema);
  // console.log("nextSchema", nextSchema);
  return nextSchema;
};

export const convertRadioSchema: convertFunction<'radio'> = (
  schema,
  data,
  forceDisable = false
) => {
  // console.log("convertTextSchema", data);
  if (!data || !data?.field) {
    return schema;
  }
  const staticOption = data?.options?.map(el => ({
    name: el?.label,
    value: el?.value,
  }));
  let fieldJsonSchema: RJSFSchema = {
    type: ['string', 'array', 'object', 'number'],
    items: {
      type: ['string', 'object', 'number'],
      properties: {
        value: {
          type: 'number',
        },
        label: {
          type: 'string',
        },
      },
    },
    enumNames: data?.options?.map(el => el?.label) ?? [],
    enum: staticOption?.length ? staticOption : undefined,
    properties: {
      value: {
        type: 'number',
      },
      label: {
        type: 'string',
      },
    },
  };
  const fieldUiSchema: Record<string, unknown> = {
    'ui:size': 'small',
    'ui:widget': 'CustomRadioWidget',
  };
  let fieldZodSchema: any = z
    .undefined({ required_error: '' })
    .or(z.number({ required_error: '' }))
    .or(z.string({ required_error: '' }))
    .or(z.object({}))
    .or(
      z.array(z.string().or(z.object({})), {
        required_error: '',
      })
    );
  // parse the json schema
  // if (data?.readonly) fieldJsonSchema["readOnly"] = true;
  fieldJsonSchema['title'] = data?.label || data?.originlabel;
  if (data?.description) fieldJsonSchema['description'] = data?.description;
  // if (data?.options && data?.options?.length > 0)
  //   fieldJsonSchema["anyOf"] = data.options?.map((el) => ({
  //     const: el?.value,
  //     title: `${el?.label}`,
  //   }));
  // parse the zodSchema
  if (!data?.required) fieldZodSchema = fieldZodSchema.optional().nullable();
  // parse the uiSchema
  if (data?.disabled || forceDisable) fieldUiSchema['ui:disabled'] = true;
  // if (data?.description) fieldUiSchema["ui:description"] = data.description;
  if (data?.placeholder) fieldUiSchema['ui:placeholder'] = data.placeholder;
  if (data?.size) fieldUiSchema['ui:size'] = data?.size;
  if (data?.field_xs) fieldUiSchema['ui:field_xs'] = data?.field_xs;
  if (data?.field_xl) fieldUiSchema['ui:field_xl'] = data?.field_xl;
  if (data?.field_md) fieldUiSchema['ui:field_md'] = data?.field_md;
  if (data?.field_lg) fieldUiSchema['ui:field_lg'] = data?.field_lg;
  if (data?.labelKey) {
    fieldUiSchema['ui:labelKey'] =
      !data?.label || data?.label === data?.originlabel ? data?.labelKey : '';
  }
  if (data?.asyncConfig) fieldUiSchema['ui:asyncConfig'] = data?.asyncConfig;
  if (data?.icon) fieldUiSchema['ui:icon'] = data?.icon;
  if (data?.readonly) fieldUiSchema['ui:readonly'] = data?.readonly;

  const producer = produce<TJsonSchemaData>(draft => {
    draft.zodSchema = draft.zodSchema?.merge(
      z.object({ [data.field]: fieldZodSchema })
    );
    if (draft.jsonSchema.properties && fieldJsonSchema) {
      draft.jsonSchema.properties[data.field] = {
        ...(cloneDeep(draft.jsonSchema.properties[data.field] as RJSFSchema) ??
          {}),
        ...fieldJsonSchema,
      };
    }
    if (fieldUiSchema) {
      draft.uiSchema = {
        ...draft.uiSchema,
        [data.field]: fieldUiSchema,
      };
    }
    if (data?.required) {
      draft.jsonSchema.required?.push(data.field);
    }
  });
  const nextSchema = producer(schema);
  // console.log("nextSchema", nextSchema);
  return nextSchema;
};

export const convertCheckboxesSchema: convertFunction<'checkboxGroups'> = (
  schema,
  data,
  forceDisable = false
) => {
  // console.log("convertTextSchema", data);
  if (!data || !data?.field) {
    return schema;
  }
  const staticOption = data?.options?.map(el => ({
    label: el?.label,
    value: el?.value,
  }));
  let fieldJsonSchema: RJSFSchema = {
    type: ['string', 'array', 'object', 'number'],
    items: {
      type: ['string', 'object', 'number'],
      properties: {
        value: {
          type: 'number',
        },
        label: {
          type: 'string',
        },
      },
    },
    // enumNames is label, enum is value
    // enumOptions: [{label: enumName, value: enumOption}]
    enumNames: data?.options?.map(el => el?.label) ?? [],
    enum: staticOption,
    properties: {
      value: {
        type: 'number',
      },
      label: {
        type: 'string',
      },
    },
  };
  const fieldUiSchema: Record<string, unknown> = {
    'ui:size': 'small',
    'ui:widget': 'CustomCheckboxesWidget',
  };
  let fieldZodSchema: any = z
    .undefined({ required_error: '' })
    .or(z.number({ required_error: '' }))
    .or(z.string({ required_error: '' }))
    .or(z.object({}))
    .or(
      z.array(z.string().or(z.object({})), {
        required_error: '',
      })
    );
  // parse the json schema
  // if (data?.readonly) fieldJsonSchema["readOnly"] = true;
  fieldJsonSchema['title'] = data?.label || data?.originlabel;
  if (data?.description) fieldJsonSchema['description'] = data?.description;
  // if (data?.options && data?.options?.length > 0)
  //   fieldJsonSchema["anyOf"] = data.options?.map((el) => ({
  //     const: el?.value,
  //     title: `${el?.label}`,
  //   }));
  // parse the zodSchema
  if (!data?.required) fieldZodSchema = fieldZodSchema.optional().nullable();
  // parse the uiSchema
  if (data?.disabled || forceDisable) fieldUiSchema['ui:disabled'] = true;
  // if (data?.description) fieldUiSchema["ui:description"] = data.description;
  if (data?.placeholder) fieldUiSchema['ui:placeholder'] = data.placeholder;
  if (data?.size) fieldUiSchema['ui:size'] = data?.size;
  if (data?.multiple) fieldUiSchema['ui:multiple'] = true;
  if (data?.field_xs) fieldUiSchema['ui:field_xs'] = data?.field_xs;
  if (data?.field_xl) fieldUiSchema['ui:field_xl'] = data?.field_xl;
  if (data?.field_md) fieldUiSchema['ui:field_md'] = data?.field_md;
  if (data?.field_lg) fieldUiSchema['ui:field_lg'] = data?.field_lg;
  if (data?.labelKey) {
    fieldUiSchema['ui:labelKey'] =
      !data?.label || data?.label === data?.originlabel ? data?.labelKey : '';
  }
  if (data?.asyncConfig) fieldUiSchema['ui:asyncConfig'] = data?.asyncConfig;
  if (data?.icon) fieldUiSchema['ui:icon'] = data?.icon;
  if (data?.readonly) fieldUiSchema['ui:readonly'] = data?.readonly;

  const producer = produce<TJsonSchemaData>(draft => {
    draft.zodSchema = draft.zodSchema?.merge(
      z.object({ [data.field]: fieldZodSchema })
    );
    if (draft.jsonSchema.properties && fieldJsonSchema) {
      draft.jsonSchema.properties[data.field] = {
        ...(cloneDeep(draft.jsonSchema.properties[data.field] as RJSFSchema) ??
          {}),
        ...fieldJsonSchema,
      };
    }
    if (fieldUiSchema) {
      draft.uiSchema = {
        ...draft.uiSchema,
        [data.field]: fieldUiSchema,
      };
    }
    if (data?.required) {
      draft.jsonSchema.required?.push(data.field);
    }
  });
  const nextSchema = producer(schema);
  // console.log("nextSchema", nextSchema);
  return nextSchema;
};

export const convertCheckboxSchema: convertFunction<'checkbox'> = (
  schema,
  data,
  forceDisable = false
) => {
  if (!data || !data?.field) {
    return schema;
  }
  let fieldJsonSchema: RJSFSchema = { type: 'boolean' };
  const fieldUiSchema: Record<string, unknown> = {
    'ui:size': 'small',
    'ui:widget': 'CustomCheckboxWidget',
  };
  let fieldZodSchema: any = z.boolean({
    required_error: '',
  });
  // parse the json schema
  // if (data?.readonly) fieldJsonSchema["readOnly"] = true;
  fieldJsonSchema['title'] = data?.label || data?.originlabel;
  if (data?.description) fieldJsonSchema['description'] = data?.description;
  if (!data?.required) fieldZodSchema = fieldZodSchema.optional().nullable();
  // parse the uiSchema
  if (data?.disabled || forceDisable) fieldUiSchema['ui:disabled'] = true;
  if (data?.placeholder) fieldUiSchema['ui:placeholder'] = data.placeholder;
  if (data?.size) fieldUiSchema['ui:size'] = data?.size;
  if (data?.field_xs) fieldUiSchema['ui:field_xs'] = data?.field_xs;
  if (data?.field_xl) fieldUiSchema['ui:field_xl'] = data?.field_xl;
  if (data?.field_md) fieldUiSchema['ui:field_md'] = data?.field_md;
  if (data?.field_lg) fieldUiSchema['ui:field_lg'] = data?.field_lg;
  if (data?.icon) fieldUiSchema['ui:icon'] = data?.icon;
  if (data?.labelKey) {
    fieldUiSchema['ui:labelKey'] =
      !data?.label || data?.label === data?.originlabel ? data?.labelKey : '';
  }
  if (data?.readonly) fieldUiSchema['ui:readonly'] = data?.readonly;

  const producer = produce<TJsonSchemaData>(draft => {
    draft.zodSchema = draft.zodSchema?.merge(
      z.object({ [data.field]: fieldZodSchema })
    );
    if (draft.jsonSchema.properties && fieldJsonSchema) {
      draft.jsonSchema.properties[data.field] = {
        ...(cloneDeep(draft.jsonSchema.properties[data.field] as RJSFSchema) ??
          {}),
        ...fieldJsonSchema,
      };
    }
    if (fieldUiSchema) {
      draft.uiSchema = {
        ...draft.uiSchema,
        [data.field]: fieldUiSchema,
      };
    }
    if (data?.required) {
      draft.jsonSchema.required?.push(data.field);
    }
  });
  const nextSchema = producer(schema);
  // console.log("nextSchema", nextSchema);
  return nextSchema;
};

export const ConvertJsonSchemaFunc = (
  data: PrettifiedTFormInput[],
  disabledFields?: string[],
  viewType?: boolean
) => {
  let convertSchema: TJsonSchemaData = {
    jsonSchema: {
      title: '',
      type: 'object',
      required: [],
      properties: {},
    },
    uiSchema: {
      'ui:options': {
        'ui:field_xs': 12,
        'ui:field_md': 6,
        'ui:field_lg': 4,
        'ui:field_xl': 4,
        'ui:size': 'small',
      },
    },
    zodSchema: z.object({}),
  };
  // sort and hide form items.
  const handledData = data
    ?.filter(el => !el?.hide)
    ?.sort((prev, next) => {
      if (prev?.order && next?.order) {
        return prev?.order - next?.order;
      }
      return 0;
    });
  if (viewType) {
    for (const item of handledData) {
      convertSchema = convertViewSchema(
        convertSchema,
        item as any,
        disabledFields?.includes(item?.field) ?? false
      ) as TJsonSchemaData;
    }
    return convertSchema;
  }

  // type: text/select/date/number
  for (const item of handledData) {
    // convertCommonInfo(convertSchema, item);
    switch (item.type) {
      case 'text':
        convertSchema = convertTextSchema(
          convertSchema,
          item,
          disabledFields?.includes(item?.field) ?? false
        ) as TJsonSchemaData;
        break;
      case 'number':
        convertSchema = convertNumberSchema(
          convertSchema,
          item,
          disabledFields?.includes(item?.field) ?? false
        ) as TJsonSchemaData;
        break;
      case 'select':
      case 'multi-select':
        convertSchema = convertSelectSchema(
          convertSchema,
          item,
          disabledFields?.includes(item?.field) ?? false
        ) as TJsonSchemaData;
        break;
      // case "multi-select":
      //   convertSchema = convertSelectSchema(
      //     convertSchema,
      //     item,
      //     disabledFields?.includes(item?.field) ?? false
      //   ) as TJsonSchemaData;
      //   break;
      case 'chips':
        convertSchema = convertChipsSchema(
          convertSchema,
          item,
          disabledFields?.includes(item?.field) ?? false
        ) as TJsonSchemaData;
        break;
      case 'date':
        convertSchema = convertDateSchema(
          convertSchema,
          item,
          disabledFields?.includes(item?.field) ?? false
        ) as TJsonSchemaData;
        break;
      case 'radio':
        convertSchema = convertRadioSchema(
          convertSchema,
          item,
          disabledFields?.includes(item?.field) ?? false
        ) as TJsonSchemaData;
        break;
      case 'checkboxGroups':
        convertSchema = convertCheckboxesSchema(
          convertSchema,
          item,
          disabledFields?.includes(item?.field) ?? false
        ) as TJsonSchemaData;
        break;
      case 'checkbox':
        convertSchema = convertCheckboxSchema(
          convertSchema,
          item,
          disabledFields?.includes(item?.field) ?? false
        ) as TJsonSchemaData;
        break;
      default:
        console.log('form item definition type error');
    }
  }

  // console.log("convertSchema", convertSchema);

  return convertSchema;
};

// mock the product module dropdown list data front end. actually from the api.
export const mockDropdownListData: Record<
  string,
  Array<Omit<OptionItem, 'label'> & { label: string }>
> = {
  // productCategory: [
  //   { label: "Pharmaceuticals", value: "Pharmaceuticals" },
  //   { label: "Vaccine", value: "Vaccine" },
  //   { label: "Biologicals", value: "Biologicals" },
  // ],
  // productSubcategory: [
  //   { label: "Simple", value: "Simple" },
  //   { label: "Reconstituted Simple", value: "Reconstituted Simple" },
  //   { label: "Reconstituted Combination", value: "Reconstituted Combination" },
  //   { label: "Combination Pack", value: "Combination Pack" },
  // ],
  // productType: [
  //   { label: "Marketable", value: "Marketable" },
  //   { label: "Investigational", value: "Investigational" },
  // ],
  // dosageForm: [
  //   { label: "Solution for Injection", value: "Solution for Injection" },
  //   { label: "Oral Suspension", value: "Oral Suspension" },
  // ],
  // businessunit: [
  //   { label: "BU-ROW", value: "BU-ROW" },
  //   { label: "BU-MEA", value: "BU-MEA" },
  //   { label: "BU-NA", value: "BU-NA" },
  // ],
};
