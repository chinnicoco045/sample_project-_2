import axios from "axios";
import { useFreyrLibraryContext } from '../../../context/FreyrLibraryContext';

export const getFetchOptionListFunc = (
  completeUrl: string,
  method = "GET",
  params?: {
    params?: unknown;
    data?: unknown;
    responseConfig?: {
      labelPath: string;
      valuePath: string;
    };
  }
) => {
  const { language, token } = useFreyrLibraryContext();
  return () => {
    const languageformat = language === 'en' ? '' : language;
    let tokenformat = token;
    if (completeUrl) {
      return axios({
        method,
        url: completeUrl,
        params: params?.["params"],
        data: params?.["data"],
        headers: {
          Authorization: tokenformat ? `Bearer ${tokenformat}` : "",
          "Accept-Language": languageformat || ""
        },
      });
    }

  };
};
