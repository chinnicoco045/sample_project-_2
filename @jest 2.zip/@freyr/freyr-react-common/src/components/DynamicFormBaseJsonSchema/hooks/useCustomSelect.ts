import { useMemo, useEffect, useRef } from 'react';
import get from 'lodash/get';
import { useQuery } from '@tanstack/react-query';
import { getFetchOptionListFunc } from './CustomSelectService';
import { forceFormatValue } from '../utils/paramFormat';
import { useFreyrLibraryContext } from '../../../context/FreyrLibraryContext';

const filterEqualListItem = (value: unknown, condition: unknown) =>
  value === condition;
const filterNotEqualListItem = (value: unknown, condition: unknown) =>
  value !== condition;
// const filterIncludeListItem = (value: )

const filterListDataByType = (
  type: 'equal' | 'notEqual' | 'include' | 'exclude',
  value: unknown,
  condition: unknown
) => {
  switch (type) {
    case 'equal':
      return filterEqualListItem(value, condition);
    case 'notEqual':
      return filterNotEqualListItem(value, condition);
    case 'include':
    case 'exclude':
      return true;
  }
};

export const useCustomSelect = (
  asyncConfig: TSelectInput['asyncConfig'],
  uniqueKey: string | string[],
  store: {
    formState: Record<string, unknown>;
    EditItem?: Record<string, unknown>;
    extraState?: Record<string, unknown>;
  },
  enabled = true,
  funcs?: {
    onOptionsChangeAfterDependency?: (data: OptionItem[]) => void;
  }
) => {
  const { tenant, domain } = useFreyrLibraryContext();
  const dependencyVarsChangeRef = useRef(false);
  const initialRequest = useRef(true);

  const asyncConfigParams = useMemo(() => {
    let params: Record<string, unknown> = {};
    asyncConfig?.params?.forEach(el => {
      let val;
      if (el?.value) {
        val = el?.value;
      } else if (el?.valuePath === 'all') {
        val = store?.formState;
      } else {
        val = get(store[el.store as StoreKey], el?.valuePath, null);
      }
      params[el?.fieldName as string] = val;
    });
    return params;
  }, [asyncConfig?.params, store]);

  const asyncConfigBodyData = useMemo(() => {
    let data: Record<string, unknown> = {};
    const identifier =
      (asyncConfig?.body?.find(el => el?.fieldName === 'identifier')
        ?.value as string) ?? '';
    asyncConfig?.body?.forEach(el => {
      let val;
      if (el?.value) {
        val = el?.value;
      } else if (el?.valuePath === 'all') {
        val = store?.formState;
      } else {
        val = get(store[el.store as StoreKey], el?.valuePath, null);
      }
      const formatVal = forceFormatValue(el?.format, val);
      if (
        identifier &&
        formatVal &&
        typeof formatVal === 'object' &&
        identifier in formatVal
      ) {
        delete (formatVal as Record<string, unknown>)[identifier];
        data[el?.fieldName as string] = formatVal;
        return;
      }
      data[el?.fieldName as string] = formatVal;
      // data[el?.fieldName as string] =
      //   el?.value ?? get(store[el.store as StoreKey], el?.valuePath, null);
    });
    return data;
  }, [asyncConfig?.body, store]);

  const dependencyVars = useMemo(() => {
    let dependencyVars: Record<string, unknown> = {};
    asyncConfig?.dependencies?.forEach(el => {
      dependencyVars[el] = asyncConfigParams?.[el];
    });
    return dependencyVars;
  }, [asyncConfig?.dependencies, asyncConfigParams]);

  const dependencyBodyVars = useMemo(() => {
    let dependencyVars: Record<string, unknown> = {};
    asyncConfig?.dependencies?.forEach(el => {
      if (el?.includes('.')) {
        // value path
        dependencyVars[el] = get(asyncConfigBodyData, el, null);
        return;
      }
      dependencyVars[el] = asyncConfigBodyData?.[el];
      // dependencyVars[el] = asyncConfigBodyData?.[el];
    });
    return dependencyVars;
  }, [asyncConfig?.dependencies, asyncConfigBodyData]);

  // console.log("dependencyVars", dependencyVars);

  const fetchOptionList = getFetchOptionListFunc(
    `${process.env[asyncConfig?.prefixEnvName ?? asyncConfig?.basicUrl ?? ''] ??
      process.env.REACT_APP_API_GETWAY}${asyncConfig?.url ?? ''}`,
    `${asyncConfig?.requestMethod ?? 'GET'}`,
    {
      params: asyncConfigParams,
      // params: dependencyVars,
      data: {
        ...asyncConfigBodyData,
        tenantId: tenant,
        domainName: domain,
      },
    }
  );

  // console.log("dependencyVars", dependencyVars, dependencyBodyVars);
  const keysToUse = Array.isArray(uniqueKey) ? uniqueKey : [uniqueKey];

  const { data: resOptionList, isLoading, remove } = useQuery(
    [...keysToUse, dependencyVars, dependencyBodyVars],
    () => fetchOptionList(),
    {
      enabled: enabled,
      staleTime: Infinity,
      refetchOnWindowFocus: false,
      retry: false,
      select(data) {
        // console.log("select data: ", data);
        const allDependencyAreEmpty =
          Object.keys(dependencyVars)?.length &&
          Object.values(dependencyVars).every(value => !value);
        const resData = allDependencyAreEmpty ? [] : data?.data;
        if (
          Number(resData?.code) !== 200 ||
          !resData?.data ||
          resData?.data?.length === 0
        ) {
          return [];
        }
        if (!asyncConfig?.valuePath) {
          return [];
        }
        if (asyncConfig?.listDataPath) {
          let listData = get(resData?.data, asyncConfig?.listDataPath, []);
          if (typeof listData === 'string') {
            listData = JSON.parse(listData);
          }
          console.log('listData---: ', listData);
          return listData
            ?.filter(el => {
              if (
                !asyncConfig?.listFilters ||
                asyncConfig?.listFilters?.length === 0
              )
                return true;
              return asyncConfig?.listFilters?.every(
                ([path, val, type]) =>
                  filterListDataByType(type, get(el, path), val) // get(el, path) === val
              );
            })
            ?.map((el: any) => {
              return {
                label: get(el, asyncConfig?.labelPath),
                value: get(el, asyncConfig?.valuePath),
              };
            });
        }
        return resData?.data
          ?.filter(el => {
            if (
              !asyncConfig?.listFilters ||
              asyncConfig?.listFilters?.length === 0
            )
              return true;
            return asyncConfig?.listFilters?.every(
              ([path, val, type]) =>
                filterListDataByType(type, get(el, path), val) // get(el, path) === val
            );
          })
          ?.map((el: any) => {
            return {
              label: get(el, asyncConfig?.labelPath),
              value: get(el, asyncConfig?.valuePath),
            };
          });
      },
      onSuccess(data) {
        if (!data) return;
        initialRequest.current = false;
      },
    }
  );

  useEffect(() => {
    if (!initialRequest.current) {
      dependencyVarsChangeRef.current = true;
    }
  }, [dependencyVars]); // dependencyBodyVars

  useEffect(() => {
    if (resOptionList === undefined || resOptionList === null) return;
    if (dependencyVarsChangeRef.current) {
      dependencyVarsChangeRef.current = false;
      funcs?.onOptionsChangeAfterDependency?.(resOptionList ?? []);
    }
  }, [resOptionList]);

  useEffect(() => {
    return () => {
      if (!asyncConfig?.keepQueryCache) remove?.();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return {
    asyncConfigParams,
    dependencyVars,
    resOptionList: resOptionList as Array<{
      label: string;
      value: string | number;
      disabled?: boolean;
    }>,
    fetchLoading: isLoading && enabled,
  };
};

export const transformStateByDefinitions = (
  formState?: Record<string, unknown>,
  definition?: PrettifiedTFormInput[]
) => {
  const newArr = Object.entries(formState ?? {})?.map(([key, val]) => {
    const type = definition?.find(el => el?.field === key)?.type ?? '';
    if (!['select', 'multi-select']?.includes(type)) {
      return [key, val];
    }
    const newVal = Array.isArray(val) ? val : [val];
    return [key, newVal];
  });
  const newState = Object.fromEntries(newArr);
  console.log('newState: ', newState);
  return newState;
};
