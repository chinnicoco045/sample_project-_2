export const formatArrayValue = (
  data?: string | number | Array<string | number> | unknown
) => {
  if (Array.isArray(data)) return data;
  return data ? [data] : [];
};

export const formatArrayStringValue = (
  data?: string | number | Array<string | number> | unknown
) => {
  if (Array.isArray(data)) return data?.map(el => `${el}`);
  return data ? [`${data}`] : [];
};

export const formatObjectValue = (
  data: Record<string, unknown>,
  format: ParamFromState['format']
) => {
  const fieldsVals: Array<[string, unknown]> =
    Object.entries(data ?? {})?.map(([key, val]) => {
      if (Array.isArray(val)) {
        const newVal =
          format === 'array'
            ? formatArrayValue(val)
            : formatArrayStringValue(val);
        return [key, newVal];
      }
      if (typeof val === 'object' && val)
        return [key, formatObjectValue(val as Record<string, unknown>, format)];
      if (typeof val === 'boolean') return [key, val];
      if (format === 'array') return [key, formatArrayValue(val)];
      if (format === 'arrayOfString') return [key, formatArrayStringValue(val)];
      return [key, val];
    }) ?? [];
  // ?.forEach(([key, val]) => {
  //   finalFieldVals[key as string] = val;
  // });
  // console.log("fieldsVals: ", fieldsVals);
  // console.log("data: ", data);
  return Object.fromEntries(fieldsVals);
};

export const forceFormatValue = (
  format: ParamFromState['format'],
  data?: string | number | Array<string | number> | Object | unknown
) => {
  if (!format) return data;
  if (Array.isArray(data)) {
    return format === 'array'
      ? formatArrayValue(data)
      : formatArrayStringValue(data);
  }
  if (typeof data === 'object' && data) {
    return formatObjectValue(data as Record<string, unknown>, format);
  }
  if (format === 'array') return formatArrayValue(data);
  if (format === 'arrayOfString') return formatArrayStringValue(data);
  return data;
};
