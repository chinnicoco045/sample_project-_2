import React, { ChangeEvent, useEffect, useMemo, useState } from 'react';
import Checkbox from '@mui/material/Checkbox';
import FormControlLabel from '@mui/material/FormControlLabel';
import FormGroup from '@mui/material/FormGroup';
import {
  ariaDescribedByIds,
  labelValue,
  optionId,
  FormContextType,
  WidgetProps,
  RJSFSchema,
  StrictRJSFSchema,
} from '@rjsf/utils';
import { isNil } from 'lodash';
import { useCustomSelect } from '../hooks/useCustomSelect';
import { FormControl } from '@mui/material';
import CustomizedFormLabel from './CustomizedFormLabel';

/** The `CheckboxesWidget` is a widget for rendering checkbox groups.
 *  It is typically used to represent an array of enums.
 *
 * @param props - The `WidgetProps` for this component
 */
export default function CheckboxesWidget<
  T = any,
  S extends StrictRJSFSchema = RJSFSchema,
  F extends FormContextType = any
>({
  schema,
  label,
  hideLabel,
  id,
  name,
  disabled,
  options,
  value,
  autofocus,
  readonly,
  required,
  onChange,
  onBlur,
  onFocus,
  formContext,
  uiSchema,
  ...otherProps
}: WidgetProps<T, S, F>) {
  const uniqueKey = `${name}-unique-select`;
  const formState = formContext?.['formState'] as Record<string, unknown>;
  const extraState = formContext?.['extraState'] as Record<string, unknown>;
  const dynamicFormContextQueryKey =
    (formContext?.['dynamicFormContextQueryKey'] as string) ?? '';
  const asyncConfig = uiSchema?.[
    'ui:asyncConfig'
  ] as TSelectInput['asyncConfig'];
  const { enumOptions, inline = true } = options;
  const multiple = uiSchema?.["ui:multiple"] ?? false;
  
  const [checkboxesValue, setCheckboxesValue] = useState<OptionItem[]>([]);

  const enumOptionsFromDefinition = useMemo(() => {
    return (
      enumOptions?.map(el => ({
        label: el?.label,
        value: el?.value?.value,
      })) ?? []
    );
  }, [enumOptions]);

  const { resOptionList } = useCustomSelect(
    asyncConfig,
    dynamicFormContextQueryKey
      ? [dynamicFormContextQueryKey, uniqueKey]
      : uniqueKey,
    { formState, extraState },
    !!asyncConfig?.url
  );

  const optionList = useMemo(() => {
    return resOptionList?.length > 0
      ? resOptionList
      : enumOptionsFromDefinition || [];
  }, [enumOptionsFromDefinition, name, resOptionList]);

  const enumOptionsSelectValue = (
    valueIndex: string | number,
    selected: OptionItem[],
    allOptions: OptionItem[]
  ) => {
    const option = allOptions.find((_, index) => valueIndex === index);
    if (!isNil(option)) {
      return [...selected, option].map(item => item.value);
    }
  };

  const enumOptionsDeselectValue = (
    valueIndex: string | number,
    selected: OptionItem[],
    allOptions: OptionItem[]
  ) => {
    const option = allOptions.find((_, index) => valueIndex === index);
    if (!isNil(option)) {
      return selected
        .filter(item => item.value !== option.value)
        .map(item => item.value);
    }
  };

  const handleValueChange = (index: number) => ({
    target: { checked },
  }: ChangeEvent<HTMLInputElement>) => {
    if (checked) {
      const newValue = enumOptionsSelectValue(
        index,
        checkboxesValue,
        optionList
      );
      onChange(newValue);
    } else {
      const newValue = enumOptionsDeselectValue(
        index,
        checkboxesValue,
        optionList
      );
      onChange(newValue?.length ? newValue : undefined);
      if (!newValue || newValue?.length === 0) {
        setCheckboxesValue([]);
      }
    }
  };

  const handleMultiInitValue = (
    optionList: (Omit<OptionItem, 'label'> & {
      label: string;
    })[]
  ) => {
    if (!value) return [];
    // show old format value.
    if (
      !Array?.isArray(value) &&
      (typeof value === 'string' || typeof value === 'number')
    ) {
      return optionList?.filter(
        el => `${el?.value}`?.toLowerCase() === `${value}`?.toLowerCase()
      );
    }
    if (!Array?.isArray(value) || value?.length === 0) {
      return [];
    }
    return value
      ?.map(item => {
        const res = optionList?.find(el => {
          if (typeof item !== 'object') {
            return (
              item && `${el?.value}`?.toLowerCase() === `${item}`?.toLowerCase()
            );
          }
          const some =
            value &&
            `${el?.value}`?.toLowerCase() === `${item?.value}`?.toLowerCase();
          return some;
        });
        return res;
      })
      ?.filter(el => !!el) as (Omit<OptionItem, 'label'> & {
      label: string;
    })[];
  };

  useEffect(() => {
    if (
      !optionList ||
      // optionList?.length === 0 ||
      !value ||
      (Array.isArray(value) && value?.length === 0)
    ) {
      return;
    }
    const newValue = handleMultiInitValue(optionList);
    setCheckboxesValue(newValue ?? []);
  }, [optionList, value]);
  return (
    <FormControl>
      <CustomizedFormLabel
        label={
          (labelValue(label || undefined, hideLabel, false) as string) ?? ''
        }
        labelKey={uiSchema?.['ui:labelKey']}
        required={required}
        description={uiSchema?.['ui:description'] ?? schema['description']}
        icon={uiSchema?.['ui:icon']}
        readonly={uiSchema?.['ui:readonly'] ?? schema?.['readOnly']}
        disabled={uiSchema?.['ui:disabled']}
      ></CustomizedFormLabel>
      <FormGroup id={id} row={!!inline}>
        {Array.isArray(optionList) &&
          optionList.map((option, index: number) => {
            const checked = checkboxesValue.some(
              item => item.value === option.value
            );
            const checkbox = (
              <Checkbox
                id={optionId(id, index)}
                name={id}
                checked={checked}
                disabled={disabled || readonly}
                autoFocus={autofocus && index === 0}
                onChange={handleValueChange(index)}
                aria-describedby={ariaDescribedByIds<T>(id)}
              />
            );
            return (
              <FormControlLabel
                control={checkbox}
                key={index}
                label={option.label}
              />
            );
          })}
      </FormGroup>
    </FormControl>
  );
}
