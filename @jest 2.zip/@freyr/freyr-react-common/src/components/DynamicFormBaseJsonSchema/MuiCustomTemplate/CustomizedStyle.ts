import { GridTypeMap } from "@mui/system";

const GridContainerProps: Omit<GridTypeMap["props"], "container"> & {
  className: string;
} = {
  className: "grid-root-container-for-json-schema-form",
  // spacing: 2, // spacing property on Grid component from mui.
  // columnGap: 1,
  sx: {
    // change all the label text color in json-schema-form to red.
    "& .MuiFormLabel-root": {
      // color: "red !important",
    },
    "& .MuiInputAdornment-positionEnd": {
      height: "auto !important",
    },
    // "& .MuiAutocomplete-root input": {
    //   minWidth: "130px !important",
    // },
  },
};

export default GridContainerProps;
