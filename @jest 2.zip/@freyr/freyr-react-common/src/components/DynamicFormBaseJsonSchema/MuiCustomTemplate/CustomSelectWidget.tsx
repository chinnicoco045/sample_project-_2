/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
// import { ChangeEvent, FocusEvent } from "react";
import ClearIcon from "@mui/icons-material/Clear";
import {
  // FormLabel,
  // MenuItem,
  Autocomplete,
  AutocompleteChangeDetails,
  AutocompleteChangeReason,
  Chip,
  // TextFieldProps,
  FormControl,
  InputAdornment,
  TextField,
  Tooltip,
} from "@mui/material";
import CircularProgress from "@mui/material/CircularProgress";
import {
  FormContextType,
  RJSFSchema,
  StrictRJSFSchema,
  WidgetProps,
  labelValue
} from "@rjsf/utils";
import React, { useEffect, useMemo, useState } from "react";
import { useCustomSelect } from "../hooks/useCustomSelect";
import CustomizedFormLabel from "./CustomizedFormLabel";

/** The `SelectWidget` is a widget for rendering dropdowns.
 *  It is typically used with string properties constrained with enum options.
 *
 * @param props - The `WidgetProps` for this component
 */
export default function SelectWidget<
  T = any,
  S extends StrictRJSFSchema = RJSFSchema,
  F extends FormContextType = any
>(props: WidgetProps<T, S, F>) {
  const {
    schema,
    id,
    name, // remove this from textFieldProps
    options,
    label,
    hideLabel,
    required,
    disabled,
    placeholder,
    readonly,
    value,
    multiple: multipleProp,
    autofocus,
    onChange,
    onBlur,
    onFocus,
    rawErrors = [],
    registry,
    uiSchema,
    hideError,
    formContext,
    ...textFieldProps
  } = props;
  // console.log("custom select -------------: ", name, options);
  const uniqueKey = `${name}-unique-select`;
  const formState = formContext?.["formState"] as Record<string, unknown>;
  const extraState = formContext?.["extraState"] as Record<string, unknown>;
  const dynamicFormContextQueryKey =
    (formContext?.["dynamicFormContextQueryKey"] as string) ?? "";

  const asyncConfig = uiSchema?.[
    "ui:asyncConfig"
  ] as TSelectInput["asyncConfig"];

  const { enumOptions, enumDisabled, emptyValue: optEmptyVal } = options;

  const enumOptionsFromDefinition = useMemo(() => {
    return (
      enumOptions?.map((el) => ({
        label: el?.label,
        value: el?.value?.value,
      })) ?? []
    );
  }, [enumOptions]);

  const multiple = uiSchema?.["ui:multiple"] ?? false;
  const multipleChip = uiSchema?.["ui:multipleChip"] ?? false;
  const [autocompleteValue, setAutocompleteValue] = useState<
    OptionItem | OptionItem[] | null
  >(multiple ? [] : null);

  const handleSingleInitValue = (
    optionList: (Omit<OptionItem, "label"> & {
      label: string;
    })[]
  ) => {
    const newValue = optionList?.find((el) => {
      if (Array.isArray(value)) {
        return value?.some((item) => `${item}` === `${el?.value}`);
      }
      if (typeof value !== "object") {
        return value && `${el?.value}` === `${value}`;
      }
      return value && `${el?.value}` === `${value?.value}`;
    });
    return newValue;
  };

  const handleMultiInitValue = (
    optionList: (Omit<OptionItem, "label"> & {
      label: string;
    })[]
  ) => {
    if (!value) return [];
    // show old format value.
    if (
      !Array?.isArray(value) &&
      (typeof value === "string" || typeof value === "number")
    ) {
      return optionList?.filter(
        (el) => `${el?.value}`?.toLowerCase() === `${value}`?.toLowerCase()
      );
    }
    if (!Array?.isArray(value) || value?.length === 0) {
      return [];
    }
    return value
      ?.map((item) => {
        const res = optionList?.find((el) => {
          if (typeof item !== "object") {
            return (
              item && `${el?.value}`?.toLowerCase() === `${item}`?.toLowerCase()
            );
          }
          const some =
            value &&
            `${el?.value}`?.toLowerCase() === `${item?.value}`?.toLowerCase();
          return some;
        });
        return res;
      })
      ?.filter((el) => !!el) as (Omit<OptionItem, "label"> & {
      label: string;
    })[];
  };

  const handleValueOnDependencyChange = (data: OptionItem[]) => {
    if (!multiple) {
      const handledNewValue = handleSingleInitValue(data);
      const newValue = handledNewValue?.value;
      onChange?.(newValue ? newValue : undefined);
      return;
    }
    const handledNewValue = handleMultiInitValue(data);
    const newValue = handledNewValue?.map((el) => el?.value);
    onChange?.(newValue?.length ? newValue : undefined);
  };

  const { resOptionList, fetchLoading } = useCustomSelect(
    asyncConfig,
    dynamicFormContextQueryKey
      ? [dynamicFormContextQueryKey, uniqueKey]
      : uniqueKey,
    { formState, extraState },
    !!asyncConfig?.url,
    {
      onOptionsChangeAfterDependency: handleValueOnDependencyChange,
    }
  );

  const optionList = useMemo(() => {
    return resOptionList?.length > 0
      ? resOptionList
      : enumOptionsFromDefinition || [];
  }, [enumOptionsFromDefinition, name, resOptionList]);

  // console.log(
  //   "custom select -------------optionList: ",
  //   name,
  //   autocompleteValue
  // );

  const handleValueChange = (
    event: React.SyntheticEvent<Element, Event>,
    value: any,
    reason: AutocompleteChangeReason,
    details?: AutocompleteChangeDetails<any> | undefined
  ) => {
    let newValue = value?.value ?? undefined;
    if (multiple) {
      newValue = value?.length
        ? value.map((item: OptionItem) => item.value)
        : undefined;
    }
    // console.log("newValue", newValue);
    onChange?.(newValue);
    if (!newValue || newValue?.length === 0) {
      setAutocompleteValue(multiple ? [] : null);
    }
  };

  useEffect(() => {
    if (
      !optionList ||
      // optionList?.length === 0 ||
      !value ||
      (Array.isArray(value) && value?.length === 0)
    ) {
      return;
    }
    // fetch the option list init. Remake the value.
    // refresh the option list by dependencyVars. clean the value.
    if (!multiple) {
      const newValue = handleSingleInitValue(optionList);
      // console.log("newValue: ", newValue);
      setAutocompleteValue(newValue ?? null);
      // onChange?.(newValue ? newValue : undefined);
      return;
    }
    const newValue = handleMultiInitValue(optionList);
    setAutocompleteValue(newValue ?? []);
    // onChange?.(newValue?.length ? newValue : undefined);
  }, [optionList, value]);

  return (
    <FormControl>
      <CustomizedFormLabel
        label={
          (labelValue(label || undefined, hideLabel, false) as string) ?? ""
        }
        labelKey={uiSchema?.["ui:labelKey"]}
        required={required}
        maxLen={uiSchema?.["ui:maxLen"] ?? undefined}
        existLen={value?.length ?? 0}
        description={uiSchema?.["ui:description"] ?? schema["description"]}
        icon={uiSchema?.["ui:icon"]}
        readonly={uiSchema?.["ui:readonly"] ?? schema?.["readOnly"]}
        disabled={uiSchema?.["ui:disabled"]}
      ></CustomizedFormLabel>
      <Autocomplete
        id={id}
        className="custom-autocomplete"
        renderTags={(selectedOptions: any) => {
          const tooltipLabel = (selectedOptions as OptionItem[])
            .map((el) => el.label)
            ?.join("，");
          if (!multipleChip) {
            return (
              <Tooltip title={tooltipLabel} placement="top">
                <Chip label={selectedOptions?.length + " selected"} />
              </Tooltip>
            );
          }
          if (Array.isArray(selectedOptions)) {
            return selectedOptions?.map((el) => {
              return (
                <Chip
                  key={el?.label}
                  label={el?.label ?? ("" as string)}
                  deleteIcon={<ClearIcon />}
                  disabled={disabled || fetchLoading || readonly}
                  onDelete={(ev) => {
                    if (disabled || fetchLoading || readonly) {
                      return;
                    }
                    // console.log("delete chip", el?.label);
                    const newVals =
                      selectedOptions?.filter(
                        (item) => item?.value !== el?.value
                      ) ?? [];
                    // console.log("newVals", newVals);
                    if (!newVals || newVals?.length === 0) {
                      handleValueChange(ev, null, "removeOption");
                      return;
                    }
                    handleValueChange(ev, newVals, "removeOption");
                  }}
                />
              );
            });
          }
          return <></>;
        }}
        disabled={disabled || fetchLoading}
        readOnly={readonly}
        multiple={multiple}
        loading={fetchLoading}
        disableCloseOnSelect={!!multiple}
        value={autocompleteValue}
        // value={multiple ? value ?? [] : value ?? null}
        options={optionList}
        getOptionLabel={(option) => option?.label || ""}
        isOptionEqualToValue={(option, value) => {
          if (typeof value === "object" && "value" in value && value?.value)
            return option?.value === value?.value;
          const res = option?.value === (value as unknown as string | number);
          return res;
        }}
        renderInput={(params) => {
          // console.log("renderInput params------: ", params);
          return (
            <TextField
              {...params}
              required={required}
              error={rawErrors.length > 0}
              placeholder={placeholder}
              InputProps={{
                ...params?.InputProps,
                endAdornment: (
                  <>
                    {fetchLoading ? (
                      <InputAdornment position="end">
                      <CircularProgress color="inherit" size={20} />
                        {/* {((Array.isArray(value) && value?.length > 0) || !!value) &&
                    !disabled &&
                    !fetchLoading ? (
                            <ClearIcon
                              sx={{
                                "&:hover": {
                                  color: "Highlight",
                                  cursor: "pointer",
                                },
                              }}
                        onClick={(ev) => {
                          if (fetchLoading) return;
                          handleValueChange(ev, null, "clear");
                        }}
                            />
                          ) : params?.InputProps.endAdornment} */}
                  </InputAdornment>
                    ) : (
                      params?.InputProps.endAdornment
                    )}
                  </>
                ),
              }}
              inputProps={{
                ...params.inputProps,
                onKeyDown: (e) => {
                  if (e.keyCode === 13) {
                    e.preventDefault();
                  }
                },
              }}
            />
          );
        }}
        onChange={handleValueChange}
        sx={{
          "& .MuiOutlinedInput-root": {
            padding: 0,
            // border: 1,
            // borderColor: "#ced4da",
          },
          "& .MuiTextField-root": {
            marginLeft: 0,
            marginTop: 0,
            marginBottom: 0,
          },
          "& .MuiOutlinedInput-root .MuiAutocomplete-input": { border: "none" },
          "& .MuiFormControl-root .MuiInputBase-root input:focus": {
            outline: "none !important",
          },
          "& .MuiAutocomplete-inputRoot": { paddingLeft: "10px" },
          // "& .MuiAutocomplete-endAdornment": { top: "calc(50% - 12px)" },
          "& .MuiChip-root": {
            marginBottom: "0px !important",
            marginTop: "5px !important",
          },
        }}
      />
    </FormControl>
  );
}
