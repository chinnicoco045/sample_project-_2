import React, { useMemo } from "react";
import { Box, FormLabel, Tooltip, Typography, styled } from "@mui/material";
import InfoOutlinedIcon from "@mui/icons-material/InfoOutlined";
import { useTranslation } from "react-i18next";

const CustomizedFormLabel: React.FC<{
  label?: string | React.ReactElement;
  labelKey?: string;
  required?: boolean;
  description?: string;
  maxLen?: number;
  existLen?: number;
  descIcon?: React.ReactNode;
  icon?: Icon[];
  readonly?: boolean;
  disabled?: boolean;
}> = ({
  label = "",
  labelKey,
  required = false,
  description = "",
  maxLen,
  existLen,
  descIcon,
  icon,
  readonly = false,
  disabled = false,
}) => {
  const metaIconClassName = {
    IDMPC: "idfr-txt idmp cond",
    xEVMPDC: "idfr-txt xvmpd cond",
    IDMPO: "idfr-txt idmp optional",
    xEVMPDO: "idfr-txt idmp man",
    IDMPM: "idfr-txt xvmpd optional",
    xEVMPDM: "idfr-txt xvmpd man",
  };
  const CustomPaper = styled("span")({
    ".idfr-txt": {
      position: "relative",
      marginRight: "-2px",
      width: "24px",
      float: "left",
      textAlign: "center",
    },
    ".idfr-txt.idmp:before": {
      content: '"I"',
      fontSize: "12px",
      fontWeight: 800,
      marginLeft: "5px",
    },
    ".idfr-txt.xvmpd:before": {
      content: '"X"',
      fontSize: "12px",
      fontWeight: 800,
      marginLeft: "5px",
    },
    ".idfr-txt.optional:after": {
      content: '"o"',
      position: "absolute",
      top: "-5px",
    },
    ".idfr-txt.cond:after": {
      content: '"c"',
      position: "absolute",
      top: "-5px",
    },
    ".idfr-txt.cond": {
      color: "blue",
    },
    ".idfr-txt.optional": {
      color: "green",
    },
    ".idfr-txt.man": {
      color: "red",
    },
    ".idfr-txt.man:after": {
      content: '"*"',
      position: "absolute",
      top: "-5px",
    },
  });
  const { t } = useTranslation();
  // console.log("label", label)
  // console.log("description", description)
  const labelMaxWith = useMemo(() => {
    let subtract = 0;
    if (required) subtract += 10;
    if (description) subtract += 10;
    return `calc(100% - ${subtract}px)`;
  }, [required, description]);

  return (
    <FormLabel
      disabled={readonly || disabled}
      sx={{
        textAlign: "left",
        my: 1,
        display: "flex",
        alignItems: "center",
        color: "initial",
        position: "relative",
      }}
      required={false}
    >
      <Box flex={1} overflow={"hidden"} display={"flex"}>
        {" "}
        <Tooltip title={label}>
          <span
            className="text-ellipsis"
            style={{ maxWidth: labelMaxWith }}
          >
            {label}
          </span>
        </Tooltip>
        {required ? <span style={{ color: "red" }}> * </span> : ""}
        {!descIcon && description && (
          <Tooltip title={description ?? ""}>
            <InfoOutlinedIcon
              // titleAccess={description ?? ""}
              sx={{
                color: "inherit",
                fontSize: "15px",
                mx: 0.5,
              }}
            ></InfoOutlinedIcon>
          </Tooltip>
        )}
        {descIcon && description && (
          <Tooltip title={description ?? ""}>
            <>{descIcon}</>
          </Tooltip>
        )}
      </Box>
      {icon?.length ? (
        <CustomPaper>
          {icon.map((item) => (
            <span key={item} className={metaIconClassName[item]}></span>
          ))}
        </CustomPaper>
      ) : null}
      {maxLen !== undefined && existLen !== undefined && (
        <Box
          sx={{
            mx: 0.5,
          }}
        >
          {existLen}/{maxLen}
        </Box>
      )}
    </FormLabel>
  );
};

export default CustomizedFormLabel;
