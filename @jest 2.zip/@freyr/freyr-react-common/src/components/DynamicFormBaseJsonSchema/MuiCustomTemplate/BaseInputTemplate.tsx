/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import React, { ChangeEvent, FocusEvent } from 'react';
import {
  TextField,
  TextFieldProps,
  InputLabel,
  FormControl,
  FormLabel,
} from "@mui/material";
import {
  ariaDescribedByIds,
  BaseInputTemplateProps,
  examplesId,
  getInputProps,
  labelValue,
  FormContextType,
  RJSFSchema,
  StrictRJSFSchema,
  getUiOptions,
} from "@rjsf/utils";
import CustomizedFormLabel from "./CustomizedFormLabel";

const TYPES_THAT_SHRINK_LABEL = ["date", "datetime-local", "file", "time"];

/** The `BaseInputTemplate` is the template to use to render the basic `<input>` component for the `core` theme.
 * It is used as the template for rendering many of the <input> based widgets that differ by `type` and callbacks only.
 * It can be customized/overridden for other themes or individual implementations as needed.
 *
 * @param props - The `WidgetProps` for this template
 */
export default function BaseInputTemplate<
  T = any,
  S extends StrictRJSFSchema = RJSFSchema,
  F extends FormContextType = any
>(props: BaseInputTemplateProps<T, S, F>) {
  const {
    id,
    name, // remove this from textFieldProps
    placeholder,
    required,
    readonly,
    disabled,
    type,
    label,
    hideLabel,
    value,
    onChange,
    onChangeOverride,
    onBlur,
    onFocus,
    autofocus,
    options,
    schema,
    uiSchema,
    rawErrors = [],
    formContext,
    registry,
    InputLabelProps,
    ...textFieldProps
  } = props;
  // console.log("name: ", name, "uiSchema: ", uiSchema, "schema: ", schema);
  const inputProps = getInputProps<T, S, F>(schema, type, options);
  const uiOptions = getUiOptions<T, S, F>(uiSchema);
  // Now we need to pull out the step, min, max into an inner `inputProps` for material-ui
  const { step, min, max, ...rest } = inputProps;
  const otherProps = {
    inputProps: {
      step,
      min,
      max,
      ...(schema.examples ? { list: examplesId<T>(id) } : undefined),
    },
    ...rest,
  };
  const _onChange = ({ target: { value } }: ChangeEvent<HTMLInputElement>) =>
    onChange(value === "" ? options.emptyValue : value);
  const _onBlur = ({ target: { value } }: FocusEvent<HTMLInputElement>) =>
    onBlur(id, value);
  const _onFocus = ({ target: { value } }: FocusEvent<HTMLInputElement>) =>
    onFocus(id, value);
  const DisplayInputLabelProps = TYPES_THAT_SHRINK_LABEL.includes(type)
    ? {
        ...InputLabelProps,
        shrink: true,
      }
    : InputLabelProps;

  // console.log("uiOptions: ", uiOptions)

  return (
    <FormControl>
      {/* <FormLabel sx={{ textAlign: "left", my: 1 }}>
        {labelValue(label || undefined, hideLabel, false)}
        {required ? <span style={{ color: "red" }}> * </span> : ""}
      </FormLabel> */}
      <CustomizedFormLabel
        label={
          (labelValue(label || undefined, hideLabel, false) as string) ?? ""
        }
        labelKey={uiSchema?.["ui:labelKey"]}
        required={required}
        maxLen={uiSchema?.["ui:maxLen"] ?? undefined}
        existLen={value?.length ?? 0}
        description={uiSchema?.["ui:description"] ?? schema?.["description"]}
        icon={uiSchema?.["ui:icon"]}
        readonly={uiSchema?.["ui:readonly"] ?? schema?.["readOnly"]}
        disabled={uiSchema?.["ui:disabled"]}
      ></CustomizedFormLabel>
      <TextField
        id={id}
        name={id}
        placeholder={placeholder}
        // label={labelValue(label || undefined, hideLabel, false)}
        autoFocus={autofocus}
        required={required}
        disabled={disabled || readonly}
        {...otherProps}
        value={value || value === 0 ? value : ""}
        error={rawErrors.length > 0}
        onChange={onChangeOverride || _onChange}
        onBlur={_onBlur}
        onFocus={_onFocus}
        size={uiSchema?.["ui:size"] || uiOptions?.["ui:size"] || "medium"}
        InputLabelProps={{
          ...DisplayInputLabelProps,
          shrink: false,
        }}
        inputProps={{
          maxLength: uiSchema?.["ui:maxLen"] ?? null,
          min: schema?.["minimum"] ?? null,
          max: schema?.["maximum"] ?? null,
        }}
        {...(textFieldProps as TextFieldProps)}
        aria-describedby={ariaDescribedByIds<T>(id, !!schema.examples)}
      />
      {Array.isArray(schema.examples) && (
        <datalist id={examplesId<T>(id)}>
          {(schema.examples as string[])
            .concat(
              schema.default && !schema.examples.includes(schema.default)
                ? ([schema.default] as string[])
                : []
            )
            .map((example: any) => {
              return <option key={example} value={example} />;
            })}
        </datalist>
      )}
    </FormControl>
  );
}
