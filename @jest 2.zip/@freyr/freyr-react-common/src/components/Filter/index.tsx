import { Box, Stack } from "@mui/material";
import { useEffect, useMemo, useRef, useState } from "react";
import FilterSelectItem, {
  FilterSelectDateItem,
  IdentifiersSelectItem,
} from "./components/FilterSelectItem";
// import ArrowDropUpOutlinedIcon from "@mui/icons-material/ArrowDropUpOutlined";
import { useTranslation } from "react-i18next";
import {
  FilterItem,
  useFilterItemsStore
} from "../../store/filter";
// import { useQueryClient } from "@tanstack/react-query";
import { useIdentifierList } from "./hooks/filter";
import React from "react";

export const Filter = (props: any) => {
  const { activeModule, disableIdentifierList = [], initFilterList, selectedIdentifiers } = props;
  const wrapperDom = useRef<HTMLElement>();

  const { t } = useTranslation();
  const initIdentifierList = initFilterList ? Object.keys(initFilterList) : [];
  const { identifiersDefineOptions } = useIdentifierList(activeModule);
  const [haveDateTime, setHaveDateTime] = useState(false);

  const [
    filterItems,
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    updateFilterItems,
    fieldsState,
    updateFieldsState,
    removeSpareField
  ] = useFilterItemsStore((state) => [
    state.filterItems,
    state.updateFilterItems,
    state.fieldsState,
    state.updateFieldsState,
    state.removeSpareField
  ]);

  selectedIdentifiers(fieldsState)

  useEffect(() => {
    if (initIdentifierList && initIdentifierList.length > 0 && identifiersDefineOptions && identifiersDefineOptions.length > 0) {
      const list = identifiersDefineOptions.filter(item => initIdentifierList.includes(item.value));
      //@ts-ignore
      updateFilterItems(list);
      updateFieldsState("All", handleInitFilterList(list));
    }
}, [identifiersDefineOptions])

const handleInitFilterList = (list: any) => {
  const initFilterList2 = {} as any;
  list.forEach((el: any) => {
    if (el.data.itemType === "date") {
      initFilterList2[el.value] = {
        type: "less",
        less: Number(initFilterList[el.value][0])
      };
      setHaveDateTime(true);
    } else {
      initFilterList2[el.value] = initFilterList[el.value].map((value: string) => ({ value }));
    }
  }); 
  return initFilterList2;
}

  const getIsDisabled = (item: any) => {
    return disableIdentifierList.includes(item.value) ? true : (activeModule?.name
      ? !item.data?.linkedModules?.[activeModule.name]?.status
      : false);
  };
  return (
    <Box sx={{ width: "100%" }}>
        <Stack direction="row" className="filters-row">
          <Box className="filterItemsWrapper" ref={wrapperDom}>
            <Box
              // direction="row"
              whiteSpace="nowrap"
              alignItems="center"
              px={1}
              display="inline-block"
            >
              {filterItems?.map((el, index) => {
                if (!el?.data?.itemType || el?.data?.itemType === "select") {
                  return (
                    <FilterSelectItem
                      key={el?.data?.field}
                      field={el?.data?.field}
                      label={el?.data?.label}
                      totalLabel={el?.data?.totalLabel}
                      fieldItemMode={el?.data?.fieldItemMode}
                      searchPlaceholder={el?.data?.searchPlaceholder}
                      value={fieldsState?.[el?.data?.field] as unknown[]}
                      asyncConfig={el?.data?.asyncConfig}
                      options={[]}
                      onValueChange={(data) => {
                        updateFieldsState(el?.data?.field, data);
                      }}
                      onRemove={() => {
                        removeSpareField({
                          removeFields: [el?.data?.field],
                        });
                      }}
                      disable={getIsDisabled(el)}
                    />
                  );
                }
                if (el?.data?.itemType === "date") {
                  return (
                    <FilterSelectDateItem
                      label={el?.label}
                      field={el?.data?.field}
                      value={
                        fieldsState?.[el?.data?.field] as Record<
                          string,
                          unknown
                        >
                      }
                      onValueChange={(data) => {
                        if (!haveDateTime) {
                          const timezoneOffsetInMinutes = new Date().getTimezoneOffset();
                          const timezoneOffsetInMilliseconds =
                            timezoneOffsetInMinutes * 60 * 1000;
                          const utc = Number(data?.less) - timezoneOffsetInMilliseconds
                          const newData = {
                            type: "less",
                            less: utc
                          }
                          updateFieldsState(el?.data?.field, newData);
                        } else {
                          updateFieldsState(el?.data?.field, data);
                        }
                      }}
                      onRemove={() => {
                        removeSpareField({
                          removeFields: [el?.data?.field],
                        });
                      }}
                      disable={getIsDisabled(el)}
                    />
                  );
                }
                return <></>;
              })}
              <IdentifiersSelectItem
                  field="filterItems"
                  value={filterItems}
                  options={identifiersDefineOptions.map((el) => {
                    return {
                      label: el.label,
                      value: el.value,
                      disabled: getIsDisabled(el),
                      data: el.data,
                    };
                  })}
                  onValueChange={(data) => {
                    removeSpareField({
                      keepFields:
                        data?.map((el) => (el as FilterItem)?.data?.field) ??
                        [],
                      newFilterItems: data as FilterItem[],
                    });
                  }}
                />
            </Box>
          </Box>
        </Stack>
    </Box>
  );
};
