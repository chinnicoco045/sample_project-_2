import React, { useState, useRef, useMemo, useEffect } from "react";
import {
  Box,
  Stack,
  Typography,
  // Popper,
  // Fade,
  Paper,
  Button,
  Popover,
  TextField,
  InputAdornment,
  Radio,
  RadioGroup,
  FormControlLabel,
  MenuItem,
  ListItemIcon,
  ListItemText,
  Checkbox,
  CircularProgress,
} from "@mui/material";
import ArrowDropUpIcon from "@mui/icons-material/ArrowDropUp";
import ArrowDropDownIcon from "@mui/icons-material/ArrowDropDown";
import SearchOutlinedIcon from "@mui/icons-material/SearchOutlined";
import CheckIcon from "@mui/icons-material/Check";
import AddIcon from "@mui/icons-material/Add";
// import { ClickAwayListener } from "@mui/base";
import CategoryOutlinedIcon from "@mui/icons-material/CategoryOutlined";
import StoreOutlinedIcon from "@mui/icons-material/StoreOutlined";
import PublicOutlinedIcon from "@mui/icons-material/PublicOutlined";
import AttractionsOutlinedIcon from "@mui/icons-material/AttractionsOutlined";
import ClearRoundedIcon from "@mui/icons-material/ClearRounded";
import { DatePickerValue } from "./CustomDatePicker";
import dayjs from "dayjs";
import { useTranslation } from "react-i18next";
import { create } from "zustand";
import { immer } from "zustand/middleware/immer";
import { useCustomSelect } from "../hooks/useCustomSelect";
import { useGlobalFilterState } from "../../../store/filter";
import cloneDeep from "lodash/cloneDeep";
import isEqual from "lodash/isEqual";

const SelectItemComp: React.FC<{
  selected?: boolean;
  label?: string;
  value?: string | number;
  disabled?: boolean;
  onChange?: (data: { label?: string; value?: string | number }) => void;
  mode?: "plain" | "checkbox";
}> = ({
  selected = false,
  label,
  value,
  onChange,
  disabled = false,
  mode = "plain",
}) => {
    if (mode === "checkbox") {
      return (
        <MenuItem
          disabled={disabled}
          selected={selected}
          sx={{ maxWidth: "330px" }}
          onClick={() => {
            if (disabled) {
              return;
            }
            onChange?.({ label, value });
          }}
        >
          <ListItemIcon>
            <Checkbox checked={selected}></Checkbox>
          </ListItemIcon>
          <ListItemText
            title={label ?? ""}
            sx={{
              maxWidth: "80%",
              "& .MuiListItemText-primary": {
                overflow: "hidden",
                textOverflow: "ellipsis",
                whiteSpace: "nowrap",
              },
            }}
          >
            {label ?? ""}
          </ListItemText>
        </MenuItem>
      );
    }
    return (
      <Stack
        direction="row"
        justifyContent="space-between"
        alignItems="center"
        sx={{
          minHeight: "40px",
          borderRadius: "8px",
          boxSizing: "border-box",
          padding: "0 20px",
          maxWidth: "330px",
          backgroundColor: disabled
            ? "#f7f7f8"
            : selected
              ? "#eff2ff"
              : "#f7f7f8",
          "& .hover-selectable-icon": {
            display: "none",
          },
          "&:hover": {
            cursor: disabled ? "not-allowed" : "pointer",
            backgroundColor: disabled ? "#f7f7f8" : "#eff2ff",
          },
          "&:hover .hover-selectable-icon": {
            display: "initial",
          },
        }}
        onClick={() => {
          if (disabled) {
            return;
          }
          onChange?.({ label, value });
        }}
      >
        <Typography
          sx={{
            maxWidth: "85%",
            overflow: "hidden",
            textOverflow: "ellipsis",
            whiteSpace: "nowrap",
          }}
          title={label ?? ""}
        >
          {label ?? ""}
        </Typography>
        {selected && (
          <CheckIcon
            sx={{
              fontSize: "18px",
              color: "#567cde",
              scale: "1.5",
              // minWidth: "50px",
            }}
          />
        )}
        {!selected && (
          <CheckIcon
            className="hover-selectable-icon"
            sx={{
              fontSize: "18px",
              color: "#acc0f2",
              scale: "1.5",
              // minWidth: "50px",
            }}
          />
        )}
      </Stack>
    );
  };

interface FilterSelectShowCompProps {
  field: string;
  open?: boolean;
  setOpen?: (val: boolean) => void;
  label?: string;
  showItemLabel?: string;
  selectedLen?: number;
  identifierMode?: boolean;
  clearIcon?: boolean;
  onClearClick?: VoidFunction;
  activeMode?: boolean;
  disable?: boolean;
}

const FilterSelectShowComp: React.FC<FilterSelectShowCompProps> = ({
  field,
  open = false,
  setOpen,
  label,
  showItemLabel,
  selectedLen,
  identifierMode = false,
  clearIcon = false,
  onClearClick,
  activeMode = false,
  disable = false,
}) => {
  const { t } = useTranslation();

  return (
    <Stack
      direction="row"
      gap={1}
      alignItems="center"
      onClick={() => !disable && setOpen?.(!open)}
      sx={{
        "&:hover": {
          cursor: disable ? "not-allowed" : "pointer",
        },
        // backgroundColor: selectedLen && selectedLen > 0 ? "#567cde" : "white",
      }}
    >
      {clearIcon && (
        <ClearRoundedIcon
          // sx={{
          //   fontSize: "14px",
          //   marginTop: "-2px",
          // }}
          onClick={() => !disable && onClearClick?.()}
        ></ClearRoundedIcon>
      )}
      <Typography whiteSpace="nowrap" sx={{ fontWeight: !identifierMode ? '700 !important' : '500' }}>
        {label ?? ""}
        {!identifierMode && !!showItemLabel && ": "}
      </Typography>
      {!identifierMode && (
        <>
          {showItemLabel && (
            <Typography
              fontWeight="bold"
              whiteSpace="nowrap"
              className="weight-600"
            >
              {showItemLabel ?? ""}
            </Typography>
          )}
          {selectedLen !== undefined && selectedLen > 0 && (
            <Typography className="filter-selected-count">
              {selectedLen && selectedLen > 0 ? `+${selectedLen}` : ""}
            </Typography>
          )}
          {open && <ArrowDropUpIcon />}
          {!open && <ArrowDropDownIcon />}
        </>
      )}
      {identifierMode && (
        <AddIcon
          sx={
            {
              // fontSize: "14px",
              // marginTop: "-2px",
            }
          }
        ></AddIcon>
      )}
    </Stack>
  );
};

const FilterSelectPopper: React.FC<{
  isLoading?: boolean;
  field: string;
  open?: boolean;
  setOpen?: (val: boolean) => void;
  anchorEl: HTMLElement;
  selected?: Array<string | number>;
  options?: Array<{
    label: string;
    value: string | number;
    disabled?: boolean;
  }>;
  onChange?: (data: { label?: string; value?: string | number }) => void;
  label?: string;
  totalLabel?: string;
  searchPlaceholder?: string;
  selectedLen?: number;
  onClear?: VoidFunction;
  listItemMode?: "plain" | "checkbox";
}> = ({
  field,
  open = false,
  setOpen,
  anchorEl,
  selected = [],
  options = [],
  onChange,
  label,
  totalLabel,
  searchPlaceholder,
  selectedLen,
  onClear,
  listItemMode,
  isLoading = false,
}) => {
    const [filterKey, setFilterKey] = useState("");

    const { t } = useTranslation();

    const filteredOptions = useMemo(() => {
      return (
        options?.filter((el) => {
          return el?.label?.toLowerCase()?.includes(filterKey?.toLowerCase());
        }) ?? []
      );
    }, [filterKey, options]);

    return (
      <Popover
        id={label}
        open={open}
        anchorEl={anchorEl}
        className="filters-popover"
        onClose={() => setOpen?.(false)}
        anchorOrigin={{
          vertical: "bottom",
          horizontal: "left",
        }}
        transformOrigin={{
          horizontal: 0,
          vertical: -3,
        }}
      >
        <Paper className="paper">
          <Box
            className="filters-popover-box"
            sx={{
              boxSizing: "border-box",
              minWidth: "350px",
              minHeight: "200px",
              maxHeight: "500px",
              padding: "10px",
            }}
          >
            <Stack
              className="filters-popover-header"
              direction="row"
              justifyContent="space-between"
              alignItems="center"
            >
              <Typography>{label ?? field ?? ""}</Typography>
              <Button variant="text" size="small" onClick={onClear}>
                {t("filter.clear")}
              </Button>
            </Stack>
            <Box marginY={1} className="filters-popover-search">
              <TextField
                fullWidth
                variant="outlined"
                size="small"
                placeholder={
                  searchPlaceholder ?? t(`common.search`) + `${field}`
                }
                // startDecorator={<SearchOutlinedIcon />}
                value={filterKey}
                onChange={(ev) => {
                  setFilterKey(ev?.target?.value ?? "");
                }}
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <SearchOutlinedIcon></SearchOutlinedIcon>
                    </InputAdornment>
                  ),
                }}
              />
              <Typography fontSize={10} marginY={1}>
                {t(`filter.searchIntro`)}
                {/* You can select/unselect to filter content. */}
              </Typography>
            </Box>

            <Stack
              direction="row"
              justifyContent="space-between"
              alignItems="center"
              marginY={1}
              className="filters-popover-fileds-header"
            >
              <Typography>
                {totalLabel ?? t("filter.total") + `${field}` ?? ""} (
                {options?.length})
              </Typography>
              <Typography>
                {t("filter.selected")} ({selectedLen ?? 0})
              </Typography>
            </Stack>
            <Box sx={{ display: "flex" }} justifyContent={"center"}>
              {isLoading && <CircularProgress />}
            </Box>
            <Stack
              className="filters-popover-fileds-data"
              direction="column"
              gap={0.5}
              maxHeight="300px"
              sx={{
                overflowY: "auto",
                "::-webkit-scrollbar": {
                  display: "none",
                },
              }}
            >
              {filteredOptions?.map((el) => {
                return (
                  <SelectItemComp
                    key={el.value}
                    label={el.label}
                    value={el.value}
                    selected={selected?.includes(el?.value)}
                    onChange={onChange}
                    disabled={el?.disabled}
                    mode={listItemMode}
                  />
                );
              })}
            </Stack>
          </Box>
        </Paper>
      </Popover>
    );
  };

interface FilterSelectItemProps {
  field: string;
  label?: string;
  totalLabel?: string;
  searchPlaceholder?: string;
  fieldItemMode?: "plain" | "checkbox";
  defaultOpen?: boolean;
  value?: unknown[];
  onValueChange?: (newData: unknown[], changeItem?: unknown) => void;
  options: Array<{
    label: string;
    value: string | number;
    disabled?: boolean;
  }>;
  dependMode?: boolean;
  dependValue?: unknown;
  getOptionsByDependValue?: (
    param: FilterSelectItemProps["dependValue"]
  ) =>
    | FilterSelectItemProps["options"]
    | Promise<FilterSelectItemProps["options"]>;
  onRemove?: VoidFunction;
  disable?: boolean;
  asyncConfig?: TSelectInput["asyncConfig"] | null;
}

const FilterSelectItem: React.FC<FilterSelectItemProps> = ({
  field,
  label,
  totalLabel,
  searchPlaceholder,
  onValueChange,
  options = [],
  value,
  onRemove,
  fieldItemMode,
  disable = false,
  // dependMode = false,
  // dependValue,
  // getOptionsByDependValue,
  asyncConfig = null,
}) => {
  const [selected, setSelected] = useState<Array<string | number>>([]);
  const [open, setOpen] = useState(false);
  const domRef = useRef<HTMLElement>();
  const { fieldsStateFormatted } = useGlobalFilterState();
  const [newParams, setNewParams] = useState<Record<string, unknown>>();
  useEffect(() => {
    const state = cloneDeep(fieldsStateFormatted);
    console.log("state-------------", state)
    if (state[field]) delete state[field];
    if (!isEqual(state, newParams)) {
      setNewParams(state);
    }
  }, [fieldsStateFormatted]);
  const formState = {
    filter: newParams,
  };
  const { resOptionList, fetchLoading } = useCustomSelect(
    asyncConfig as TSelectInput["asyncConfig"],
    `global-filter-${field}`,
    formState,
    !!asyncConfig && !!asyncConfig?.url && open
  );

  const realOptions = !!asyncConfig ? resOptionList : options;

  const showItemLabel = useMemo(() => {
    if (!selected || selected?.length === 0) {
      return "";
    }
    const label = realOptions?.find(
      (el) => el?.value === selected?.[selected?.length - 1]
    )?.label;
    return label;
  }, [realOptions, selected]);

  useEffect(() => {
    console.log("value++++++++++++++", value)
    if (!value || value?.length === 0) {
      setSelected([]);
      return;
    }
    setSelected(
      value?.map(
        (el) => (el as Record<string, unknown>)?.value as string | number
      )
    );
  }, [value]);

  console.log("selectedValue", selected);
  return (
    <Box
      ref={domRef} className={selected?.length > 0 ? "selected-filter" : ""}
      sx={{
        height: "30px",
        boxSizing: "border-box",
        padding: "2px 5px",
        borderRadius: "5px",
        border: "1px solid #bdbdbd",
        margin: "6px 20px 6px 0",
        backgroundColor: selected?.length > 0 ? "#567cde" : "white",
        // minWidth: selected?.length === 0 ? "160px" : "200px",
        display: "inline-block",
        alignItems: "center",
        color: selected?.length > 0 ? "white" : "black",
        opacity: disable ? 0.5 : 1,
        cursor: disable ? "not-allowed" : "initial",
      }}
    >
      <Box
        sx={{
          width: "100%",
          height: "100%",
          display: "flex",
          alignItems: "center",
        }}
      >
        <FilterSelectShowComp
          field={field}
          open={open}
          setOpen={setOpen}
          label={label ?? ""}
          showItemLabel={showItemLabel}
          selectedLen={selected?.length}
          clearIcon
          onClearClick={onRemove}
          disable={disable}
        />
      </Box>

      <FilterSelectPopper
        isLoading={fetchLoading}
        field={field}
        open={open}
        setOpen={setOpen}
        anchorEl={domRef.current as HTMLElement}
        options={realOptions}
        selected={selected}
        onChange={(data) => {
          const index = selected?.findIndex((el) => el === data?.value);
          // console.log("data==: ", data, "index: ", index);
          if (index === -1) {
            const newSelected = [
              ...structuredClone(selected),
              data?.value as string | number,
            ];
            setSelected(newSelected);
            const wholeData = realOptions?.filter((el) =>
              newSelected?.includes(el?.value)
            );
            onValueChange?.(wholeData, data);
            return;
          }
          const newSelected = [...structuredClone(selected)].filter(
            (el) => el !== data?.value
          );
          // console.log("newSelected", newSelected);
          setSelected(newSelected);
          const wholeData = realOptions?.filter((el) =>
            newSelected?.includes(el?.value)
          );
          onValueChange?.(wholeData, data);
        }}
        label={label}
        totalLabel={totalLabel}
        searchPlaceholder={searchPlaceholder}
        selectedLen={selected?.length}
        onClear={() => {
          setSelected([]);
          onValueChange?.([]);
        }}
        listItemMode={fieldItemMode}
      />
    </Box>
  );
};

export default FilterSelectItem;

const useIdentifierPopperState = create<{
  open: boolean;
  updateOpen: (val: boolean) => void;
}>()(
  immer((set, get) => ({
    open: false,
    updateOpen(val) {
      set((state) => {
        state.open = val;
      });
    },
  }))
);

export const IdentifiersSelectItem: React.FC<FilterSelectItemProps> = ({
  field,
  onValueChange,
  value,
  options,
  defaultOpen = false,
}) => {
  const [selected, setSelected] = useState<Array<string | number>>([]);
  const [open, setOpen] = useIdentifierPopperState((state) => [
    state.open,
    state.updateOpen,
  ]);
  const domRef = useRef<HTMLElement>();
  const realOptions = options;

  const { t } = useTranslation();

  const showItemLabel = useMemo(() => {
    if (!selected || selected?.length === 0) {
      return "";
    }
    const label = realOptions?.find(
      (el) => el?.value === selected?.[selected?.length - 1]
    )?.label;
    return label;
  }, [realOptions, selected]);

  useEffect(() => {
    if (!value || value?.length === 0) {
      setSelected([]);
      return;
    }
    setSelected(
      value?.map(
        (el) => (el as Record<string, unknown>)?.value as string | number
      )
    );
  }, [value]);

  // console.log("selected", selected);
  return (
    <Box
      ref={domRef}
      sx={{
        height: "30px",
        boxSizing: "border-box",
        padding: "2px 5px",
        borderRadius: "5px",
        border: "1px solid #bdbdbd",
        margin: "6px 20px 6px 0",
        backgroundColor: "white",
        // minWidth: selected?.length === 0 ? "160px" : "200px",
        display: "inline-block",
        alignItems: "center",
      }}
    >
      <Box
        sx={{
          width: "100%",
          height: "100%",
          display: "flex",
          alignItems: "center",
        }}
      >
        <FilterSelectShowComp
          field={field}
          open={open}
          setOpen={setOpen}
          label={t("filter.more")}
          showItemLabel={showItemLabel}
          selectedLen={selected?.length}
          identifierMode
        />
      </Box>

      <FilterSelectPopper
        field={field}
        open={open}
        setOpen={setOpen}
        anchorEl={domRef.current as HTMLElement}
        options={realOptions}
        selected={selected}
        onChange={(data) => {
          const index = selected?.findIndex((el) => el === data?.value);
          // console.log("data==: ", data, "index: ", index);
          if (index === -1) {
            const newSelected = [
              ...structuredClone(selected),
              data?.value as string | number,
            ];
            setSelected(newSelected);
            const wholeData = realOptions?.filter((el) =>
              newSelected?.includes(el?.value)
            );
            wholeData && onValueChange?.(wholeData, data);
            return;
          }
          const newSelected = [...structuredClone(selected)].filter(
            (el) => el !== data?.value
          );
          // console.log("newSelected", newSelected);
          setSelected(newSelected);
          const wholeData = realOptions?.filter((el) =>
            newSelected?.includes(el?.value)
          );
          wholeData && onValueChange?.(wholeData, data);
        }}
        label={t("filter.filterItems.label")}
        totalLabel={t("filter.filterItems.totalLabel")}
        searchPlaceholder={t("filter.filterItems.searchPlaceholder")}
        selectedLen={selected?.length}
        onClear={() => {
          setSelected([]);
          onValueChange?.([]);
        }}
        listItemMode="checkbox"
      />
    </Box>
  );
};

export enum FilterIcons {
  "Product" = 1,
  "Country" = 2,
  "Market" = 3,
  "Function" = 4,
}

const getIconNodeByIconType = (iconType: FilterIcons) => {
  switch (iconType) {
    case FilterIcons.Product:
      return <CategoryOutlinedIcon />;
    case FilterIcons.Country:
      return <PublicOutlinedIcon />;
    case FilterIcons.Market:
      return <StoreOutlinedIcon />;
    case FilterIcons.Function:
      return <AttractionsOutlinedIcon />;
  }
};

export const ViewItem: React.FC<{
  title: string;
  iconType: FilterIcons;
}> = ({ title, iconType }) => {
  const iconNode = useMemo(() => getIconNodeByIconType(iconType), [iconType]);
  return (
    <Stack
      direction="row"
      alignItems="center"
      gap={1}
      color="#567cde"
      borderRadius={2.5}
      border="1px solid #567cde"
      paddingX={1}
      paddingY={0.5}
    >
      {iconNode}
      <Typography color="inherit">{title ?? ""}</Typography>
    </Stack>
  );
};

export const FilterSelectTimePopper: React.FC<{
  field: string;
  dateRangeValue?: Record<string, unknown>;
  open?: boolean;
  setOpen?: (val: boolean) => void;
  anchorEl?: HTMLElement;
  onChange?: (data: Record<string, unknown>) => void;
  onClear?: VoidFunction;
}> = ({
  field,
  open = false,
  setOpen,
  anchorEl,
  onChange,
  onClear,
  dateRangeValue,
}) => {
    const [type, setType] = useState(dateRangeValue?.["type"] ?? "less");
    const { t } = useTranslation();

    const removeBetweenDate = () => {
      if (dateRangeValue?.type === 'between') {
        const isRemoveDate = (!dateRangeValue.fromDate && !dateRangeValue.toDate) || (dateRangeValue.fromDate && dateRangeValue.toDate);
        if (!isRemoveDate) {
          onChange?.({
            type: "between",
            fromDate: "",
            toDate: "",
          });
        }
      }
    }

    return (
      <Popover
        id="date-picker-popover"
        open={open}
        anchorEl={anchorEl}
        onClose={() => { setOpen?.(false); removeBetweenDate() }}
        anchorOrigin={{
          vertical: "bottom",
          horizontal: "left",
        }}
        transformOrigin={{
          horizontal: 0,
          vertical: -3,
        }}
      >
        <Paper className="paper">
          <Box
            sx={{
              boxSizing: "border-box",
              minWidth: "350px",
              // minHeight: "100px",
              maxHeight: "500px",
              padding: "10px",
            }}
          >
                <Stack direction="row" alignItems="center" marginY={1} pl={3}>
                  <DatePickerValue
                    value={(dateRangeValue?.["less"] as string) ?? ""}
                    onChange={(val) => {
                      onChange?.({
                        type: "less",
                        less: val ?? "",
                      });
                    }}
                    onClear={() => {
                      onChange?.({
                        type: "less",
                        less: "",
                      });
                    }}
                    placeholder={t(`filter.beforeThanPlaceholder`)}
                    width={160}
                  ></DatePickerValue>
                </Stack>
          </Box>
        </Paper>
      </Popover>
    );
  };

export const FilterSelectDateItem: React.FC<
  Partial<
    Omit<FilterSelectItemProps, "onValueChange" | "value"> & {
      onValueChange?: (data: Record<string, unknown>) => void;
      value?: Record<string, unknown>;
    }
  >
> = ({ field, label, onValueChange, value, onRemove, disable = false }) => {
  const [open, setOpen] = useState(false);
  const domRef = useRef<HTMLElement>();

  const showItemLabel = useMemo(() => {
    const type = value?.["type"];
    if (type === "between") {
      const fromDate = value?.["fromDate"]
        ? dayjs(value?.["fromDate"] as string)?.format("DD/MM/YYYY")
        : "";
      const toDate = value?.["toDate"]
        ? dayjs(value?.["toDate"] as string)?.format("DD/MM/YYYY")
        : "";
      if (!fromDate && !toDate) {
        return "";
      }
      return `${fromDate} - ${toDate}`;
    }
    if (type === "less") {
      const lessDate = value?.["less"]
        ? dayjs(value?.["less"] as string)?.format("DD/MM/YYYY")
        : "";
      return lessDate;
    }
    if (type === "more") {
      const moreDate = value?.["more"]
        ? dayjs(value?.["more"] as string)?.format("DD/MM/YYYY")
        : "";
      return moreDate;
    }
    return "";
  }, [value]);

  return (
    <Box
      ref={domRef}
      className={Object.keys(value ?? {}).length > 0 ? "selected-filter" : ""}
      sx={{
        height: "30px",
        boxSizing: "border-box",
        padding: "2px 5px",
        borderRadius: "5px",
        border: "1px solid #bdbdbd",
        margin: "6px 20px 6px 0",
        backgroundColor: !!showItemLabel ? "#567cde" : "white",
        // minWidth: selected?.length === 0 ? "160px" : "200px",
        display: "inline-block",
        alignItems: "center",
        color: !!showItemLabel ? "white" : "black",
        opacity: disable ? 0.5 : 1,
        cursor: disable ? "not-allowed" : "initial",
      }}
    >
      <Box
        sx={{
          width: "100%",
          height: "100%",
          display: "flex",
          alignItems: "center",
        }}
      >
        <FilterSelectShowComp
          field={field as string}
          open={open}
          setOpen={setOpen}
          label={label ?? ""}
          showItemLabel={showItemLabel}
          selectedLen={0}
          clearIcon
          onClearClick={onRemove}
          disable={disable}
        />
      </Box>

      <FilterSelectTimePopper
        field={field as string}
        open={open}
        setOpen={setOpen}
        anchorEl={domRef.current as HTMLElement}
        onChange={(data) => {
          onValueChange?.(data);
        }}
        dateRangeValue={value}
      // onClear={() => {
      //   setSelected([]);
      //   onValueChange?.([]);
      // }}
      />
    </Box>
  );
};