import React from "react";
import dayjs from "dayjs";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import { FormControl, TextField, InputAdornment, IconButton } from "@mui/material";
import HighlightOffOutlinedIcon from "@mui/icons-material/HighlightOffOutlined";
import CalendarMonthOutlinedIcon from "@mui/icons-material/CalendarMonthOutlined";

export const DatePickerValue: React.FC<{
  value?: string | number;
  onChange?: (val: string | number) => void;
  fieldLabel?: string;
  disabled?: boolean;
  defaultValue?: string | number;
  minDate?: string | number;
  onClear?: VoidFunction;
  placeholder?: string;
  width?: number,
  maxDate?: string | number;
}> = ({ value, onChange, onClear, placeholder, width, maxDate, minDate }) => {
  const [open, setOpen] = React.useState(false);
  // const [innerValue, setInnerValue] = React.useState<Dayjs | null>(dayjs());

  return (
    <FormControl sx={{ my: 1, width: width ?? 140 }} size="small">
      <LocalizationProvider dateAdapter={AdapterDayjs}>
        <DatePicker
          className="custom-date-picker"
          inputFormat="DD/MM/YYYY"
          value={value ?? ""}
          onChange={(newVal) => onChange?.(dayjs(newVal).valueOf())}
          open={open}
          onOpen={() => setOpen(true)}
          onClose={() => setOpen(false)}
          maxDate={maxDate}
          minDate={minDate}
          renderInput={(params) => {
            // console.log("params?.value: ", params);
            return (
              <TextField
                {...params}
                inputProps={{
                  ...params.inputProps,
                  value: value ? dayjs(value).format("DD/MM/YYYY") : "",
                  readOnly: true,
                  placeholder: placeholder ?? "Select Date",
                }}
                error={false}
                variant="standard"
                size="small"
                sx={{
                  maxWidth: width ? `${width}px` : "140px",
                }}
                onClick={() => setOpen(true)}
                InputProps={{
                  endAdornment: (
                    <InputAdornment position="end">
                      {!!params.inputProps?.value && (
                        <HighlightOffOutlinedIcon
                          onClick={(ev) => {
                            ev.preventDefault();
                            ev.stopPropagation();
                            onClear?.();
                          }}
                          sx={{
                            marginBottom: "4px",
                            marginX: "5px",
                            fontSize: "14px",
                            color: "GrayText",
                            "&:hover": {
                              color: "Highlight",
                              cursor: "pointer",
                            },
                          }}
                        ></HighlightOffOutlinedIcon>
                      )}
                      <IconButton
                        size="small"
                        sx={{
                          borderRadius: "50%",
                          marginBottom: "4px",
                        }}
                      >
                        <CalendarMonthOutlinedIcon
                          sx={{
                            fontSize: "16px",
                            color: "GrayText",
                            "&:hover": {
                              color: "Highlight",
                            },
                          }}
                        ></CalendarMonthOutlinedIcon>
                      </IconButton>
                    </InputAdornment>
                  ),
                }}
              />
            );
          }}
        />
      </LocalizationProvider>
    </FormControl>
  );
};
