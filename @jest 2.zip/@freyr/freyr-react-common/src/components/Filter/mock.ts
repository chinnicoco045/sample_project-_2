// mock the product module dropdown list data front end. actually from the api.
export const mockDropdownListData: Record<
  string,
  Array<Omit<OptionItem, "label"> & { label: string }>
> = {
  productCategory: [
    { label: "Pharmaceuticals", value: "Pharmaceuticals" },
    { label: "Vaccine", value: "Vaccine" },
    { label: "Biologicals", value: "Biologicals" },
  ],
  productSubcategory: [
    { label: "Simple", value: "Simple" },
    { label: "Reconstituted Simple", value: "Reconstituted Simple" },
    { label: "Reconstituted Combination", value: "Reconstituted Combination" },
    { label: "Combination Pack", value: "Combination Pack" },
  ],
  productType: [
    { label: "Marketable", value: "Marketable" },
    { label: "Investigational", value: "Investigational" },
  ],
  dosageForm: [
    { label: "Solution for Injection", value: "Solution for Injection" },
    { label: "Oral Suspension", value: "Oral Suspension" },
  ],
  businessunit: [
    { label: "BU-ROW", value: "BU-ROW" },
    { label: "BU-MEA", value: "BU-MEA" },
    { label: "BU-NA", value: "BU-NA" },
  ],
};