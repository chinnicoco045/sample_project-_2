import { useMemo, useEffect } from "react";
import  get  from "lodash/get";
import { useQuery } from "@tanstack/react-query";
import { getFetchOptionListFunc } from "../../DynamicFormBaseJsonSchema/hooks/CustomSelectService";
import { useFreyrLibraryContext } from "../../../context/FreyrLibraryContext";

export const useCustomSelect = (
  asyncConfig: TSelectInput["asyncConfig"],
  uniqueKey: string,
  formState?: Record<string, unknown>,
  enabled = true
) => {
  console.log('formState--------------', formState);
  const { tenant, domain, domainName } = useFreyrLibraryContext();
  const asyncConfigParams = useMemo(() => {
    let params: Record<string, unknown> = {};
    asyncConfig?.params?.forEach((el) => {
      params[el?.fieldName as string] =
        el?.value ?? get(formState, el?.valuePath, null);
    });
    return params;
  }, [asyncConfig?.params, formState]);

  const asyncConfigBodyData = useMemo(() => {
    let data: Record<string, unknown> = {};
    asyncConfig?.body?.forEach((el) => {
      data[el?.fieldName as string] =
        el?.value ?? get(formState, el?.valuePath, null);
    });
    return data;
  }, [asyncConfig?.body, formState]);

  const dependencyVars = useMemo(() => {
    let dependencyVars: Record<string, unknown> = {};
    asyncConfig?.dependencies?.forEach((el) => {
      dependencyVars[el] = asyncConfigParams?.[el];
    });
    return dependencyVars;
  }, [asyncConfig?.dependencies, asyncConfigParams]);

  const dependencyBodyVars = useMemo(() => {
    let dependencyVars: Record<string, unknown> = {};
    asyncConfig?.dependencies?.forEach((el) => {
      dependencyVars[el] = asyncConfigBodyData?.[el];
    });
    return dependencyVars;
  }, [asyncConfig?.dependencies, asyncConfigBodyData]);

  const method = asyncConfig?.method ?? "GET";
  const fetchOptionList = getFetchOptionListFunc(
    `${
      process.env[asyncConfig?.prefixEnvName ?? asyncConfig?.basicUrl ?? ""] ??
      process.env.REACT_APP_API_GETWAY
    }${asyncConfig?.url ?? ""}`,
    method,
    {
      params: asyncConfigParams,
      data: {
        ...asyncConfigBodyData,
        tenantId: tenant,
        domainId: domain,
        domainName: domainName
      },
    }
  );

  console.log("enabled", enabled);

  const {
    data: resOptionList,
    isLoading,
    remove,
  } = useQuery(
    [uniqueKey, dependencyVars, dependencyBodyVars],
    () => fetchOptionList(),
    {
      enabled: enabled,
      staleTime: Infinity,
      refetchOnWindowFocus: false,
      select(data) {
        // console.log("select data: ", data);
        const resData = data?.data;
        if (
          Number(resData?.code) !== 200 ||
          !resData?.data ||
          resData?.data?.length === 0
        ) {
          return [];
        }
        if (!asyncConfig?.valuePath) {
          return [];
        }
        if (asyncConfig?.listDataPath) {
          let listData = get(resData?.data, asyncConfig?.listDataPath, []);
          if (typeof listData === "string") {
            listData = JSON.parse(listData);
          }
          console.log("listData---: ", listData);
          return listData?.map((el: any) => {
            return {
              label: get(el, asyncConfig?.labelPath),
              value: get(el, asyncConfig?.valuePath),
            };
          });
        }
        return resData?.data?.map((el: any) => {
          return {
            label: get(el, asyncConfig?.labelPath),
            // value: get(el, asyncConfig?.valuePath),
            value: Object.values(el.id_mapping)?.[0],
            id_mapping: el.id_mapping
          };
        });
      },
    }
  );

  useEffect(() => {
    return () => {
      remove?.();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return {
    asyncConfigParams,
    dependencyVars,
    resOptionList: resOptionList as Array<{
      label: string;
      value: string | number;
      disabled?: boolean;
    }>,
    fetchLoading: isLoading && enabled,
  };
};
