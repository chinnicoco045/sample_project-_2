import { useQuery } from "@tanstack/react-query";
import { useEffect, useRef } from "react";
import {
  FilterItem,
  useFilterItemsStore,
  useNonPersistentFilterItemsStore,
} from "../../../store/filter";
import { isEqual } from "lodash";
import { getFetchOptionListFunc } from "../../DynamicFormBaseJsonSchema/hooks/CustomSelectService";
import { useFreyrLibraryContext } from "../../../context/FreyrLibraryContext";

interface optionItem {
  "select": string;
  "multi-select": string;
  "date": string;
}

const dataType: optionItem = {
  "select": "select",
  "multi-select": "select",
  "date": "date"
}

export const useIdentifierList = (activeModule: any) => {
  const getIdentifiersDefineOptions = getFetchOptionListFunc(
    `${process.env.REACT_APP_API_GETWAY}/im/identifier/getIdentifiersByLinkedModuleName/${activeModule?.name}`
  );
  const { data: identifiersDefineOptions = [], isFetching } = useQuery(
    ["fetchIdentifiersOptions", "product"],
    () => getIdentifiersDefineOptions(),
    {
      retry: false,
      refetchOnWindowFocus: false,
      select(response) {
        return response.data.data.map((item) => {
          const identifierVo = item.identifierVo || {};
          const linkedModulesFormat = identifierVo?.linkedModules?.map(
            (item) => {
              return {
                [item.name]: {
                  status: item.confirm,
                  mappingModule: item.mappingModule,
                  mappingSearch: item.mappingSearch
                },
              };
            }
          ) || [];
          const linkedModulesFormatObj = Object.assign({}, ...linkedModulesFormat);
          return {
            label: identifierVo.displayName,
            value: identifierVo.uiPattern === 'date' ? identifierVo.name : identifierVo.sourceName,
            // disabled: !item.status,
            data: {
              field: identifierVo.uiPattern === 'date' ? identifierVo.name : identifierVo.sourceName,
              label: identifierVo.displayName,
              totalLabel: `Total ${identifierVo.displayName}`,
              searchPlaceholder: `Search ${identifierVo.displayName}`,
              iconType: 2,
              fieldItemMode: "checkbox" as "plain" | "checkbox",
              //@ts-ignore
              itemType: dataType?.[identifierVo.uiPattern],
              asyncConfig: {
                labelPath: "name",
                valuePath: "id",
                url: "/im/identifier/filter",
                method: "POST",
                body: [
                  {
                    fieldName: "identifier",
                    value: identifierVo.uiPattern === 'date' ? identifierVo.name : identifierVo.sourceName,
                  },
                  {
                    store: "formState",
                    fieldName: "filter",
                    valuePath: "filter",
                  },
                ],
                dependencies: ["filter"],
              },
              linkedModules: linkedModulesFormatObj,
              fieldId: identifierVo.id
            },
          };
        });
      },
    }
  );

  const prevIdentifiersDefineOptionsRef = useRef<FilterItem[]>();
  const [updateIdentifiers] = useNonPersistentFilterItemsStore((state) => [
    state?.updateIdentifiers,
  ]);

  const prevFilterItemsRef = useRef<FilterItem[]>();
  // const [realFilterItems, updateRealFilterItems] = useFilterItemsStore((state) => [
  //   state?.realFilterItems,
  //   state?.updateRealFilterItems,
  // ]);

  useEffect(() => {
    //-----updateRealFilterItems
    if (isFetching || !identifiersDefineOptions) return;
    // const newFilterItems =
    //   realFilterItems.map((item) => {
    //     const newItem = identifiersDefineOptions.find(
    //       (identifier) => identifier.data?.field === item.data?.field
    //     );
    //     return {
    //       ...item,
    //       // disabled: newItem?.disabled,
    //       data: {
    //         ...item.data,
    //         linkedModules: newItem?.data?.linkedModules,
    //       },
    //     };
    //   }) || [];
    // if (!isEqual(newFilterItems, prevFilterItemsRef.current)) {
    //   updateRealFilterItems(newFilterItems);
    //   prevFilterItemsRef.current = newFilterItems;
    // }

    // -----updateIdentifiers
    if (
      !isEqual(
        identifiersDefineOptions,
        prevIdentifiersDefineOptionsRef.current
      )
    ) {
      const data = identifiersDefineOptions as FilterItem[];
      console.log('updateIdentifiers', data)
      updateIdentifiers?.(data);
      prevIdentifiersDefineOptionsRef.current = data;
    }
  }, [identifiersDefineOptions, isFetching]);

  return { identifiersDefineOptions, isFetching };
};
