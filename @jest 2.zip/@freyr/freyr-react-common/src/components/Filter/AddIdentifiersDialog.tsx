import {
  Box,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  FormControl,
  FormControlLabel,
  Radio,
  RadioGroup,
  Typography
} from "@mui/material";
import React from "react";
import { useState } from "react";
import { useTranslation } from "react-i18next";
import { Filter } from ".";

export interface AddIdentifiersDialogProps {
  openPopup: boolean;
  initFilterList?: Record<string, any[]>;
  activeModule: Record<string, string>;
  disableIdentifierList?: string[];
  handleClickCancel?: VoidFunction;
  handleClickSave?: (item: any) => void;
}

export const AddIdentifiersDialog = (props: AddIdentifiersDialogProps) => {
  const { t } = useTranslation();
  const { openPopup, handleClickCancel, handleClickSave, initFilterList, activeModule, disableIdentifierList = [] } = props;
  const [value, setValue] = useState("Yes");
  const [selectedIdentifiers, setSelectedIdentifiers] = useState<any>("")

  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setValue((event.target as HTMLInputElement).value);
  };

  const handleSave = () => {
    const parameters = {
      isAddFlag: value === "Yes",
      selectedIdentifiers: selectedIdentifiers
    }
    console.log('parameters is ', parameters)
    handleClickSave(parameters)
  }

  const getSelectedIdentifiers = (item: any) => {
    setSelectedIdentifiers(item);
  }

  return (
    <Dialog
      open={openPopup}
      maxWidth="md"
      fullWidth
      className="popup-dialog"
    >
      <DialogTitle>
        <h5>{t("rtq.identifiers.title")}</h5>
      </DialogTitle>
      <Box
        component="form"
        sx={{ display: "flex", flexDirection: "column" }}
      >
        <DialogContent className="form-group popup-content">
          <Typography variant="body2" gutterBottom>
            Please select action you would like to perform on selected
            components
          </Typography>
          <FormControl>
            <RadioGroup 
              aria-labelledby="identifier-radio-buttons-group-label"
              name="identifier-radio-buttons-group"
              row
              value={value}
              onChange={handleChange}
            >
              <FormControlLabel value="Yes" control={<Radio />} label="Add Identifiers" />
              <FormControlLabel value="No" control={<Radio />} label="Remove Identifiers" />
            </RadioGroup>
          </FormControl>
          <Typography variant="body2" gutterBottom>
            Please select identifiers you would like to add / remove
          </Typography>
          <Filter activeModule={activeModule} initFilterList={initFilterList} disableIdentifierList={disableIdentifierList} selectedIdentifiers={getSelectedIdentifiers}></Filter>
        </DialogContent>
        <DialogActions>
          <Button
            variant="text"
            size="small"
            onClick={() => {
              handleClickCancel();
            }}>
            {t("common.cancel")}
          </Button>
          <Button
              variant="contained" 
              size="small"
              onClick={() => {
                handleSave();
              }}>
            {t("common.save")}{" "}
          </Button>
        </DialogActions>
      </Box>
    </Dialog>
  );
}
