import {
  Box,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle
} from "@mui/material";
import { useState } from "react";
import { useTranslation } from "react-i18next";
import { Filter } from ".";
import React from "react";
import { AddIdentifiersDialogProps } from "./AddIdentifiersDialog";

export const EditIdentifiersDialog = (props: AddIdentifiersDialogProps) => {
  const { t } = useTranslation();
  const { openPopup, handleClickCancel, handleClickSave, initFilterList, activeModule, disableIdentifierList = [] } = props;
  const [selectedIdentifiers, setSelectedIdentifiers] = useState<any>("")

  const handleSave = () => {
    const parameters = {
      selectedIdentifiers: selectedIdentifiers
    }
    handleClickSave(parameters)
  }

  const getSelectedIdentifiers = (item: any) => {
    setSelectedIdentifiers(item);
  }

  return (
    <Dialog
      open={openPopup}
      maxWidth="md"
      fullWidth
      className="popup-dialog"
    >
      <DialogTitle>
        <h5>{t("rtq.identifiers.title")}</h5>
      </DialogTitle>
      <Box
        component="form"
        sx={{ display: "flex", flexDirection: "column" }}
      >
        <DialogContent className="form-group popup-content">
          <Filter activeModule={activeModule} initFilterList={initFilterList} selectedIdentifiers={getSelectedIdentifiers} disableIdentifierList={disableIdentifierList}></Filter>
        </DialogContent>
        <DialogActions>
          <Button
            variant="text"
            size="small"
            onClick={() => {
              handleClickCancel();
            }}>
            {t("common.cancel")}
          </Button>
          <Button
              variant="contained" 
              size="small"
              onClick={() => {
                handleSave();
              }}>
            {t("common.save")}{" "}
          </Button>
        </DialogActions>
      </Box>
    </Dialog>
  );
}
