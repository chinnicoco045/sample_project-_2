import React, { useState } from "react";
import {
  Autocomplete,
  Chip,
  TextField,
  InputAdornment,
  IconButton,
  MenuItem,
  Tooltip,
  Typography,
} from "@mui/material";
import ClearIcon from "@mui/icons-material/Clear";

type AutocompleteParams = Parameters<typeof Autocomplete>[0];

const ChipsInputWithOptionsList: React.FC<
  Partial<Omit<AutocompleteParams, "options" | "value" | "onChange">> & {
    placeholder?: string;
    options?: Array<{ label: string; value: string | number }>;
    value?: string[] | null;
    onChange?: (value: string[]) => void;
    disableInputValAsChip?: boolean;
    inputRenderVariant?: "outlined" | "standard" | "filled";
    catchInputValAsChipOnBlur?: boolean; // false by default; true will catch input el value and set as one chip, then form will submit with the chip, but disableInputValAsChip must be false;
    optionTooltip?: boolean;
  }
> = ({
  value = [],
  onChange,
  options = [],
  disabled,
  disableInputValAsChip = false,
  catchInputValAsChipOnBlur = false,
  inputRenderVariant,
  optionTooltip = false,
  ...otherProps
}) => {
  const [inputValue, setInputValue] = useState("");
  
  // console.log("ChipsInputWithOptionsList otherProps: ", otherProps)

  // useEffect(() => {
  //   // 当value prop改变时，重置inputValue
  //   setInputValue('');
  // }, [value]);

  const handleDelete = (chipToDelete: string) => {
    value && onChange?.(value?.filter((chip) => chip !== chipToDelete));
  };

  const handleInputChange = (
    event: React.SyntheticEvent,
    newInputValue: string
  ) => {
    setInputValue(newInputValue);
  };

  const handleKeyDown = (event: React.KeyboardEvent) => {
    if (
      event.key === "Enter" &&
      inputValue &&
      value &&
      !value.includes(inputValue)
    ) {
      event.preventDefault();
      event?.stopPropagation();
      console.log("compValue: 11111");
      if (disableInputValAsChip) {
        console.log("compValue: 22222");
        // can not set input text as one chip.
        setInputValue("");
        return;
      }
      console.log("compValue: 33333");
      // 添加新的chip并重置inputValue
      onChange?.([...(value ?? []), inputValue]);
      setInputValue("");
    }
  };

  const handleInputBlur = (
    event: React.FocusEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    if (
      catchInputValAsChipOnBlur &&
      inputValue &&
      (!value || !value.includes(inputValue))
    ) {
      event.preventDefault();
      event?.stopPropagation();
      if (disableInputValAsChip) {
        // can not set input text as one chip.
        setInputValue("");
        return;
      }
      // 添加新的chip并重置inputValue
      onChange?.([...(value ?? []), inputValue]);
      setInputValue("");
    }
  };

  const handleClear = () => {
    onChange?.([]);
  };

  // console.log("ChipsInputWithOptionsList: ", value);

  return (
    <Autocomplete<OptionItem | string | null> // <string[] | null>
      multiple
      id="tags-filled"
      options={options}
      getOptionLabel={(option) => {
        if (option && typeof option === "object" && "label" in option)
          return option?.label;
        return option;
      }}
      // value={value ?? []}
      value={
        value?.map((val) => {
          const target = options?.find((option) => option.value === val);
          if (target) return target;
          return val;
        }) ?? []
      }
      inputValue={inputValue}
      onInputChange={handleInputChange}
      onKeyDown={handleKeyDown}
      onBlur={handleInputBlur}
      freeSolo
      size="small"
      fullWidth
      disabled={disabled}
      clearIcon={<></>}
      filterOptions={(options, params) => {
        const filtered = options.filter((option) => {
          if (option && typeof option === "object" && "label" in option)
            return option?.label
              ?.toLowerCase()
              ?.includes(params.inputValue?.toLowerCase());
          return false;
        });
        return filtered;
      }}
      renderTags={(tagValue, getTagProps) =>
        tagValue.map((option, index: number) => {
          let label = option,
            value: any = option;
          if (option && typeof option === "object" && "label" in option) {
            label = option?.label;
            value = option?.value;
          }
          return (
            <Chip
              variant="outlined"
              data-testid="Chip"
              size="small"
              label={label as unknown as string}
              {...getTagProps({ index })}
              onDelete={() => handleDelete(value as string)}
              sx={{
                "& .MuiChip-label": {
                  textTransform: "none !important",
                },
              }}
            />
          );
        })
      }
      renderInput={(params) => (
        <TextField
          {...params}
          data-testid="TextField"
          // label="Movie"
          size="small"
          variant={inputRenderVariant}
          sx={{
            "& .MuiInputBase-input": {
              minWidth: "0 !important",
              width: "0 !important",
            },
          }}
          onKeyDown={handleKeyDown}
          onBlur={handleInputBlur}
          placeholder={otherProps?.placeholder ?? ""}
          InputProps={{
            ...params.InputProps,
            endAdornment: (
              <>
                {value && value?.length > 0 && !disabled && (
                  <InputAdornment position="end">
                    <IconButton onClick={handleClear}>
                      <ClearIcon />
                    </IconButton>
                  </InputAdornment>
                )}
                {params.InputProps.endAdornment}
              </>
            ),
          }}
        />
      )}
      onChange={(event, newValue) => {
        // console.log("onChange: ", newValue);
        const newVal = newValue as unknown as Array<OptionItem | string>;
        onChange?.(
          newVal?.map((el) => {
            if (typeof el === "object" && "value" in el)
              return el?.value as string;
            return el as string;
          }) ?? []
        );
      }}
      renderOption={(props, options, state, ownerState) => {
        // if (!optionTooltip) {
        //   return (
        //     <MenuItem
        //       {...props}
        //       selected={state?.selected}
        //     >
        //       <Typography
        //         sx={{
        //           textOverflow: "ellipsis",
        //           overflow: "hidden",
        //           whiteSpace: "nowrap",
        //           width: "100%",
        //         }}
        //       >
        //         {typeof options === "string" ? options : options?.label}
        //       </Typography>
        //     </MenuItem>
        //   );
        // }
        return (
          <Tooltip
            disableFocusListener={!optionTooltip}
            disableHoverListener={!optionTooltip}
            disableTouchListener={!optionTooltip}
            title={typeof options === "string" ? options : options?.label ?? ""}
            leaveTouchDelay={0}
            disableInteractive
          >
            <MenuItem {...props} selected={state?.selected}>
              <Typography
                sx={{
                  textOverflow: "ellipsis",
                  overflow: "hidden",
                  whiteSpace: "nowrap",
                  width: "100%",
                }}
              >
                {typeof options === "string" ? options : options?.label}
              </Typography>
            </MenuItem>
          </Tooltip>
        );
      }}
      slotProps={{
        paper: {
          sx: {
            minWidth: 160,
          },
        },
      }}
      {...(otherProps as any)}
    />
  );
};

export default ChipsInputWithOptionsList;
