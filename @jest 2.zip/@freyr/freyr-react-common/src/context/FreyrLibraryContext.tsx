import React, { createContext, ReactNode, useContext } from 'react';

interface FreyrLibraryContextType {
  language?: string;
  token?: string;
  tenant?: string;
  domain?: string;
  domainName?: string;
}

const FreyrLibraryContext = createContext<FreyrLibraryContextType | undefined>(
  undefined
);

interface FreyrLibraryProviderProps {
  language?: string;
  token?: string;
  tenant?: string;
  domain?: string;
  domainName?: string;
  children: ReactNode;
}

export const FreyrLibraryProvider: React.FC<FreyrLibraryProviderProps> = ({
  language,
  token,
  tenant,
  domain,
  domainName,
  children,
}) => {
  return (
    <FreyrLibraryContext.Provider value={{ language, token, tenant, domain, domainName }}>
      {children}
    </FreyrLibraryContext.Provider>
  );
};

export const useFreyrLibraryContext = (): FreyrLibraryContextType => {
  const context = useContext(FreyrLibraryContext);
  if (!context) {
    throw new Error(
      'useFreyrLibraryContext must be used within a FreyrLibraryProvider'
    );
  }
  return context;
};
