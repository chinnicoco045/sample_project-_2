import type { Meta, StoryObj } from '@storybook/react';
import { fn } from '@storybook/test';
import { mockJsonData } from '../components/DynamicFormBaseJsonSchema/hooks/convert';
import { WithWrapper } from '../components/DynamicFormBaseJsonSchema/WithWrapper';

import {DynamicFormCompBasicJsonSchema as DynamicForm} from '../components/DynamicFormBaseJsonSchema';


const meta: Meta<typeof DynamicForm> = {
    title: 'Components/DynamicForm',
    component: DynamicForm,
    parameters: {
      // Optional parameter to center the component in the Canvas.
      layout: 'centered',
    },
    decorators: [WithWrapper],
    // This component will have an automatically generated Autodocs entry
    tags: ['autodocs'],
    argTypes: {},
    args: {
      onFormSubmit(data) {
        console.log("submit form data: ", data)
      },
     },
  };
  
  export default meta;
  type Story = StoryObj<typeof DynamicForm>;

  export const BasicJsonForm: Story = {
    args: {
      uniqueKey: "my-first-form-unique-key",
      jsonData: mockJsonData,
      initialFormData: {
        text_field: "initial text value",
        textarea_field: "initial textarea value",
        number_field: 4,
        view_field: "initial view value",
        checkbox_field1: ["gilad"],
        checkbox_field2: true
      }
    },
  };