export const LANGUAGEMAP: { [key: string]: any } = {
  wangeditor: {
    en: 'en',
    zh: 'zh-CN',
    jp: 'jaJP',
  },
  mui: {
    en: 'enUS',
    zh: 'zhCN',
    jp: 'jaJP',
  },
};
