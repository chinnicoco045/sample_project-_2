// Can't import from pro package - hence duplication
export const GRID_DETAIL_PANEL_TOGGLE_FIELD = '__detail_panel_toggle__';