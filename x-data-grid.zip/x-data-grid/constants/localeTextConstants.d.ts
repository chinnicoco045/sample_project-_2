import { GridLocaleText } from '../models/api/gridLocaleTextApi';
export declare const GRID_DEFAULT_LOCALE_TEXT: GridLocaleText;
