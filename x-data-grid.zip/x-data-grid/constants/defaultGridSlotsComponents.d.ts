import { GridSlotsComponent } from '../models';
export declare const DATA_GRID_DEFAULT_SLOTS_COMPONENTS: GridSlotsComponent;
