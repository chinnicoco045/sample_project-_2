import { GridColumnTypesRecord } from '../models/colDef/gridColumnTypesRecord';
export declare const DEFAULT_GRID_COL_TYPE_KEY = "__default__";
export declare const getGridDefaultColumnTypes: () => GridColumnTypesRecord;
