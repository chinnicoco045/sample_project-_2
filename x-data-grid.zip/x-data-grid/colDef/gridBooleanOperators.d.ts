import { GridFilterOperator } from '../models/gridFilterOperator';
export declare const getGridBooleanOperators: () => GridFilterOperator<any, boolean | null, any>[];
