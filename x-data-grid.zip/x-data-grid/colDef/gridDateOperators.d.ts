import { GridFilterOperator } from '../models/gridFilterOperator';
export declare const getGridDateOperators: (showTime?: boolean) => GridFilterOperator<any, Date, any>[];
