import { GridFilterOperator } from '../models/gridFilterOperator';
export declare const getGridSingleSelectOperators: () => GridFilterOperator[];
