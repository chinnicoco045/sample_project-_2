import { GridColTypeDef } from '../models/colDef/gridColDef';
export declare const GRID_BOOLEAN_COL_DEF: GridColTypeDef<boolean | null, any>;
