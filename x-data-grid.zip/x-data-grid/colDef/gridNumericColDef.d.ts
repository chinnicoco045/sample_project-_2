import { GridColTypeDef } from '../models/colDef/gridColDef';
export declare const GRID_NUMERIC_COL_DEF: GridColTypeDef<number | string | null, string>;
