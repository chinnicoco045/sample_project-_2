import { GridColTypeDef } from '../models/colDef/gridColDef';
/**
 * TODO: Move pro and premium properties outside of this Community file
 */
export declare const GRID_STRING_COL_DEF: GridColTypeDef<any, any>;
