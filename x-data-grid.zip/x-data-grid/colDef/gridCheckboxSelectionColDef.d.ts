import { GridColDef } from '../models/colDef/gridColDef';
export declare const GRID_CHECKBOX_SELECTION_FIELD = "__check__";
export declare const GRID_CHECKBOX_SELECTION_COL_DEF: GridColDef;
