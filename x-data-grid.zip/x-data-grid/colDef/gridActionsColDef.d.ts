import { GridColTypeDef } from '../models/colDef/gridColDef';
export declare const GRID_ACTIONS_COLUMN_TYPE = "actions";
export declare const GRID_ACTIONS_COL_DEF: GridColTypeDef;
