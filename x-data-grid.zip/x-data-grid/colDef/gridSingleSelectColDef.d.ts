import { GridSingleSelectColDef } from '../models/colDef/gridColDef';
export declare const GRID_SINGLE_SELECT_COL_DEF: Omit<GridSingleSelectColDef, 'field'>;
