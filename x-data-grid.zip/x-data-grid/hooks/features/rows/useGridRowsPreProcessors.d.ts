import * as React from 'react';
import { GridPrivateApiCommunity } from '../../../models/api/gridApiCommunity';
export declare const useGridRowsPreProcessors: (apiRef: React.MutableRefObject<GridPrivateApiCommunity>) => void;
