import { GridStateCommunity } from '../../../models/gridStateCommunity';
export declare const gridRowsMetaSelector: (state: GridStateCommunity) => import("./gridRowsMetaState").GridRowsMetaState;
