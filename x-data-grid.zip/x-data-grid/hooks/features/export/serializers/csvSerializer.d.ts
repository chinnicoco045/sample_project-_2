/// <reference types="react" />
import type { GridCsvExportOptions, GridRowId } from '../../../../models';
import type { GridCellParams } from '../../../../models/params/gridCellParams';
import type { GridStateColDef } from '../../../../models/colDef/gridColDef';
import type { GridApiCommunity } from '../../../../models/api/gridApiCommunity';
export declare const serializeCellValue: (cellParams: GridCellParams, options: {
    csvOptions: CSVOptions;
    ignoreValueFormatter: boolean;
}) => any;
type CSVOptions = Required<Pick<GridCsvExportOptions, 'delimiter' | 'shouldAppendQuotes' | 'escapeFormulas'>>;
interface BuildCSVOptions {
    columns: GridStateColDef[];
    rowIds: GridRowId[];
    csvOptions: Required<Pick<GridCsvExportOptions, 'delimiter' | 'includeColumnGroupsHeaders' | 'includeHeaders' | 'shouldAppendQuotes' | 'escapeFormulas'>>;
    ignoreValueFormatter: boolean;
    apiRef: React.MutableRefObject<GridApiCommunity>;
}
export declare function buildCSV(options: BuildCSVOptions): string;
export {};
