import { GridDensity } from '../../../models/gridDensity';
export interface GridDensityState {
    value: GridDensity;
    factor: number;
}
