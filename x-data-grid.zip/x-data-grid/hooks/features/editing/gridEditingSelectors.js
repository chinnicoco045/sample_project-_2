// TODO v6: rename to gridEditingStateSelector
export const gridEditRowsStateSelector = state => state.editRows;