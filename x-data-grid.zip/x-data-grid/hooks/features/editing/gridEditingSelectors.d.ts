import { GridStateCommunity } from '../../../models/gridStateCommunity';
export declare const gridEditRowsStateSelector: (state: GridStateCommunity) => import("../../..").GridEditingState;
