import { GridStateCommunity } from '../../../models/gridStateCommunity';
export declare const gridColumnMenuSelector: (state: GridStateCommunity) => import("./columnMenuInterfaces").GridColumnMenuState;
