import { GridStateCommunity } from '../../../models/gridStateCommunity';
export declare const gridPreferencePanelStateSelector: (state: GridStateCommunity) => import("./gridPreferencePanelState").GridPreferencePanelState;
