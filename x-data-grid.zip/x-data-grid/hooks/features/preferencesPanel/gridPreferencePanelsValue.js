var GridPreferencePanelsValue = /*#__PURE__*/function (GridPreferencePanelsValue) {
  GridPreferencePanelsValue["filters"] = "filters";
  GridPreferencePanelsValue["columns"] = "columns";
  return GridPreferencePanelsValue;
}(GridPreferencePanelsValue || {});
export { GridPreferencePanelsValue };