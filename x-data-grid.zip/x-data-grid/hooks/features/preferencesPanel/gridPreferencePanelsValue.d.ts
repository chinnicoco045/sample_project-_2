declare enum GridPreferencePanelsValue {
    filters = "filters",
    columns = "columns"
}
export { GridPreferencePanelsValue };
