import * as React from 'react';
/**
 * Hook that instantiate a [[GridApiRef]].
 */
export const useGridApiRef = () => React.useRef({});