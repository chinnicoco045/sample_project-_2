export declare const useGridAriaAttributes: () => {
    role: string;
    'aria-colcount': number;
    'aria-rowcount': number;
    'aria-multiselectable': boolean;
};
