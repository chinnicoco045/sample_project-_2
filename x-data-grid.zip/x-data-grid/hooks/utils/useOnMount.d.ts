import * as React from 'react';
export declare function useOnMount(fn: React.EffectCallback): void;
