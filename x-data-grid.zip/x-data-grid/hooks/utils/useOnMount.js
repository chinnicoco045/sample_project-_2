import * as React from 'react';
const EMPTY = [];
export function useOnMount(fn) {
  /* eslint-disable react-hooks/exhaustive-deps */
  React.useEffect(fn, EMPTY);
  /* eslint-enable react-hooks/exhaustive-deps */
}