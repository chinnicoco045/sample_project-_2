export declare const useFirstRender: (callback: () => void) => void;
