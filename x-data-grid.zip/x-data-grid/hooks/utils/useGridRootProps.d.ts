import type { DataGridProcessedProps } from '../../models/props/DataGridProps';
export declare const useGridRootProps: () => DataGridProcessedProps<any>;
