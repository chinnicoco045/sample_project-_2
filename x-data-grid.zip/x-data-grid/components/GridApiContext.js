import * as React from 'react';
export const GridApiContext = /*#__PURE__*/React.createContext(undefined);
if (process.env.NODE_ENV !== 'production') {
  GridApiContext.displayName = 'GridApiContext';
}