import * as React from 'react';
export declare const GridApiContext: React.Context<unknown>;
