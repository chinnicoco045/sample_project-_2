import * as React from 'react';
export declare function GridOverlays(): React.JSX.Element | null;
