import * as React from 'react';
export declare function GridFooterPlaceholder(): React.JSX.Element | null;
