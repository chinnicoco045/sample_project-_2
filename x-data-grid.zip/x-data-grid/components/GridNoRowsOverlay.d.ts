import * as React from 'react';
declare const GridNoRowsOverlay: React.ForwardRefExoticComponent<React.HTMLAttributes<HTMLDivElement> & {
    sx?: import("@mui/system").SxProps<import("@mui/system").Theme> | undefined;
} & React.RefAttributes<HTMLDivElement>>;
export { GridNoRowsOverlay };
