import * as React from 'react';
declare const DataGridVirtualScroller: React.ForwardRefExoticComponent<React.HTMLAttributes<HTMLDivElement> & React.RefAttributes<HTMLDivElement>>;
export { DataGridVirtualScroller };
