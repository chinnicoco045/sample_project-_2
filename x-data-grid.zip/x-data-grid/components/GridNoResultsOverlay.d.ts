import * as React from 'react';
export declare const GridNoResultsOverlay: React.ForwardRefExoticComponent<React.HTMLAttributes<HTMLDivElement> & {
    sx?: import("@mui/system").SxProps<import("@mui/system").Theme> | undefined;
} & React.RefAttributes<HTMLDivElement>>;
