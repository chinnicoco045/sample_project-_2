import * as React from 'react';
import { GridColumnMenuItemProps } from '../GridColumnMenuItemProps';
declare function GridColumnMenuManageItem(props: GridColumnMenuItemProps): React.JSX.Element | null;
declare namespace GridColumnMenuManageItem {
    var propTypes: any;
}
export { GridColumnMenuManageItem };
