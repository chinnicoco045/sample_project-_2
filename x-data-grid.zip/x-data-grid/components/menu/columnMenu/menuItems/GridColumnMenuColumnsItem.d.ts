import * as React from 'react';
import { GridColumnMenuItemProps } from '../GridColumnMenuItemProps';
declare function GridColumnMenuColumnsItem(props: GridColumnMenuItemProps): React.JSX.Element;
declare namespace GridColumnMenuColumnsItem {
    var propTypes: any;
}
export { GridColumnMenuColumnsItem };
