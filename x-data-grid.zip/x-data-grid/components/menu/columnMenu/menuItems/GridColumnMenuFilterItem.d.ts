import * as React from 'react';
import { GridColumnMenuItemProps } from '../GridColumnMenuItemProps';
declare function GridColumnMenuFilterItem(props: GridColumnMenuItemProps): React.JSX.Element | null;
declare namespace GridColumnMenuFilterItem {
    var propTypes: any;
}
export { GridColumnMenuFilterItem };
