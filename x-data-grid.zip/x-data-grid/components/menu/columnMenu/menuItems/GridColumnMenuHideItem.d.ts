import * as React from 'react';
import { GridColumnMenuItemProps } from '../GridColumnMenuItemProps';
declare function GridColumnMenuHideItem(props: GridColumnMenuItemProps): React.JSX.Element | null;
declare namespace GridColumnMenuHideItem {
    var propTypes: any;
}
export { GridColumnMenuHideItem };
