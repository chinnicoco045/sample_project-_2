import * as React from 'react';
import { GridColumnMenuItemProps } from '../GridColumnMenuItemProps';
declare function GridColumnMenuSortItem(props: GridColumnMenuItemProps): React.JSX.Element | null;
declare namespace GridColumnMenuSortItem {
    var propTypes: any;
}
export { GridColumnMenuSortItem };
