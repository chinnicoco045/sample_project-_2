import * as React from 'react';
export declare const GridMainContainer: React.ForwardRefExoticComponent<{
    children?: React.ReactNode;
} & React.RefAttributes<HTMLDivElement>>;
