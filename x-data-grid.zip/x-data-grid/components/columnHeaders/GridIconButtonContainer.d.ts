import * as React from 'react';
export type GridIconButtonContainerProps = React.HTMLAttributes<HTMLDivElement>;
export declare const GridIconButtonContainer: React.ForwardRefExoticComponent<GridIconButtonContainerProps & React.RefAttributes<HTMLDivElement>>;
