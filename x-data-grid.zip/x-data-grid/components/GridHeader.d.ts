import * as React from 'react';
export declare function GridHeader(): React.JSX.Element;
