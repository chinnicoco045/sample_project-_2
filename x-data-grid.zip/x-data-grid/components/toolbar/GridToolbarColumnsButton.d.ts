import * as React from 'react';
import { ButtonProps } from '@mui/material/Button';
export declare const GridToolbarColumnsButton: React.ForwardRefExoticComponent<Omit<ButtonProps, "ref"> & React.RefAttributes<HTMLButtonElement>>;
