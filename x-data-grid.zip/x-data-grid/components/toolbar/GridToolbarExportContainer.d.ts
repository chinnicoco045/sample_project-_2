import * as React from 'react';
import { ButtonProps } from '@mui/material/Button';
export declare const GridToolbarExportContainer: React.ForwardRefExoticComponent<Omit<ButtonProps, "ref"> & React.RefAttributes<HTMLButtonElement>>;
