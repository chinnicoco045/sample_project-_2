import * as React from 'react';
declare const GridRootPropsContext: React.Context<unknown>;
export { GridRootPropsContext };
