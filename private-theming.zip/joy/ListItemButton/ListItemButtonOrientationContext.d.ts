import * as React from 'react';
declare const ListItemButtonOrientationContext: React.Context<"horizontal" | "vertical">;
export default ListItemButtonOrientationContext;
