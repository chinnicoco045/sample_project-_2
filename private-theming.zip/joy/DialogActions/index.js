'use client';

export { default } from './DialogActions';
export * from './dialogActionsClasses';
export { default as dialogActionsClasses } from './dialogActionsClasses';
export * from './DialogActionsProps';