/**
 * @ignore - internal component.
 */
declare const _default: import("@mui/types").OverridableComponent<import("../..").SvgIconTypeMap<{}, "svg">>;
export default _default;
