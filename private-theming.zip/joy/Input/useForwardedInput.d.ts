import { FormControlContextValue } from '../FormControl/FormControlContext';
export default function useForwardedInput<Output>(props: any, classes: {
    disabled: string;
    error: string;
    focused: string;
    formControl: string;
}): {
    propsToForward: Record<string, any>;
    rootStateClasses: Record<string, any>;
    inputStateClasses: Record<string, any>;
} & import("@mui/base/useInput").UseInputReturnValue & Output & {
    formControl: FormControlContextValue;
};
