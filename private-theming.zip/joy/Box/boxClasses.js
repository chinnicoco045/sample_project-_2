import { unstable_generateUtilityClasses as generateUtilityClasses } from '@mui/utils';
const boxClasses = generateUtilityClasses('MuiBox', ['root']);
export default boxClasses;