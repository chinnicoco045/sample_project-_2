'use client';

export { default } from './Box';
export * from './BoxProps';
export { default as boxClasses } from './boxClasses';
export * from './boxClasses';