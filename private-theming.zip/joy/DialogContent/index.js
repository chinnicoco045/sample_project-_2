'use client';

export { default } from './DialogContent';
export * from './dialogContentClasses';
export { default as dialogContentClasses } from './dialogContentClasses';
export * from './DialogContentProps';