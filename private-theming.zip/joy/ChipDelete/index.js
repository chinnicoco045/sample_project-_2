'use client';

export { default } from './ChipDelete';
export * from './chipDeleteClasses';
export { default as chipDeleteClasses } from './chipDeleteClasses';
export * from './ChipDeleteProps';