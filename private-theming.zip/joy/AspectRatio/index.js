'use client';

export { default } from './AspectRatio';
export * from './aspectRatioClasses';
export { default as aspectRatioClasses } from './aspectRatioClasses';
export * from './AspectRatioProps';