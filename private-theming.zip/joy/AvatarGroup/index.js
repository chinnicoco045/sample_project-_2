'use client';

export { default } from './AvatarGroup';
export * from './avatarGroupClasses';
export { default as avatarGroupClasses } from './avatarGroupClasses';
export * from './AvatarGroupProps';