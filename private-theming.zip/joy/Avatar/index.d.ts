export { default } from './Avatar';
export * from './avatarClasses';
export { default as avatarClasses } from './avatarClasses';
export * from './AvatarProps';
