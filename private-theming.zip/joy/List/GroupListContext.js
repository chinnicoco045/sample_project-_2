import * as React from 'react';
const GroupListContext = /*#__PURE__*/React.createContext(undefined);
if (process.env.NODE_ENV !== 'production') {
  GroupListContext.displayName = 'GroupListContext';
}
export default GroupListContext;