import * as React from 'react';
declare const NestedListContext: React.Context<string | boolean>;
export default NestedListContext;
