import * as React from 'react';
const RowListContext = /*#__PURE__*/React.createContext(false);
if (process.env.NODE_ENV !== 'production') {
  RowListContext.displayName = 'RowListContext';
}
export default RowListContext;