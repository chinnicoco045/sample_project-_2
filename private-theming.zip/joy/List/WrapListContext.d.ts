import * as React from 'react';
declare const WrapListContext: React.Context<boolean>;
export default WrapListContext;
