import * as React from 'react';
declare const ComponentListContext: React.Context<string | undefined>;
export default ComponentListContext;
