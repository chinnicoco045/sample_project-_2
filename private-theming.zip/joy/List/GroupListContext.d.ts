import * as React from 'react';
declare const GroupListContext: React.Context<"menu" | "select" | undefined>;
export default GroupListContext;
