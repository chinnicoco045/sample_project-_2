import * as React from 'react';
declare const RowListContext: React.Context<boolean>;
export default RowListContext;
