export { applySolidInversion, applySoftInversion } from './colorInversionUtils';
