export { default } from './colors';
