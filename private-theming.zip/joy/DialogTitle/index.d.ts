export { default } from './DialogTitle';
export * from './dialogTitleClasses';
export { default as dialogTitleClasses } from './dialogTitleClasses';
export * from './DialogTitleProps';
