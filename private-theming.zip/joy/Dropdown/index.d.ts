export { Dropdown as default, type DropdownProps } from '@mui/base/Dropdown';
