import { OverridableComponent } from '@mui/types';
import { ContainerTypeMap } from './ContainerProps';
declare const Container: OverridableComponent<ContainerTypeMap<{}, "div">>;
export default Container;
