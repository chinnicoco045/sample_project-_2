export { default as ThemeProvider } from './ThemeProvider';
export * from './ThemeProvider';

export { default as useTheme } from './useTheme';
export * from './useTheme';

export * from './defaultTheme';
