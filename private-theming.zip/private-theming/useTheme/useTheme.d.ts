import { DefaultTheme } from '../defaultTheme';

export default function useTheme<T = DefaultTheme>(): T;
