# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [1.4.126](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.125...@aw-web-design/x-default-browser@1.4.126) (2022-08-07)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.125](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.124...@aw-web-design/x-default-browser@1.4.125) (2022-08-07)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.124](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.123...@aw-web-design/x-default-browser@1.4.124) (2022-08-06)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## 1.4.123 (2022-08-05)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## 1.4.122 (2022-08-02)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## 1.4.121 (2022-08-01)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## 1.4.120 (2022-07-31)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.119](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.118...@aw-web-design/x-default-browser@1.4.119) (2022-07-31)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## 1.4.118 (2022-07-31)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.117](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.116...@aw-web-design/x-default-browser@1.4.117) (2022-07-30)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## 1.4.116 (2022-07-29)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## 1.4.115 (2022-07-28)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.114](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.113...@aw-web-design/x-default-browser@1.4.114) (2022-07-26)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.113](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.112...@aw-web-design/x-default-browser@1.4.113) (2022-07-26)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.112](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.111...@aw-web-design/x-default-browser@1.4.112) (2022-07-26)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## 1.4.111 (2022-07-25)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.110](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.109...@aw-web-design/x-default-browser@1.4.110) (2022-07-22)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.109](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.108...@aw-web-design/x-default-browser@1.4.109) (2022-07-22)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.108](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.107...@aw-web-design/x-default-browser@1.4.108) (2022-07-20)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.107](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.106...@aw-web-design/x-default-browser@1.4.107) (2022-07-18)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.106](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.105...@aw-web-design/x-default-browser@1.4.106) (2022-07-17)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.105](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.104...@aw-web-design/x-default-browser@1.4.105) (2022-07-16)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.104](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.103...@aw-web-design/x-default-browser@1.4.104) (2022-07-16)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.103](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.102...@aw-web-design/x-default-browser@1.4.103) (2022-07-16)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.102](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.101...@aw-web-design/x-default-browser@1.4.102) (2022-07-15)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.101](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.100...@aw-web-design/x-default-browser@1.4.101) (2022-07-14)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## 1.4.100 (2022-07-14)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## 1.4.99 (2022-07-14)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.98](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.97...@aw-web-design/x-default-browser@1.4.98) (2022-07-13)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.97](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.96...@aw-web-design/x-default-browser@1.4.97) (2022-07-13)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.96](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.95...@aw-web-design/x-default-browser@1.4.96) (2022-07-12)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.95](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.94...@aw-web-design/x-default-browser@1.4.95) (2022-07-10)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## 1.4.94 (2022-07-10)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.93](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.92...@aw-web-design/x-default-browser@1.4.93) (2022-07-10)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.92](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.91...@aw-web-design/x-default-browser@1.4.92) (2022-07-10)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.91](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.90...@aw-web-design/x-default-browser@1.4.91) (2022-07-10)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.90](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.89...@aw-web-design/x-default-browser@1.4.90) (2022-07-09)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.89](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.88...@aw-web-design/x-default-browser@1.4.89) (2022-07-09)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## 1.4.88 (2022-06-30)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.87](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.86...@aw-web-design/x-default-browser@1.4.87) (2022-06-29)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.86](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.85...@aw-web-design/x-default-browser@1.4.86) (2022-06-29)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.85](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.84...@aw-web-design/x-default-browser@1.4.85) (2022-06-28)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.84](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.83...@aw-web-design/x-default-browser@1.4.84) (2022-06-28)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## 1.4.83 (2022-06-28)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.82](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.81...@aw-web-design/x-default-browser@1.4.82) (2022-06-26)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.81](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.80...@aw-web-design/x-default-browser@1.4.81) (2022-06-25)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.80](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.79...@aw-web-design/x-default-browser@1.4.80) (2022-06-25)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.79](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.78...@aw-web-design/x-default-browser@1.4.79) (2022-06-25)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.78](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.77...@aw-web-design/x-default-browser@1.4.78) (2022-06-24)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.77](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.76...@aw-web-design/x-default-browser@1.4.77) (2022-06-24)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.76](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.75...@aw-web-design/x-default-browser@1.4.76) (2022-06-22)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## 1.4.75 (2022-06-20)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## 1.4.74 (2022-06-18)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.73](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.72...@aw-web-design/x-default-browser@1.4.73) (2022-06-18)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.72](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.71...@aw-web-design/x-default-browser@1.4.72) (2022-06-17)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.71](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.70...@aw-web-design/x-default-browser@1.4.71) (2022-06-17)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.70](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.69...@aw-web-design/x-default-browser@1.4.70) (2022-06-17)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.69](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.68...@aw-web-design/x-default-browser@1.4.69) (2022-06-16)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.68](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.67...@aw-web-design/x-default-browser@1.4.68) (2022-06-16)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.67](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.66...@aw-web-design/x-default-browser@1.4.67) (2022-06-16)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.66](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.65...@aw-web-design/x-default-browser@1.4.66) (2022-06-15)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.65](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.64...@aw-web-design/x-default-browser@1.4.65) (2022-06-15)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## 1.4.64 (2022-06-15)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.63](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.62...@aw-web-design/x-default-browser@1.4.63) (2022-06-14)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.62](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.61...@aw-web-design/x-default-browser@1.4.62) (2022-06-14)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.61](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.60...@aw-web-design/x-default-browser@1.4.61) (2022-06-14)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## 1.4.60 (2022-06-13)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.59](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.58...@aw-web-design/x-default-browser@1.4.59) (2022-06-09)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## 1.4.58 (2022-06-08)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## 1.4.57 (2022-06-07)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## 1.4.56 (2022-06-07)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.55](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.54...@aw-web-design/x-default-browser@1.4.55) (2022-06-06)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.54](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.53...@aw-web-design/x-default-browser@1.4.54) (2022-06-06)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.53](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.52...@aw-web-design/x-default-browser@1.4.53) (2022-06-06)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.52](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.51...@aw-web-design/x-default-browser@1.4.52) (2022-06-05)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.51](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.50...@aw-web-design/x-default-browser@1.4.51) (2022-06-05)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.50](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.49...@aw-web-design/x-default-browser@1.4.50) (2022-06-04)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.49](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.48...@aw-web-design/x-default-browser@1.4.49) (2022-06-04)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## 1.4.48 (2022-06-03)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## 1.4.47 (2022-06-03)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.46](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.45...@aw-web-design/x-default-browser@1.4.46) (2022-06-02)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.45](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.44...@aw-web-design/x-default-browser@1.4.45) (2022-06-02)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.44](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.43...@aw-web-design/x-default-browser@1.4.44) (2022-06-02)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.43](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.42...@aw-web-design/x-default-browser@1.4.43) (2022-06-01)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.42](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.41...@aw-web-design/x-default-browser@1.4.42) (2022-06-01)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.41](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.40...@aw-web-design/x-default-browser@1.4.41) (2022-06-01)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## 1.4.40 (2022-06-01)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.39](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.38...@aw-web-design/x-default-browser@1.4.39) (2022-05-31)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.38](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.37...@aw-web-design/x-default-browser@1.4.38) (2022-05-31)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.37](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.36...@aw-web-design/x-default-browser@1.4.37) (2022-05-30)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## 1.4.36 (2022-05-30)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.35](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.34...@aw-web-design/x-default-browser@1.4.35) (2022-05-30)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## 1.4.34 (2022-05-29)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## 1.4.33 (2022-05-28)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.32](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.31...@aw-web-design/x-default-browser@1.4.32) (2022-05-28)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.31](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.30...@aw-web-design/x-default-browser@1.4.31) (2022-05-25)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.30](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.29...@aw-web-design/x-default-browser@1.4.30) (2022-05-25)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.29](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.28...@aw-web-design/x-default-browser@1.4.29) (2022-05-25)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.28](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.27...@aw-web-design/x-default-browser@1.4.28) (2022-05-24)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.27](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.26...@aw-web-design/x-default-browser@1.4.27) (2022-05-24)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.26](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.25...@aw-web-design/x-default-browser@1.4.26) (2022-05-24)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## 1.4.25 (2022-05-23)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.24](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.23...@aw-web-design/x-default-browser@1.4.24) (2022-05-21)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.23](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.22...@aw-web-design/x-default-browser@1.4.23) (2022-05-21)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## 1.4.22 (2022-05-21)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.21](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.20...@aw-web-design/x-default-browser@1.4.21) (2022-05-19)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## 1.4.20 (2022-05-19)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## 1.4.19 (2022-05-18)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.18](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.17...@aw-web-design/x-default-browser@1.4.18) (2022-05-17)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.17](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.16...@aw-web-design/x-default-browser@1.4.17) (2022-05-17)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## 1.4.16 (2022-05-17)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## 1.4.15 (2022-05-16)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.14](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.13...@aw-web-design/x-default-browser@1.4.14) (2022-05-16)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.13](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.12...@aw-web-design/x-default-browser@1.4.13) (2022-05-15)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.12](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.11...@aw-web-design/x-default-browser@1.4.12) (2022-05-14)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## 1.4.11 (2022-05-14)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.10](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.9...@aw-web-design/x-default-browser@1.4.10) (2022-05-13)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.9](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.8...@aw-web-design/x-default-browser@1.4.9) (2022-05-12)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.8](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.7...@aw-web-design/x-default-browser@1.4.8) (2022-05-12)


### Bug Fixes

* update a load of stuff ([56bb576](https://github.com/The-Code-Monkey/TechStack/commit/56bb5764633af9eda7889541548c588cdaa43b9d))





## 1.4.7 (2022-05-12)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.6](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.5...@aw-web-design/x-default-browser@1.4.6) (2022-05-11)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## 1.4.5 (2022-05-10)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## [1.4.4](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.4.3...@aw-web-design/x-default-browser@1.4.4) (2022-05-10)

**Note:** Version bump only for package @aw-web-design/x-default-browser





## 1.4.3 (2022-05-10)


### Bug Fixes

* bump tcm cli ([0771246](https://github.com/The-Code-Monkey/TechStack/commit/07712465e0786403b873a21d8220ecf71af2afaf))





## [1.4.1](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.2.0...@aw-web-design/x-default-browser@1.4.1) (2022-05-08)

**Note:** Version bump only for package @aw-web-design/x-default-browser





# [1.4.0](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.2.0...@aw-web-design/x-default-browser@1.4.0) (2022-05-06)


### Bug Fixes

* add publish config ([30b2a8f](https://github.com/The-Code-Monkey/TechStack/commit/30b2a8fcc02b5298f92024478c3652f02e6e15d2))
* linting ([6e535e2](https://github.com/The-Code-Monkey/TechStack/commit/6e535e21bcd5f317914b42ddbfa3ccd4fb7fda65))


### Features

* add x-default-browser ([077fe59](https://github.com/The-Code-Monkey/TechStack/commit/077fe59adf3b8faef6e2cd0facea4625d279386e))





# [1.2.0](https://github.com/The-Code-Monkey/TechStack/compare/@aw-web-design/x-default-browser@1.1.0...@aw-web-design/x-default-browser@1.2.0) (2022-05-06)


### Bug Fixes

* add publish config ([30b2a8f](https://github.com/The-Code-Monkey/TechStack/commit/30b2a8fcc02b5298f92024478c3652f02e6e15d2))
* linting ([6e535e2](https://github.com/The-Code-Monkey/TechStack/commit/6e535e21bcd5f317914b42ddbfa3ccd4fb7fda65))


### Features

* add x-default-browser ([077fe59](https://github.com/The-Code-Monkey/TechStack/commit/077fe59adf3b8faef6e2cd0facea4625d279386e))





# 1.1.0 (2022-05-06)


### Bug Fixes

* linting ([6e535e2](https://github.com/The-Code-Monkey/TechStack/commit/6e535e21bcd5f317914b42ddbfa3ccd4fb7fda65))


### Features

* add x-default-browser ([077fe59](https://github.com/The-Code-Monkey/TechStack/commit/077fe59adf3b8faef6e2cd0facea4625d279386e))
