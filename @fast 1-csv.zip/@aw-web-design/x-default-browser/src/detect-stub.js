module.exports = function (callback) {
  callback('Your platform is not supported, sorry. Patches welcome.');
};
