var assertClassBrand = require("./assertClassBrand.js");
function _classPrivateFieldGet2(s, a) {
  return s.get(assertClassBrand(s, a));
}
module.exports = _classPrivateFieldGet2, module.exports.__esModule = true, module.exports["default"] = module.exports;