function _classApplyDescriptorGet(e, t) {
  return t.get ? t.get.call(e) : t.value;
}
module.exports = _classApplyDescriptorGet, module.exports.__esModule = true, module.exports["default"] = module.exports;