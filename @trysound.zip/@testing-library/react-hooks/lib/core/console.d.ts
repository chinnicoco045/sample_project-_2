declare function suppressErrorOutput(): () => void;
declare function enableErrorOutputSuppression(): void;
export { enableErrorOutputSuppression, suppressErrorOutput };
