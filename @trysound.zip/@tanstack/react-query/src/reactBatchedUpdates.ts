'use client'
import * as ReactDOM from 'react-dom'

export const unstable_batchedUpdates = ReactDOM.unstable_batchedUpdates
