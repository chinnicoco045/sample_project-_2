// TODO: Once we upgrade to Jest 28/29 we can probably remove this entire mock.
module.exports = {};
