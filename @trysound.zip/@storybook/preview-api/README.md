# Preview API

TODO write proper documentation of this package

# "Sub packages" README documents

This package used to be multiple packages (they have been combined into this one):

- `@storybook/addons` [read (old) docs](./README-addons.md)
- `@storybook/core-client` [read (old) docs](./README-core-client.md)
- `@storybook/preview-web` [read (old) docs](./README-preview-web.md)
- `@storybook/store` [read (old) docs](./README-store.md)
