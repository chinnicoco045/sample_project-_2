# global

Require global variables

## Example

```js
import { global } from "global";
```

## Installation

`yarn add @storybook/global`
