# Changelog

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

## [2.0.0](https://github.com/istanbuljs/append-transform/compare/v1.0.0...v2.0.0) (2019-09-09)


### ⚠ BREAKING CHANGES

* Requires Node.js 8

### Features

* Update dependencies ([#12](https://github.com/istanbuljs/append-transform/issues/12)) ([2a8b22b](https://github.com/istanbuljs/append-transform/commit/2a8b22b))
