export declare function printPruneHelp(): void;
export declare function printHelp(): void;
export declare function printSuppressHelp(): void;
//# sourceMappingURL=print-help.d.ts.map