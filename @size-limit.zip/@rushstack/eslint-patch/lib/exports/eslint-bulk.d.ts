import '../eslint-bulk-suppressions/cli/start';
//# sourceMappingURL=eslint-bulk.d.ts.map