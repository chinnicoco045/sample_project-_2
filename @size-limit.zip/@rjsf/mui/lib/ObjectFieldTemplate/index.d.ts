export { default } from './ObjectFieldTemplate';
export * from './ObjectFieldTemplate';
