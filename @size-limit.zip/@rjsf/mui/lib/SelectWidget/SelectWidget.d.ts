import { FormContextType, RJSFSchema, StrictRJSFSchema, WidgetProps } from '@rjsf/utils';
/** The `SelectWidget` is a widget for rendering dropdowns.
 *  It is typically used with string properties constrained with enum options.
 *
 * @param props - The `WidgetProps` for this component
 */
export default function SelectWidget<T = any, S extends StrictRJSFSchema = RJSFSchema, F extends FormContextType = any>({ schema, id, name, // remove this from textFieldProps
options, label, hideLabel, required, disabled, placeholder, readonly, value, multiple, autofocus, onChange, onBlur, onFocus, errorSchema, rawErrors, registry, uiSchema, hideError, formContext, ...textFieldProps }: WidgetProps<T, S, F>): import("react/jsx-runtime").JSX.Element;
