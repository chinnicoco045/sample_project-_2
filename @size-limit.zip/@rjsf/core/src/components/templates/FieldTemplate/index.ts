import FieldTemplate from './FieldTemplate';

export default FieldTemplate;
