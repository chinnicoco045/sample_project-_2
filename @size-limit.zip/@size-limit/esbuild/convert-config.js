export function convertConfig(config) {
  config.metafile = true
}
