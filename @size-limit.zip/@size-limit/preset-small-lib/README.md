# Size Limit Preset for Small Libraries

The preset for [Size Limit] for libraries < 10 kB. It uses
esbuild and file plugins to track the size of all files and dependencies.

See Size Limit docs for more details.

[Size Limit]: https://github.com/ai/size-limit/

<a href="https://evilmartians.com/?utm_source=size-limit">
  <img src="https://evilmartians.com/badges/sponsored-by-evil-martians.svg"
       alt="Sponsored by Evil Martians" width="236" height="54">
</a>
