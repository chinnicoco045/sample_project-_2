import esbuild from '@size-limit/esbuild'
import file from '@size-limit/file'

export default [...esbuild, ...file]
