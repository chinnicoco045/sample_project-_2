# Size Limit File Plugin

The plugin for [Size Limit] to track file size.

See Size Limit docs for more details.

[Size Limit]: https://github.com/ai/size-limit/

<a href="https://evilmartians.com/?utm_source=size-limit">
  <img src="https://evilmartians.com/badges/sponsored-by-evil-martians.svg"
       alt="Sponsored by Evil Martians" width="236" height="54">
</a>
