import React, { useMemo, createContext, useContext, useRef, useEffect, useState, forwardRef, useImperativeHandle } from 'react';
import { styled, FormLabel, Box, Tooltip, FormControl, TextField, Autocomplete, Chip, InputAdornment, IconButton, MenuItem, Typography, FormControlLabel as FormControlLabel$1, Checkbox as Checkbox$1, Stack, Button, Popover, Paper, CircularProgress as CircularProgress$1, ListItemIcon, ListItemText, Dialog, DialogTitle, DialogContent, RadioGroup as RadioGroup$1, Radio as Radio$1, DialogActions } from '@mui/material';
import validator from '@rjsf/validator-ajv8';
import { withTheme } from '@rjsf/core';
import { Theme } from '@rjsf/mui';
import Grid from '@mui/material/Grid';
import { getUiOptions, getTemplate, titleId, descriptionId, canExpand, getInputProps, examplesId, labelValue, ariaDescribedByIds, errorId, optionId } from '@rjsf/utils';
import InfoOutlinedIcon from '@mui/icons-material/InfoOutlined';
import { useTranslation } from 'react-i18next';
import ClearIcon from '@mui/icons-material/Clear';
import CircularProgress from '@mui/material/CircularProgress';
import get from 'lodash-es/get';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import axios from 'axios';
import Typography$1 from '@mui/material/Typography';
import ListItem from '@mui/material/ListItem';
import FormHelperText from '@mui/material/FormHelperText';
import List from '@mui/material/List';
import Box$1 from '@mui/material/Box';
import Checkbox from '@mui/material/Checkbox';
import FormControlLabel from '@mui/material/FormControlLabel';
import FormGroup from '@mui/material/FormGroup';
import { isNil, cloneDeep, isEqual } from 'lodash-es';
import { LocalizationProvider, DatePicker } from '@mui/x-date-pickers';
import dayjs from 'dayjs';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import HighlightOffOutlinedIcon from '@mui/icons-material/HighlightOffOutlined';
import CalendarMonthOutlinedIcon from '@mui/icons-material/CalendarMonthOutlined';
import { object, string, undefined as undefined$1, number, array, date, boolean } from 'zod';
import { produce } from 'immer';
import Radio from '@mui/material/Radio';
import RadioGroup from '@mui/material/RadioGroup';
import ArrowDropUpIcon from '@mui/icons-material/ArrowDropUp';
import ArrowDropDownIcon from '@mui/icons-material/ArrowDropDown';
import SearchOutlinedIcon from '@mui/icons-material/SearchOutlined';
import CheckIcon from '@mui/icons-material/Check';
import AddIcon from '@mui/icons-material/Add';
import '@mui/icons-material/CategoryOutlined';
import '@mui/icons-material/StoreOutlined';
import '@mui/icons-material/PublicOutlined';
import '@mui/icons-material/AttractionsOutlined';
import ClearRoundedIcon from '@mui/icons-material/ClearRounded';
import { LocalizationProvider as LocalizationProvider$1 } from '@mui/x-date-pickers/LocalizationProvider';
import { DatePicker as DatePicker$1 } from '@mui/x-date-pickers/DatePicker';
import { create } from 'zustand';
import { immer } from 'zustand/middleware/immer';
import { subscribeWithSelector } from 'zustand/middleware';
import cloneDeep$1 from 'lodash-es/cloneDeep';
import mapValues from 'lodash-es/mapValues';
import isEqual$1 from 'lodash-es/isEqual';

function _extends() {
  _extends = Object.assign ? Object.assign.bind() : function (target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends.apply(this, arguments);
}
function _objectWithoutPropertiesLoose(source, excluded) {
  if (source == null) return {};
  var target = {};
  for (var key in source) {
    if (Object.prototype.hasOwnProperty.call(source, key)) {
      if (excluded.indexOf(key) >= 0) continue;
      target[key] = source[key];
    }
  }
  return target;
}
function _unsupportedIterableToArray(o, minLen) {
  if (!o) return;
  if (typeof o === "string") return _arrayLikeToArray(o, minLen);
  var n = Object.prototype.toString.call(o).slice(8, -1);
  if (n === "Object" && o.constructor) n = o.constructor.name;
  if (n === "Map" || n === "Set") return Array.from(o);
  if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen);
}
function _arrayLikeToArray(arr, len) {
  if (len == null || len > arr.length) len = arr.length;
  for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i];
  return arr2;
}
function _createForOfIteratorHelperLoose(o, allowArrayLike) {
  var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"];
  if (it) return (it = it.call(o)).next.bind(it);
  if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") {
    if (it) o = it;
    var i = 0;
    return function () {
      if (i >= o.length) return {
        done: true
      };
      return {
        done: false,
        value: o[i++]
      };
    };
  }
  throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}

/* eslint-disable @typescript-eslint/no-explicit-any */
/** The `ObjectFieldTemplate` is the template to use to render all the inner properties of an object along with the
 * title and description if available. If the object is expandable, then an `AddButton` is also rendered after all
 * the properties.
 *
 * @param props - The `ObjectFieldTemplateProps` for this component
 */
function ObjectFieldTemplate(props) {
  var description = props.description,
    title = props.title,
    properties = props.properties,
    required = props.required,
    disabled = props.disabled,
    readonly = props.readonly,
    uiSchema = props.uiSchema,
    idSchema = props.idSchema,
    schema = props.schema,
    formData = props.formData,
    onAddClick = props.onAddClick,
    registry = props.registry;
  var uiOptions = getUiOptions(uiSchema);
  var TitleFieldTemplate = getTemplate("TitleFieldTemplate", registry, uiOptions);
  var DescriptionFieldTemplate = getTemplate("DescriptionFieldTemplate", registry, uiOptions);
  // Button templates are not overridden in the uiSchema
  var AddButton = registry.templates.ButtonTemplates.AddButton;
  // console.log("title", title);
  // console.log("uiOptions", uiOptions);
  // console.log("uiSchema", uiSchema);
  return React.createElement(React.Fragment, null, title && React.createElement(TitleFieldTemplate, {
    id: titleId(idSchema),
    title: title,
    required: required,
    schema: schema,
    uiSchema: uiSchema,
    registry: registry
  }), description && React.createElement(DescriptionFieldTemplate, {
    id: descriptionId(idSchema),
    description: description,
    schema: schema,
    uiSchema: uiSchema,
    registry: registry
  }), React.createElement(Grid, {
    container: true,
    spacing: 0,
    columnGap: 0,
    style: {
      marginTop: "10px",
      marginBottom: "20px"
    }
  }, properties.map(function (element, index) {
    var _uiSchema$element$nam, _uiSchema$element$nam2, _uiSchema$element$nam3, _uiSchema$element$nam4;
    return (
      // Remove the <Grid> if the inner element is hidden as the <Grid>
      // itself would otherwise still take up space.
      element.hidden ? element.content : React.createElement(Grid, {
        item: true,
        xs: (uiSchema == null || (_uiSchema$element$nam = uiSchema[element.name]) == null ? void 0 : _uiSchema$element$nam["ui:field_xs"]) || (uiOptions == null ? void 0 : uiOptions["ui:field_xs"]) || 12,
        xl: (uiSchema == null || (_uiSchema$element$nam2 = uiSchema[element.name]) == null ? void 0 : _uiSchema$element$nam2["ui:field_xl"]) || (uiOptions == null ? void 0 : uiOptions["ui:field_xl"]) || 12,
        md: (uiSchema == null || (_uiSchema$element$nam3 = uiSchema[element.name]) == null ? void 0 : _uiSchema$element$nam3["ui:field_md"]) || (uiOptions == null ? void 0 : uiOptions["ui:field_md"]) || 12,
        lg: (uiSchema == null || (_uiSchema$element$nam4 = uiSchema[element.name]) == null ? void 0 : _uiSchema$element$nam4["ui:field_lg"]) || (uiOptions == null ? void 0 : uiOptions["ui:field_lg"]) || 12,
        key: index
      }, element.content)
    );
  }), canExpand(schema, uiSchema, formData) && React.createElement(Grid, {
    container: true,
    justifyContent: "flex-end"
  }, React.createElement(Grid, {
    item: true
  }, React.createElement(AddButton, {
    className: "object-property-expand",
    onClick: onAddClick(schema),
    disabled: disabled || readonly,
    uiSchema: uiSchema,
    registry: registry
  })))));
}

var CustomizedFormLabel = function CustomizedFormLabel(_ref) {
  var _ref$label = _ref.label,
    label = _ref$label === void 0 ? "" : _ref$label,
    _ref$required = _ref.required,
    required = _ref$required === void 0 ? false : _ref$required,
    _ref$description = _ref.description,
    description = _ref$description === void 0 ? "" : _ref$description,
    maxLen = _ref.maxLen,
    existLen = _ref.existLen,
    descIcon = _ref.descIcon,
    icon = _ref.icon,
    _ref$readonly = _ref.readonly,
    readonly = _ref$readonly === void 0 ? false : _ref$readonly,
    _ref$disabled = _ref.disabled,
    disabled = _ref$disabled === void 0 ? false : _ref$disabled;
  var metaIconClassName = {
    IDMPC: "idfr-txt idmp cond",
    xEVMPDC: "idfr-txt xvmpd cond",
    IDMPO: "idfr-txt idmp optional",
    xEVMPDO: "idfr-txt idmp man",
    IDMPM: "idfr-txt xvmpd optional",
    xEVMPDM: "idfr-txt xvmpd man"
  };
  var CustomPaper = styled("span")({
    ".idfr-txt": {
      position: "relative",
      marginRight: "-2px",
      width: "24px",
      "float": "left",
      textAlign: "center"
    },
    ".idfr-txt.idmp:before": {
      content: '"I"',
      fontSize: "12px",
      fontWeight: 800,
      marginLeft: "5px"
    },
    ".idfr-txt.xvmpd:before": {
      content: '"X"',
      fontSize: "12px",
      fontWeight: 800,
      marginLeft: "5px"
    },
    ".idfr-txt.optional:after": {
      content: '"o"',
      position: "absolute",
      top: "-5px"
    },
    ".idfr-txt.cond:after": {
      content: '"c"',
      position: "absolute",
      top: "-5px"
    },
    ".idfr-txt.cond": {
      color: "blue"
    },
    ".idfr-txt.optional": {
      color: "green"
    },
    ".idfr-txt.man": {
      color: "red"
    },
    ".idfr-txt.man:after": {
      content: '"*"',
      position: "absolute",
      top: "-5px"
    }
  });
  var _useTranslation = useTranslation();
  // console.log("label", label)
  // console.log("description", description)
  var labelMaxWith = useMemo(function () {
    var subtract = 0;
    if (required) subtract += 10;
    if (description) subtract += 10;
    return "calc(100% - " + subtract + "px)";
  }, [required, description]);
  return React.createElement(FormLabel, {
    disabled: readonly || disabled,
    sx: {
      textAlign: "left",
      my: 1,
      display: "flex",
      alignItems: "center",
      color: "initial",
      position: "relative"
    },
    required: false
  }, React.createElement(Box, {
    flex: 1,
    overflow: "hidden",
    display: "flex"
  }, " ", React.createElement(Tooltip, {
    title: label
  }, React.createElement("span", {
    className: "text-ellipsis",
    style: {
      maxWidth: labelMaxWith
    }
  }, label)), required ? React.createElement("span", {
    style: {
      color: "red"
    }
  }, " * ") : "", !descIcon && description && React.createElement(Tooltip, {
    title: description != null ? description : ""
  }, React.createElement(InfoOutlinedIcon
  // titleAccess={description ?? ""}
  , {
    // titleAccess={description ?? ""}
    sx: {
      color: "inherit",
      fontSize: "15px",
      mx: 0.5
    }
  })), descIcon && description && React.createElement(Tooltip, {
    title: description != null ? description : ""
  }, React.createElement(React.Fragment, null, descIcon))), icon != null && icon.length ? React.createElement(CustomPaper, null, icon.map(function (item) {
    return React.createElement("span", {
      key: item,
      className: metaIconClassName[item]
    });
  })) : null, maxLen !== undefined && existLen !== undefined && React.createElement(Box, {
    sx: {
      mx: 0.5
    }
  }, existLen, "/", maxLen));
};

var _excluded = ["id", "name", "placeholder", "required", "readonly", "disabled", "type", "label", "hideLabel", "value", "onChange", "onChangeOverride", "onBlur", "onFocus", "autofocus", "options", "schema", "uiSchema", "rawErrors", "formContext", "registry", "InputLabelProps"],
  _excluded2 = ["step", "min", "max"];
var TYPES_THAT_SHRINK_LABEL = ["date", "datetime-local", "file", "time"];
/** The `BaseInputTemplate` is the template to use to render the basic `<input>` component for the `core` theme.
 * It is used as the template for rendering many of the <input> based widgets that differ by `type` and callbacks only.
 * It can be customized/overridden for other themes or individual implementations as needed.
 *
 * @param props - The `WidgetProps` for this template
 */
function BaseInputTemplate(props) {
  var _labelValue, _uiSchema$uiMaxLen, _value$length, _uiSchema$uiDescript, _uiSchema$uiReadonly, _uiSchema$uiMaxLen2, _schema$minimum, _schema$maximum;
  var id = props.id,
    placeholder = props.placeholder,
    required = props.required,
    readonly = props.readonly,
    disabled = props.disabled,
    type = props.type,
    label = props.label,
    hideLabel = props.hideLabel,
    value = props.value,
    onChange = props.onChange,
    onChangeOverride = props.onChangeOverride,
    onBlur = props.onBlur,
    onFocus = props.onFocus,
    autofocus = props.autofocus,
    options = props.options,
    schema = props.schema,
    uiSchema = props.uiSchema,
    _props$rawErrors = props.rawErrors,
    rawErrors = _props$rawErrors === void 0 ? [] : _props$rawErrors,
    InputLabelProps = props.InputLabelProps,
    textFieldProps = _objectWithoutPropertiesLoose(props, _excluded);
  // console.log("name: ", name, "uiSchema: ", uiSchema, "schema: ", schema);
  var inputProps = getInputProps(schema, type, options);
  var uiOptions = getUiOptions(uiSchema);
  // Now we need to pull out the step, min, max into an inner `inputProps` for material-ui
  var step = inputProps.step,
    min = inputProps.min,
    max = inputProps.max,
    rest = _objectWithoutPropertiesLoose(inputProps, _excluded2);
  var otherProps = _extends({
    inputProps: _extends({
      step: step,
      min: min,
      max: max
    }, schema.examples ? {
      list: examplesId(id)
    } : undefined)
  }, rest);
  var _onChange = function _onChange(_ref) {
    var value = _ref.target.value;
    return onChange(value === "" ? options.emptyValue : value);
  };
  var _onBlur = function _onBlur(_ref2) {
    var value = _ref2.target.value;
    return onBlur(id, value);
  };
  var _onFocus = function _onFocus(_ref3) {
    var value = _ref3.target.value;
    return onFocus(id, value);
  };
  var DisplayInputLabelProps = TYPES_THAT_SHRINK_LABEL.includes(type) ? _extends({}, InputLabelProps, {
    shrink: true
  }) : InputLabelProps;
  // console.log("uiOptions: ", uiOptions)
  return React.createElement(FormControl, null, React.createElement(CustomizedFormLabel, {
    label: (_labelValue = labelValue(label || undefined, hideLabel, false)) != null ? _labelValue : "",
    labelKey: uiSchema == null ? void 0 : uiSchema["ui:labelKey"],
    required: required,
    maxLen: (_uiSchema$uiMaxLen = uiSchema == null ? void 0 : uiSchema["ui:maxLen"]) != null ? _uiSchema$uiMaxLen : undefined,
    existLen: (_value$length = value == null ? void 0 : value.length) != null ? _value$length : 0,
    description: (_uiSchema$uiDescript = uiSchema == null ? void 0 : uiSchema["ui:description"]) != null ? _uiSchema$uiDescript : schema == null ? void 0 : schema["description"],
    icon: uiSchema == null ? void 0 : uiSchema["ui:icon"],
    readonly: (_uiSchema$uiReadonly = uiSchema == null ? void 0 : uiSchema["ui:readonly"]) != null ? _uiSchema$uiReadonly : schema == null ? void 0 : schema["readOnly"],
    disabled: uiSchema == null ? void 0 : uiSchema["ui:disabled"]
  }), React.createElement(TextField, Object.assign({
    id: id,
    name: id,
    placeholder: placeholder,
    // label={labelValue(label || undefined, hideLabel, false)}
    autoFocus: autofocus,
    required: required,
    disabled: disabled || readonly
  }, otherProps, {
    value: value || value === 0 ? value : "",
    error: rawErrors.length > 0,
    onChange: onChangeOverride || _onChange,
    onBlur: _onBlur,
    onFocus: _onFocus,
    size: (uiSchema == null ? void 0 : uiSchema["ui:size"]) || (uiOptions == null ? void 0 : uiOptions["ui:size"]) || "medium",
    InputLabelProps: _extends({}, DisplayInputLabelProps, {
      shrink: false
    }),
    inputProps: {
      maxLength: (_uiSchema$uiMaxLen2 = uiSchema == null ? void 0 : uiSchema["ui:maxLen"]) != null ? _uiSchema$uiMaxLen2 : null,
      min: (_schema$minimum = schema == null ? void 0 : schema["minimum"]) != null ? _schema$minimum : null,
      max: (_schema$maximum = schema == null ? void 0 : schema["maximum"]) != null ? _schema$maximum : null
    }
  }, textFieldProps, {
    "aria-describedby": ariaDescribedByIds(id, !!schema.examples)
  })), Array.isArray(schema.examples) && React.createElement("datalist", {
    id: examplesId(id)
  }, schema.examples.concat(schema["default"] && !schema.examples.includes(schema["default"]) ? [schema["default"]] : []).map(function (example) {
    return React.createElement("option", {
      key: example,
      value: example
    });
  })));
}

var FreyrLibraryContext = /*#__PURE__*/createContext(undefined);
var FreyrLibraryProvider = function FreyrLibraryProvider(_ref) {
  var language = _ref.language,
    token = _ref.token,
    tenant = _ref.tenant,
    domain = _ref.domain,
    domainName = _ref.domainName,
    children = _ref.children;
  return React.createElement(FreyrLibraryContext.Provider, {
    value: {
      language: language,
      token: token,
      tenant: tenant,
      domain: domain,
      domainName: domainName
    }
  }, children);
};
var useFreyrLibraryContext = function useFreyrLibraryContext() {
  var context = useContext(FreyrLibraryContext);
  if (!context) {
    throw new Error('useFreyrLibraryContext must be used within a FreyrLibraryProvider');
  }
  return context;
};

var getFetchOptionListFunc = function getFetchOptionListFunc(completeUrl, method, params) {
  if (method === void 0) {
    method = "GET";
  }
  var _useFreyrLibraryConte = useFreyrLibraryContext(),
    language = _useFreyrLibraryConte.language,
    token = _useFreyrLibraryConte.token;
  return function () {
    var languageformat = language === 'en' ? '' : language;
    var tokenformat = token;
    if (completeUrl) {
      return axios({
        method: method,
        url: completeUrl,
        params: params == null ? void 0 : params["params"],
        data: params == null ? void 0 : params["data"],
        headers: {
          Authorization: tokenformat ? "Bearer " + tokenformat : "",
          "Accept-Language": languageformat || ""
        }
      });
    }
  };
};

var formatArrayValue = function formatArrayValue(data) {
  if (Array.isArray(data)) return data;
  return data ? [data] : [];
};
var formatArrayStringValue = function formatArrayStringValue(data) {
  if (Array.isArray(data)) return data == null ? void 0 : data.map(function (el) {
    return "" + el;
  });
  return data ? ["" + data] : [];
};
var formatObjectValue = function formatObjectValue(data, format) {
  var _Object$entries$map, _Object$entries;
  var fieldsVals = (_Object$entries$map = (_Object$entries = Object.entries(data != null ? data : {})) == null ? void 0 : _Object$entries.map(function (_ref) {
    var key = _ref[0],
      val = _ref[1];
    if (Array.isArray(val)) {
      var newVal = format === 'array' ? formatArrayValue(val) : formatArrayStringValue(val);
      return [key, newVal];
    }
    if (typeof val === 'object' && val) return [key, formatObjectValue(val, format)];
    if (typeof val === 'boolean') return [key, val];
    if (format === 'array') return [key, formatArrayValue(val)];
    if (format === 'arrayOfString') return [key, formatArrayStringValue(val)];
    return [key, val];
  })) != null ? _Object$entries$map : [];
  // ?.forEach(([key, val]) => {
  //   finalFieldVals[key as string] = val;
  // });
  // console.log("fieldsVals: ", fieldsVals);
  // console.log("data: ", data);
  return Object.fromEntries(fieldsVals);
};
var forceFormatValue = function forceFormatValue(format, data) {
  if (!format) return data;
  if (Array.isArray(data)) {
    return format === 'array' ? formatArrayValue(data) : formatArrayStringValue(data);
  }
  if (typeof data === 'object' && data) {
    return formatObjectValue(data, format);
  }
  if (format === 'array') return formatArrayValue(data);
  if (format === 'arrayOfString') return formatArrayStringValue(data);
  return data;
};

var filterEqualListItem = function filterEqualListItem(value, condition) {
  return value === condition;
};
var filterNotEqualListItem = function filterNotEqualListItem(value, condition) {
  return value !== condition;
};
// const filterIncludeListItem = (value: )
var filterListDataByType = function filterListDataByType(type, value, condition) {
  switch (type) {
    case 'equal':
      return filterEqualListItem(value, condition);
    case 'notEqual':
      return filterNotEqualListItem(value, condition);
    case 'include':
    case 'exclude':
      return true;
  }
};
var useCustomSelect = function useCustomSelect(asyncConfig, uniqueKey, store, enabled, funcs) {
  var _process$env, _ref, _asyncConfig$prefixEn, _asyncConfig$url, _asyncConfig$requestM;
  if (enabled === void 0) {
    enabled = true;
  }
  var _useFreyrLibraryConte = useFreyrLibraryContext(),
    tenant = _useFreyrLibraryConte.tenant,
    domain = _useFreyrLibraryConte.domain;
  var dependencyVarsChangeRef = useRef(false);
  var initialRequest = useRef(true);
  var asyncConfigParams = useMemo(function () {
    var _asyncConfig$params;
    var params = {};
    asyncConfig == null || (_asyncConfig$params = asyncConfig.params) == null || _asyncConfig$params.forEach(function (el) {
      var val;
      if (el != null && el.value) {
        val = el == null ? void 0 : el.value;
      } else if ((el == null ? void 0 : el.valuePath) === 'all') {
        val = store == null ? void 0 : store.formState;
      } else {
        val = get(store[el.store], el == null ? void 0 : el.valuePath, null);
      }
      params[el == null ? void 0 : el.fieldName] = val;
    });
    return params;
  }, [asyncConfig == null ? void 0 : asyncConfig.params, store]);
  var asyncConfigBodyData = useMemo(function () {
    var _asyncConfig$body$fin, _asyncConfig$body, _asyncConfig$body2;
    var data = {};
    var identifier = (_asyncConfig$body$fin = asyncConfig == null || (_asyncConfig$body = asyncConfig.body) == null || (_asyncConfig$body = _asyncConfig$body.find(function (el) {
      return (el == null ? void 0 : el.fieldName) === 'identifier';
    })) == null ? void 0 : _asyncConfig$body.value) != null ? _asyncConfig$body$fin : '';
    asyncConfig == null || (_asyncConfig$body2 = asyncConfig.body) == null || _asyncConfig$body2.forEach(function (el) {
      var val;
      if (el != null && el.value) {
        val = el == null ? void 0 : el.value;
      } else if ((el == null ? void 0 : el.valuePath) === 'all') {
        val = store == null ? void 0 : store.formState;
      } else {
        val = get(store[el.store], el == null ? void 0 : el.valuePath, null);
      }
      var formatVal = forceFormatValue(el == null ? void 0 : el.format, val);
      if (identifier && formatVal && typeof formatVal === 'object' && identifier in formatVal) {
        delete formatVal[identifier];
        data[el == null ? void 0 : el.fieldName] = formatVal;
        return;
      }
      data[el == null ? void 0 : el.fieldName] = formatVal;
      // data[el?.fieldName as string] =
      //   el?.value ?? get(store[el.store as StoreKey], el?.valuePath, null);
    });
    return data;
  }, [asyncConfig == null ? void 0 : asyncConfig.body, store]);
  var dependencyVars = useMemo(function () {
    var _asyncConfig$dependen;
    var dependencyVars = {};
    asyncConfig == null || (_asyncConfig$dependen = asyncConfig.dependencies) == null || _asyncConfig$dependen.forEach(function (el) {
      dependencyVars[el] = asyncConfigParams == null ? void 0 : asyncConfigParams[el];
    });
    return dependencyVars;
  }, [asyncConfig == null ? void 0 : asyncConfig.dependencies, asyncConfigParams]);
  var dependencyBodyVars = useMemo(function () {
    var _asyncConfig$dependen2;
    var dependencyVars = {};
    asyncConfig == null || (_asyncConfig$dependen2 = asyncConfig.dependencies) == null || _asyncConfig$dependen2.forEach(function (el) {
      if (el != null && el.includes('.')) {
        // value path
        dependencyVars[el] = get(asyncConfigBodyData, el, null);
        return;
      }
      dependencyVars[el] = asyncConfigBodyData == null ? void 0 : asyncConfigBodyData[el];
      // dependencyVars[el] = asyncConfigBodyData?.[el];
    });
    return dependencyVars;
  }, [asyncConfig == null ? void 0 : asyncConfig.dependencies, asyncConfigBodyData]);
  // console.log("dependencyVars", dependencyVars);
  var fetchOptionList = getFetchOptionListFunc("" + ((_process$env = process.env[(_ref = (_asyncConfig$prefixEn = asyncConfig == null ? void 0 : asyncConfig.prefixEnvName) != null ? _asyncConfig$prefixEn : asyncConfig == null ? void 0 : asyncConfig.basicUrl) != null ? _ref : '']) != null ? _process$env : process.env.REACT_APP_API_GETWAY) + ((_asyncConfig$url = asyncConfig == null ? void 0 : asyncConfig.url) != null ? _asyncConfig$url : ''), "" + ((_asyncConfig$requestM = asyncConfig == null ? void 0 : asyncConfig.requestMethod) != null ? _asyncConfig$requestM : 'GET'), {
    params: asyncConfigParams,
    // params: dependencyVars,
    data: _extends({}, asyncConfigBodyData, {
      tenantId: tenant,
      domainName: domain
    })
  });
  // console.log("dependencyVars", dependencyVars, dependencyBodyVars);
  var keysToUse = Array.isArray(uniqueKey) ? uniqueKey : [uniqueKey];
  var _useQuery = useQuery([].concat(keysToUse, [dependencyVars, dependencyBodyVars]), function () {
      return fetchOptionList();
    }, {
      enabled: enabled,
      staleTime: Infinity,
      refetchOnWindowFocus: false,
      retry: false,
      select: function select(data) {
        var _Object$keys, _resData$data, _resData$data2;
        // console.log("select data: ", data);
        var allDependencyAreEmpty = ((_Object$keys = Object.keys(dependencyVars)) == null ? void 0 : _Object$keys.length) && Object.values(dependencyVars).every(function (value) {
          return !value;
        });
        var resData = allDependencyAreEmpty ? [] : data == null ? void 0 : data.data;
        if (Number(resData == null ? void 0 : resData.code) !== 200 || !(resData != null && resData.data) || (resData == null || (_resData$data = resData.data) == null ? void 0 : _resData$data.length) === 0) {
          return [];
        }
        if (!(asyncConfig != null && asyncConfig.valuePath)) {
          return [];
        }
        if (asyncConfig != null && asyncConfig.listDataPath) {
          var _listData;
          var listData = get(resData == null ? void 0 : resData.data, asyncConfig == null ? void 0 : asyncConfig.listDataPath, []);
          if (typeof listData === 'string') {
            listData = JSON.parse(listData);
          }
          console.log('listData---: ', listData);
          return (_listData = listData) == null || (_listData = _listData.filter(function (el) {
            var _asyncConfig$listFilt, _asyncConfig$listFilt2;
            if (!(asyncConfig != null && asyncConfig.listFilters) || (asyncConfig == null || (_asyncConfig$listFilt = asyncConfig.listFilters) == null ? void 0 : _asyncConfig$listFilt.length) === 0) return true;
            return asyncConfig == null || (_asyncConfig$listFilt2 = asyncConfig.listFilters) == null ? void 0 : _asyncConfig$listFilt2.every(function (_ref2) {
              var path = _ref2[0],
                val = _ref2[1],
                type = _ref2[2];
              return filterListDataByType(type, get(el, path), val);
            } // get(el, path) === val
            );
          })) == null ? void 0 : _listData.map(function (el) {
            return {
              label: get(el, asyncConfig == null ? void 0 : asyncConfig.labelPath),
              value: get(el, asyncConfig == null ? void 0 : asyncConfig.valuePath)
            };
          });
        }
        return resData == null || (_resData$data2 = resData.data) == null || (_resData$data2 = _resData$data2.filter(function (el) {
          var _asyncConfig$listFilt3, _asyncConfig$listFilt4;
          if (!(asyncConfig != null && asyncConfig.listFilters) || (asyncConfig == null || (_asyncConfig$listFilt3 = asyncConfig.listFilters) == null ? void 0 : _asyncConfig$listFilt3.length) === 0) return true;
          return asyncConfig == null || (_asyncConfig$listFilt4 = asyncConfig.listFilters) == null ? void 0 : _asyncConfig$listFilt4.every(function (_ref3) {
            var path = _ref3[0],
              val = _ref3[1],
              type = _ref3[2];
            return filterListDataByType(type, get(el, path), val);
          } // get(el, path) === val
          );
        })) == null ? void 0 : _resData$data2.map(function (el) {
          return {
            label: get(el, asyncConfig == null ? void 0 : asyncConfig.labelPath),
            value: get(el, asyncConfig == null ? void 0 : asyncConfig.valuePath)
          };
        });
      },
      onSuccess: function onSuccess(data) {
        if (!data) return;
        initialRequest.current = false;
      }
    }),
    resOptionList = _useQuery.data,
    isLoading = _useQuery.isLoading,
    remove = _useQuery.remove;
  useEffect(function () {
    if (!initialRequest.current) {
      dependencyVarsChangeRef.current = true;
    }
  }, [dependencyVars]); // dependencyBodyVars
  useEffect(function () {
    if (resOptionList === undefined || resOptionList === null) return;
    if (dependencyVarsChangeRef.current) {
      dependencyVarsChangeRef.current = false;
      funcs == null || funcs.onOptionsChangeAfterDependency == null || funcs.onOptionsChangeAfterDependency(resOptionList != null ? resOptionList : []);
    }
  }, [resOptionList]);
  useEffect(function () {
    return function () {
      if (!(asyncConfig != null && asyncConfig.keepQueryCache)) remove == null || remove();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  return {
    asyncConfigParams: asyncConfigParams,
    dependencyVars: dependencyVars,
    resOptionList: resOptionList,
    fetchLoading: isLoading && enabled
  };
};
var transformStateByDefinitions = function transformStateByDefinitions(formState, definition) {
  var _Object$entries;
  var newArr = (_Object$entries = Object.entries(formState != null ? formState : {})) == null ? void 0 : _Object$entries.map(function (_ref4) {
    var _definition$find$type, _definition$find, _ref5;
    var key = _ref4[0],
      val = _ref4[1];
    var type = (_definition$find$type = definition == null || (_definition$find = definition.find(function (el) {
      return (el == null ? void 0 : el.field) === key;
    })) == null ? void 0 : _definition$find.type) != null ? _definition$find$type : '';
    if (!((_ref5 = ['select', 'multi-select']) != null && _ref5.includes(type))) {
      return [key, val];
    }
    var newVal = Array.isArray(val) ? val : [val];
    return [key, newVal];
  });
  var newState = Object.fromEntries(newArr);
  console.log('newState: ', newState);
  return newState;
};

var _excluded$1 = ["schema", "id", "name", "options", "label", "hideLabel", "required", "disabled", "placeholder", "readonly", "value", "multiple", "autofocus", "onChange", "onBlur", "onFocus", "rawErrors", "registry", "uiSchema", "hideError", "formContext"];
/** The `SelectWidget` is a widget for rendering dropdowns.
 *  It is typically used with string properties constrained with enum options.
 *
 * @param props - The `WidgetProps` for this component
 */
function SelectWidget(props) {
  var _formContext$dynamicF, _uiSchema$uiMultiple, _uiSchema$uiMultiple2, _labelValue, _uiSchema$uiMaxLen, _value$length, _uiSchema$uiDescript, _uiSchema$uiReadonly;
  var schema = props.schema,
    id = props.id,
    name = props.name,
    options = props.options,
    label = props.label,
    hideLabel = props.hideLabel,
    required = props.required,
    disabled = props.disabled,
    placeholder = props.placeholder,
    readonly = props.readonly,
    value = props.value,
    onChange = props.onChange,
    _props$rawErrors = props.rawErrors,
    rawErrors = _props$rawErrors === void 0 ? [] : _props$rawErrors,
    uiSchema = props.uiSchema,
    formContext = props.formContext,
    textFieldProps = _objectWithoutPropertiesLoose(props, _excluded$1);
  // console.log("custom select -------------: ", name, options);
  var uniqueKey = name + "-unique-select";
  var formState = formContext == null ? void 0 : formContext["formState"];
  var extraState = formContext == null ? void 0 : formContext["extraState"];
  var dynamicFormContextQueryKey = (_formContext$dynamicF = formContext == null ? void 0 : formContext["dynamicFormContextQueryKey"]) != null ? _formContext$dynamicF : "";
  var asyncConfig = uiSchema == null ? void 0 : uiSchema["ui:asyncConfig"];
  var enumOptions = options.enumOptions;
  var enumOptionsFromDefinition = useMemo(function () {
    var _enumOptions$map;
    return (_enumOptions$map = enumOptions == null ? void 0 : enumOptions.map(function (el) {
      var _el$value;
      return {
        label: el == null ? void 0 : el.label,
        value: el == null || (_el$value = el.value) == null ? void 0 : _el$value.value
      };
    })) != null ? _enumOptions$map : [];
  }, [enumOptions]);
  var multiple = (_uiSchema$uiMultiple = uiSchema == null ? void 0 : uiSchema["ui:multiple"]) != null ? _uiSchema$uiMultiple : false;
  var multipleChip = (_uiSchema$uiMultiple2 = uiSchema == null ? void 0 : uiSchema["ui:multipleChip"]) != null ? _uiSchema$uiMultiple2 : false;
  var _useState = useState(multiple ? [] : null),
    autocompleteValue = _useState[0],
    setAutocompleteValue = _useState[1];
  var handleSingleInitValue = function handleSingleInitValue(optionList) {
    var newValue = optionList == null ? void 0 : optionList.find(function (el) {
      if (Array.isArray(value)) {
        return value == null ? void 0 : value.some(function (item) {
          return "" + item === "" + (el == null ? void 0 : el.value);
        });
      }
      if (typeof value !== "object") {
        return value && "" + (el == null ? void 0 : el.value) === "" + value;
      }
      return value && "" + (el == null ? void 0 : el.value) === "" + (value == null ? void 0 : value.value);
    });
    return newValue;
  };
  var handleMultiInitValue = function handleMultiInitValue(optionList) {
    var _value$map;
    if (!value) return [];
    // show old format value.
    if (!(Array != null && Array.isArray(value)) && (typeof value === "string" || typeof value === "number")) {
      return optionList == null ? void 0 : optionList.filter(function (el) {
        var _ref, _ref2;
        return ((_ref = "" + (el == null ? void 0 : el.value)) == null ? void 0 : _ref.toLowerCase()) === ((_ref2 = "" + value) == null ? void 0 : _ref2.toLowerCase());
      });
    }
    if (!(Array != null && Array.isArray(value)) || (value == null ? void 0 : value.length) === 0) {
      return [];
    }
    return value == null || (_value$map = value.map(function (item) {
      var res = optionList == null ? void 0 : optionList.find(function (el) {
        var _ref5, _ref6;
        if (typeof item !== "object") {
          var _ref3, _ref4;
          return item && ((_ref3 = "" + (el == null ? void 0 : el.value)) == null ? void 0 : _ref3.toLowerCase()) === ((_ref4 = "" + item) == null ? void 0 : _ref4.toLowerCase());
        }
        var some = value && ((_ref5 = "" + (el == null ? void 0 : el.value)) == null ? void 0 : _ref5.toLowerCase()) === ((_ref6 = "" + (item == null ? void 0 : item.value)) == null ? void 0 : _ref6.toLowerCase());
        return some;
      });
      return res;
    })) == null ? void 0 : _value$map.filter(function (el) {
      return !!el;
    });
  };
  var handleValueOnDependencyChange = function handleValueOnDependencyChange(data) {
    if (!multiple) {
      var _handledNewValue = handleSingleInitValue(data);
      var _newValue = _handledNewValue == null ? void 0 : _handledNewValue.value;
      onChange == null || onChange(_newValue ? _newValue : undefined);
      return;
    }
    var handledNewValue = handleMultiInitValue(data);
    var newValue = handledNewValue == null ? void 0 : handledNewValue.map(function (el) {
      return el == null ? void 0 : el.value;
    });
    onChange == null || onChange(newValue != null && newValue.length ? newValue : undefined);
  };
  var _useCustomSelect = useCustomSelect(asyncConfig, dynamicFormContextQueryKey ? [dynamicFormContextQueryKey, uniqueKey] : uniqueKey, {
      formState: formState,
      extraState: extraState
    }, !!(asyncConfig != null && asyncConfig.url), {
      onOptionsChangeAfterDependency: handleValueOnDependencyChange
    }),
    resOptionList = _useCustomSelect.resOptionList,
    fetchLoading = _useCustomSelect.fetchLoading;
  var optionList = useMemo(function () {
    return (resOptionList == null ? void 0 : resOptionList.length) > 0 ? resOptionList : enumOptionsFromDefinition || [];
  }, [enumOptionsFromDefinition, name, resOptionList]);
  // console.log(
  //   "custom select -------------optionList: ",
  //   name,
  //   autocompleteValue
  // );
  var handleValueChange = function handleValueChange(event, value, reason, details) {
    var _value$value, _newValue2;
    var newValue = (_value$value = value == null ? void 0 : value.value) != null ? _value$value : undefined;
    if (multiple) {
      newValue = value != null && value.length ? value.map(function (item) {
        return item.value;
      }) : undefined;
    }
    // console.log("newValue", newValue);
    onChange == null || onChange(newValue);
    if (!newValue || ((_newValue2 = newValue) == null ? void 0 : _newValue2.length) === 0) {
      setAutocompleteValue(multiple ? [] : null);
    }
  };
  useEffect(function () {
    if (!optionList ||
    // optionList?.length === 0 ||
    !value || Array.isArray(value) && (value == null ? void 0 : value.length) === 0) {
      return;
    }
    // fetch the option list init. Remake the value.
    // refresh the option list by dependencyVars. clean the value.
    if (!multiple) {
      var _newValue3 = handleSingleInitValue(optionList);
      // console.log("newValue: ", newValue);
      setAutocompleteValue(_newValue3 != null ? _newValue3 : null);
      // onChange?.(newValue ? newValue : undefined);
      return;
    }
    var newValue = handleMultiInitValue(optionList);
    setAutocompleteValue(newValue != null ? newValue : []);
    // onChange?.(newValue?.length ? newValue : undefined);
  }, [optionList, value]);
  return React.createElement(FormControl, null, React.createElement(CustomizedFormLabel, {
    label: (_labelValue = labelValue(label || undefined, hideLabel, false)) != null ? _labelValue : "",
    labelKey: uiSchema == null ? void 0 : uiSchema["ui:labelKey"],
    required: required,
    maxLen: (_uiSchema$uiMaxLen = uiSchema == null ? void 0 : uiSchema["ui:maxLen"]) != null ? _uiSchema$uiMaxLen : undefined,
    existLen: (_value$length = value == null ? void 0 : value.length) != null ? _value$length : 0,
    description: (_uiSchema$uiDescript = uiSchema == null ? void 0 : uiSchema["ui:description"]) != null ? _uiSchema$uiDescript : schema["description"],
    icon: uiSchema == null ? void 0 : uiSchema["ui:icon"],
    readonly: (_uiSchema$uiReadonly = uiSchema == null ? void 0 : uiSchema["ui:readonly"]) != null ? _uiSchema$uiReadonly : schema == null ? void 0 : schema["readOnly"],
    disabled: uiSchema == null ? void 0 : uiSchema["ui:disabled"]
  }), React.createElement(Autocomplete, {
    id: id,
    className: "custom-autocomplete",
    renderTags: function renderTags(selectedOptions) {
      var _selectedOptions$map;
      var tooltipLabel = (_selectedOptions$map = selectedOptions.map(function (el) {
        return el.label;
      })) == null ? void 0 : _selectedOptions$map.join("，");
      if (!multipleChip) {
        return React.createElement(Tooltip, {
          title: tooltipLabel,
          placement: "top"
        }, React.createElement(Chip, {
          label: (selectedOptions == null ? void 0 : selectedOptions.length) + " selected"
        }));
      }
      if (Array.isArray(selectedOptions)) {
        return selectedOptions == null ? void 0 : selectedOptions.map(function (el) {
          var _el$label;
          return React.createElement(Chip, {
            key: el == null ? void 0 : el.label,
            label: (_el$label = el == null ? void 0 : el.label) != null ? _el$label : "",
            deleteIcon: React.createElement(ClearIcon, null),
            disabled: disabled || fetchLoading || readonly,
            onDelete: function onDelete(ev) {
              var _selectedOptions$filt;
              if (disabled || fetchLoading || readonly) {
                return;
              }
              // console.log("delete chip", el?.label);
              var newVals = (_selectedOptions$filt = selectedOptions == null ? void 0 : selectedOptions.filter(function (item) {
                return (item == null ? void 0 : item.value) !== (el == null ? void 0 : el.value);
              })) != null ? _selectedOptions$filt : [];
              // console.log("newVals", newVals);
              if (!newVals || (newVals == null ? void 0 : newVals.length) === 0) {
                handleValueChange(ev, null);
                return;
              }
              handleValueChange(ev, newVals);
            }
          });
        });
      }
      return React.createElement(React.Fragment, null);
    },
    disabled: disabled || fetchLoading,
    readOnly: readonly,
    multiple: multiple,
    loading: fetchLoading,
    disableCloseOnSelect: !!multiple,
    value: autocompleteValue,
    // value={multiple ? value ?? [] : value ?? null}
    options: optionList,
    getOptionLabel: function getOptionLabel(option) {
      return (option == null ? void 0 : option.label) || "";
    },
    isOptionEqualToValue: function isOptionEqualToValue(option, value) {
      if (typeof value === "object" && "value" in value && value != null && value.value) return (option == null ? void 0 : option.value) === (value == null ? void 0 : value.value);
      var res = (option == null ? void 0 : option.value) === value;
      return res;
    },
    renderInput: function renderInput(params) {
      // console.log("renderInput params------: ", params);
      return React.createElement(TextField, Object.assign({}, params, {
        required: required,
        error: rawErrors.length > 0,
        placeholder: placeholder,
        InputProps: _extends({}, params == null ? void 0 : params.InputProps, {
          endAdornment: React.createElement(React.Fragment, null, fetchLoading ? React.createElement(InputAdornment, {
            position: "end"
          }, React.createElement(CircularProgress, {
            color: "inherit",
            size: 20
          })) : params == null ? void 0 : params.InputProps.endAdornment)
        }),
        inputProps: _extends({}, params.inputProps, {
          onKeyDown: function onKeyDown(e) {
            if (e.keyCode === 13) {
              e.preventDefault();
            }
          }
        })
      }));
    },
    onChange: handleValueChange,
    sx: {
      "& .MuiOutlinedInput-root": {
        padding: 0
      },
      "& .MuiTextField-root": {
        marginLeft: 0,
        marginTop: 0,
        marginBottom: 0
      },
      "& .MuiOutlinedInput-root .MuiAutocomplete-input": {
        border: "none"
      },
      "& .MuiFormControl-root .MuiInputBase-root input:focus": {
        outline: "none !important"
      },
      "& .MuiAutocomplete-inputRoot": {
        paddingLeft: "10px"
      },
      // "& .MuiAutocomplete-endAdornment": { top: "calc(50% - 12px)" },
      "& .MuiChip-root": {
        marginBottom: "0px !important",
        marginTop: "5px !important"
      }
    }
  }));
}

var _excluded$2 = ["value", "onChange", "options", "disabled", "disableInputValAsChip", "catchInputValAsChipOnBlur", "inputRenderVariant", "optionTooltip"];
var ChipsInputWithOptionsList = function ChipsInputWithOptionsList(_ref) {
  var _value$map;
  var _ref$value = _ref.value,
    value = _ref$value === void 0 ? [] : _ref$value,
    _onChange = _ref.onChange,
    _ref$options = _ref.options,
    options = _ref$options === void 0 ? [] : _ref$options,
    disabled = _ref.disabled,
    _ref$disableInputValA = _ref.disableInputValAsChip,
    disableInputValAsChip = _ref$disableInputValA === void 0 ? false : _ref$disableInputValA,
    _ref$catchInputValAsC = _ref.catchInputValAsChipOnBlur,
    catchInputValAsChipOnBlur = _ref$catchInputValAsC === void 0 ? false : _ref$catchInputValAsC,
    inputRenderVariant = _ref.inputRenderVariant,
    _ref$optionTooltip = _ref.optionTooltip,
    optionTooltip = _ref$optionTooltip === void 0 ? false : _ref$optionTooltip,
    otherProps = _objectWithoutPropertiesLoose(_ref, _excluded$2);
  var _useState = useState(""),
    inputValue = _useState[0],
    setInputValue = _useState[1];
  // console.log("ChipsInputWithOptionsList otherProps: ", otherProps)
  // useEffect(() => {
  //   // 当value prop改变时，重置inputValue
  //   setInputValue('');
  // }, [value]);
  var handleDelete = function handleDelete(chipToDelete) {
    value && (_onChange == null ? void 0 : _onChange(value == null ? void 0 : value.filter(function (chip) {
      return chip !== chipToDelete;
    })));
  };
  var handleInputChange = function handleInputChange(event, newInputValue) {
    setInputValue(newInputValue);
  };
  var handleKeyDown = function handleKeyDown(event) {
    if (event.key === "Enter" && inputValue && value && !value.includes(inputValue)) {
      event.preventDefault();
      event == null || event.stopPropagation();
      console.log("compValue: 11111");
      if (disableInputValAsChip) {
        console.log("compValue: 22222");
        // can not set input text as one chip.
        setInputValue("");
        return;
      }
      console.log("compValue: 33333");
      // 添加新的chip并重置inputValue
      _onChange == null || _onChange([].concat(value != null ? value : [], [inputValue]));
      setInputValue("");
    }
  };
  var handleInputBlur = function handleInputBlur(event) {
    if (catchInputValAsChipOnBlur && inputValue && (!value || !value.includes(inputValue))) {
      event.preventDefault();
      event == null || event.stopPropagation();
      if (disableInputValAsChip) {
        // can not set input text as one chip.
        setInputValue("");
        return;
      }
      // 添加新的chip并重置inputValue
      _onChange == null || _onChange([].concat(value != null ? value : [], [inputValue]));
      setInputValue("");
    }
  };
  var handleClear = function handleClear() {
    _onChange == null || _onChange([]);
  };
  // console.log("ChipsInputWithOptionsList: ", value);
  return React.createElement(Autocomplete, Object.assign({
    multiple: true,
    id: "tags-filled",
    options: options,
    getOptionLabel: function getOptionLabel(option) {
      if (option && typeof option === "object" && "label" in option) return option == null ? void 0 : option.label;
      return option;
    },
    // value={value ?? []}
    value: (_value$map = value == null ? void 0 : value.map(function (val) {
      var target = options == null ? void 0 : options.find(function (option) {
        return option.value === val;
      });
      if (target) return target;
      return val;
    })) != null ? _value$map : [],
    inputValue: inputValue,
    onInputChange: handleInputChange,
    onKeyDown: handleKeyDown,
    onBlur: handleInputBlur,
    freeSolo: true,
    size: "small",
    fullWidth: true,
    disabled: disabled,
    clearIcon: React.createElement(React.Fragment, null),
    filterOptions: function filterOptions(options, params) {
      var filtered = options.filter(function (option) {
        var _option$label, _params$inputValue;
        if (option && typeof option === "object" && "label" in option) return option == null || (_option$label = option.label) == null || (_option$label = _option$label.toLowerCase()) == null ? void 0 : _option$label.includes((_params$inputValue = params.inputValue) == null ? void 0 : _params$inputValue.toLowerCase());
        return false;
      });
      return filtered;
    },
    renderTags: function renderTags(tagValue, getTagProps) {
      return tagValue.map(function (option, index) {
        var label = option,
          value = option;
        if (option && typeof option === "object" && "label" in option) {
          label = option == null ? void 0 : option.label;
          value = option == null ? void 0 : option.value;
        }
        return React.createElement(Chip, Object.assign({
          variant: "outlined",
          "data-testid": "Chip",
          size: "small",
          label: label
        }, getTagProps({
          index: index
        }), {
          onDelete: function onDelete() {
            return handleDelete(value);
          },
          sx: {
            "& .MuiChip-label": {
              textTransform: "none !important"
            }
          }
        }));
      });
    },
    renderInput: function renderInput(params) {
      var _otherProps$placehold;
      return React.createElement(TextField, Object.assign({}, params, {
        "data-testid": "TextField",
        // label="Movie"
        size: "small",
        variant: inputRenderVariant,
        sx: {
          "& .MuiInputBase-input": {
            minWidth: "0 !important",
            width: "0 !important"
          }
        },
        onKeyDown: handleKeyDown,
        onBlur: handleInputBlur,
        placeholder: (_otherProps$placehold = otherProps == null ? void 0 : otherProps.placeholder) != null ? _otherProps$placehold : "",
        InputProps: _extends({}, params.InputProps, {
          endAdornment: React.createElement(React.Fragment, null, value && (value == null ? void 0 : value.length) > 0 && !disabled && React.createElement(InputAdornment, {
            position: "end"
          }, React.createElement(IconButton, {
            onClick: handleClear
          }, React.createElement(ClearIcon, null))), params.InputProps.endAdornment)
        })
      }));
    },
    onChange: function onChange(event, newValue) {
      var _newVal$map;
      // console.log("onChange: ", newValue);
      var newVal = newValue;
      _onChange == null || _onChange((_newVal$map = newVal == null ? void 0 : newVal.map(function (el) {
        if (typeof el === "object" && "value" in el) return el == null ? void 0 : el.value;
        return el;
      })) != null ? _newVal$map : []);
    },
    renderOption: function renderOption(props, options, state, ownerState) {
      var _options$label;
      // if (!optionTooltip) {
      //   return (
      //     <MenuItem
      //       {...props}
      //       selected={state?.selected}
      //     >
      //       <Typography
      //         sx={{
      //           textOverflow: "ellipsis",
      //           overflow: "hidden",
      //           whiteSpace: "nowrap",
      //           width: "100%",
      //         }}
      //       >
      //         {typeof options === "string" ? options : options?.label}
      //       </Typography>
      //     </MenuItem>
      //   );
      // }
      return React.createElement(Tooltip, {
        disableFocusListener: !optionTooltip,
        disableHoverListener: !optionTooltip,
        disableTouchListener: !optionTooltip,
        title: typeof options === "string" ? options : (_options$label = options == null ? void 0 : options.label) != null ? _options$label : "",
        leaveTouchDelay: 0,
        disableInteractive: true
      }, React.createElement(MenuItem, Object.assign({}, props, {
        selected: state == null ? void 0 : state.selected
      }), React.createElement(Typography, {
        sx: {
          textOverflow: "ellipsis",
          overflow: "hidden",
          whiteSpace: "nowrap",
          width: "100%"
        }
      }, typeof options === "string" ? options : options == null ? void 0 : options.label)));
    },
    slotProps: {
      paper: {
        sx: {
          minWidth: 160
        }
      }
    }
  }, otherProps));
};

var _excluded$3 = ["id", "name", "placeholder", "required", "readonly", "disabled", "type", "label", "hideLabel", "value", "onChange", "onChangeOverride", "onBlur", "onFocus", "autofocus", "options", "schema", "uiSchema", "rawErrors", "formContext", "registry", "InputLabelProps"],
  _excluded2$1 = ["step", "min", "max"];
var TYPES_THAT_SHRINK_LABEL$1 = ["date", "datetime-local", "file", "time"];
/** The `BaseInputTemplate` is the template to use to render the basic `<input>` component for the `core` theme.
 * It is used as the template for rendering many of the <input> based widgets that differ by `type` and callbacks only.
 * It can be customized/overridden for other themes or individual implementations as needed.
 *
 * @param props - The `WidgetProps` for this template
 */
function CustomChipsInput(props) {
  var _labelValue, _uiSchema$uiMaxLen, _value$length, _uiSchema$uiDescript, _uiSchema$uiReadonly, _ref, _uiOptions$customOpti;
  var id = props.id,
    placeholder = props.placeholder,
    required = props.required,
    readonly = props.readonly,
    disabled = props.disabled,
    type = props.type,
    label = props.label,
    hideLabel = props.hideLabel,
    value = props.value,
    onChange = props.onChange,
    autofocus = props.autofocus,
    options = props.options,
    schema = props.schema,
    uiSchema = props.uiSchema,
    InputLabelProps = props.InputLabelProps,
    textFieldProps = _objectWithoutPropertiesLoose(props, _excluded$3);
  // console.log("name: ", name, "uiSchema: ", uiSchema, "schema: ", schema);
  var inputProps = getInputProps(schema, type, options);
  var uiOptions = getUiOptions(uiSchema);
  // Now we need to pull out the step, min, max into an inner `inputProps` for material-ui
  var step = inputProps.step,
    min = inputProps.min,
    max = inputProps.max,
    rest = _objectWithoutPropertiesLoose(inputProps, _excluded2$1);
  var otherProps = _extends({
    inputProps: _extends({
      step: step,
      min: min,
      max: max
    }, schema.examples ? {
      list: examplesId(id)
    } : undefined)
  }, rest);
  var _onChange = function _onChange(value) {
    console.log("custom chips input _onchange: ", value);
    onChange(!value || (value == null ? void 0 : value.length) === 0 ? options.emptyValue : value);
  };
  var DisplayInputLabelProps = TYPES_THAT_SHRINK_LABEL$1.includes(type) ? _extends({}, InputLabelProps, {
    shrink: true
  }) : InputLabelProps;
  // console.log(
  //   "custom chips input value: ====================",
  //   id,
  //   name,
  //   value,
  //   "inputProps, ",
  //   inputProps,
  //   "uiSchema options: ",
  //   uiOptions?.["customOptions"],
  //   "uiOptions: ", uiOptions
  // );
  return React.createElement(FormControl, {
    sx: {
      "& .MuiChip-root": {
        marginTop: "5px !important"
      }
    }
  }, React.createElement(CustomizedFormLabel, {
    label: (_labelValue = labelValue(label || undefined, hideLabel, false)) != null ? _labelValue : "",
    labelKey: uiSchema == null ? void 0 : uiSchema["ui:labelKey"],
    required: required,
    maxLen: (_uiSchema$uiMaxLen = uiSchema == null ? void 0 : uiSchema["ui:maxLen"]) != null ? _uiSchema$uiMaxLen : undefined,
    existLen: (_value$length = value == null ? void 0 : value.length) != null ? _value$length : 0,
    description: (_uiSchema$uiDescript = uiSchema == null ? void 0 : uiSchema["ui:description"]) != null ? _uiSchema$uiDescript : schema == null ? void 0 : schema["description"],
    icon: uiSchema == null ? void 0 : uiSchema["ui:icon"],
    readonly: (_uiSchema$uiReadonly = uiSchema == null ? void 0 : uiSchema["ui:readonly"]) != null ? _uiSchema$uiReadonly : schema == null ? void 0 : schema["readOnly"],
    disabled: uiSchema == null ? void 0 : uiSchema["ui:disabled"]
  }), React.createElement(ChipsInputWithOptionsList, Object.assign({
    id: id,
    // name={name}
    placeholder: (_ref = placeholder != null ? placeholder : uiSchema == null ? void 0 : uiSchema["ui:placeholder"]) != null ? _ref : "",
    // label={labelValue(label || undefined, hideLabel, false)}
    autoFocus: autofocus,
    // required={required}
    disabled: disabled || readonly
  }, otherProps, {
    value: value != null ? value : [],
    options: (_uiOptions$customOpti = uiOptions == null ? void 0 : uiOptions["customOptions"]) != null ? _uiOptions$customOpti : undefined,
    // error={rawErrors.length > 0}
    onChange: _onChange,
    // onBlur={_onBlur as any}
    // onFocus={_onFocus as any}
    size: (uiSchema == null ? void 0 : uiSchema["ui:size"]) || (uiOptions == null ? void 0 : uiOptions["ui:size"]) || "medium",
    catchInputValAsChipOnBlur: (uiSchema == null ? void 0 : uiSchema["ui:catchInputValAsChipOnBlur"]) || (uiOptions == null ? void 0 : uiOptions["ui:catchInputValAsChipOnBlur"])
  })));
}

/* eslint-disable @typescript-eslint/no-explicit-any */
/** The `DescriptionField` is the template to use to render the description of a field
 *
 * @param props - The `DescriptionFieldProps` for this component
 */
function DescriptionField(props) {
  var id = props.id,
    description = props.description;
  if (description) {
    return React.createElement(Typography$1, {
      id: id,
      variant: "subtitle2",
      sx: {
        marginTop: "5px",
        textAlign: "left",
        pl: 1,
        display: "none"
      }
    }, description);
  }
  return null;
}

/* eslint-disable @typescript-eslint/no-explicit-any */
/** The `FieldErrorTemplate` component renders the errors local to the particular field
 *
 * @param props - The `FieldErrorProps` for the errors being rendered
 */
function FieldErrorTemplate(props) {
  var _errors$filter;
  var _props$errors = props.errors,
    errors = _props$errors === void 0 ? [] : _props$errors,
    idSchema = props.idSchema;
  if (errors.length === 0) {
    return null;
  }
  var id = errorId(idSchema);
  // console.log("errors: ", errors);
  return React.createElement(List, {
    dense: true,
    disablePadding: true,
    className: "form-error-list"
  }, errors == null || (_errors$filter = errors.filter(function (el) {
    return !!el;
  })) == null ? void 0 : _errors$filter.map(function (error, i) {
    return React.createElement(ListItem, {
      key: i,
      disableGutters: true
    }, React.createElement(FormHelperText, {
      id: id
    }, error));
  }));
}

/* eslint-disable @typescript-eslint/no-explicit-any */
/** The `TitleField` is the template to use to render the title of a field
 *
 * @param props - The `TitleFieldProps` for this component
 */
function TitleField(_ref) {
  var id = _ref.id,
    title = _ref.title;
  // console.log("title: ", title)
  return React.createElement(Box$1, {
    id: id,
    my: 1
  }, React.createElement(Typography$1, {
    variant: 'h5'
  }, title));
}

var _excluded$4 = ["schema", "label", "hideLabel", "id", "name", "disabled", "options", "value", "autofocus", "readonly", "required", "onChange", "onBlur", "onFocus", "formContext", "uiSchema"];
/** The `CheckboxesWidget` is a widget for rendering checkbox groups.
 *  It is typically used to represent an array of enums.
 *
 * @param props - The `WidgetProps` for this component
 */
function CheckboxesWidget(_ref) {
  var _formContext$dynamicF, _labelValue, _uiSchema$uiDescript, _uiSchema$uiReadonly;
  var schema = _ref.schema,
    label = _ref.label,
    hideLabel = _ref.hideLabel,
    id = _ref.id,
    name = _ref.name,
    disabled = _ref.disabled,
    options = _ref.options,
    value = _ref.value,
    autofocus = _ref.autofocus,
    readonly = _ref.readonly,
    required = _ref.required,
    onChange = _ref.onChange,
    formContext = _ref.formContext,
    uiSchema = _ref.uiSchema,
    otherProps = _objectWithoutPropertiesLoose(_ref, _excluded$4);
  var uniqueKey = name + "-unique-select";
  var formState = formContext == null ? void 0 : formContext['formState'];
  var extraState = formContext == null ? void 0 : formContext['extraState'];
  var dynamicFormContextQueryKey = (_formContext$dynamicF = formContext == null ? void 0 : formContext['dynamicFormContextQueryKey']) != null ? _formContext$dynamicF : '';
  var asyncConfig = uiSchema == null ? void 0 : uiSchema['ui:asyncConfig'];
  var enumOptions = options.enumOptions,
    _options$inline = options.inline,
    inline = _options$inline === void 0 ? true : _options$inline;
  var _useState = useState([]),
    checkboxesValue = _useState[0],
    setCheckboxesValue = _useState[1];
  var enumOptionsFromDefinition = useMemo(function () {
    var _enumOptions$map;
    return (_enumOptions$map = enumOptions == null ? void 0 : enumOptions.map(function (el) {
      var _el$value;
      return {
        label: el == null ? void 0 : el.label,
        value: el == null || (_el$value = el.value) == null ? void 0 : _el$value.value
      };
    })) != null ? _enumOptions$map : [];
  }, [enumOptions]);
  var _useCustomSelect = useCustomSelect(asyncConfig, dynamicFormContextQueryKey ? [dynamicFormContextQueryKey, uniqueKey] : uniqueKey, {
      formState: formState,
      extraState: extraState
    }, !!(asyncConfig != null && asyncConfig.url)),
    resOptionList = _useCustomSelect.resOptionList;
  var optionList = useMemo(function () {
    return (resOptionList == null ? void 0 : resOptionList.length) > 0 ? resOptionList : enumOptionsFromDefinition || [];
  }, [enumOptionsFromDefinition, name, resOptionList]);
  var enumOptionsSelectValue = function enumOptionsSelectValue(valueIndex, selected, allOptions) {
    var option = allOptions.find(function (_, index) {
      return valueIndex === index;
    });
    if (!isNil(option)) {
      return [].concat(selected, [option]).map(function (item) {
        return item.value;
      });
    }
  };
  var enumOptionsDeselectValue = function enumOptionsDeselectValue(valueIndex, selected, allOptions) {
    var option = allOptions.find(function (_, index) {
      return valueIndex === index;
    });
    if (!isNil(option)) {
      return selected.filter(function (item) {
        return item.value !== option.value;
      }).map(function (item) {
        return item.value;
      });
    }
  };
  var handleValueChange = function handleValueChange(index) {
    return function (_ref2) {
      var checked = _ref2.target.checked;
      if (checked) {
        var newValue = enumOptionsSelectValue(index, checkboxesValue, optionList);
        onChange(newValue);
      } else {
        var _newValue = enumOptionsDeselectValue(index, checkboxesValue, optionList);
        onChange(_newValue != null && _newValue.length ? _newValue : undefined);
        if (!_newValue || (_newValue == null ? void 0 : _newValue.length) === 0) {
          setCheckboxesValue([]);
        }
      }
    };
  };
  var handleMultiInitValue = function handleMultiInitValue(optionList) {
    var _value$map;
    if (!value) return [];
    // show old format value.
    if (!(Array != null && Array.isArray(value)) && (typeof value === 'string' || typeof value === 'number')) {
      return optionList == null ? void 0 : optionList.filter(function (el) {
        var _ref3, _ref4;
        return ((_ref3 = "" + (el == null ? void 0 : el.value)) == null ? void 0 : _ref3.toLowerCase()) === ((_ref4 = "" + value) == null ? void 0 : _ref4.toLowerCase());
      });
    }
    if (!(Array != null && Array.isArray(value)) || (value == null ? void 0 : value.length) === 0) {
      return [];
    }
    return value == null || (_value$map = value.map(function (item) {
      var res = optionList == null ? void 0 : optionList.find(function (el) {
        var _ref7, _ref8;
        if (typeof item !== 'object') {
          var _ref5, _ref6;
          return item && ((_ref5 = "" + (el == null ? void 0 : el.value)) == null ? void 0 : _ref5.toLowerCase()) === ((_ref6 = "" + item) == null ? void 0 : _ref6.toLowerCase());
        }
        var some = value && ((_ref7 = "" + (el == null ? void 0 : el.value)) == null ? void 0 : _ref7.toLowerCase()) === ((_ref8 = "" + (item == null ? void 0 : item.value)) == null ? void 0 : _ref8.toLowerCase());
        return some;
      });
      return res;
    })) == null ? void 0 : _value$map.filter(function (el) {
      return !!el;
    });
  };
  useEffect(function () {
    if (!optionList ||
    // optionList?.length === 0 ||
    !value || Array.isArray(value) && (value == null ? void 0 : value.length) === 0) {
      return;
    }
    var newValue = handleMultiInitValue(optionList);
    setCheckboxesValue(newValue != null ? newValue : []);
  }, [optionList, value]);
  return React.createElement(FormControl, null, React.createElement(CustomizedFormLabel, {
    label: (_labelValue = labelValue(label || undefined, hideLabel, false)) != null ? _labelValue : '',
    labelKey: uiSchema == null ? void 0 : uiSchema['ui:labelKey'],
    required: required,
    description: (_uiSchema$uiDescript = uiSchema == null ? void 0 : uiSchema['ui:description']) != null ? _uiSchema$uiDescript : schema['description'],
    icon: uiSchema == null ? void 0 : uiSchema['ui:icon'],
    readonly: (_uiSchema$uiReadonly = uiSchema == null ? void 0 : uiSchema['ui:readonly']) != null ? _uiSchema$uiReadonly : schema == null ? void 0 : schema['readOnly'],
    disabled: uiSchema == null ? void 0 : uiSchema['ui:disabled']
  }), React.createElement(FormGroup, {
    id: id,
    row: !!inline
  }, Array.isArray(optionList) && optionList.map(function (option, index) {
    var checked = checkboxesValue.some(function (item) {
      return item.value === option.value;
    });
    var checkbox = React.createElement(Checkbox, {
      id: optionId(id, index),
      name: id,
      checked: checked,
      disabled: disabled || readonly,
      autoFocus: autofocus && index === 0,
      onChange: handleValueChange(index),
      "aria-describedby": ariaDescribedByIds(id)
    });
    return React.createElement(FormControlLabel, {
      control: checkbox,
      key: index,
      label: option.label
    });
  })));
}

/** The `CheckBoxWidget` is a widget for rendering boolean properties.
 *  It is typically used to represent a boolean.
 *
 * @param props - The `WidgetProps` for this component
 */
function CheckboxWidget(props) {
  var _labelValue, _uiSchema$uiDescript, _uiSchema$uiReadonly;
  var schema = props.schema,
    id = props.id,
    value = props.value,
    disabled = props.disabled,
    required = props.required,
    readonly = props.readonly,
    _props$label = props.label,
    label = _props$label === void 0 ? '' : _props$label,
    hideLabel = props.hideLabel,
    autofocus = props.autofocus,
    onChange = props.onChange,
    uiSchema = props.uiSchema;
  // Because an unchecked checkbox will cause html5 validation to fail, only add
  // the "required" attribute if the field value must be "true", due to the
  // "const" or "enum" keywords
  var _onChange = function _onChange(_, checked) {
    return onChange(checked);
  };
  return React.createElement(FormControl, null, React.createElement(CustomizedFormLabel, {
    label: (_labelValue = labelValue(label || undefined, hideLabel, false)) != null ? _labelValue : '',
    labelKey: uiSchema == null ? void 0 : uiSchema['ui:labelKey'],
    required: required,
    description: (_uiSchema$uiDescript = uiSchema == null ? void 0 : uiSchema['ui:description']) != null ? _uiSchema$uiDescript : schema['description'],
    icon: uiSchema == null ? void 0 : uiSchema['ui:icon'],
    readonly: (_uiSchema$uiReadonly = uiSchema == null ? void 0 : uiSchema['ui:readonly']) != null ? _uiSchema$uiReadonly : schema == null ? void 0 : schema['readOnly'],
    disabled: uiSchema == null ? void 0 : uiSchema['ui:disabled']
  }), React.createElement(FormControlLabel, {
    control: React.createElement(Checkbox, {
      id: id,
      name: id,
      checked: typeof value === 'undefined' ? false : Boolean(value),
      disabled: disabled || readonly,
      autoFocus: autofocus,
      onChange: _onChange
    }),
    label: ''
  }));
}

function CustomDateWidget(props) {
  var _labelValue, _uiSchema$uiDescript, _uiSchema$uiReadonly;
  console.log("CustomDateWidget: ", props);
  var uiSchema = props.uiSchema,
    schema = props.schema,
    _onChange2 = props.onChange,
    value = props.value;
  var label = props.label,
    hideLabel = props.hideLabel,
    required = props.required,
    disabled = props.disabled,
    readonly = props.readonly,
    placeholder = props.placeholder,
    _props$rawErrors = props.rawErrors,
    rawErrors = _props$rawErrors === void 0 ? [] : _props$rawErrors;
  var _React$useState = React.useState(false),
    open = _React$useState[0],
    setOpen = _React$useState[1];
  var handleOpen = function handleOpen(status) {
    if (status && (readonly || disabled)) return;
    setOpen(status);
  };
  var dateFormat = "DD/MMM/YYYY";
  return React.createElement(FormControl, null, React.createElement(CustomizedFormLabel, {
    label: (_labelValue = labelValue(label || undefined, hideLabel, false)) != null ? _labelValue : "",
    labelKey: uiSchema == null ? void 0 : uiSchema["ui:labelKey"],
    required: required,
    description: (_uiSchema$uiDescript = uiSchema == null ? void 0 : uiSchema["ui:description"]) != null ? _uiSchema$uiDescript : schema["description"],
    icon: uiSchema == null ? void 0 : uiSchema["ui:icon"],
    readonly: (_uiSchema$uiReadonly = uiSchema == null ? void 0 : uiSchema["ui:readonly"]) != null ? _uiSchema$uiReadonly : schema == null ? void 0 : schema["readOnly"],
    disabled: uiSchema == null ? void 0 : uiSchema["ui:disabled"]
  }), React.createElement(LocalizationProvider, {
    dateAdapter: AdapterDayjs
  }, React.createElement(DatePicker, {
    className: "custom-date-picker",
    inputFormat: dateFormat,
    value: value != null ? value : "",
    onChange: function onChange(newVal) {
      _onChange2 == null || _onChange2(dayjs(newVal).format(dateFormat));
    },
    open: open,
    onOpen: function onOpen() {
      return handleOpen(true);
    },
    onClose: function onClose() {
      return handleOpen(false);
    },
    minDate: uiSchema == null ? void 0 : uiSchema.minDate,
    maxDate: uiSchema == null ? void 0 : uiSchema.maxDate,
    disabled: disabled,
    readOnly: readonly,
    renderInput: function renderInput(params) {
      return React.createElement(TextField, Object.assign({}, params, {
        inputProps: _extends({}, params.inputProps, {
          value: value ? dayjs(value).format(dateFormat) : "",
          readOnly: true,
          placeholder: placeholder != null ? placeholder : "Select Date"
        }),
        error: rawErrors.length > 0,
        size: "small",
        onClick: function onClick() {
          return handleOpen(true);
        },
        InputProps: {
          endAdornment: React.createElement(InputAdornment, {
            position: "end"
          }, value && React.createElement(HighlightOffOutlinedIcon, {
            onClick: function onClick(ev) {
              ev.preventDefault();
              ev.stopPropagation();
              if (disabled) {
                return;
              } else {
                _onChange2(undefined);
              }
            },
            sx: {
              marginX: "5px",
              fontSize: "14px",
              color: "GrayText",
              "&:hover": disabled ? {} : {
                color: "Highlight",
                cursor: "pointer"
              }
            }
          }), React.createElement(IconButton, {
            size: "small",
            sx: {
              borderRadius: "50%"
            },
            disabled: disabled
          }, React.createElement(CalendarMonthOutlinedIcon, {
            sx: {
              fontSize: "16px",
              color: "GrayText",
              "&:hover": {
                color: "Highlight"
              }
            }
          })))
        }
      }));
    }
  })));
}

var convertTextSchema = function convertTextSchema(schema, data, forceDisable) {
  if (forceDisable === void 0) {
    forceDisable = false;
  }
  // console.log("convertTextSchema", data);
  if (!data || !(data != null && data.field)) {
    return schema;
  }
  var fieldJsonSchema = {
    type: 'string'
  };
  var fieldUiSchema = {
    'ui:size': 'small'
  };
  var fieldZodSchema = string({
    required_error: ''
  });
  // parse the json schema
  // if (data?.readonly) fieldJsonSchema["readOnly"] = true;
  fieldJsonSchema['title'] = (data == null ? void 0 : data.label) || (data == null ? void 0 : data.originlabel);
  if (data != null && data.description) fieldJsonSchema['description'] = data == null ? void 0 : data.description;
  // parse the zodSchema
  if ((data == null ? void 0 : data.minLen) !== undefined) fieldZodSchema = fieldZodSchema.min(data == null ? void 0 : data.minLen, "no less than " + (data == null ? void 0 : data.minLen));
  if (data != null && data.maxLen) fieldZodSchema = fieldZodSchema.max(data == null ? void 0 : data.maxLen, "no longer than " + (data == null ? void 0 : data.maxLen));
  if (data != null && data.pattern) fieldZodSchema = fieldZodSchema.refine(function (str) {
    var reg = new RegExp(data.pattern, 'g');
    return reg.test(str);
  }, 'format error');
  if (!(data != null && data.required)) fieldZodSchema = fieldZodSchema.optional().nullable();
  // parse the uiSchema
  if (data != null && data.disabled || forceDisable) fieldUiSchema['ui:disabled'] = true;
  // if (data?.description) fieldUiSchema["ui:description"] = data.description;
  if (data != null && data.placeholder) fieldUiSchema['ui:placeholder'] = data.placeholder;
  if (data != null && data.size) fieldUiSchema['ui:size'] = data == null ? void 0 : data.size;
  if (data != null && data.textArea) fieldUiSchema['ui:widget'] = 'textarea';
  if (data != null && data.maxRows) fieldUiSchema['ui:rows'] = data == null ? void 0 : data.maxRows;
  if (data != null && data.field_xs) fieldUiSchema['ui:field_xs'] = data == null ? void 0 : data.field_xs;
  if (data != null && data.field_xl) fieldUiSchema['ui:field_xl'] = data == null ? void 0 : data.field_xl;
  if (data != null && data.field_md) fieldUiSchema['ui:field_md'] = data == null ? void 0 : data.field_md;
  if (data != null && data.field_lg) fieldUiSchema['ui:field_lg'] = data == null ? void 0 : data.field_lg;
  if (data != null && data.minLen) fieldUiSchema['ui:minLen'] = data == null ? void 0 : data.minLen;
  if (data != null && data.maxLen) fieldUiSchema['ui:maxLen'] = data == null ? void 0 : data.maxLen;
  if (data != null && data.icon) fieldUiSchema['ui:icon'] = data == null ? void 0 : data.icon;
  if (data != null && data.labelKey) {
    fieldUiSchema['ui:labelKey'] = !(data != null && data.label) || (data == null ? void 0 : data.label) === (data == null ? void 0 : data.originlabel) ? data == null ? void 0 : data.labelKey : '';
  }
  if (data != null && data.readonly) fieldUiSchema['ui:readonly'] = data == null ? void 0 : data.readonly;
  var producer = produce(function (draft) {
    var _draft$zodSchema, _z$object;
    draft.zodSchema = (_draft$zodSchema = draft.zodSchema) == null ? void 0 : _draft$zodSchema.merge(object((_z$object = {}, _z$object[data.field] = fieldZodSchema, _z$object)));
    if (draft.jsonSchema.properties && fieldJsonSchema) {
      var _cloneDeep;
      draft.jsonSchema.properties[data.field] = _extends({}, (_cloneDeep = cloneDeep(draft.jsonSchema.properties[data.field])) != null ? _cloneDeep : {}, fieldJsonSchema);
    }
    if (fieldUiSchema) {
      var _extends2;
      draft.uiSchema = _extends({}, draft.uiSchema, (_extends2 = {}, _extends2[data.field] = fieldUiSchema, _extends2));
    }
    if (data != null && data.required) {
      var _draft$jsonSchema$req;
      (_draft$jsonSchema$req = draft.jsonSchema.required) == null || _draft$jsonSchema$req.push(data.field);
    }
  });
  var nextSchema = producer(schema);
  // console.log("nextSchema", nextSchema);
  return nextSchema;
};
var convertChipsSchema = function convertChipsSchema(schema, data, forceDisable) {
  var _data$options;
  if (forceDisable === void 0) {
    forceDisable = false;
  }
  // console.log("convertTextSchema", data);
  if (!data || !(data != null && data.field)) {
    return schema;
  }
  var fieldJsonSchema = {
    type: ['string', 'array', 'object', 'number'],
    items: {
      type: ['string', 'object', 'number'],
      properties: {
        value: {
          type: 'number'
        },
        label: {
          type: 'string'
        }
      }
    },
    properties: {
      value: {
        type: 'number'
      },
      label: {
        type: 'string'
      }
    }
  };
  var fieldUiSchema = {
    'ui:size': 'small',
    'ui:widget': 'CustomChipsInput'
  };
  var fieldZodSchema = undefined$1({
    required_error: ''
  }).or(number({
    required_error: ''
  })).or(string({
    required_error: ''
  })).or(object({})).or(array(string().or(object({})), {
    required_error: ''
  }));
  // parse the json schema
  // if (data?.readonly) fieldJsonSchema["readOnly"] = true;
  fieldJsonSchema['title'] = (data == null ? void 0 : data.label) || (data == null ? void 0 : data.originlabel);
  if (data != null && data.description) fieldJsonSchema['description'] = data == null ? void 0 : data.description;
  // parse the zodSchema
  if ((data == null ? void 0 : data.max) !== undefined) {
    fieldZodSchema = fieldZodSchema.refine(function (vals) {
      return (vals == null ? void 0 : vals.length) <= (data == null ? void 0 : data.max);
    }, 'over max limits');
  }
  if (!(data != null && data.required)) fieldZodSchema = fieldZodSchema.optional().nullable();
  // parse the uiSchema
  if (data != null && data.options && (data == null || (_data$options = data.options) == null ? void 0 : _data$options.length) > 0) {
    // console.log("chips convert: ", data?.options);
    fieldUiSchema['ui:customOptions'] = data == null ? void 0 : data.options;
  }
  if (data != null && data.disabled || forceDisable) fieldUiSchema['ui:disabled'] = true;
  // if (data?.description) fieldUiSchema["ui:description"] = data.description;
  if (data != null && data.placeholder) fieldUiSchema['ui:placeholder'] = data.placeholder;
  if (data != null && data.size) fieldUiSchema['ui:size'] = data == null ? void 0 : data.size;
  if (data != null && data.max) fieldUiSchema['ui:max'] = data == null ? void 0 : data.max;
  if (data != null && data.field_xs) fieldUiSchema['ui:field_xs'] = data == null ? void 0 : data.field_xs;
  if (data != null && data.field_xl) fieldUiSchema['ui:field_xl'] = data == null ? void 0 : data.field_xl;
  if (data != null && data.field_md) fieldUiSchema['ui:field_md'] = data == null ? void 0 : data.field_md;
  if (data != null && data.field_lg) fieldUiSchema['ui:field_lg'] = data == null ? void 0 : data.field_lg;
  if (data != null && data.icon) fieldUiSchema['ui:icon'] = data == null ? void 0 : data.icon;
  if (data != null && data.labelKey) {
    fieldUiSchema['ui:labelKey'] = !(data != null && data.label) || (data == null ? void 0 : data.label) === (data == null ? void 0 : data.originlabel) ? data == null ? void 0 : data.labelKey : '';
  }
  if (data != null && data.readonly) fieldUiSchema['ui:readonly'] = data == null ? void 0 : data.readonly;
  if (data != null && data.catchInputValAsChipOnBlur) fieldUiSchema['ui:catchInputValAsChipOnBlur'] = data == null ? void 0 : data.catchInputValAsChipOnBlur;
  var producer = produce(function (draft) {
    var _draft$zodSchema2, _z$object2;
    draft.zodSchema = (_draft$zodSchema2 = draft.zodSchema) == null ? void 0 : _draft$zodSchema2.merge(object((_z$object2 = {}, _z$object2[data.field] = fieldZodSchema, _z$object2)));
    if (draft.jsonSchema.properties && fieldJsonSchema) {
      var _cloneDeep2;
      draft.jsonSchema.properties[data.field] = _extends({}, (_cloneDeep2 = cloneDeep(draft.jsonSchema.properties[data.field])) != null ? _cloneDeep2 : {}, fieldJsonSchema);
    }
    if (fieldUiSchema) {
      var _extends3;
      draft.uiSchema = _extends({}, draft.uiSchema, (_extends3 = {}, _extends3[data.field] = fieldUiSchema, _extends3));
    }
    if (data != null && data.required) {
      var _draft$jsonSchema$req2;
      (_draft$jsonSchema$req2 = draft.jsonSchema.required) == null || _draft$jsonSchema$req2.push(data.field);
    }
  });
  var nextSchema = producer(schema);
  // console.log("nextSchema", nextSchema);
  return nextSchema;
};
var convertNumberSchema = function convertNumberSchema(schema, data, forceDisable) {
  if (forceDisable === void 0) {
    forceDisable = false;
  }
  if (!data || !(data != null && data.field)) {
    return;
  }
  var config = {
    jsonSchema: [{
      prop: 'title',
      key: 'label'
    }, {
      prop: 'minimum',
      key: 'min'
    }, {
      prop: 'maximum',
      key: 'max'
    }],
    uiSchema: [{
      prop: 'ui:disabled',
      key: 'disabled'
    }, {
      prop: 'ui:readonly',
      key: 'readonly'
    }, {
      prop: 'ui:description',
      key: 'description'
    }, {
      prop: 'ui:size',
      key: 'size'
    }, {
      prop: 'ui:placeholder',
      key: 'placeholder'
    }, {
      prop: 'ui:field_xl',
      key: 'field_xl'
    }, {
      prop: 'ui:field_lg',
      key: 'field_lg'
    }, {
      prop: 'ui:field_md',
      key: 'field_md'
    }, {
      prop: 'ui:field_xs',
      key: 'field_xs'
    }, {
      prop: 'ui:icon',
      key: 'icon'
    }, {
      prop: 'ui:labelKey',
      key: 'labelKey'
    }]
  };
  var fieldJsonSchema = {
    type: 'number'
  };
  var fieldUiSchema = {};
  var fieldZodSchema = number({
    required_error: ''
  });
  if ((data == null ? void 0 : data.min) !== undefined) fieldZodSchema = fieldZodSchema.min(data.min, "no less than " + data.min);
  if (data != null && data.max) fieldZodSchema = fieldZodSchema.max(data.max, "no longer than " + (data == null ? void 0 : data.max));
  if (!(data != null && data.required)) {
    fieldZodSchema = fieldZodSchema.optional().nullable();
  }
  // jsonSchema
  for (var _iterator = _createForOfIteratorHelperLoose(config.jsonSchema), _step; !(_step = _iterator()).done;) {
    var item = _step.value;
    if (data[item.key]) {
      var _extends5;
      fieldJsonSchema = _extends({}, fieldJsonSchema, (_extends5 = {}, _extends5[item.prop] = data[item.key], _extends5));
    }
  }
  // uiSchema
  for (var _iterator2 = _createForOfIteratorHelperLoose(config.uiSchema), _step2; !(_step2 = _iterator2()).done;) {
    var _item = _step2.value;
    if (data[_item.key]) {
      var _extends6;
      fieldUiSchema = _extends({}, fieldUiSchema, (_extends6 = {}, _extends6[_item.prop] = data[_item.key], _extends6));
    }
  }
  fieldJsonSchema['title'] = (data == null ? void 0 : data.label) || (data == null ? void 0 : data.originlabel);
  if (forceDisable) {
    fieldUiSchema = _extends({}, fieldUiSchema, {
      'ui:disabled': true
    });
  }
  if (data != null && data.labelKey) {
    fieldUiSchema['ui:labelKey'] = !(data != null && data.label) || (data == null ? void 0 : data.label) === (data == null ? void 0 : data.originlabel) ? data == null ? void 0 : data.labelKey : '';
  }
  var producer = produce(function (draft) {
    var _draft$zodSchema3, _z$object3;
    draft.zodSchema = (_draft$zodSchema3 = draft.zodSchema) == null ? void 0 : _draft$zodSchema3.merge(object((_z$object3 = {}, _z$object3[data.field] = fieldZodSchema, _z$object3)));
    if (draft.jsonSchema.properties && fieldJsonSchema) {
      var _cloneDeep3;
      draft.jsonSchema.properties[data.field] = _extends({}, (_cloneDeep3 = cloneDeep(draft.jsonSchema.properties[data.field])) != null ? _cloneDeep3 : {}, fieldJsonSchema);
    }
    if (fieldUiSchema) {
      var _extends4;
      draft.uiSchema = _extends({}, draft.uiSchema, (_extends4 = {}, _extends4[data.field] = fieldUiSchema, _extends4));
    }
    if (data != null && data.required) {
      var _draft$jsonSchema$req3;
      (_draft$jsonSchema$req3 = draft.jsonSchema.required) == null || _draft$jsonSchema$req3.push(data.field);
    }
  });
  var nextSchema = producer(schema);
  return nextSchema;
};
var convertDateSchema = function convertDateSchema(schema, data, forceDisable) {
  if (forceDisable === void 0) {
    forceDisable = false;
  }
  if (!data || !(data != null && data.field)) {
    return;
  }
  var config = {
    jsonSchema: [{
      prop: 'title',
      key: 'label'
    }],
    uiSchema: [{
      prop: 'ui:disabled',
      key: 'disabled'
    }, {
      prop: 'ui:readonly',
      key: 'readonly'
    }, {
      prop: 'ui:description',
      key: 'description'
    }, {
      prop: 'ui:size',
      key: 'size'
    }, {
      prop: 'ui:placeholder',
      key: 'placeholder'
    }, {
      prop: 'ui:field_xl',
      key: 'field_xl'
    }, {
      prop: 'ui:field_lg',
      key: 'field_lg'
    }, {
      prop: 'ui:field_md',
      key: 'field_md'
    }, {
      prop: 'ui:field_xs',
      key: 'field_xs'
    }, {
      prop: 'minDate',
      key: 'minDate'
    }, {
      prop: 'maxDate',
      key: 'maxDate'
    }, {
      prop: 'ui:icon',
      key: 'icon'
    }, {
      prop: 'ui:labelKey',
      key: 'labelKey'
    }]
  };
  var fieldJsonSchema = {
    type: 'string',
    format: 'date'
  };
  var fieldUiSchema = {
    'ui:widget': 'CustomDateWidget'
  };
  // let fieldZodSchema: any = z.date({ required_error: "" });
  var fieldZodSchema = undefined$1().or(string({
    required_error: ''
  })).or(date({
    required_error: ''
  }));
  // jsonSchema
  for (var _iterator3 = _createForOfIteratorHelperLoose(config.jsonSchema), _step3; !(_step3 = _iterator3()).done;) {
    var item = _step3.value;
    if (data[item.key]) {
      var _extends8;
      fieldJsonSchema = _extends({}, fieldJsonSchema, (_extends8 = {}, _extends8[item.prop] = data[item.key], _extends8));
    }
  }
  fieldJsonSchema['title'] = (data == null ? void 0 : data.label) || (data == null ? void 0 : data.originlabel);
  // uiSchema
  for (var _iterator4 = _createForOfIteratorHelperLoose(config.uiSchema), _step4; !(_step4 = _iterator4()).done;) {
    var _item2 = _step4.value;
    if (data[_item2.key]) {
      var _extends9;
      fieldUiSchema = _extends({}, fieldUiSchema, (_extends9 = {}, _extends9[_item2.prop] = data[_item2.key], _extends9));
    }
  }
  if (forceDisable) {
    fieldUiSchema = _extends({}, fieldUiSchema, {
      'ui:disabled': true
    });
  }
  if (data != null && data.labelKey) {
    fieldUiSchema['ui:labelKey'] = !(data != null && data.label) || (data == null ? void 0 : data.label) === (data == null ? void 0 : data.originlabel) ? data == null ? void 0 : data.labelKey : '';
  }
  var producer = produce(function (draft) {
    var _draft$zodSchema4, _z$object4;
    draft.zodSchema = (_draft$zodSchema4 = draft.zodSchema) == null ? void 0 : _draft$zodSchema4.merge(object((_z$object4 = {}, _z$object4[data.field] = fieldZodSchema, _z$object4)));
    if (draft.jsonSchema.properties && fieldJsonSchema) {
      var _cloneDeep4;
      draft.jsonSchema.properties[data.field] = _extends({}, (_cloneDeep4 = cloneDeep(draft.jsonSchema.properties[data.field])) != null ? _cloneDeep4 : {}, fieldJsonSchema);
    }
    if (fieldUiSchema) {
      var _extends7;
      draft.uiSchema = _extends({}, draft.uiSchema, (_extends7 = {}, _extends7[data.field] = fieldUiSchema, _extends7));
    }
    if (data != null && data.required) {
      var _draft$jsonSchema$req4;
      (_draft$jsonSchema$req4 = draft.jsonSchema.required) == null || _draft$jsonSchema$req4.push(data.field);
    }
  });
  var nextSchema = producer(schema);
  return nextSchema;
};
var convertViewSchema = function convertViewSchema(schema, data, forceDisable) {
  if (forceDisable === void 0) {
    forceDisable = false;
  }
  if (!data || !(data != null && data.field)) {
    return schema;
  }
  var enumOptions = undefined;
  var enumNames = undefined;
  if ('options' in data && Array.isArray(data.options)) {
    var _data$options$map, _data$options2, _data$options3;
    enumNames = (_data$options$map = (_data$options2 = data.options) == null ? void 0 : _data$options2.map(function (el) {
      return el == null ? void 0 : el.label;
    })) != null ? _data$options$map : [];
    enumOptions = (_data$options3 = data.options) == null ? void 0 : _data$options3.map(function (el) {
      return {
        name: el == null ? void 0 : el.label,
        value: el == null ? void 0 : el.value
      };
    });
  }
  var config = {
    jsonSchema: [{
      prop: 'title',
      key: 'label'
    }],
    uiSchema: [{
      prop: 'ui:disabled',
      key: 'disabled'
    }, {
      prop: 'ui:readonly',
      key: 'readonly'
    }, {
      prop: 'ui:description',
      key: 'description'
    }, {
      prop: 'ui:size',
      key: 'size'
    }, {
      prop: 'ui:placeholder',
      key: 'placeholder'
    }, {
      prop: 'ui:field_xl',
      key: 'field_xl'
    }, {
      prop: 'ui:field_lg',
      key: 'field_lg'
    }, {
      prop: 'ui:field_md',
      key: 'field_md'
    }, {
      prop: 'ui:field_xs',
      key: 'field_xs'
    },
    // { prop: "minDate", key: "minDate" },
    // { prop: "maxDate", key: "maxDate" },
    {
      prop: 'ui:icon',
      key: 'icon'
    }, {
      prop: 'ui:labelKey',
      key: 'labelKey'
    }]
  };
  var fieldJsonSchema = {
    type: 'string',
    enumNames: enumNames,
    "enum": enumOptions
  };
  var fieldUiSchema = {
    'ui:widget': 'CustomViewWidget'
  };
  Object.entries(data).forEach(function (_ref) {
    var key = _ref[0],
      value = _ref[1];
    !!value && (fieldUiSchema["ui:" + key] = value);
  });
  var fieldZodSchema = undefined$1().or(string({
    required_error: ''
  })).or(date({
    required_error: ''
  }));
  // jsonSchema
  for (var _iterator5 = _createForOfIteratorHelperLoose(config.jsonSchema), _step5; !(_step5 = _iterator5()).done;) {
    var item = _step5.value;
    if (data[item.key]) {
      var _extends11;
      fieldJsonSchema = _extends({}, fieldJsonSchema, (_extends11 = {}, _extends11[item.prop] = data[item.key], _extends11));
    }
  }
  fieldJsonSchema['title'] = (data == null ? void 0 : data.label) || (data == null ? void 0 : data.originlabel);
  // uiSchema
  for (var _iterator6 = _createForOfIteratorHelperLoose(config.uiSchema), _step6; !(_step6 = _iterator6()).done;) {
    var _item3 = _step6.value;
    if (data[_item3.key]) {
      var _extends12;
      fieldUiSchema = _extends({}, fieldUiSchema, (_extends12 = {}, _extends12[_item3.prop] = data[_item3.key], _extends12));
    }
  }
  if (forceDisable) {
    fieldUiSchema = _extends({}, fieldUiSchema, {
      'ui:disabled': true
    });
  }
  if (data != null && data.labelKey) {
    fieldUiSchema['ui:labelKey'] = !(data != null && data.label) || (data == null ? void 0 : data.label) === (data == null ? void 0 : data.originlabel) ? data == null ? void 0 : data.labelKey : '';
  }
  var producer = produce(function (draft) {
    var _draft$zodSchema5, _z$object5;
    draft.zodSchema = (_draft$zodSchema5 = draft.zodSchema) == null ? void 0 : _draft$zodSchema5.merge(object((_z$object5 = {}, _z$object5[data.field] = fieldZodSchema, _z$object5)));
    if (draft.jsonSchema.properties && fieldJsonSchema) {
      var _cloneDeep5;
      draft.jsonSchema.properties[data.field] = _extends({}, (_cloneDeep5 = cloneDeep(draft.jsonSchema.properties[data.field])) != null ? _cloneDeep5 : {}, fieldJsonSchema);
    }
    if (fieldUiSchema) {
      var _extends10;
      draft.uiSchema = _extends({}, draft.uiSchema, (_extends10 = {}, _extends10[data.field] = fieldUiSchema, _extends10));
    }
    if (data != null && data.required) {
      var _draft$jsonSchema$req5;
      (_draft$jsonSchema$req5 = draft.jsonSchema.required) == null || _draft$jsonSchema$req5.push(data.field);
    }
  });
  var nextSchema = producer(schema);
  return nextSchema;
};
var convertSelectSchema = function convertSelectSchema(schema, data, forceDisable) {
  var _data$options4, _data$options$map2, _data$options5;
  if (forceDisable === void 0) {
    forceDisable = false;
  }
  // console.log("convertTextSchema", data);
  if (!data || !(data != null && data.field)) {
    return schema;
  }
  var staticOption = data == null || (_data$options4 = data.options) == null ? void 0 : _data$options4.map(function (el) {
    return {
      name: el == null ? void 0 : el.label,
      value: el == null ? void 0 : el.value
    };
  });
  var fieldJsonSchema = {
    type: ['string', 'array', 'object', 'number'],
    items: {
      type: ['string', 'object', 'number'],
      properties: {
        value: {
          type: 'number'
        },
        label: {
          type: 'string'
        }
      }
    },
    enumNames: (_data$options$map2 = data == null || (_data$options5 = data.options) == null ? void 0 : _data$options5.map(function (el) {
      return el == null ? void 0 : el.label;
    })) != null ? _data$options$map2 : [],
    "enum": staticOption != null && staticOption.length ? staticOption : undefined,
    properties: {
      value: {
        type: 'number'
      },
      label: {
        type: 'string'
      }
    }
  };
  var fieldUiSchema = {
    'ui:size': 'small',
    'ui:widget': 'CustomSelectWidget'
  };
  var fieldZodSchema = undefined$1({
    required_error: ''
  }).or(number({
    required_error: ''
  })).or(string({
    required_error: ''
  })).or(object({})).or(array(string().or(object({})), {
    required_error: ''
  }));
  // parse the json schema
  // if (data?.readonly) fieldJsonSchema["readOnly"] = true;
  fieldJsonSchema['title'] = (data == null ? void 0 : data.label) || (data == null ? void 0 : data.originlabel);
  if (data != null && data.description) fieldJsonSchema['description'] = data == null ? void 0 : data.description;
  // if (data?.options && data?.options?.length > 0)
  //   fieldJsonSchema["anyOf"] = data.options?.map((el) => ({
  //     const: el?.value,
  //     title: `${el?.label}`,
  //   }));
  // parse the zodSchema
  if (!(data != null && data.required)) fieldZodSchema = fieldZodSchema.optional().nullable();
  // parse the uiSchema
  if (data != null && data.disabled || forceDisable) fieldUiSchema['ui:disabled'] = true;
  // if (data?.description) fieldUiSchema["ui:description"] = data.description;
  if (data != null && data.placeholder) fieldUiSchema['ui:placeholder'] = data.placeholder;
  if (data != null && data.size) fieldUiSchema['ui:size'] = data == null ? void 0 : data.size;
  if (data != null && data.multiple) fieldUiSchema['ui:multiple'] = true;
  if (data != null && data.multipleChip) fieldUiSchema['ui:multipleChip'] = true;
  if (data != null && data.field_xs) fieldUiSchema['ui:field_xs'] = data == null ? void 0 : data.field_xs;
  if (data != null && data.field_xl) fieldUiSchema['ui:field_xl'] = data == null ? void 0 : data.field_xl;
  if (data != null && data.field_md) fieldUiSchema['ui:field_md'] = data == null ? void 0 : data.field_md;
  if (data != null && data.field_lg) fieldUiSchema['ui:field_lg'] = data == null ? void 0 : data.field_lg;
  if (data != null && data.labelKey) {
    fieldUiSchema['ui:labelKey'] = !(data != null && data.label) || (data == null ? void 0 : data.label) === (data == null ? void 0 : data.originlabel) ? data == null ? void 0 : data.labelKey : '';
  }
  if (data != null && data.asyncConfig) fieldUiSchema['ui:asyncConfig'] = data == null ? void 0 : data.asyncConfig;
  if (data != null && data.icon) fieldUiSchema['ui:icon'] = data == null ? void 0 : data.icon;
  if (data != null && data.readonly) fieldUiSchema['ui:readonly'] = data == null ? void 0 : data.readonly;
  var producer = produce(function (draft) {
    var _draft$zodSchema6, _z$object6;
    draft.zodSchema = (_draft$zodSchema6 = draft.zodSchema) == null ? void 0 : _draft$zodSchema6.merge(object((_z$object6 = {}, _z$object6[data.field] = fieldZodSchema, _z$object6)));
    if (draft.jsonSchema.properties && fieldJsonSchema) {
      var _cloneDeep6;
      draft.jsonSchema.properties[data.field] = _extends({}, (_cloneDeep6 = cloneDeep(draft.jsonSchema.properties[data.field])) != null ? _cloneDeep6 : {}, fieldJsonSchema);
    }
    if (fieldUiSchema) {
      var _extends13;
      draft.uiSchema = _extends({}, draft.uiSchema, (_extends13 = {}, _extends13[data.field] = fieldUiSchema, _extends13));
    }
    if (data != null && data.required) {
      var _draft$jsonSchema$req6;
      (_draft$jsonSchema$req6 = draft.jsonSchema.required) == null || _draft$jsonSchema$req6.push(data.field);
    }
  });
  var nextSchema = producer(schema);
  // console.log("nextSchema", nextSchema);
  return nextSchema;
};
var convertRadioSchema = function convertRadioSchema(schema, data, forceDisable) {
  var _data$options6, _data$options$map3, _data$options7;
  if (forceDisable === void 0) {
    forceDisable = false;
  }
  // console.log("convertTextSchema", data);
  if (!data || !(data != null && data.field)) {
    return schema;
  }
  var staticOption = data == null || (_data$options6 = data.options) == null ? void 0 : _data$options6.map(function (el) {
    return {
      name: el == null ? void 0 : el.label,
      value: el == null ? void 0 : el.value
    };
  });
  var fieldJsonSchema = {
    type: ['string', 'array', 'object', 'number'],
    items: {
      type: ['string', 'object', 'number'],
      properties: {
        value: {
          type: 'number'
        },
        label: {
          type: 'string'
        }
      }
    },
    enumNames: (_data$options$map3 = data == null || (_data$options7 = data.options) == null ? void 0 : _data$options7.map(function (el) {
      return el == null ? void 0 : el.label;
    })) != null ? _data$options$map3 : [],
    "enum": staticOption != null && staticOption.length ? staticOption : undefined,
    properties: {
      value: {
        type: 'number'
      },
      label: {
        type: 'string'
      }
    }
  };
  var fieldUiSchema = {
    'ui:size': 'small',
    'ui:widget': 'CustomRadioWidget'
  };
  var fieldZodSchema = undefined$1({
    required_error: ''
  }).or(number({
    required_error: ''
  })).or(string({
    required_error: ''
  })).or(object({})).or(array(string().or(object({})), {
    required_error: ''
  }));
  // parse the json schema
  // if (data?.readonly) fieldJsonSchema["readOnly"] = true;
  fieldJsonSchema['title'] = (data == null ? void 0 : data.label) || (data == null ? void 0 : data.originlabel);
  if (data != null && data.description) fieldJsonSchema['description'] = data == null ? void 0 : data.description;
  // if (data?.options && data?.options?.length > 0)
  //   fieldJsonSchema["anyOf"] = data.options?.map((el) => ({
  //     const: el?.value,
  //     title: `${el?.label}`,
  //   }));
  // parse the zodSchema
  if (!(data != null && data.required)) fieldZodSchema = fieldZodSchema.optional().nullable();
  // parse the uiSchema
  if (data != null && data.disabled || forceDisable) fieldUiSchema['ui:disabled'] = true;
  // if (data?.description) fieldUiSchema["ui:description"] = data.description;
  if (data != null && data.placeholder) fieldUiSchema['ui:placeholder'] = data.placeholder;
  if (data != null && data.size) fieldUiSchema['ui:size'] = data == null ? void 0 : data.size;
  if (data != null && data.field_xs) fieldUiSchema['ui:field_xs'] = data == null ? void 0 : data.field_xs;
  if (data != null && data.field_xl) fieldUiSchema['ui:field_xl'] = data == null ? void 0 : data.field_xl;
  if (data != null && data.field_md) fieldUiSchema['ui:field_md'] = data == null ? void 0 : data.field_md;
  if (data != null && data.field_lg) fieldUiSchema['ui:field_lg'] = data == null ? void 0 : data.field_lg;
  if (data != null && data.labelKey) {
    fieldUiSchema['ui:labelKey'] = !(data != null && data.label) || (data == null ? void 0 : data.label) === (data == null ? void 0 : data.originlabel) ? data == null ? void 0 : data.labelKey : '';
  }
  if (data != null && data.asyncConfig) fieldUiSchema['ui:asyncConfig'] = data == null ? void 0 : data.asyncConfig;
  if (data != null && data.icon) fieldUiSchema['ui:icon'] = data == null ? void 0 : data.icon;
  if (data != null && data.readonly) fieldUiSchema['ui:readonly'] = data == null ? void 0 : data.readonly;
  var producer = produce(function (draft) {
    var _draft$zodSchema7, _z$object7;
    draft.zodSchema = (_draft$zodSchema7 = draft.zodSchema) == null ? void 0 : _draft$zodSchema7.merge(object((_z$object7 = {}, _z$object7[data.field] = fieldZodSchema, _z$object7)));
    if (draft.jsonSchema.properties && fieldJsonSchema) {
      var _cloneDeep7;
      draft.jsonSchema.properties[data.field] = _extends({}, (_cloneDeep7 = cloneDeep(draft.jsonSchema.properties[data.field])) != null ? _cloneDeep7 : {}, fieldJsonSchema);
    }
    if (fieldUiSchema) {
      var _extends14;
      draft.uiSchema = _extends({}, draft.uiSchema, (_extends14 = {}, _extends14[data.field] = fieldUiSchema, _extends14));
    }
    if (data != null && data.required) {
      var _draft$jsonSchema$req7;
      (_draft$jsonSchema$req7 = draft.jsonSchema.required) == null || _draft$jsonSchema$req7.push(data.field);
    }
  });
  var nextSchema = producer(schema);
  // console.log("nextSchema", nextSchema);
  return nextSchema;
};
var convertCheckboxesSchema = function convertCheckboxesSchema(schema, data, forceDisable) {
  var _data$options8, _data$options$map4, _data$options9;
  if (forceDisable === void 0) {
    forceDisable = false;
  }
  // console.log("convertTextSchema", data);
  if (!data || !(data != null && data.field)) {
    return schema;
  }
  var staticOption = data == null || (_data$options8 = data.options) == null ? void 0 : _data$options8.map(function (el) {
    return {
      label: el == null ? void 0 : el.label,
      value: el == null ? void 0 : el.value
    };
  });
  var fieldJsonSchema = {
    type: ['string', 'array', 'object', 'number'],
    items: {
      type: ['string', 'object', 'number'],
      properties: {
        value: {
          type: 'number'
        },
        label: {
          type: 'string'
        }
      }
    },
    // enumNames is label, enum is value
    // enumOptions: [{label: enumName, value: enumOption}]
    enumNames: (_data$options$map4 = data == null || (_data$options9 = data.options) == null ? void 0 : _data$options9.map(function (el) {
      return el == null ? void 0 : el.label;
    })) != null ? _data$options$map4 : [],
    "enum": staticOption,
    properties: {
      value: {
        type: 'number'
      },
      label: {
        type: 'string'
      }
    }
  };
  var fieldUiSchema = {
    'ui:size': 'small',
    'ui:widget': 'CustomCheckboxesWidget'
  };
  var fieldZodSchema = undefined$1({
    required_error: ''
  }).or(number({
    required_error: ''
  })).or(string({
    required_error: ''
  })).or(object({})).or(array(string().or(object({})), {
    required_error: ''
  }));
  // parse the json schema
  // if (data?.readonly) fieldJsonSchema["readOnly"] = true;
  fieldJsonSchema['title'] = (data == null ? void 0 : data.label) || (data == null ? void 0 : data.originlabel);
  if (data != null && data.description) fieldJsonSchema['description'] = data == null ? void 0 : data.description;
  // if (data?.options && data?.options?.length > 0)
  //   fieldJsonSchema["anyOf"] = data.options?.map((el) => ({
  //     const: el?.value,
  //     title: `${el?.label}`,
  //   }));
  // parse the zodSchema
  if (!(data != null && data.required)) fieldZodSchema = fieldZodSchema.optional().nullable();
  // parse the uiSchema
  if (data != null && data.disabled || forceDisable) fieldUiSchema['ui:disabled'] = true;
  // if (data?.description) fieldUiSchema["ui:description"] = data.description;
  if (data != null && data.placeholder) fieldUiSchema['ui:placeholder'] = data.placeholder;
  if (data != null && data.size) fieldUiSchema['ui:size'] = data == null ? void 0 : data.size;
  if (data != null && data.multiple) fieldUiSchema['ui:multiple'] = true;
  if (data != null && data.field_xs) fieldUiSchema['ui:field_xs'] = data == null ? void 0 : data.field_xs;
  if (data != null && data.field_xl) fieldUiSchema['ui:field_xl'] = data == null ? void 0 : data.field_xl;
  if (data != null && data.field_md) fieldUiSchema['ui:field_md'] = data == null ? void 0 : data.field_md;
  if (data != null && data.field_lg) fieldUiSchema['ui:field_lg'] = data == null ? void 0 : data.field_lg;
  if (data != null && data.labelKey) {
    fieldUiSchema['ui:labelKey'] = !(data != null && data.label) || (data == null ? void 0 : data.label) === (data == null ? void 0 : data.originlabel) ? data == null ? void 0 : data.labelKey : '';
  }
  if (data != null && data.asyncConfig) fieldUiSchema['ui:asyncConfig'] = data == null ? void 0 : data.asyncConfig;
  if (data != null && data.icon) fieldUiSchema['ui:icon'] = data == null ? void 0 : data.icon;
  if (data != null && data.readonly) fieldUiSchema['ui:readonly'] = data == null ? void 0 : data.readonly;
  var producer = produce(function (draft) {
    var _draft$zodSchema8, _z$object8;
    draft.zodSchema = (_draft$zodSchema8 = draft.zodSchema) == null ? void 0 : _draft$zodSchema8.merge(object((_z$object8 = {}, _z$object8[data.field] = fieldZodSchema, _z$object8)));
    if (draft.jsonSchema.properties && fieldJsonSchema) {
      var _cloneDeep8;
      draft.jsonSchema.properties[data.field] = _extends({}, (_cloneDeep8 = cloneDeep(draft.jsonSchema.properties[data.field])) != null ? _cloneDeep8 : {}, fieldJsonSchema);
    }
    if (fieldUiSchema) {
      var _extends15;
      draft.uiSchema = _extends({}, draft.uiSchema, (_extends15 = {}, _extends15[data.field] = fieldUiSchema, _extends15));
    }
    if (data != null && data.required) {
      var _draft$jsonSchema$req8;
      (_draft$jsonSchema$req8 = draft.jsonSchema.required) == null || _draft$jsonSchema$req8.push(data.field);
    }
  });
  var nextSchema = producer(schema);
  // console.log("nextSchema", nextSchema);
  return nextSchema;
};
var convertCheckboxSchema = function convertCheckboxSchema(schema, data, forceDisable) {
  if (forceDisable === void 0) {
    forceDisable = false;
  }
  if (!data || !(data != null && data.field)) {
    return schema;
  }
  var fieldJsonSchema = {
    type: 'boolean'
  };
  var fieldUiSchema = {
    'ui:size': 'small',
    'ui:widget': 'CustomCheckboxWidget'
  };
  var fieldZodSchema = boolean({
    required_error: ''
  });
  // parse the json schema
  // if (data?.readonly) fieldJsonSchema["readOnly"] = true;
  fieldJsonSchema['title'] = (data == null ? void 0 : data.label) || (data == null ? void 0 : data.originlabel);
  if (data != null && data.description) fieldJsonSchema['description'] = data == null ? void 0 : data.description;
  if (!(data != null && data.required)) fieldZodSchema = fieldZodSchema.optional().nullable();
  // parse the uiSchema
  if (data != null && data.disabled || forceDisable) fieldUiSchema['ui:disabled'] = true;
  if (data != null && data.placeholder) fieldUiSchema['ui:placeholder'] = data.placeholder;
  if (data != null && data.size) fieldUiSchema['ui:size'] = data == null ? void 0 : data.size;
  if (data != null && data.field_xs) fieldUiSchema['ui:field_xs'] = data == null ? void 0 : data.field_xs;
  if (data != null && data.field_xl) fieldUiSchema['ui:field_xl'] = data == null ? void 0 : data.field_xl;
  if (data != null && data.field_md) fieldUiSchema['ui:field_md'] = data == null ? void 0 : data.field_md;
  if (data != null && data.field_lg) fieldUiSchema['ui:field_lg'] = data == null ? void 0 : data.field_lg;
  if (data != null && data.icon) fieldUiSchema['ui:icon'] = data == null ? void 0 : data.icon;
  if (data != null && data.labelKey) {
    fieldUiSchema['ui:labelKey'] = !(data != null && data.label) || (data == null ? void 0 : data.label) === (data == null ? void 0 : data.originlabel) ? data == null ? void 0 : data.labelKey : '';
  }
  if (data != null && data.readonly) fieldUiSchema['ui:readonly'] = data == null ? void 0 : data.readonly;
  var producer = produce(function (draft) {
    var _draft$zodSchema9, _z$object9;
    draft.zodSchema = (_draft$zodSchema9 = draft.zodSchema) == null ? void 0 : _draft$zodSchema9.merge(object((_z$object9 = {}, _z$object9[data.field] = fieldZodSchema, _z$object9)));
    if (draft.jsonSchema.properties && fieldJsonSchema) {
      var _cloneDeep9;
      draft.jsonSchema.properties[data.field] = _extends({}, (_cloneDeep9 = cloneDeep(draft.jsonSchema.properties[data.field])) != null ? _cloneDeep9 : {}, fieldJsonSchema);
    }
    if (fieldUiSchema) {
      var _extends16;
      draft.uiSchema = _extends({}, draft.uiSchema, (_extends16 = {}, _extends16[data.field] = fieldUiSchema, _extends16));
    }
    if (data != null && data.required) {
      var _draft$jsonSchema$req9;
      (_draft$jsonSchema$req9 = draft.jsonSchema.required) == null || _draft$jsonSchema$req9.push(data.field);
    }
  });
  var nextSchema = producer(schema);
  // console.log("nextSchema", nextSchema);
  return nextSchema;
};
var ConvertJsonSchemaFunc = function ConvertJsonSchemaFunc(data, disabledFields, viewType) {
  var _data$filter, _disabledFields$inclu2, _disabledFields$inclu3, _disabledFields$inclu4, _disabledFields$inclu5, _disabledFields$inclu6, _disabledFields$inclu7, _disabledFields$inclu8, _disabledFields$inclu9;
  var convertSchema = {
    jsonSchema: {
      title: '',
      type: 'object',
      required: [],
      properties: {}
    },
    uiSchema: {
      'ui:options': {
        'ui:field_xs': 12,
        'ui:field_md': 6,
        'ui:field_lg': 4,
        'ui:field_xl': 4,
        'ui:size': 'small'
      }
    },
    zodSchema: object({})
  };
  // sort and hide form items.
  var handledData = data == null || (_data$filter = data.filter(function (el) {
    return !(el != null && el.hide);
  })) == null ? void 0 : _data$filter.sort(function (prev, next) {
    if (prev != null && prev.order && next != null && next.order) {
      return (prev == null ? void 0 : prev.order) - (next == null ? void 0 : next.order);
    }
    return 0;
  });
  if (viewType) {
    for (var _iterator7 = _createForOfIteratorHelperLoose(handledData), _step7; !(_step7 = _iterator7()).done;) {
      var _disabledFields$inclu;
      var item = _step7.value;
      convertSchema = convertViewSchema(convertSchema, item, (_disabledFields$inclu = disabledFields == null ? void 0 : disabledFields.includes(item == null ? void 0 : item.field)) != null ? _disabledFields$inclu : false);
    }
    return convertSchema;
  }
  // type: text/select/date/number
  for (var _iterator8 = _createForOfIteratorHelperLoose(handledData), _step8; !(_step8 = _iterator8()).done;) {
    var _item4 = _step8.value;
    // convertCommonInfo(convertSchema, item);
    switch (_item4.type) {
      case 'text':
        convertSchema = convertTextSchema(convertSchema, _item4, (_disabledFields$inclu2 = disabledFields == null ? void 0 : disabledFields.includes(_item4 == null ? void 0 : _item4.field)) != null ? _disabledFields$inclu2 : false);
        break;
      case 'number':
        convertSchema = convertNumberSchema(convertSchema, _item4, (_disabledFields$inclu3 = disabledFields == null ? void 0 : disabledFields.includes(_item4 == null ? void 0 : _item4.field)) != null ? _disabledFields$inclu3 : false);
        break;
      case 'select':
      case 'multi-select':
        convertSchema = convertSelectSchema(convertSchema, _item4, (_disabledFields$inclu4 = disabledFields == null ? void 0 : disabledFields.includes(_item4 == null ? void 0 : _item4.field)) != null ? _disabledFields$inclu4 : false);
        break;
      // case "multi-select":
      //   convertSchema = convertSelectSchema(
      //     convertSchema,
      //     item,
      //     disabledFields?.includes(item?.field) ?? false
      //   ) as TJsonSchemaData;
      //   break;
      case 'chips':
        convertSchema = convertChipsSchema(convertSchema, _item4, (_disabledFields$inclu5 = disabledFields == null ? void 0 : disabledFields.includes(_item4 == null ? void 0 : _item4.field)) != null ? _disabledFields$inclu5 : false);
        break;
      case 'date':
        convertSchema = convertDateSchema(convertSchema, _item4, (_disabledFields$inclu6 = disabledFields == null ? void 0 : disabledFields.includes(_item4 == null ? void 0 : _item4.field)) != null ? _disabledFields$inclu6 : false);
        break;
      case 'radio':
        convertSchema = convertRadioSchema(convertSchema, _item4, (_disabledFields$inclu7 = disabledFields == null ? void 0 : disabledFields.includes(_item4 == null ? void 0 : _item4.field)) != null ? _disabledFields$inclu7 : false);
        break;
      case 'checkboxGroups':
        convertSchema = convertCheckboxesSchema(convertSchema, _item4, (_disabledFields$inclu8 = disabledFields == null ? void 0 : disabledFields.includes(_item4 == null ? void 0 : _item4.field)) != null ? _disabledFields$inclu8 : false);
        break;
      case 'checkbox':
        convertSchema = convertCheckboxSchema(convertSchema, _item4, (_disabledFields$inclu9 = disabledFields == null ? void 0 : disabledFields.includes(_item4 == null ? void 0 : _item4.field)) != null ? _disabledFields$inclu9 : false);
        break;
      default:
        console.log('form item definition type error');
    }
  }
  // console.log("convertSchema", convertSchema);
  return convertSchema;
};

function CustomViewWidget(props) {
  var _formContext$dynamicF, _uiSchema$uiMultiple;
  var label = props.label,
    value = props.value,
    uiSchema = props.uiSchema,
    name = props.name,
    formContext = props.formContext,
    options = props.options;
  var _useState = useState(""),
    showValue = _useState[0],
    setShowValue = _useState[1];
  var enumOptions = options.enumOptions;
  var uniqueKey = name + "-unique-select";
  var formState = formContext == null ? void 0 : formContext["formState"];
  var extraState = formContext == null ? void 0 : formContext["extraState"];
  var dynamicFormContextQueryKey = (_formContext$dynamicF = formContext == null ? void 0 : formContext["dynamicFormContextQueryKey"]) != null ? _formContext$dynamicF : "";
  var shadowFormState = formContext == null ? void 0 : formContext["shadowFormState"];
  var shadowValue = shadowFormState == null ? void 0 : shadowFormState[name];
  var shadowOptionList = useMemo(function () {
    if (shadowValue === undefined) return undefined;
    if (Array.isArray(shadowValue)) return undefined;
    return [{
      label: String(shadowValue),
      value: value
    }];
  }, [shadowValue, value]);
  var asyncConfig = uiSchema == null ? void 0 : uiSchema["ui:asyncConfig"];
  var type = uiSchema == null ? void 0 : uiSchema["ui:type"];
  var multiple = (_uiSchema$uiMultiple = uiSchema == null ? void 0 : uiSchema["ui:multiple"]) != null ? _uiSchema$uiMultiple : false;
  var isNeedFetch = useMemo(function () {
    return ['select', 'radio', 'checkboxGroups'].includes(type);
  }, [type]);
  var enumOptionsFromDefinition = useMemo(function () {
    var _enumOptions$map;
    return (_enumOptions$map = enumOptions == null ? void 0 : enumOptions.map(function (el) {
      var _el$value;
      return {
        label: el == null ? void 0 : el.label,
        value: el == null || (_el$value = el.value) == null ? void 0 : _el$value.value
      };
    })) != null ? _enumOptions$map : [];
  }, [enumOptions]);
  var _useCustomSelect = useCustomSelect(asyncConfig, dynamicFormContextQueryKey ? [dynamicFormContextQueryKey, uniqueKey] : uniqueKey, {
      formState: formState,
      extraState: extraState
    }, isNeedFetch && shadowOptionList === undefined && !!(asyncConfig != null && asyncConfig.url)),
    resOptionList = _useCustomSelect.resOptionList;
  var optionList = useMemo(function () {
    var _ref;
    return (_ref = shadowOptionList != null ? shadowOptionList : resOptionList) != null ? _ref : enumOptionsFromDefinition || [];
  }, [enumOptionsFromDefinition, name, resOptionList, shadowOptionList]);
  var handleSingleInitValue = function handleSingleInitValue(optionList) {
    var newValue = optionList == null ? void 0 : optionList.find(function (el) {
      if (Array.isArray(value)) {
        return value == null ? void 0 : value.some(function (item) {
          return "" + item === "" + (el == null ? void 0 : el.value);
        });
      }
      if (typeof value !== "object") {
        return value && "" + (el == null ? void 0 : el.value) === "" + value;
      }
      return value && "" + (el == null ? void 0 : el.value) === "" + (value == null ? void 0 : value.value);
    });
    return newValue;
  };
  var handleMultiInitValue = function handleMultiInitValue(optionList) {
    var _value$map;
    if (!value) return [];
    // show old format value.
    if (!(Array != null && Array.isArray(value)) && (typeof value === "string" || typeof value === "number")) {
      return optionList == null ? void 0 : optionList.filter(function (el) {
        var _ref2, _ref3;
        return ((_ref2 = "" + (el == null ? void 0 : el.value)) == null ? void 0 : _ref2.toLowerCase()) === ((_ref3 = "" + value) == null ? void 0 : _ref3.toLowerCase());
      });
    }
    if (!(Array != null && Array.isArray(value)) || (value == null ? void 0 : value.length) === 0) {
      return [];
    }
    return value == null || (_value$map = value.map(function (item) {
      var res = optionList == null ? void 0 : optionList.find(function (el) {
        var _ref6, _ref7;
        if (typeof item !== "object") {
          var _ref4, _ref5;
          return item && ((_ref4 = "" + (el == null ? void 0 : el.value)) == null ? void 0 : _ref4.toLowerCase()) === ((_ref5 = "" + item) == null ? void 0 : _ref5.toLowerCase());
        }
        var some = value && ((_ref6 = "" + (el == null ? void 0 : el.value)) == null ? void 0 : _ref6.toLowerCase()) === ((_ref7 = "" + (item == null ? void 0 : item.value)) == null ? void 0 : _ref7.toLowerCase());
        return some;
      });
      return res;
    })) == null ? void 0 : _value$map.filter(function (el) {
      return !!el;
    });
  };
  useEffect(function () {
    var _newValue$map$join, _newValue$map;
    if (!optionList || (optionList == null ? void 0 : optionList.length) === 0 || !value || Array.isArray(value) && (value == null ? void 0 : value.length) === 0) {
      return;
    }
    if (!multiple) {
      var _newValue$label;
      var _newValue = handleSingleInitValue(optionList);
      setShowValue((_newValue$label = _newValue == null ? void 0 : _newValue.label) != null ? _newValue$label : "");
      return;
    }
    var newValue = handleMultiInitValue(optionList);
    setShowValue((_newValue$map$join = (_newValue$map = newValue.map(function (item) {
      var _item$label;
      return (_item$label = item.label) != null ? _item$label : "";
    })) == null ? void 0 : _newValue$map.join(",")) != null ? _newValue$map$join : "");
  }, [optionList, value, multiple]);
  var labelValue = useMemo(function () {
    return isNeedFetch ? showValue : value;
  }, [showValue, value, type]);
  return React.createElement(Box, null, React.createElement(FormLabel, {
    required: false,
    className: "text-ellipsis",
    sx: {
      textAlign: "left",
      my: 1,
      display: "flex",
      alignItems: "center",
      color: "initial",
      position: "relative"
    }
  }, React.createElement(Box, {
    flex: 1,
    overflow: "hidden",
    display: "flex"
  }, " ", React.createElement(Tooltip, {
    title: label
  }, React.createElement("span", {
    className: "text-ellipsis"
  }, label)))), type !== 'checkbox' ? React.createElement(Tooltip, {
    placement: "bottom-start",
    title: labelValue
  }, React.createElement(Box, {
    marginTop: "10px"
  }, labelValue || "-")) : React.createElement(FormControlLabel$1, {
    control: React.createElement(Checkbox$1, {
      disabled: true,
      checked: typeof value === 'undefined' ? false : Boolean(labelValue)
    }),
    label: ''
  }));
}

var _excluded$5 = ["schema", "id", "name", "options", "label", "hideLabel", "required", "disabled", "placeholder", "readonly", "value", "autofocus", "onChange", "onBlur", "onFocus", "rawErrors", "registry", "uiSchema", "hideError", "formContext"];
/** The `RadioWidget` is a widget for rendering a radio group.
 *  It is typically used with a string property constrained with enum options.
 *
 * @param props - The `WidgetProps` for this component
 */
function RadioWidget(_ref) {
  var _formContext$dynamicF, _labelValue, _uiSchema$uiDescript, _uiSchema$uiReadonly;
  var schema = _ref.schema,
    id = _ref.id,
    name = _ref.name,
    options = _ref.options,
    label = _ref.label,
    hideLabel = _ref.hideLabel,
    required = _ref.required,
    disabled = _ref.disabled,
    readonly = _ref.readonly,
    value = _ref.value,
    onChange = _ref.onChange,
    uiSchema = _ref.uiSchema,
    formContext = _ref.formContext,
    otherProps = _objectWithoutPropertiesLoose(_ref, _excluded$5);
  var uniqueKey = name + "-unique-select";
  var formState = formContext == null ? void 0 : formContext["formState"];
  var extraState = formContext == null ? void 0 : formContext["extraState"];
  var dynamicFormContextQueryKey = (_formContext$dynamicF = formContext == null ? void 0 : formContext["dynamicFormContextQueryKey"]) != null ? _formContext$dynamicF : "";
  var asyncConfig = uiSchema == null ? void 0 : uiSchema["ui:asyncConfig"];
  var enumOptions = options.enumOptions;
  var _useState = useState(null),
    radioValue = _useState[0],
    setRadioValue = _useState[1];
  var enumOptionsFromDefinition = useMemo(function () {
    var _enumOptions$map;
    return (_enumOptions$map = enumOptions == null ? void 0 : enumOptions.map(function (el) {
      var _el$value;
      return {
        label: el == null ? void 0 : el.label,
        value: el == null || (_el$value = el.value) == null ? void 0 : _el$value.value
      };
    })) != null ? _enumOptions$map : [];
  }, [enumOptions]);
  var _useCustomSelect = useCustomSelect(asyncConfig, dynamicFormContextQueryKey ? [dynamicFormContextQueryKey, uniqueKey] : uniqueKey, {
      formState: formState,
      extraState: extraState
    }, !!(asyncConfig != null && asyncConfig.url)),
    resOptionList = _useCustomSelect.resOptionList;
  var optionList = useMemo(function () {
    return (resOptionList == null ? void 0 : resOptionList.length) > 0 ? resOptionList : enumOptionsFromDefinition || [];
  }, [enumOptionsFromDefinition, name, resOptionList]);
  var handleValueChange = function handleValueChange(event) {
    var newValue = event.target.value;
    onChange == null || onChange(newValue);
    if (!newValue) {
      setRadioValue(null);
    }
  };
  var handleSingleInitValue = function handleSingleInitValue(optionList) {
    var newValue = optionList == null ? void 0 : optionList.find(function (el) {
      if (Array.isArray(value)) {
        return value == null ? void 0 : value.some(function (item) {
          return "" + item === "" + (el == null ? void 0 : el.value);
        });
      }
      if (typeof value !== "object") {
        return value && "" + (el == null ? void 0 : el.value) === "" + value;
      }
      return value && "" + (el == null ? void 0 : el.value) === "" + (value == null ? void 0 : value.value);
    });
    return newValue;
  };
  useEffect(function () {
    var _newValue$value;
    if (!optionList || (optionList == null ? void 0 : optionList.length) === 0 || !value) {
      return;
    }
    var newValue = handleSingleInitValue(optionList);
    setRadioValue((_newValue$value = newValue == null ? void 0 : newValue.value) != null ? _newValue$value : null);
    return;
  }, [optionList, value]);
  return React.createElement(React.Fragment, null, React.createElement(CustomizedFormLabel, {
    label: (_labelValue = labelValue(label || undefined, hideLabel, false)) != null ? _labelValue : "",
    labelKey: uiSchema == null ? void 0 : uiSchema["ui:labelKey"],
    required: required,
    description: (_uiSchema$uiDescript = uiSchema == null ? void 0 : uiSchema["ui:description"]) != null ? _uiSchema$uiDescript : schema["description"],
    icon: uiSchema == null ? void 0 : uiSchema["ui:icon"],
    readonly: (_uiSchema$uiReadonly = uiSchema == null ? void 0 : uiSchema["ui:readonly"]) != null ? _uiSchema$uiReadonly : schema == null ? void 0 : schema["readOnly"],
    disabled: uiSchema == null ? void 0 : uiSchema["ui:disabled"]
  }), React.createElement(RadioGroup, {
    value: radioValue,
    onChange: handleValueChange,
    row: true
  }, Array.isArray(optionList) && optionList.map(function (option, index) {
    var radio = React.createElement(FormControlLabel, {
      control: React.createElement(Radio, {
        name: id,
        id: optionId(id, index),
        color: "primary"
      }),
      label: option.label,
      value: option.value,
      key: index,
      disabled: disabled || readonly
    });
    return radio;
  })));
}

var Form = /*#__PURE__*/withTheme(Theme);
var DynamicFormCompBasicJsonSchema = /*#__PURE__*/forwardRef(function (_ref, ref) {
  var uniqueKey = _ref.uniqueKey,
    jsonData = _ref.jsonData,
    onFormSubmit = _ref.onFormSubmit,
    initialFormData = _ref.initialFormData,
    okKey = _ref.okKey,
    _ref$okText = _ref.okText,
    okText = _ref$okText === void 0 ? 'Submit' : _ref$okText,
    cancelKey = _ref.cancelKey,
    _ref$cancelText = _ref.cancelText,
    cancelText = _ref$cancelText === void 0 ? 'Cancel' : _ref$cancelText,
    _ref$buttonPosition = _ref.buttonPosition,
    buttonPosition = _ref$buttonPosition === void 0 ? 'right' : _ref$buttonPosition,
    onCancel = _ref.onCancel,
    _ref$disabledFields = _ref.disabledFields,
    disabledFields = _ref$disabledFields === void 0 ? [] : _ref$disabledFields,
    _ref$removeButtons = _ref.removeButtons,
    removeButtons = _ref$removeButtons === void 0 ? false : _ref$removeButtons,
    _ref$disabled = _ref.disabled,
    disabled = _ref$disabled === void 0 ? false : _ref$disabled,
    _ref$forbiddenSubmit = _ref.forbiddenSubmit,
    forbiddenSubmit = _ref$forbiddenSubmit === void 0 ? false : _ref$forbiddenSubmit,
    _ref$viewType = _ref.viewType,
    viewType = _ref$viewType === void 0 ? false : _ref$viewType,
    extraState = _ref.extraState,
    viewComponent = _ref.viewComponent,
    formContextQueryKey = _ref.formContextQueryKey,
    _ref$shadowFormState = _ref.shadowFormState,
    shadowFormState = _ref$shadowFormState === void 0 ? {} : _ref$shadowFormState,
    _ref$transformStateBy = _ref.transformStateByDefinitions,
    transformStateByDefinitions$1 = _ref$transformStateBy === void 0 ? transformStateByDefinitions : _ref$transformStateBy,
    _ref$transformDataMod = _ref.transformDataMode,
    transformDataMode = _ref$transformDataMod === void 0 ? false : _ref$transformDataMod;
  // const [dynamicFields, setDynamicFields] = useState<DynamicFields>([]);
  var submitButtonHideRef = useRef(null);
  var _useState = useState(initialFormData != null ? initialFormData : {}),
    formData = _useState[0],
    setFormData = _useState[1];
  var _useState2 = useState(initialFormData != null ? initialFormData : {}),
    formStateWithLabel = _useState2[0],
    setFormStateWithLabel = _useState2[1];
  var _useState3 = useState(extraState != null ? extraState : {}),
    extraData = _useState3[0],
    setExtraData = _useState3[1];
  var _useTranslation = useTranslation(),
    t = _useTranslation.t;
  var queryClient = useQueryClient();
  // const dynamicSchema = dynamicMap?.get(uniqueKey)?.schema;
  var dynamicSchema = useMemo(function () {
    if (jsonData && (jsonData == null ? void 0 : jsonData.length) > 0) {
      return ConvertJsonSchemaFunc(jsonData, disabledFields, viewType);
    }
    return ConvertJsonSchemaFunc([], disabledFields);
  }, [disabledFields, jsonData, uniqueKey, viewType]);
  var handleFormStateWithLabelChange = function handleFormStateWithLabelChange(field, data) {
    setFormStateWithLabel(produce(function (draft) {
      var _ref2;
      if (!draft) return _ref2 = {}, _ref2[field] = data, _ref2;
      draft[field] = data;
      return draft;
    }));
  };
  // console.log("uniqueKey", uniqueKey);
  // console.log("dynamicMap", dynamicMap);
  // console.log("info", info);
  // console.log("dynamicFields", dynamicFields);
  console.log('DynamicFormCompBasicJsonSchema formData------------', formData);
  useEffect(function () {
    if (initialFormData && !isEqual(initialFormData, formData)) {
      setFormData(initialFormData);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [initialFormData]);
  useEffect(function () {
    if (extraState && !isEqual(extraState, extraData)) {
      setExtraData(extraState);
    }
  }, [extraState]);
  useImperativeHandle(ref, function () {
    return {
      submitForm: function submitForm() {
        var _submitButtonHideRef$;
        return submitButtonHideRef == null || (_submitButtonHideRef$ = submitButtonHideRef.current) == null ? void 0 : _submitButtonHideRef$.click();
      },
      clearFormState: function clearFormState() {
        return setFormData({});
      },
      getFormState: function getFormState() {
        return formData;
      }
    };
  }, []);
  useEffect(function () {
    return function () {
      formContextQueryKey && (queryClient == null ? void 0 : queryClient.removeQueries([formContextQueryKey]));
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  return React.createElement(Form
  // tagName="div"
  // noValidate
  , {
    // tagName="div"
    // noValidate
    noHtml5Validate: true,
    schema: dynamicSchema == null ? void 0 : dynamicSchema.jsonSchema,
    validator: validator,
    uiSchema: dynamicSchema == null ? void 0 : dynamicSchema.uiSchema,
    formData: formData,
    formContext: {
      formState: formData,
      extraState: extraData,
      viewComponent: viewComponent,
      formStateWithLabel: formStateWithLabel,
      onFormStateWithLabelChange: handleFormStateWithLabelChange,
      dynamicFormContextQueryKey: formContextQueryKey,
      shadowFormState: shadowFormState
    },
    omitExtraData // omit the extra; will cause remove some data auto, need clear handle.
    : true,
    idPrefix: uniqueKey,
    disabled: disabled,
    // readonly // readonly to all fields
    showErrorList: false,
    // just validate on submit.
    liveValidate: false,
    templates: {
      ObjectFieldTemplate: ObjectFieldTemplate,
      BaseInputTemplate: BaseInputTemplate,
      DescriptionFieldTemplate: DescriptionField,
      FieldErrorTemplate: FieldErrorTemplate,
      TitleFieldTemplate: TitleField
    },
    widgets: {
      CustomSelectWidget: SelectWidget,
      CustomDateWidget: CustomDateWidget,
      CustomViewWidget: CustomViewWidget,
      CustomRadioWidget: RadioWidget,
      CustomChipsInput: CustomChipsInput,
      CustomCheckboxesWidget: CheckboxesWidget,
      CustomCheckboxWidget: CheckboxWidget
    },
    onSubmit: function onSubmit(data) {
      console.log('on submit data: ', data, data == null ? void 0 : data.formData);
      // console.log("exist data: ", formData);
      setFormData(data == null ? void 0 : data.formData);
      if (forbiddenSubmit) return;
      if (transformDataMode) {
        var newFormState = transformStateByDefinitions$1(data == null ? void 0 : data.formData, jsonData);
        onFormSubmit == null || onFormSubmit(newFormState);
        return;
      }
      onFormSubmit == null || onFormSubmit(data == null ? void 0 : data.formData);
    },
    onError: function onError(errors) {
      console.log('errors', errors);
    },
    onChange: function onChange(data) {
      // console.log("on change data: ", data?.formData);
      setFormData(function (prev) {
        return _extends({}, prev, data == null ? void 0 : data.formData);
      });
    },
    customValidate: function customValidate(formData, errors) {
      var _dynamicSchema$zodSch, _parseRes$error$flatt;
      console.log('formData: ', formData);
      var parseRes = dynamicSchema == null || (_dynamicSchema$zodSch = dynamicSchema.zodSchema) == null ? void 0 : _dynamicSchema$zodSch.safeParse(formData);
      console.log('parseRes: ', parseRes);
      if (!parseRes || parseRes != null && parseRes.success) {
        return errors;
      }
      console.log('parseRes.error: ', parseRes.error);
      var errorMsg = (_parseRes$error$flatt = parseRes.error.flatten()) == null ? void 0 : _parseRes$error$flatt.fieldErrors;
      var fields = Object.keys(formData);
      // console.log("errorMsg", errorMsg);
      // console.log("fields", fields);
      for (var _i = 0, _fields = fields; _i < _fields.length; _i++) {
        var _errorMsg$field;
        var field = _fields[_i];
        if (field in errorMsg && (errorMsg == null || (_errorMsg$field = errorMsg[field]) == null ? void 0 : _errorMsg$field.length) > 0) {
          var _errors$field, _errorMsg$field$, _errorMsg$field2;
          // console.log("field", field);
          (_errors$field = errors[field]) == null || _errors$field.addError((_errorMsg$field$ = errorMsg == null || (_errorMsg$field2 = errorMsg[field]) == null ? void 0 : _errorMsg$field2[0]) != null ? _errorMsg$field$ : '');
          // console.log("field errors: ", errors[field]?.__errors);
        }
      }
      console.log('formData: ', formData);
      return errors;
    },
    // transformErrors exec before customValidate.
    transformErrors: function transformErrors(errors) {
      var finalErrors = [];
      for (var _iterator = _createForOfIteratorHelperLoose(errors), _step; !(_step = _iterator()).done;) {
        var err = _step.value;
        if ((err == null ? void 0 : err.name) === 'required') {
          var _err$message;
          var labelName = err == null || (_err$message = err.message) == null || (_err$message = _err$message.split('required property')) == null || (_err$message = _err$message[1]) == null ? void 0 : _err$message.slice(2, -1);
          finalErrors.push(_extends({}, err, {
            message: (labelName != null ? labelName : err.property) + " " + t('validation.isRequired')
          }));
        }
      }
      // console.log("errors", errors);
      console.log('finalErrors', finalErrors);
      return finalErrors;
    }
  }, !removeButtons && React.createElement(Stack, {
    direction: "row",
    alignItems: "center",
    justifyContent: buttonPosition === 'left' ? 'flex-start' : buttonPosition === 'right' ? 'flex-end' : 'center',
    gap: 1,
    mt: 4
  }, React.createElement(Button, {
    variant: "text",
    onClick: onCancel,
    "data-testid": "cancelBtn",
    size: "small"
  }, cancelKey ? t(cancelKey) : cancelText), !forbiddenSubmit && React.createElement(Button, {
    "data-testid": "okBtn",
    size: "small",
    variant: "contained",
    type: "submit",
    ref: submitButtonHideRef
  }, okKey ? t(okKey) : okText)), removeButtons && React.createElement(Stack, {
    direction: "row",
    alignItems: "center",
    justifyContent: buttonPosition === 'left' ? 'flex-start' : buttonPosition === 'right' ? 'flex-end' : 'center',
    gap: 1,
    mt: 4,
    display: "none"
  }, React.createElement(Button, {
    "data-testid": "okBtn",
    size: "small",
    variant: "contained",
    type: "submit",
    ref: submitButtonHideRef
  }, okKey ? t(okKey) : okText)));
});

var DatePickerValue = function DatePickerValue(_ref) {
  var value = _ref.value,
    _onChange = _ref.onChange,
    onClear = _ref.onClear,
    placeholder = _ref.placeholder,
    width = _ref.width,
    maxDate = _ref.maxDate,
    minDate = _ref.minDate;
  var _React$useState = React.useState(false),
    open = _React$useState[0],
    setOpen = _React$useState[1];
  // const [innerValue, setInnerValue] = React.useState<Dayjs | null>(dayjs());
  return React.createElement(FormControl, {
    sx: {
      my: 1,
      width: width != null ? width : 140
    },
    size: "small"
  }, React.createElement(LocalizationProvider$1, {
    dateAdapter: AdapterDayjs
  }, React.createElement(DatePicker$1, {
    className: "custom-date-picker",
    inputFormat: "DD/MM/YYYY",
    value: value != null ? value : "",
    onChange: function onChange(newVal) {
      return _onChange == null ? void 0 : _onChange(dayjs(newVal).valueOf());
    },
    open: open,
    onOpen: function onOpen() {
      return setOpen(true);
    },
    onClose: function onClose() {
      return setOpen(false);
    },
    maxDate: maxDate,
    minDate: minDate,
    renderInput: function renderInput(params) {
      var _params$inputProps;
      // console.log("params?.value: ", params);
      return React.createElement(TextField, Object.assign({}, params, {
        inputProps: _extends({}, params.inputProps, {
          value: value ? dayjs(value).format("DD/MM/YYYY") : "",
          readOnly: true,
          placeholder: placeholder != null ? placeholder : "Select Date"
        }),
        error: false,
        variant: "standard",
        size: "small",
        sx: {
          maxWidth: width ? width + "px" : "140px"
        },
        onClick: function onClick() {
          return setOpen(true);
        },
        InputProps: {
          endAdornment: React.createElement(InputAdornment, {
            position: "end"
          }, !!((_params$inputProps = params.inputProps) != null && _params$inputProps.value) && React.createElement(HighlightOffOutlinedIcon, {
            onClick: function onClick(ev) {
              ev.preventDefault();
              ev.stopPropagation();
              onClear == null || onClear();
            },
            sx: {
              marginBottom: "4px",
              marginX: "5px",
              fontSize: "14px",
              color: "GrayText",
              "&:hover": {
                color: "Highlight",
                cursor: "pointer"
              }
            }
          }), React.createElement(IconButton, {
            size: "small",
            sx: {
              borderRadius: "50%",
              marginBottom: "4px"
            }
          }, React.createElement(CalendarMonthOutlinedIcon, {
            sx: {
              fontSize: "16px",
              color: "GrayText",
              "&:hover": {
                color: "Highlight"
              }
            }
          })))
        }
      }));
    }
  })));
};

var useCustomSelect$1 = function useCustomSelect(asyncConfig, uniqueKey, formState, enabled) {
  var _asyncConfig$method, _process$env, _ref, _asyncConfig$prefixEn, _asyncConfig$url;
  if (enabled === void 0) {
    enabled = true;
  }
  console.log('formState--------------', formState);
  var _useFreyrLibraryConte = useFreyrLibraryContext(),
    tenant = _useFreyrLibraryConte.tenant,
    domain = _useFreyrLibraryConte.domain,
    domainName = _useFreyrLibraryConte.domainName;
  var asyncConfigParams = useMemo(function () {
    var _asyncConfig$params;
    var params = {};
    asyncConfig == null || (_asyncConfig$params = asyncConfig.params) == null || _asyncConfig$params.forEach(function (el) {
      var _el$value;
      params[el == null ? void 0 : el.fieldName] = (_el$value = el == null ? void 0 : el.value) != null ? _el$value : get(formState, el == null ? void 0 : el.valuePath, null);
    });
    return params;
  }, [asyncConfig == null ? void 0 : asyncConfig.params, formState]);
  var asyncConfigBodyData = useMemo(function () {
    var _asyncConfig$body;
    var data = {};
    asyncConfig == null || (_asyncConfig$body = asyncConfig.body) == null || _asyncConfig$body.forEach(function (el) {
      var _el$value2;
      data[el == null ? void 0 : el.fieldName] = (_el$value2 = el == null ? void 0 : el.value) != null ? _el$value2 : get(formState, el == null ? void 0 : el.valuePath, null);
    });
    return data;
  }, [asyncConfig == null ? void 0 : asyncConfig.body, formState]);
  var dependencyVars = useMemo(function () {
    var _asyncConfig$dependen;
    var dependencyVars = {};
    asyncConfig == null || (_asyncConfig$dependen = asyncConfig.dependencies) == null || _asyncConfig$dependen.forEach(function (el) {
      dependencyVars[el] = asyncConfigParams == null ? void 0 : asyncConfigParams[el];
    });
    return dependencyVars;
  }, [asyncConfig == null ? void 0 : asyncConfig.dependencies, asyncConfigParams]);
  var dependencyBodyVars = useMemo(function () {
    var _asyncConfig$dependen2;
    var dependencyVars = {};
    asyncConfig == null || (_asyncConfig$dependen2 = asyncConfig.dependencies) == null || _asyncConfig$dependen2.forEach(function (el) {
      dependencyVars[el] = asyncConfigBodyData == null ? void 0 : asyncConfigBodyData[el];
    });
    return dependencyVars;
  }, [asyncConfig == null ? void 0 : asyncConfig.dependencies, asyncConfigBodyData]);
  var method = (_asyncConfig$method = asyncConfig == null ? void 0 : asyncConfig.method) != null ? _asyncConfig$method : "GET";
  var fetchOptionList = getFetchOptionListFunc("" + ((_process$env = process.env[(_ref = (_asyncConfig$prefixEn = asyncConfig == null ? void 0 : asyncConfig.prefixEnvName) != null ? _asyncConfig$prefixEn : asyncConfig == null ? void 0 : asyncConfig.basicUrl) != null ? _ref : ""]) != null ? _process$env : process.env.REACT_APP_API_GETWAY) + ((_asyncConfig$url = asyncConfig == null ? void 0 : asyncConfig.url) != null ? _asyncConfig$url : ""), method, {
    params: asyncConfigParams,
    data: _extends({}, asyncConfigBodyData, {
      tenantId: tenant,
      domainId: domain,
      domainName: domainName
    })
  });
  console.log("enabled", enabled);
  var _useQuery = useQuery([uniqueKey, dependencyVars, dependencyBodyVars], function () {
      return fetchOptionList();
    }, {
      enabled: enabled,
      staleTime: Infinity,
      refetchOnWindowFocus: false,
      select: function select(data) {
        var _resData$data, _resData$data2;
        // console.log("select data: ", data);
        var resData = data == null ? void 0 : data.data;
        if (Number(resData == null ? void 0 : resData.code) !== 200 || !(resData != null && resData.data) || (resData == null || (_resData$data = resData.data) == null ? void 0 : _resData$data.length) === 0) {
          return [];
        }
        if (!(asyncConfig != null && asyncConfig.valuePath)) {
          return [];
        }
        if (asyncConfig != null && asyncConfig.listDataPath) {
          var _listData;
          var listData = get(resData == null ? void 0 : resData.data, asyncConfig == null ? void 0 : asyncConfig.listDataPath, []);
          if (typeof listData === "string") {
            listData = JSON.parse(listData);
          }
          console.log("listData---: ", listData);
          return (_listData = listData) == null ? void 0 : _listData.map(function (el) {
            return {
              label: get(el, asyncConfig == null ? void 0 : asyncConfig.labelPath),
              value: get(el, asyncConfig == null ? void 0 : asyncConfig.valuePath)
            };
          });
        }
        return resData == null || (_resData$data2 = resData.data) == null ? void 0 : _resData$data2.map(function (el) {
          var _Object$values;
          return {
            label: get(el, asyncConfig == null ? void 0 : asyncConfig.labelPath),
            // value: get(el, asyncConfig?.valuePath),
            value: (_Object$values = Object.values(el.id_mapping)) == null ? void 0 : _Object$values[0],
            id_mapping: el.id_mapping
          };
        });
      }
    }),
    resOptionList = _useQuery.data,
    isLoading = _useQuery.isLoading,
    remove = _useQuery.remove;
  useEffect(function () {
    return function () {
      remove == null || remove();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  return {
    asyncConfigParams: asyncConfigParams,
    dependencyVars: dependencyVars,
    resOptionList: resOptionList,
    fetchLoading: isLoading && enabled
  };
};

var useFilterItemsStore = /*#__PURE__*/create()( /*#__PURE__*/subscribeWithSelector( /*#__PURE__*/immer(function (set, get) {
  return {
    // keyword: "",
    filterItems: [],
    fieldsState: {},
    updateFilterItems: function updateFilterItems(data) {
      set(function (state) {
        state.filterItems = data;
        return state;
      });
    },
    updateFieldsState: function updateFieldsState(field, data) {
      set(function (state) {
        if (field === "All") {
          state.fieldsState = data;
        } else {
          state.fieldsState[field] = data;
        }
        // state.fieldsState[field] = data;
        return state;
      });
    },
    removeSpareField: function removeSpareField(data) {
      console.log("data11", data);
      if ("keepFields" in data && data != null && data.keepFields) {
        var _Object$entries;
        var newFieldsState = Object.fromEntries((_Object$entries = Object.entries(get().fieldsState)) == null ? void 0 : _Object$entries.filter(function (_ref) {
          var _data$keepFields;
          var field = _ref[0];
          return data == null || (_data$keepFields = data.keepFields) == null ? void 0 : _data$keepFields.includes(field);
        }));
        console.log("===================2", newFieldsState);
        var newFilterItems;
        if (data != null && data.newFilterItems) {
          var _data$newFilterItems;
          newFilterItems = (_data$newFilterItems = data == null ? void 0 : data.newFilterItems) != null ? _data$newFilterItems : [];
        } else {
          var _cloneDeep;
          newFilterItems = (_cloneDeep = cloneDeep$1(get().filterItems)) == null ? void 0 : _cloneDeep.filter(function (el) {
            var _data$keepFields2, _el$data;
            return data == null || (_data$keepFields2 = data.keepFields) == null ? void 0 : _data$keepFields2.includes(el == null || (_el$data = el.data) == null ? void 0 : _el$data.field);
          });
          // console.log("newFilterItems", newFilterItems);
        }
        set(function (state) {
          state.fieldsState = newFieldsState;
          state.filterItems = newFilterItems;
          // state.realFilterParams = newFieldsState;
          return state;
        });
      }
      if ("removeFields" in data && data != null && data.removeFields) {
        var _Object$entries2;
        var _newFieldsState = Object.fromEntries((_Object$entries2 = Object.entries(get().fieldsState)) == null ? void 0 : _Object$entries2.filter(function (_ref2) {
          var _data$removeFields;
          var field = _ref2[0];
          return !(data != null && (_data$removeFields = data.removeFields) != null && _data$removeFields.includes(field));
        }));
        console.log("===================3", _newFieldsState);
        var _newFilterItems;
        if (data != null && data.newFilterItems) {
          var _data$newFilterItems2;
          _newFilterItems = (_data$newFilterItems2 = data == null ? void 0 : data.newFilterItems) != null ? _data$newFilterItems2 : [];
        } else {
          var _cloneDeep$filter, _cloneDeep2;
          _newFilterItems = (_cloneDeep$filter = (_cloneDeep2 = cloneDeep$1(get().filterItems)) == null ? void 0 : _cloneDeep2.filter(function (el) {
            var _data$removeFields2, _el$data2;
            return !(data != null && (_data$removeFields2 = data.removeFields) != null && _data$removeFields2.includes(el == null || (_el$data2 = el.data) == null ? void 0 : _el$data2.field));
          })) != null ? _cloneDeep$filter : [];
        }
        set(function (state) {
          state.fieldsState = _newFieldsState;
          state.filterItems = _newFilterItems;
          // state.realFilterParams = newFieldsState;
          return state;
        });
        // useViewModelStore?.getState()?.resetPagination?.();
      }
    }
  };
})));
var useNonPersistentFilterItemsStore = /*#__PURE__*/create( /*#__PURE__*/immer(function (set, get) {
  return {
    identifiers: [],
    updateIdentifiers: function updateIdentifiers(data) {
      set(function (state) {
        state.identifiers = data;
        return state;
      });
    }
  };
}));
var useGlobalFilterState = function useGlobalFilterState() {
  var _useFilterItemsStore = useFilterItemsStore(function (state) {
      return [state == null ? void 0 : state.fieldsState];
    }),
    fieldsState = _useFilterItemsStore[0];
  var _useNonPersistentFilt = useNonPersistentFilterItemsStore(function (state) {
      return [state == null ? void 0 : state.identifiers];
    }),
    identifiers = _useNonPersistentFilt[0];
  var fieldsStateFormatted = useMemo(function () {
    var formattedData = mapValues(fieldsState, function (items, key) {
      var identifier = identifiers == null ? void 0 : identifiers.find(function (identifier) {
        var _identifier$data;
        return ((_identifier$data = identifier.data) == null ? void 0 : _identifier$data.field) === key;
      });
      var filterType = identifier ? identifier.data.itemType === "select" : false;
      if (filterType) {
        return items.map(function (item) {
          if (item.id_mapping) {
            var _Object$values;
            var commonCode = (_Object$values = Object.values(item.id_mapping)) == null ? void 0 : _Object$values[0];
            return commonCode != null ? commonCode : item.value;
          } else if (item.value) {
            return item.value;
          }
        });
      }
    });
    for (var key in formattedData) {
      var value = formattedData[key];
      if (value === undefined || Array.isArray(value) && !value.length) {
        delete formattedData[key];
      }
    }
    return formattedData;
  }, [fieldsState]);
  return {
    fieldsStateFormatted: fieldsStateFormatted
  };
};

var SelectItemComp = function SelectItemComp(_ref) {
  var _ref$selected = _ref.selected,
    selected = _ref$selected === void 0 ? false : _ref$selected,
    label = _ref.label,
    value = _ref.value,
    onChange = _ref.onChange,
    _ref$disabled = _ref.disabled,
    disabled = _ref$disabled === void 0 ? false : _ref$disabled,
    _ref$mode = _ref.mode,
    mode = _ref$mode === void 0 ? "plain" : _ref$mode;
  if (mode === "checkbox") {
    return React.createElement(MenuItem, {
      disabled: disabled,
      selected: selected,
      sx: {
        maxWidth: "330px"
      },
      onClick: function onClick() {
        if (disabled) {
          return;
        }
        onChange == null || onChange({
          label: label,
          value: value
        });
      }
    }, React.createElement(ListItemIcon, null, React.createElement(Checkbox$1, {
      checked: selected
    })), React.createElement(ListItemText, {
      title: label != null ? label : "",
      sx: {
        maxWidth: "80%",
        "& .MuiListItemText-primary": {
          overflow: "hidden",
          textOverflow: "ellipsis",
          whiteSpace: "nowrap"
        }
      }
    }, label != null ? label : ""));
  }
  return React.createElement(Stack, {
    direction: "row",
    justifyContent: "space-between",
    alignItems: "center",
    sx: {
      minHeight: "40px",
      borderRadius: "8px",
      boxSizing: "border-box",
      padding: "0 20px",
      maxWidth: "330px",
      backgroundColor: disabled ? "#f7f7f8" : selected ? "#eff2ff" : "#f7f7f8",
      "& .hover-selectable-icon": {
        display: "none"
      },
      "&:hover": {
        cursor: disabled ? "not-allowed" : "pointer",
        backgroundColor: disabled ? "#f7f7f8" : "#eff2ff"
      },
      "&:hover .hover-selectable-icon": {
        display: "initial"
      }
    },
    onClick: function onClick() {
      if (disabled) {
        return;
      }
      onChange == null || onChange({
        label: label,
        value: value
      });
    }
  }, React.createElement(Typography, {
    sx: {
      maxWidth: "85%",
      overflow: "hidden",
      textOverflow: "ellipsis",
      whiteSpace: "nowrap"
    },
    title: label != null ? label : ""
  }, label != null ? label : ""), selected && React.createElement(CheckIcon, {
    sx: {
      fontSize: "18px",
      color: "#567cde",
      scale: "1.5"
    }
  }), !selected && React.createElement(CheckIcon, {
    className: "hover-selectable-icon",
    sx: {
      fontSize: "18px",
      color: "#acc0f2",
      scale: "1.5"
    }
  }));
};
var FilterSelectShowComp = function FilterSelectShowComp(_ref2) {
  var _ref2$open = _ref2.open,
    open = _ref2$open === void 0 ? false : _ref2$open,
    setOpen = _ref2.setOpen,
    label = _ref2.label,
    showItemLabel = _ref2.showItemLabel,
    selectedLen = _ref2.selectedLen,
    _ref2$identifierMode = _ref2.identifierMode,
    identifierMode = _ref2$identifierMode === void 0 ? false : _ref2$identifierMode,
    _ref2$clearIcon = _ref2.clearIcon,
    clearIcon = _ref2$clearIcon === void 0 ? false : _ref2$clearIcon,
    onClearClick = _ref2.onClearClick,
    _ref2$disable = _ref2.disable,
    disable = _ref2$disable === void 0 ? false : _ref2$disable;
  var _useTranslation = useTranslation();
  return React.createElement(Stack, {
    direction: "row",
    gap: 1,
    alignItems: "center",
    onClick: function onClick() {
      return !disable && (setOpen == null ? void 0 : setOpen(!open));
    },
    sx: {
      "&:hover": {
        cursor: disable ? "not-allowed" : "pointer"
      }
    }
  }, clearIcon && React.createElement(ClearRoundedIcon
  // sx={{
  //   fontSize: "14px",
  //   marginTop: "-2px",
  // }}
  , {
    // sx={{
    //   fontSize: "14px",
    //   marginTop: "-2px",
    // }}
    onClick: function onClick() {
      return !disable && (onClearClick == null ? void 0 : onClearClick());
    }
  }), React.createElement(Typography, {
    whiteSpace: "nowrap",
    sx: {
      fontWeight: !identifierMode ? '700 !important' : '500'
    }
  }, label != null ? label : "", !identifierMode && !!showItemLabel && ": "), !identifierMode && React.createElement(React.Fragment, null, showItemLabel && React.createElement(Typography, {
    fontWeight: "bold",
    whiteSpace: "nowrap",
    className: "weight-600"
  }, showItemLabel != null ? showItemLabel : ""), selectedLen !== undefined && selectedLen > 0 && React.createElement(Typography, {
    className: "filter-selected-count"
  }, selectedLen && selectedLen > 0 ? "+" + selectedLen : ""), open && React.createElement(ArrowDropUpIcon, null), !open && React.createElement(ArrowDropDownIcon, null)), identifierMode && React.createElement(AddIcon, {
    sx: {
      // fontSize: "14px",
      // marginTop: "-2px",
    }
  }));
};
var FilterSelectPopper = function FilterSelectPopper(_ref3) {
  var _ref4, _ref5;
  var field = _ref3.field,
    _ref3$open = _ref3.open,
    open = _ref3$open === void 0 ? false : _ref3$open,
    setOpen = _ref3.setOpen,
    anchorEl = _ref3.anchorEl,
    _ref3$selected = _ref3.selected,
    selected = _ref3$selected === void 0 ? [] : _ref3$selected,
    _ref3$options = _ref3.options,
    options = _ref3$options === void 0 ? [] : _ref3$options,
    onChange = _ref3.onChange,
    label = _ref3.label,
    totalLabel = _ref3.totalLabel,
    searchPlaceholder = _ref3.searchPlaceholder,
    selectedLen = _ref3.selectedLen,
    onClear = _ref3.onClear,
    listItemMode = _ref3.listItemMode,
    _ref3$isLoading = _ref3.isLoading,
    isLoading = _ref3$isLoading === void 0 ? false : _ref3$isLoading;
  var _useState = useState(""),
    filterKey = _useState[0],
    setFilterKey = _useState[1];
  var _useTranslation2 = useTranslation(),
    t = _useTranslation2.t;
  var filteredOptions = useMemo(function () {
    var _options$filter;
    return (_options$filter = options == null ? void 0 : options.filter(function (el) {
      var _el$label;
      return el == null || (_el$label = el.label) == null || (_el$label = _el$label.toLowerCase()) == null ? void 0 : _el$label.includes(filterKey == null ? void 0 : filterKey.toLowerCase());
    })) != null ? _options$filter : [];
  }, [filterKey, options]);
  return React.createElement(Popover, {
    id: label,
    open: open,
    anchorEl: anchorEl,
    className: "filters-popover",
    onClose: function onClose() {
      return setOpen == null ? void 0 : setOpen(false);
    },
    anchorOrigin: {
      vertical: "bottom",
      horizontal: "left"
    },
    transformOrigin: {
      horizontal: 0,
      vertical: -3
    }
  }, React.createElement(Paper, {
    className: "paper"
  }, React.createElement(Box, {
    className: "filters-popover-box",
    sx: {
      boxSizing: "border-box",
      minWidth: "350px",
      minHeight: "200px",
      maxHeight: "500px",
      padding: "10px"
    }
  }, React.createElement(Stack, {
    className: "filters-popover-header",
    direction: "row",
    justifyContent: "space-between",
    alignItems: "center"
  }, React.createElement(Typography, null, (_ref4 = label != null ? label : field) != null ? _ref4 : ""), React.createElement(Button, {
    variant: "text",
    size: "small",
    onClick: onClear
  }, t("filter.clear"))), React.createElement(Box, {
    marginY: 1,
    className: "filters-popover-search"
  }, React.createElement(TextField, {
    fullWidth: true,
    variant: "outlined",
    size: "small",
    placeholder: searchPlaceholder != null ? searchPlaceholder : t("common.search") + ("" + field),
    // startDecorator={<SearchOutlinedIcon />}
    value: filterKey,
    onChange: function onChange(ev) {
      var _ev$target$value, _ev$target;
      setFilterKey((_ev$target$value = ev == null || (_ev$target = ev.target) == null ? void 0 : _ev$target.value) != null ? _ev$target$value : "");
    },
    InputProps: {
      startAdornment: React.createElement(InputAdornment, {
        position: "start"
      }, React.createElement(SearchOutlinedIcon, null))
    }
  }), React.createElement(Typography, {
    fontSize: 10,
    marginY: 1
  }, t("filter.searchIntro"))), React.createElement(Stack, {
    direction: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginY: 1,
    className: "filters-popover-fileds-header"
  }, React.createElement(Typography, null, (_ref5 = totalLabel != null ? totalLabel : t("filter.total") + ("" + field)) != null ? _ref5 : "", " (", options == null ? void 0 : options.length, ")"), React.createElement(Typography, null, t("filter.selected"), " (", selectedLen != null ? selectedLen : 0, ")")), React.createElement(Box, {
    sx: {
      display: "flex"
    },
    justifyContent: "center"
  }, isLoading && React.createElement(CircularProgress$1, null)), React.createElement(Stack, {
    className: "filters-popover-fileds-data",
    direction: "column",
    gap: 0.5,
    maxHeight: "300px",
    sx: {
      overflowY: "auto",
      "::-webkit-scrollbar": {
        display: "none"
      }
    }
  }, filteredOptions == null ? void 0 : filteredOptions.map(function (el) {
    return React.createElement(SelectItemComp, {
      key: el.value,
      label: el.label,
      value: el.value,
      selected: selected == null ? void 0 : selected.includes(el == null ? void 0 : el.value),
      onChange: onChange,
      disabled: el == null ? void 0 : el.disabled,
      mode: listItemMode
    });
  })))));
};
var FilterSelectItem = function FilterSelectItem(_ref6) {
  var field = _ref6.field,
    label = _ref6.label,
    totalLabel = _ref6.totalLabel,
    searchPlaceholder = _ref6.searchPlaceholder,
    onValueChange = _ref6.onValueChange,
    _ref6$options = _ref6.options,
    options = _ref6$options === void 0 ? [] : _ref6$options,
    value = _ref6.value,
    onRemove = _ref6.onRemove,
    fieldItemMode = _ref6.fieldItemMode,
    _ref6$disable = _ref6.disable,
    disable = _ref6$disable === void 0 ? false : _ref6$disable,
    _ref6$asyncConfig = _ref6.asyncConfig,
    asyncConfig = _ref6$asyncConfig === void 0 ? null : _ref6$asyncConfig;
  var _useState2 = useState([]),
    selected = _useState2[0],
    setSelected = _useState2[1];
  var _useState3 = useState(false),
    open = _useState3[0],
    setOpen = _useState3[1];
  var domRef = useRef();
  var _useGlobalFilterState = useGlobalFilterState(),
    fieldsStateFormatted = _useGlobalFilterState.fieldsStateFormatted;
  var _useState4 = useState(),
    newParams = _useState4[0],
    setNewParams = _useState4[1];
  useEffect(function () {
    var state = cloneDeep$1(fieldsStateFormatted);
    console.log("state-------------", state);
    if (state[field]) delete state[field];
    if (!isEqual$1(state, newParams)) {
      setNewParams(state);
    }
  }, [fieldsStateFormatted]);
  var formState = {
    filter: newParams
  };
  var _useCustomSelect = useCustomSelect$1(asyncConfig, "global-filter-" + field, formState, !!asyncConfig && !!(asyncConfig != null && asyncConfig.url) && open),
    resOptionList = _useCustomSelect.resOptionList,
    fetchLoading = _useCustomSelect.fetchLoading;
  var realOptions = !!asyncConfig ? resOptionList : options;
  var showItemLabel = useMemo(function () {
    var _realOptions$find;
    if (!selected || (selected == null ? void 0 : selected.length) === 0) {
      return "";
    }
    var label = realOptions == null || (_realOptions$find = realOptions.find(function (el) {
      return (el == null ? void 0 : el.value) === (selected == null ? void 0 : selected[(selected == null ? void 0 : selected.length) - 1]);
    })) == null ? void 0 : _realOptions$find.label;
    return label;
  }, [realOptions, selected]);
  useEffect(function () {
    console.log("value++++++++++++++", value);
    if (!value || (value == null ? void 0 : value.length) === 0) {
      setSelected([]);
      return;
    }
    setSelected(value == null ? void 0 : value.map(function (el) {
      return el == null ? void 0 : el.value;
    }));
  }, [value]);
  console.log("selectedValue", selected);
  return React.createElement(Box, {
    ref: domRef,
    className: (selected == null ? void 0 : selected.length) > 0 ? "selected-filter" : "",
    sx: {
      height: "30px",
      boxSizing: "border-box",
      padding: "2px 5px",
      borderRadius: "5px",
      border: "1px solid #bdbdbd",
      margin: "6px 20px 6px 0",
      backgroundColor: (selected == null ? void 0 : selected.length) > 0 ? "#567cde" : "white",
      // minWidth: selected?.length === 0 ? "160px" : "200px",
      display: "inline-block",
      alignItems: "center",
      color: (selected == null ? void 0 : selected.length) > 0 ? "white" : "black",
      opacity: disable ? 0.5 : 1,
      cursor: disable ? "not-allowed" : "initial"
    }
  }, React.createElement(Box, {
    sx: {
      width: "100%",
      height: "100%",
      display: "flex",
      alignItems: "center"
    }
  }, React.createElement(FilterSelectShowComp, {
    field: field,
    open: open,
    setOpen: setOpen,
    label: label != null ? label : "",
    showItemLabel: showItemLabel,
    selectedLen: selected == null ? void 0 : selected.length,
    clearIcon: true,
    onClearClick: onRemove,
    disable: disable
  })), React.createElement(FilterSelectPopper, {
    isLoading: fetchLoading,
    field: field,
    open: open,
    setOpen: setOpen,
    anchorEl: domRef.current,
    options: realOptions,
    selected: selected,
    onChange: function onChange(data) {
      var index = selected == null ? void 0 : selected.findIndex(function (el) {
        return el === (data == null ? void 0 : data.value);
      });
      // console.log("data==: ", data, "index: ", index);
      if (index === -1) {
        var _newSelected = [].concat(structuredClone(selected), [data == null ? void 0 : data.value]);
        setSelected(_newSelected);
        var _wholeData = realOptions == null ? void 0 : realOptions.filter(function (el) {
          return _newSelected == null ? void 0 : _newSelected.includes(el == null ? void 0 : el.value);
        });
        onValueChange == null || onValueChange(_wholeData, data);
        return;
      }
      var newSelected = [].concat(structuredClone(selected)).filter(function (el) {
        return el !== (data == null ? void 0 : data.value);
      });
      // console.log("newSelected", newSelected);
      setSelected(newSelected);
      var wholeData = realOptions == null ? void 0 : realOptions.filter(function (el) {
        return newSelected == null ? void 0 : newSelected.includes(el == null ? void 0 : el.value);
      });
      onValueChange == null || onValueChange(wholeData, data);
    },
    label: label,
    totalLabel: totalLabel,
    searchPlaceholder: searchPlaceholder,
    selectedLen: selected == null ? void 0 : selected.length,
    onClear: function onClear() {
      setSelected([]);
      onValueChange == null || onValueChange([]);
    },
    listItemMode: fieldItemMode
  }));
};
var useIdentifierPopperState = /*#__PURE__*/create()( /*#__PURE__*/immer(function (set, get) {
  return {
    open: false,
    updateOpen: function updateOpen(val) {
      set(function (state) {
        state.open = val;
      });
    }
  };
}));
var IdentifiersSelectItem = function IdentifiersSelectItem(_ref7) {
  var field = _ref7.field,
    onValueChange = _ref7.onValueChange,
    value = _ref7.value,
    options = _ref7.options;
  var _useState5 = useState([]),
    selected = _useState5[0],
    setSelected = _useState5[1];
  var _useIdentifierPopperS = useIdentifierPopperState(function (state) {
      return [state.open, state.updateOpen];
    }),
    open = _useIdentifierPopperS[0],
    setOpen = _useIdentifierPopperS[1];
  var domRef = useRef();
  var realOptions = options;
  var _useTranslation3 = useTranslation(),
    t = _useTranslation3.t;
  var showItemLabel = useMemo(function () {
    var _realOptions$find2;
    if (!selected || (selected == null ? void 0 : selected.length) === 0) {
      return "";
    }
    var label = realOptions == null || (_realOptions$find2 = realOptions.find(function (el) {
      return (el == null ? void 0 : el.value) === (selected == null ? void 0 : selected[(selected == null ? void 0 : selected.length) - 1]);
    })) == null ? void 0 : _realOptions$find2.label;
    return label;
  }, [realOptions, selected]);
  useEffect(function () {
    if (!value || (value == null ? void 0 : value.length) === 0) {
      setSelected([]);
      return;
    }
    setSelected(value == null ? void 0 : value.map(function (el) {
      return el == null ? void 0 : el.value;
    }));
  }, [value]);
  // console.log("selected", selected);
  return React.createElement(Box, {
    ref: domRef,
    sx: {
      height: "30px",
      boxSizing: "border-box",
      padding: "2px 5px",
      borderRadius: "5px",
      border: "1px solid #bdbdbd",
      margin: "6px 20px 6px 0",
      backgroundColor: "white",
      // minWidth: selected?.length === 0 ? "160px" : "200px",
      display: "inline-block",
      alignItems: "center"
    }
  }, React.createElement(Box, {
    sx: {
      width: "100%",
      height: "100%",
      display: "flex",
      alignItems: "center"
    }
  }, React.createElement(FilterSelectShowComp, {
    field: field,
    open: open,
    setOpen: setOpen,
    label: t("filter.more"),
    showItemLabel: showItemLabel,
    selectedLen: selected == null ? void 0 : selected.length,
    identifierMode: true
  })), React.createElement(FilterSelectPopper, {
    field: field,
    open: open,
    setOpen: setOpen,
    anchorEl: domRef.current,
    options: realOptions,
    selected: selected,
    onChange: function onChange(data) {
      var index = selected == null ? void 0 : selected.findIndex(function (el) {
        return el === (data == null ? void 0 : data.value);
      });
      // console.log("data==: ", data, "index: ", index);
      if (index === -1) {
        var _newSelected2 = [].concat(structuredClone(selected), [data == null ? void 0 : data.value]);
        setSelected(_newSelected2);
        var _wholeData2 = realOptions == null ? void 0 : realOptions.filter(function (el) {
          return _newSelected2 == null ? void 0 : _newSelected2.includes(el == null ? void 0 : el.value);
        });
        _wholeData2 && (onValueChange == null ? void 0 : onValueChange(_wholeData2, data));
        return;
      }
      var newSelected = [].concat(structuredClone(selected)).filter(function (el) {
        return el !== (data == null ? void 0 : data.value);
      });
      // console.log("newSelected", newSelected);
      setSelected(newSelected);
      var wholeData = realOptions == null ? void 0 : realOptions.filter(function (el) {
        return newSelected == null ? void 0 : newSelected.includes(el == null ? void 0 : el.value);
      });
      wholeData && (onValueChange == null ? void 0 : onValueChange(wholeData, data));
    },
    label: t("filter.filterItems.label"),
    totalLabel: t("filter.filterItems.totalLabel"),
    searchPlaceholder: t("filter.filterItems.searchPlaceholder"),
    selectedLen: selected == null ? void 0 : selected.length,
    onClear: function onClear() {
      setSelected([]);
      onValueChange == null || onValueChange([]);
    },
    listItemMode: "checkbox"
  }));
};
var FilterIcons;
(function (FilterIcons) {
  FilterIcons[FilterIcons["Product"] = 1] = "Product";
  FilterIcons[FilterIcons["Country"] = 2] = "Country";
  FilterIcons[FilterIcons["Market"] = 3] = "Market";
  FilterIcons[FilterIcons["Function"] = 4] = "Function";
})(FilterIcons || (FilterIcons = {}));
var FilterSelectTimePopper = function FilterSelectTimePopper(_ref9) {
  var _dateRangeValue$type, _dateRangeValue$less;
  var _ref9$open = _ref9.open,
    open = _ref9$open === void 0 ? false : _ref9$open,
    setOpen = _ref9.setOpen,
    anchorEl = _ref9.anchorEl,
    _onChange = _ref9.onChange,
    dateRangeValue = _ref9.dateRangeValue;
  var _useState6 = useState((_dateRangeValue$type = dateRangeValue == null ? void 0 : dateRangeValue["type"]) != null ? _dateRangeValue$type : "less");
  var _useTranslation4 = useTranslation(),
    t = _useTranslation4.t;
  var removeBetweenDate = function removeBetweenDate() {
    if ((dateRangeValue == null ? void 0 : dateRangeValue.type) === 'between') {
      var isRemoveDate = !dateRangeValue.fromDate && !dateRangeValue.toDate || dateRangeValue.fromDate && dateRangeValue.toDate;
      if (!isRemoveDate) {
        _onChange == null || _onChange({
          type: "between",
          fromDate: "",
          toDate: ""
        });
      }
    }
  };
  return React.createElement(Popover, {
    id: "date-picker-popover",
    open: open,
    anchorEl: anchorEl,
    onClose: function onClose() {
      setOpen == null || setOpen(false);
      removeBetweenDate();
    },
    anchorOrigin: {
      vertical: "bottom",
      horizontal: "left"
    },
    transformOrigin: {
      horizontal: 0,
      vertical: -3
    }
  }, React.createElement(Paper, {
    className: "paper"
  }, React.createElement(Box, {
    sx: {
      boxSizing: "border-box",
      minWidth: "350px",
      // minHeight: "100px",
      maxHeight: "500px",
      padding: "10px"
    }
  }, React.createElement(Stack, {
    direction: "row",
    alignItems: "center",
    marginY: 1,
    pl: 3
  }, React.createElement(DatePickerValue, {
    value: (_dateRangeValue$less = dateRangeValue == null ? void 0 : dateRangeValue["less"]) != null ? _dateRangeValue$less : "",
    onChange: function onChange(val) {
      _onChange == null || _onChange({
        type: "less",
        less: val != null ? val : ""
      });
    },
    onClear: function onClear() {
      _onChange == null || _onChange({
        type: "less",
        less: ""
      });
    },
    placeholder: t("filter.beforeThanPlaceholder"),
    width: 160
  })))));
};
var FilterSelectDateItem = function FilterSelectDateItem(_ref10) {
  var field = _ref10.field,
    label = _ref10.label,
    onValueChange = _ref10.onValueChange,
    value = _ref10.value,
    onRemove = _ref10.onRemove,
    _ref10$disable = _ref10.disable,
    disable = _ref10$disable === void 0 ? false : _ref10$disable;
  var _useState7 = useState(false),
    open = _useState7[0],
    setOpen = _useState7[1];
  var domRef = useRef();
  var showItemLabel = useMemo(function () {
    var type = value == null ? void 0 : value["type"];
    if (type === "between") {
      var _dayjs, _dayjs2;
      var fromDate = value != null && value["fromDate"] ? (_dayjs = dayjs(value == null ? void 0 : value["fromDate"])) == null ? void 0 : _dayjs.format("DD/MM/YYYY") : "";
      var toDate = value != null && value["toDate"] ? (_dayjs2 = dayjs(value == null ? void 0 : value["toDate"])) == null ? void 0 : _dayjs2.format("DD/MM/YYYY") : "";
      if (!fromDate && !toDate) {
        return "";
      }
      return fromDate + " - " + toDate;
    }
    if (type === "less") {
      var _dayjs3;
      var lessDate = value != null && value["less"] ? (_dayjs3 = dayjs(value == null ? void 0 : value["less"])) == null ? void 0 : _dayjs3.format("DD/MM/YYYY") : "";
      return lessDate;
    }
    if (type === "more") {
      var _dayjs4;
      var moreDate = value != null && value["more"] ? (_dayjs4 = dayjs(value == null ? void 0 : value["more"])) == null ? void 0 : _dayjs4.format("DD/MM/YYYY") : "";
      return moreDate;
    }
    return "";
  }, [value]);
  return React.createElement(Box, {
    ref: domRef,
    className: Object.keys(value != null ? value : {}).length > 0 ? "selected-filter" : "",
    sx: {
      height: "30px",
      boxSizing: "border-box",
      padding: "2px 5px",
      borderRadius: "5px",
      border: "1px solid #bdbdbd",
      margin: "6px 20px 6px 0",
      backgroundColor: !!showItemLabel ? "#567cde" : "white",
      // minWidth: selected?.length === 0 ? "160px" : "200px",
      display: "inline-block",
      alignItems: "center",
      color: !!showItemLabel ? "white" : "black",
      opacity: disable ? 0.5 : 1,
      cursor: disable ? "not-allowed" : "initial"
    }
  }, React.createElement(Box, {
    sx: {
      width: "100%",
      height: "100%",
      display: "flex",
      alignItems: "center"
    }
  }, React.createElement(FilterSelectShowComp, {
    field: field,
    open: open,
    setOpen: setOpen,
    label: label != null ? label : "",
    showItemLabel: showItemLabel,
    selectedLen: 0,
    clearIcon: true,
    onClearClick: onRemove,
    disable: disable
  })), React.createElement(FilterSelectTimePopper, {
    field: field,
    open: open,
    setOpen: setOpen,
    anchorEl: domRef.current,
    onChange: function onChange(data) {
      onValueChange == null || onValueChange(data);
    },
    dateRangeValue: value
  }));
};

var dataType = {
  "select": "select",
  "multi-select": "select",
  "date": "date"
};
var useIdentifierList = function useIdentifierList(activeModule) {
  var getIdentifiersDefineOptions = getFetchOptionListFunc(process.env.REACT_APP_API_GETWAY + "/im/identifier/getIdentifiersByLinkedModuleName/" + (activeModule == null ? void 0 : activeModule.name));
  var _useQuery = useQuery(["fetchIdentifiersOptions", "product"], function () {
      return getIdentifiersDefineOptions();
    }, {
      retry: false,
      refetchOnWindowFocus: false,
      select: function select(response) {
        return response.data.data.map(function (item) {
          var _identifierVo$linkedM;
          var identifierVo = item.identifierVo || {};
          var linkedModulesFormat = (identifierVo == null || (_identifierVo$linkedM = identifierVo.linkedModules) == null ? void 0 : _identifierVo$linkedM.map(function (item) {
            var _ref;
            return _ref = {}, _ref[item.name] = {
              status: item.confirm,
              mappingModule: item.mappingModule,
              mappingSearch: item.mappingSearch
            }, _ref;
          })) || [];
          var linkedModulesFormatObj = Object.assign.apply(Object, [{}].concat(linkedModulesFormat));
          return {
            label: identifierVo.displayName,
            value: identifierVo.uiPattern === 'date' ? identifierVo.name : identifierVo.sourceName,
            // disabled: !item.status,
            data: {
              field: identifierVo.uiPattern === 'date' ? identifierVo.name : identifierVo.sourceName,
              label: identifierVo.displayName,
              totalLabel: "Total " + identifierVo.displayName,
              searchPlaceholder: "Search " + identifierVo.displayName,
              iconType: 2,
              fieldItemMode: "checkbox",
              //@ts-ignore
              itemType: dataType == null ? void 0 : dataType[identifierVo.uiPattern],
              asyncConfig: {
                labelPath: "name",
                valuePath: "id",
                url: "/im/identifier/filter",
                method: "POST",
                body: [{
                  fieldName: "identifier",
                  value: identifierVo.uiPattern === 'date' ? identifierVo.name : identifierVo.sourceName
                }, {
                  store: "formState",
                  fieldName: "filter",
                  valuePath: "filter"
                }],
                dependencies: ["filter"]
              },
              linkedModules: linkedModulesFormatObj,
              fieldId: identifierVo.id
            }
          };
        });
      }
    }),
    _useQuery$data = _useQuery.data,
    identifiersDefineOptions = _useQuery$data === void 0 ? [] : _useQuery$data,
    isFetching = _useQuery.isFetching;
  var prevIdentifiersDefineOptionsRef = useRef();
  var _useNonPersistentFilt = useNonPersistentFilterItemsStore(function (state) {
      return [state == null ? void 0 : state.updateIdentifiers];
    }),
    updateIdentifiers = _useNonPersistentFilt[0];
  var prevFilterItemsRef = useRef();
  // const [realFilterItems, updateRealFilterItems] = useFilterItemsStore((state) => [
  //   state?.realFilterItems,
  //   state?.updateRealFilterItems,
  // ]);
  useEffect(function () {
    //-----updateRealFilterItems
    if (isFetching || !identifiersDefineOptions) return;
    // const newFilterItems =
    //   realFilterItems.map((item) => {
    //     const newItem = identifiersDefineOptions.find(
    //       (identifier) => identifier.data?.field === item.data?.field
    //     );
    //     return {
    //       ...item,
    //       // disabled: newItem?.disabled,
    //       data: {
    //         ...item.data,
    //         linkedModules: newItem?.data?.linkedModules,
    //       },
    //     };
    //   }) || [];
    // if (!isEqual(newFilterItems, prevFilterItemsRef.current)) {
    //   updateRealFilterItems(newFilterItems);
    //   prevFilterItemsRef.current = newFilterItems;
    // }
    // -----updateIdentifiers
    if (!isEqual(identifiersDefineOptions, prevIdentifiersDefineOptionsRef.current)) {
      var data = identifiersDefineOptions;
      console.log('updateIdentifiers', data);
      updateIdentifiers == null || updateIdentifiers(data);
      prevIdentifiersDefineOptionsRef.current = data;
    }
  }, [identifiersDefineOptions, isFetching]);
  return {
    identifiersDefineOptions: identifiersDefineOptions,
    isFetching: isFetching
  };
};

var Filter = function Filter(props) {
  var activeModule = props.activeModule,
    _props$disableIdentif = props.disableIdentifierList,
    disableIdentifierList = _props$disableIdentif === void 0 ? [] : _props$disableIdentif,
    initFilterList = props.initFilterList,
    selectedIdentifiers = props.selectedIdentifiers;
  var wrapperDom = useRef();
  var _useTranslation = useTranslation();
  var initIdentifierList = initFilterList ? Object.keys(initFilterList) : [];
  var _useIdentifierList = useIdentifierList(activeModule),
    identifiersDefineOptions = _useIdentifierList.identifiersDefineOptions;
  var _useState = useState(false),
    haveDateTime = _useState[0],
    setHaveDateTime = _useState[1];
  var _useFilterItemsStore = useFilterItemsStore(function (state) {
      return [state.filterItems, state.updateFilterItems, state.fieldsState, state.updateFieldsState, state.removeSpareField];
    }),
    filterItems = _useFilterItemsStore[0],
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    updateFilterItems = _useFilterItemsStore[1],
    fieldsState = _useFilterItemsStore[2],
    updateFieldsState = _useFilterItemsStore[3],
    removeSpareField = _useFilterItemsStore[4];
  selectedIdentifiers(fieldsState);
  useEffect(function () {
    if (initIdentifierList && initIdentifierList.length > 0 && identifiersDefineOptions && identifiersDefineOptions.length > 0) {
      var list = identifiersDefineOptions.filter(function (item) {
        return initIdentifierList.includes(item.value);
      });
      //@ts-ignore
      updateFilterItems(list);
      updateFieldsState("All", handleInitFilterList(list));
    }
  }, [identifiersDefineOptions]);
  var handleInitFilterList = function handleInitFilterList(list) {
    var initFilterList2 = {};
    list.forEach(function (el) {
      if (el.data.itemType === "date") {
        initFilterList2[el.value] = {
          type: "less",
          less: Number(initFilterList[el.value][0])
        };
        setHaveDateTime(true);
      } else {
        initFilterList2[el.value] = initFilterList[el.value].map(function (value) {
          return {
            value: value
          };
        });
      }
    });
    return initFilterList2;
  };
  var getIsDisabled = function getIsDisabled(item) {
    var _item$data;
    return disableIdentifierList.includes(item.value) ? true : activeModule != null && activeModule.name ? !((_item$data = item.data) != null && (_item$data = _item$data.linkedModules) != null && (_item$data = _item$data[activeModule.name]) != null && _item$data.status) : false;
  };
  return React.createElement(Box, {
    sx: {
      width: "100%"
    }
  }, React.createElement(Stack, {
    direction: "row",
    className: "filters-row"
  }, React.createElement(Box, {
    className: "filterItemsWrapper",
    ref: wrapperDom
  }, React.createElement(Box
  // direction="row"
  , {
    // direction="row"
    whiteSpace: "nowrap",
    alignItems: "center",
    px: 1,
    display: "inline-block"
  }, filterItems == null ? void 0 : filterItems.map(function (el, index) {
    var _el$data, _el$data2, _el$data13;
    if (!(el != null && (_el$data = el.data) != null && _el$data.itemType) || (el == null || (_el$data2 = el.data) == null ? void 0 : _el$data2.itemType) === "select") {
      var _el$data3, _el$data4, _el$data5, _el$data6, _el$data7, _el$data8, _el$data9, _el$data10;
      return React.createElement(FilterSelectItem, {
        key: el == null || (_el$data3 = el.data) == null ? void 0 : _el$data3.field,
        field: el == null || (_el$data4 = el.data) == null ? void 0 : _el$data4.field,
        label: el == null || (_el$data5 = el.data) == null ? void 0 : _el$data5.label,
        totalLabel: el == null || (_el$data6 = el.data) == null ? void 0 : _el$data6.totalLabel,
        fieldItemMode: el == null || (_el$data7 = el.data) == null ? void 0 : _el$data7.fieldItemMode,
        searchPlaceholder: el == null || (_el$data8 = el.data) == null ? void 0 : _el$data8.searchPlaceholder,
        value: fieldsState == null ? void 0 : fieldsState[el == null || (_el$data9 = el.data) == null ? void 0 : _el$data9.field],
        asyncConfig: el == null || (_el$data10 = el.data) == null ? void 0 : _el$data10.asyncConfig,
        options: [],
        onValueChange: function onValueChange(data) {
          var _el$data11;
          updateFieldsState(el == null || (_el$data11 = el.data) == null ? void 0 : _el$data11.field, data);
        },
        onRemove: function onRemove() {
          var _el$data12;
          removeSpareField({
            removeFields: [el == null || (_el$data12 = el.data) == null ? void 0 : _el$data12.field]
          });
        },
        disable: getIsDisabled(el)
      });
    }
    if ((el == null || (_el$data13 = el.data) == null ? void 0 : _el$data13.itemType) === "date") {
      var _el$data14, _el$data15;
      return React.createElement(FilterSelectDateItem, {
        label: el == null ? void 0 : el.label,
        field: el == null || (_el$data14 = el.data) == null ? void 0 : _el$data14.field,
        value: fieldsState == null ? void 0 : fieldsState[el == null || (_el$data15 = el.data) == null ? void 0 : _el$data15.field],
        onValueChange: function onValueChange(data) {
          if (!haveDateTime) {
            var _el$data16;
            var timezoneOffsetInMinutes = new Date().getTimezoneOffset();
            var timezoneOffsetInMilliseconds = timezoneOffsetInMinutes * 60 * 1000;
            var utc = Number(data == null ? void 0 : data.less) - timezoneOffsetInMilliseconds;
            var newData = {
              type: "less",
              less: utc
            };
            updateFieldsState(el == null || (_el$data16 = el.data) == null ? void 0 : _el$data16.field, newData);
          } else {
            var _el$data17;
            updateFieldsState(el == null || (_el$data17 = el.data) == null ? void 0 : _el$data17.field, data);
          }
        },
        onRemove: function onRemove() {
          var _el$data18;
          removeSpareField({
            removeFields: [el == null || (_el$data18 = el.data) == null ? void 0 : _el$data18.field]
          });
        },
        disable: getIsDisabled(el)
      });
    }
    return React.createElement(React.Fragment, null);
  }), React.createElement(IdentifiersSelectItem, {
    field: "filterItems",
    value: filterItems,
    options: identifiersDefineOptions.map(function (el) {
      return {
        label: el.label,
        value: el.value,
        disabled: getIsDisabled(el),
        data: el.data
      };
    }),
    onValueChange: function onValueChange(data) {
      var _data$map;
      removeSpareField({
        keepFields: (_data$map = data == null ? void 0 : data.map(function (el) {
          var _el$data19;
          return el == null || (_el$data19 = el.data) == null ? void 0 : _el$data19.field;
        })) != null ? _data$map : [],
        newFilterItems: data
      });
    }
  })))));
};

var AddIdentifiersDialog = function AddIdentifiersDialog(props) {
  var _useTranslation = useTranslation(),
    t = _useTranslation.t;
  var openPopup = props.openPopup,
    handleClickCancel = props.handleClickCancel,
    handleClickSave = props.handleClickSave,
    initFilterList = props.initFilterList,
    activeModule = props.activeModule,
    _props$disableIdentif = props.disableIdentifierList,
    disableIdentifierList = _props$disableIdentif === void 0 ? [] : _props$disableIdentif;
  var _useState = useState("Yes"),
    value = _useState[0],
    setValue = _useState[1];
  var _useState2 = useState(""),
    selectedIdentifiers = _useState2[0],
    setSelectedIdentifiers = _useState2[1];
  var handleChange = function handleChange(event) {
    setValue(event.target.value);
  };
  var handleSave = function handleSave() {
    var parameters = {
      isAddFlag: value === "Yes",
      selectedIdentifiers: selectedIdentifiers
    };
    console.log('parameters is ', parameters);
    handleClickSave(parameters);
  };
  var getSelectedIdentifiers = function getSelectedIdentifiers(item) {
    setSelectedIdentifiers(item);
  };
  return React.createElement(Dialog, {
    open: openPopup,
    maxWidth: "md",
    fullWidth: true,
    className: "popup-dialog"
  }, React.createElement(DialogTitle, null, React.createElement("h5", null, t("rtq.identifiers.title"))), React.createElement(Box, {
    component: "form",
    sx: {
      display: "flex",
      flexDirection: "column"
    }
  }, React.createElement(DialogContent, {
    className: "form-group popup-content"
  }, React.createElement(Typography, {
    variant: "body2",
    gutterBottom: true
  }, "Please select action you would like to perform on selected components"), React.createElement(FormControl, null, React.createElement(RadioGroup$1, {
    "aria-labelledby": "identifier-radio-buttons-group-label",
    name: "identifier-radio-buttons-group",
    row: true,
    value: value,
    onChange: handleChange
  }, React.createElement(FormControlLabel$1, {
    value: "Yes",
    control: React.createElement(Radio$1, null),
    label: "Add Identifiers"
  }), React.createElement(FormControlLabel$1, {
    value: "No",
    control: React.createElement(Radio$1, null),
    label: "Remove Identifiers"
  }))), React.createElement(Typography, {
    variant: "body2",
    gutterBottom: true
  }, "Please select identifiers you would like to add / remove"), React.createElement(Filter, {
    activeModule: activeModule,
    initFilterList: initFilterList,
    disableIdentifierList: disableIdentifierList,
    selectedIdentifiers: getSelectedIdentifiers
  })), React.createElement(DialogActions, null, React.createElement(Button, {
    variant: "text",
    size: "small",
    onClick: function onClick() {
      handleClickCancel();
    }
  }, t("common.cancel")), React.createElement(Button, {
    variant: "contained",
    size: "small",
    onClick: function onClick() {
      handleSave();
    }
  }, t("common.save"), " "))));
};

var EditIdentifiersDialog = function EditIdentifiersDialog(props) {
  var _useTranslation = useTranslation(),
    t = _useTranslation.t;
  var openPopup = props.openPopup,
    handleClickCancel = props.handleClickCancel,
    handleClickSave = props.handleClickSave,
    initFilterList = props.initFilterList,
    activeModule = props.activeModule,
    _props$disableIdentif = props.disableIdentifierList,
    disableIdentifierList = _props$disableIdentif === void 0 ? [] : _props$disableIdentif;
  var _useState = useState(""),
    selectedIdentifiers = _useState[0],
    setSelectedIdentifiers = _useState[1];
  var handleSave = function handleSave() {
    var parameters = {
      selectedIdentifiers: selectedIdentifiers
    };
    handleClickSave(parameters);
  };
  var getSelectedIdentifiers = function getSelectedIdentifiers(item) {
    setSelectedIdentifiers(item);
  };
  return React.createElement(Dialog, {
    open: openPopup,
    maxWidth: "md",
    fullWidth: true,
    className: "popup-dialog"
  }, React.createElement(DialogTitle, null, React.createElement("h5", null, t("rtq.identifiers.title"))), React.createElement(Box, {
    component: "form",
    sx: {
      display: "flex",
      flexDirection: "column"
    }
  }, React.createElement(DialogContent, {
    className: "form-group popup-content"
  }, React.createElement(Filter, {
    activeModule: activeModule,
    initFilterList: initFilterList,
    selectedIdentifiers: getSelectedIdentifiers,
    disableIdentifierList: disableIdentifierList
  })), React.createElement(DialogActions, null, React.createElement(Button, {
    variant: "text",
    size: "small",
    onClick: function onClick() {
      handleClickCancel();
    }
  }, t("common.cancel")), React.createElement(Button, {
    variant: "contained",
    size: "small",
    onClick: function onClick() {
      handleSave();
    }
  }, t("common.save"), " "))));
};

export { AddIdentifiersDialog, DynamicFormCompBasicJsonSchema, EditIdentifiersDialog, Filter, FreyrLibraryProvider };
//# sourceMappingURL=freyr-react-common.esm.js.map
