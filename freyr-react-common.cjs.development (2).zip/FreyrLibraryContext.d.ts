import React, { ReactNode } from 'react';
interface FreyrLibraryContextType {
    language?: string;
    token?: string;
    tenant?: string;
    domain?: string;
    domainName?: string;
}
interface FreyrLibraryProviderProps {
    language?: string;
    token?: string;
    tenant?: string;
    domain?: string;
    domainName?: string;
    children: ReactNode;
}
export declare const FreyrLibraryProvider: React.FC<FreyrLibraryProviderProps>;
export declare const useFreyrLibraryContext: () => FreyrLibraryContextType;
export {};
