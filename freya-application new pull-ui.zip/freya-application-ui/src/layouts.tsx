import { Box, Stack, Grid, Button, IconButton } from "@mui/material";
import React, { Suspense, useState } from "react";
import { Outlet, useParams } from "react-router-dom";
import SideNavigation from "./Components/Applications/SideNavigation";
import styles from "./index.module.scss";
import MenuIcon from '../src/assets/menu-icon.svg'
import AuditIcon from "../src/assets/audit-icon.svg";
import { t } from "i18next";

interface ComponentsProps {}
const Layouts: React.FC<ComponentsProps> = (props) => {
  const [isExpand, setIsExpand] = useState(false);
  const [openDrawer, setOpenDrawer] = useState(false);

  return (
    <>
      <Button style={{ position: "absolute", right: "17px" }} onClick={() => { setIsExpand(!isExpand) }} className={isExpand ? 'menu-link expanded' : 'menu-link'}>   <img
        src={MenuIcon}
        alt=""
        style={{ width: "20px" }}
      /> <div style={{ marginLeft: '6px' }}>{t("Menu")}</div></Button>
    {/* <Box className={styles["styregistrations-layouts"]}> */}
    <Stack direction="row" spacing={2} className="application-layouts">
      {/* <Box className="menu-form"> */}
      <Box  className="menu-form">
          <Suspense >
            <Outlet />
          </Suspense>
      </Box>
      <div>     
      <IconButton style={{float:"right",marginRight:"86px", marginTop:"9px"}}
      className = "auditlog-icon-position"
                    title="Audit"
                    onClick={() => setOpenDrawer(true)}
                  >
                    <img
                      src={AuditIcon}
                      alt="Audit Icon"
                      style={{ width: "18px" }}
                    />
      </IconButton>
      </div>
      <Stack className="custom-collapse-menu" style={isExpand ? { display: 'none' } : {}}>
              <Grid className="sidenavigation-component"  >
        <SideNavigation
        openDrawer={openDrawer} // Pass openDrawer state to SideNavigation
        setOpenDrawer={setOpenDrawer} // Pass setter function to SideNavigation
        />
      </Grid>
      </Stack>
    </Stack>
    </>
  );
};

export default Layouts;
