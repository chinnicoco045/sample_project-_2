import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import './App.scss';
import App from './App';
import reportWebVitals from './reportWebVitals';
import './i18n';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import 'react-checkbox-tree/src/scss/react-checkbox-tree.scss';
import { FreyrLibraryProvider } from "@freyr/freyr-react-common";
import { accessToken } from './types';
import { SnackbarProvider } from 'notistack';


const queryClient = new QueryClient();
const root = ReactDOM.createRoot(
  document.getElementById('root') as HTMLElement
);
root.render(
<div className='customer-page'>

    <React.StrictMode>
    <FreyrLibraryProvider
            token={accessToken}
          >
  <React.Suspense fallback="loading....">
    <QueryClientProvider client={queryClient}>
   <SnackbarProvider
    maxSnack={1}
    anchorOrigin={{ vertical: "top", horizontal: "center" }}
  >
  <App />
  </SnackbarProvider>
  </QueryClientProvider>
 
  </React.Suspense>
  </FreyrLibraryProvider>
  
    
  </React.StrictMode>
  </div>

);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
