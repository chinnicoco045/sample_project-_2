import axios from 'axios';
import Cookies from 'js-cookie';
import { useConfigStore } from '../Audit/config';


// export const GET_API="https://api.preprod.freyafusion.com/";
export const GET_API=process.env.REACT_APP_API_GETWAY+`/`;



console.log("DEVSECOPS APPIIIII",GET_API);


export const basicUrl = process.env.REACT_APP_APPLICATION_API_GATEWAY;
//  export const basicUrl="http://localhost:8104";
console.log("basic url",basicUrl);
const service = axios.create({
  baseURL: basicUrl,
});


const language = useConfigStore.getState()?.language;
export const languageformat = language === "en" ? "" : language;

service.interceptors.request.use(
  (config) => {
    const token = Cookies.get('ACCESS_TOKEN') || '';
    const language = useConfigStore.getState()?.language;
    const languageformat = language === "en" ? "" : language;
    if (token) {
      config.headers["Content-Type"] = config.responseType === "arraybuffer" && JSON.stringify(config.data) === "{}"
        ? "application/octet-stream;charset=utf-8"
        : "application/json;charset=utf-8";
      config.headers["Authorization"] = `Bearer ${token}`;
      config.headers["Accept-Language"] = languageformat || "";
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);


service.interceptors.response.use(
  (response) => {
    
    return response;
  },
  (error) => {
    if (error.response && error.response.status === 401) {
     console.log("call the refresh token api here");
    }
    return Promise.reject(error);
  }
);

export default service;