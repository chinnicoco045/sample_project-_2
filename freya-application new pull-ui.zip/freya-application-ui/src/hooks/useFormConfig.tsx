import { useQuery } from "@tanstack/react-query";
import { useEffect } from "react";


import { PrettifiedTFormInput } from "../apis/api";
import axios from "axios";
import { accessToken } from "../types";
import { apiGetFormBusinessRule, apiGetFormSetting, customFetchApi } from "../apis/apiFunctions";
import { GET_API } from "../Services/apiheader";

export const useFormSetting = (
  params: {
    module: string;
    formName: string;
    businessRule?: Record<string, unknown>;
  },
  enabled: boolean
) => {
  const queryFunc = useQuery(
    ["fetchFormSetting", params],
    () => {
      return apiGetFormSetting({ ...params });
    },
    {
      retry: false,
      enabled,
      refetchOnWindowFocus: false,
      select: (response) => {
        if (!response) {
          return null;
        }
        return {
          ...response,
          data: {
            id: Number(response?.data?.id),
            tenantId: Number(response?.data?.tenantId),
            settingsJson: JSON.parse(
              response?.data?.settingsJson as unknown as string
            ) as PrettifiedTFormInput[],
          },
        };
      },
    }
  );

  useEffect(() => {
    return () => {
      queryFunc?.remove();
    };
  }, []);

  return queryFunc;
};

export const useFormBusinessRule = (
  params: {
    module: string;
    formName: string;
  },
  enabled: boolean
) => {
  const queryFunc = useQuery(
    ["fetchFormBusinessRule", params],
    () => {
      return apiGetFormBusinessRule({ ...params });
    },
    {
      retry: false,
      enabled,
      refetchOnWindowFocus: false,
      select: (response) => {
        if (!response) {
          return null;
        }
        return {
          ...response,
          data: JSON.parse(response.data) as PrettifiedTFormInput[],
        };
      },
    }
  );

  useEffect(() => {
    return () => {
      queryFunc?.remove();
    };
  }, []);

  return queryFunc;
};



export const useFormData = (url: string, enabled: boolean) => {
  const queryFunc = useQuery(
    ["fetchFormData", url],
    () => {
      return customFetchApi(
        `${GET_API.replace(/\/$/, '')}${url}`,
        "get"
      )();
    },
    {
      retry: false,
      enabled,
      refetchOnWindowFocus: false,
      select: (response) => {
        const resData = response?.data;
        if (!resData) {
          return null;
        }
        return {
          ...resData,
          data: {
            ...resData.data,
            dynamicFieldJson: JSON.parse(resData.data.dynamicFieldJson),
          },
        };
      },
    }
  );

  useEffect(() => {
    return () => {
      queryFunc?.remove();
    };
  }, []);

  return queryFunc;
};

export const useGridData = (url: string, enabled: boolean) => {
  const queryFunc = useQuery(
    ["fetchGridData", url],
    () => {
      return customFetchApi(
        `${process.env.REACT_APP_API_GETWAY}${url}`,
        "get"
      )();
    },
    {
      retry: false,
      enabled,
      refetchOnWindowFocus: false,
      select: (response) => {
        return response?.data || [];
      },
    }
  );

  useEffect(() => {
    return () => {
      queryFunc?.remove();
    };
  }, []);

  return queryFunc;
};



  