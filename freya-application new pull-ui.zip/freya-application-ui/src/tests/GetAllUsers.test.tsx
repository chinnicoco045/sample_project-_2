import { render, waitFor } from '@testing-library/react';
import GetAllUsers from '../../src/Components/Applications/GetAllUsers';
import { RowContext } from '../../src/App';
import service from '../../src/Services/apiheader';

jest.mock('../../src/Services/apiheader', () => ({
  get: jest.fn(),
}));

// Mock the context
const mockSetRows = jest.fn();
const mockSetDisabledRows = jest.fn();
const mockSetAllRows = jest.fn();
const mockSetIsDisabled = jest.fn();
const mockSetIsEdited = jest.fn();
const mockSetIsAdded = jest.fn();
const mockSetError = jest.fn(); 


const rowContextValue = {
    rows: [], 
    setRows: mockSetRows,
    disabledRows: [], 
    setDisabledRows: mockSetDisabledRows,
    allRows: [], 
    setAllRows: mockSetAllRows,
    isEdited: false, 
    setIsEdited: mockSetIsEdited,
    isDisabled: false, 
    setIsDisabled: mockSetIsDisabled,
    isAddPrivileged: false, 
    setIsAddPrivileged: jest.fn(), 
    showDisabled: true, 
    setShowDisabled: jest.fn(), 
    isAdded: false, 
    setIsAdded: mockSetIsAdded,
    selectedRow: undefined, 
    setSelectedRow: jest.fn(), 
    checked: {}, 
    setChecked: jest.fn(), 
    applicationIdentifier: { label: '', value: '' }, 
    setApplicationIdentifier: jest.fn(), 
    error: false, 
    setError: mockSetError, 
    regionOptions: [], 
    setRegionOptions: jest.fn(), 
    countryOptions: [], 
    setCountryOptions: jest.fn(), 
    selectedCountry: [], 
    setSelectedCountry: jest.fn(), 
    inactiveRows:[],
    setinactiveRows:jest.fn(),
    activeRows:[],
    setactiveRows:jest.fn(),
    isActiveEnabled:false,
    setisActiveEnabled:jest.fn(),
    isInactiveEnabled:false,
    setisInactiveEnabled:jest.fn(),
    isEditPrivilege:true,
    setIsEditPrivilege:jest.fn(),
    paginationobject: { page: 0, pageSize: 10 },
    setPaginationobject:jest.fn(),
    paginationTotalRecord:0,
    setPaginationTotalRecord:jest.fn(),
    gridstatus:{active:true,inactive:false,disable:false},
    setGridStatus:jest.fn()
  };

// Mock data for the service calls
const mockData = {
  "data": {
      "data": {
          "content": [
              {
                  "id": 304,
                  "tenantId": null,
                  "domain_id": null,
                  "createdBy": null,
                  "modifiedBy": null,
                  "createdDate": null,
                  "modifiedDate": null,
                  "deleted": null,
                  "identifier": "10000132_Nepal_m5qr8tc7",
                  "groupid": 147,
                  "applicationdata": "{\"region\":\"CountryGroup_CGCD0002\",\"status\":\"Inactive\",\"country\":\"Country_COCO0154\",\"waveInfo\":[],\"productId\":\"10000132\",\"disabledMS\":[],\"formatType\":\"eCTD\",\"regionName\":\"Asia\",\"eIdentifier\":\"\",\"inactiveFlg\":true,\"productName\":\"Metformin Hydrochloride 1000 mg Tablet\",\"productType\":\"Pharmaceuticals\",\"sectionTree\":{\"Protocols\":{\"Protocols\":[\"1875126362646069250\",\"1874087051536449537\"],\"1800458054353461249\":[\"1800458054353461249\"]}},\"countryNames\":\"Nepal\",\"memberStates\":\"\",\"producerType\":\"Jordan Procedure\",\"productPhase\":\"Investigational\",\"applicationId\":\"\",\"msCountryCode\":\"\",\"eSubIdentifier\":\"\",\"productPhaseId\":\"PDPS00002\",\"registrationId\":\"\",\"applicationName\":\"uyutyu\",\"applicationType\":\"Active Substance Master File\",\"procedureNumber\":\"\",\"productCategory\":\"Simple\",\"applicationNumber\":\"\",\"countryIdentifier\":\"\",\"dossierIdentifier\":\"\",\"procedureTypeCode\":\"PCT00014\",\"reasonForInactive\":\"Commercial reasons\",\"eCTDReceptionNumber\":\"\"}",
                  "markfor_delete": 0,
                  "created_by": "vijaykumar.ls@freyrsolutions.com",
                  "created_date": "2025-01-10T18:20:03.531469",
                  "updated_by": "vijaykumar.ls@freyrsolutions.com",
                  "updated_date": "2025-01-13T15:51:15.628524"
              },
              {
                  "id": 256,
                  "tenantId": null,
                  "domain_id": null,
                  "createdBy": null,
                  "modifiedBy": null,
                  "createdDate": null,
                  "modifiedDate": null,
                  "deleted": null,
                  "identifier": "10000094_East Timor_m5m7uo9i",
                  "groupid": 143,
                  "applicationdata": "{\"region\":\"CountryGroup_CGCD0002\",\"status\":\"Inactive\",\"country\":\"Country_COCO0257\",\"waveInfo\":[],\"productId\":\"10000094\",\"disabledMS\":[],\"formatType\":\"eCTD\",\"regionName\":\"Asia\",\"eIdentifier\":\"\",\"inactiveFlg\":true,\"productName\":\"Penciclovir Cream; 1%\",\"productType\":\"Pharmaceuticals\",\"sectionTree\":{\"Protocols\":{\"Protocols\":[\"1874775575155785730\",\"1874085484506726401\"],\"1800458054353461249\":[\"1800458054353461249\"]}},\"countryNames\":\"East Timor\",\"memberStates\":\"\",\"producerType\":\"Jordan Procedure\",\"productPhase\":\"Investigational\",\"applicationId\":\"\",\"msCountryCode\":\"\",\"eSubIdentifier\":\"\",\"productPhaseId\":\"PDPS00002\",\"registrationId\":\"\",\"applicationName\":\"\",\"applicationType\":\"Active Substance Master File\",\"procedureNumber\":\"\",\"productCategory\":\"Simple\",\"applicationNumber\":\"fsdf\",\"countryIdentifier\":\"\",\"dossierIdentifier\":\"\",\"procedureTypeCode\":\"PCT00014\",\"reasonForInactive\":\"Commercial reasons\",\"eCTDReceptionNumber\":\"\"}",
                  "markfor_delete": 0,
                  "created_by": "vijaykumar.ls@freyrsolutions.com",
                  "created_date": "2025-01-07T14:06:06.144224",
                  "updated_by": "vijaykumar.ls@freyrsolutions.com",
                  "updated_date": "2025-01-13T15:12:39.758475"
              },
              {
                  "id": 306,
                  "tenantId": null,
                  "domain_id": null,
                  "createdBy": null,
                  "modifiedBy": null,
                  "createdDate": null,
                  "modifiedDate": null,
                  "deleted": null,
                  "identifier": "10000132_Oman_m5qr8tc7",
                  "groupid": 147,
                  "applicationdata": "{\"region\":\"CountryGroup_CGCD0002\",\"status\":\"Active\",\"country\":\"Country_COCO0165\",\"waveInfo\":[],\"productId\":\"10000132\",\"disabledMS\":[],\"formatType\":\"eCTD\",\"regionName\":\"Asia\",\"eIdentifier\":\"\",\"productName\":\"Metformin Hydrochloride 1000 mg Tablet\",\"productType\":\"Pharmaceuticals\",\"sectionTree\":{\"Protocols\":{\"Protocols\":[\"1875126362646069250\",\"1874087051536449537\"],\"1800458054353461249\":[\"1800458054353461249\"]}},\"countryNames\":\"Oman\",\"memberStates\":\"\",\"producerType\":\"Jordan Procedure\",\"productPhase\":\"Investigational\",\"applicationId\":\"\",\"msCountryCode\":\"\",\"eSubIdentifier\":\"\",\"productPhaseId\":\"PDPS00002\",\"registrationId\":\"\",\"applicationName\":\"uyutyu\",\"applicationType\":\"Active Substance Master File\",\"procedureNumber\":\"\",\"productCategory\":\"Simple\",\"applicationNumber\":\"\",\"countryIdentifier\":\"\",\"dossierIdentifier\":\"\",\"procedureTypeCode\":\"PCT00014\",\"eCTDReceptionNumber\":\"\"}",
                  "markfor_delete": 0,
                  "created_by": "vijaykumar.ls@freyrsolutions.com",
                  "created_date": "2025-01-10T18:20:03.533615",
                  "updated_by": null,
                  "updated_date": null
              },
              {
                  "id": 305,
                  "tenantId": null,
                  "domain_id": null,
                  "createdBy": null,
                  "modifiedBy": null,
                  "createdDate": null,
                  "modifiedDate": null,
                  "deleted": null,
                  "identifier": "10000132_North Korea_m5qr8tc7",
                  "groupid": 147,
                  "applicationdata": "{\"region\":\"CountryGroup_CGCD0002\",\"status\":\"Active\",\"country\":\"Country_COCO0117\",\"waveInfo\":[],\"productId\":\"10000132\",\"disabledMS\":[],\"formatType\":\"eCTD\",\"regionName\":\"Asia\",\"eIdentifier\":\"\",\"productName\":\"Metformin Hydrochloride 1000 mg Tablet\",\"productType\":\"Pharmaceuticals\",\"sectionTree\":{\"Protocols\":{\"Protocols\":[\"1875126362646069250\",\"1874087051536449537\"],\"1800458054353461249\":[\"1800458054353461249\"]}},\"countryNames\":\"North Korea\",\"memberStates\":\"\",\"producerType\":\"Jordan Procedure\",\"productPhase\":\"Investigational\",\"applicationId\":\"\",\"msCountryCode\":\"\",\"eSubIdentifier\":\"\",\"productPhaseId\":\"PDPS00002\",\"registrationId\":\"\",\"applicationName\":\"uyutyu\",\"applicationType\":\"Active Substance Master File\",\"procedureNumber\":\"\",\"productCategory\":\"Simple\",\"applicationNumber\":\"\",\"countryIdentifier\":\"\",\"dossierIdentifier\":\"\",\"procedureTypeCode\":\"PCT00014\",\"eCTDReceptionNumber\":\"\"}",
                  "markfor_delete": 0,
                  "created_by": "vijaykumar.ls@freyrsolutions.com",
                  "created_date": "2025-01-10T18:20:03.532613",
                  "updated_by": null,
                  "updated_date": null
              },
              {
                  "id": 302,
                  "tenantId": null,
                  "domain_id": null,
                  "createdBy": null,
                  "modifiedBy": null,
                  "createdDate": null,
                  "modifiedDate": null,
                  "deleted": null,
                  "identifier": "10000132_Japan_m5qr8tc7",
                  "groupid": 147,
                  "applicationdata": "{\"region\":\"CountryGroup_CGCD0002\",\"status\":\"Active\",\"country\":\"Country_COCO0111\",\"waveInfo\":[],\"productId\":\"10000132\",\"disabledMS\":[],\"formatType\":\"eCTD\",\"regionName\":\"Asia\",\"eIdentifier\":\"\",\"productName\":\"Metformin Hydrochloride 1000 mg Tablet\",\"productType\":\"Pharmaceuticals\",\"sectionTree\":{\"Protocols\":{\"Protocols\":[\"1875126362646069250\",\"1874087051536449537\"],\"1800458054353461249\":[\"1800458054353461249\"]}},\"countryNames\":\"Japan\",\"memberStates\":\"\",\"producerType\":\"Jordan Procedure\",\"productPhase\":\"Investigational\",\"applicationId\":\"\",\"msCountryCode\":\"\",\"eSubIdentifier\":\"\",\"productPhaseId\":\"PDPS00002\",\"registrationId\":\"\",\"applicationName\":\"uyutyu\",\"applicationType\":\"Active Substance Master File\",\"procedureNumber\":\"\",\"productCategory\":\"Simple\",\"applicationNumber\":\"\",\"countryIdentifier\":\"\",\"dossierIdentifier\":\"\",\"procedureTypeCode\":\"PCT00014\",\"eCTDReceptionNumber\":\"\"}",
                  "markfor_delete": 0,
                  "created_by": "vijaykumar.ls@freyrsolutions.com",
                  "created_date": "2025-01-10T18:20:03.531469",
                  "updated_by": null,
                  "updated_date": null
              },
              {
                  "id": 303,
                  "tenantId": null,
                  "domain_id": null,
                  "createdBy": null,
                  "modifiedBy": null,
                  "createdDate": null,
                  "modifiedDate": null,
                  "deleted": null,
                  "identifier": "10000132_Jordan_m5qr8tc7",
                  "groupid": 147,
                  "applicationdata": "{\"region\":\"CountryGroup_CGCD0002\",\"status\":\"Active\",\"country\":\"Country_COCO0113\",\"waveInfo\":[],\"productId\":\"10000132\",\"disabledMS\":[],\"formatType\":\"eCTD\",\"regionName\":\"Asia\",\"eIdentifier\":\"\",\"productName\":\"Metformin Hydrochloride 1000 mg Tablet\",\"productType\":\"Pharmaceuticals\",\"sectionTree\":{\"Protocols\":{\"Protocols\":[\"1875126362646069250\",\"1874087051536449537\"],\"1800458054353461249\":[\"1800458054353461249\"]}},\"countryNames\":\"Jordan\",\"memberStates\":\"\",\"producerType\":\"Jordan Procedure\",\"productPhase\":\"Investigational\",\"applicationId\":\"\",\"msCountryCode\":\"\",\"eSubIdentifier\":\"\",\"productPhaseId\":\"PDPS00002\",\"registrationId\":\"\",\"applicationName\":\"uyutyu\",\"applicationType\":\"Active Substance Master File\",\"procedureNumber\":\"\",\"productCategory\":\"Simple\",\"applicationNumber\":\"\",\"countryIdentifier\":\"\",\"dossierIdentifier\":\"\",\"procedureTypeCode\":\"PCT00014\",\"eCTDReceptionNumber\":\"\"}",
                  "markfor_delete": 0,
                  "created_by": "vijaykumar.ls@freyrsolutions.com",
                  "created_date": "2025-01-10T18:20:03.531469",
                  "updated_by": null,
                  "updated_date": null
              },
              {
                  "id": 301,
                  "tenantId": null,
                  "domain_id": null,
                  "createdBy": null,
                  "modifiedBy": null,
                  "createdDate": null,
                  "modifiedDate": null,
                  "deleted": null,
                  "identifier": "10000132_Israel_m5qr8tc7",
                  "groupid": 147,
                  "applicationdata": "{\"region\":\"CountryGroup_CGCD0002\",\"status\":\"Active\",\"country\":\"Country_COCO0108\",\"waveInfo\":[],\"productId\":\"10000132\",\"disabledMS\":[],\"formatType\":\"eCTD\",\"regionName\":\"Asia\",\"eIdentifier\":\"\",\"productName\":\"Metformin Hydrochloride 1000 mg Tablet\",\"productType\":\"Pharmaceuticals\",\"sectionTree\":{\"Protocols\":{\"Protocols\":[\"1875126362646069250\",\"1874087051536449537\"],\"1800458054353461249\":[\"1800458054353461249\"]}},\"countryNames\":\"Israel\",\"memberStates\":\"\",\"producerType\":\"Jordan Procedure\",\"productPhase\":\"Investigational\",\"applicationId\":\"\",\"msCountryCode\":\"\",\"eSubIdentifier\":\"\",\"productPhaseId\":\"PDPS00002\",\"registrationId\":\"\",\"applicationName\":\"uyutyu\",\"applicationType\":\"Active Substance Master File\",\"procedureNumber\":\"\",\"productCategory\":\"Simple\",\"applicationNumber\":\"\",\"countryIdentifier\":\"\",\"dossierIdentifier\":\"\",\"procedureTypeCode\":\"PCT00014\",\"eCTDReceptionNumber\":\"\"}",
                  "markfor_delete": 0,
                  "created_by": "vijaykumar.ls@freyrsolutions.com",
                  "created_date": "2025-01-10T18:20:03.531136",
                  "updated_by": null,
                  "updated_date": null
              },
              {
                  "id": 298,
                  "tenantId": null,
                  "domain_id": null,
                  "createdBy": null,
                  "modifiedBy": null,
                  "createdDate": null,
                  "modifiedDate": null,
                  "deleted": null,
                  "identifier": "10000132_Bhutan_m5qr8tc7",
                  "groupid": 147,
                  "applicationdata": "{\"region\":\"CountryGroup_CGCD0002\",\"status\":\"Active\",\"country\":\"Country_COCO0026\",\"waveInfo\":[],\"productId\":\"10000132\",\"disabledMS\":[],\"formatType\":\"eCTD\",\"regionName\":\"Asia\",\"eIdentifier\":\"\",\"productName\":\"Metformin Hydrochloride 1000 mg Tablet\",\"productType\":\"Pharmaceuticals\",\"sectionTree\":{\"Protocols\":{\"Protocols\":[\"1875126362646069250\",\"1874087051536449537\"],\"1800458054353461249\":[\"1800458054353461249\"]}},\"countryNames\":\"Bhutan\",\"memberStates\":\"\",\"producerType\":\"Jordan Procedure\",\"productPhase\":\"Investigational\",\"applicationId\":\"\",\"msCountryCode\":\"\",\"eSubIdentifier\":\"\",\"productPhaseId\":\"PDPS00002\",\"registrationId\":\"\",\"applicationName\":\"uyutyu\",\"applicationType\":\"Active Substance Master File\",\"procedureNumber\":\"\",\"productCategory\":\"Simple\",\"applicationNumber\":\"\",\"countryIdentifier\":\"\",\"dossierIdentifier\":\"\",\"procedureTypeCode\":\"PCT00014\",\"eCTDReceptionNumber\":\"\"}",
                  "markfor_delete": 0,
                  "created_by": "vijaykumar.ls@freyrsolutions.com",
                  "created_date": "2025-01-10T18:20:03.530014",
                  "updated_by": null,
                  "updated_date": null
              },
              {
                  "id": 299,
                  "tenantId": null,
                  "domain_id": null,
                  "createdBy": null,
                  "modifiedBy": null,
                  "createdDate": null,
                  "modifiedDate": null,
                  "deleted": null,
                  "identifier": "10000132_Bangladesh_m5qr8tc7",
                  "groupid": 147,
                  "applicationdata": "{\"region\":\"CountryGroup_CGCD0002\",\"status\":\"Active\",\"country\":\"Country_COCO0019\",\"waveInfo\":[],\"productId\":\"10000132\",\"disabledMS\":[],\"formatType\":\"eCTD\",\"regionName\":\"Asia\",\"eIdentifier\":\"\",\"productName\":\"Metformin Hydrochloride 1000 mg Tablet\",\"productType\":\"Pharmaceuticals\",\"sectionTree\":{\"Protocols\":{\"Protocols\":[\"1875126362646069250\",\"1874087051536449537\"],\"1800458054353461249\":[\"1800458054353461249\"]}},\"countryNames\":\"Bangladesh\",\"memberStates\":\"\",\"producerType\":\"Jordan Procedure\",\"productPhase\":\"Investigational\",\"applicationId\":\"\",\"msCountryCode\":\"\",\"eSubIdentifier\":\"\",\"productPhaseId\":\"PDPS00002\",\"registrationId\":\"\",\"applicationName\":\"uyutyu\",\"applicationType\":\"Active Substance Master File\",\"procedureNumber\":\"\",\"productCategory\":\"Simple\",\"applicationNumber\":\"\",\"countryIdentifier\":\"\",\"dossierIdentifier\":\"\",\"procedureTypeCode\":\"PCT00014\",\"eCTDReceptionNumber\":\"\"}",
                  "markfor_delete": 0,
                  "created_by": "vijaykumar.ls@freyrsolutions.com",
                  "created_date": "2025-01-10T18:20:03.530014",
                  "updated_by": null,
                  "updated_date": null
              },
              {
                  "id": 300,
                  "tenantId": null,
                  "domain_id": null,
                  "createdBy": null,
                  "modifiedBy": null,
                  "createdDate": null,
                  "modifiedDate": null,
                  "deleted": null,
                  "identifier": "10000132_Bahrain_m5qr8tc7",
                  "groupid": 147,
                  "applicationdata": "{\"region\":\"CountryGroup_CGCD0002\",\"status\":\"Active\",\"country\":\"Country_COCO0018\",\"waveInfo\":[],\"productId\":\"10000132\",\"disabledMS\":[],\"formatType\":\"eCTD\",\"regionName\":\"Asia\",\"eIdentifier\":\"\",\"productName\":\"Metformin Hydrochloride 1000 mg Tablet\",\"productType\":\"Pharmaceuticals\",\"sectionTree\":{\"Protocols\":{\"Protocols\":[\"1875126362646069250\",\"1874087051536449537\"],\"1800458054353461249\":[\"1800458054353461249\"]}},\"countryNames\":\"Bahrain\",\"memberStates\":\"\",\"producerType\":\"Jordan Procedure\",\"productPhase\":\"Investigational\",\"applicationId\":\"\",\"msCountryCode\":\"\",\"eSubIdentifier\":\"\",\"productPhaseId\":\"PDPS00002\",\"registrationId\":\"\",\"applicationName\":\"uyutyu\",\"applicationType\":\"Active Substance Master File\",\"procedureNumber\":\"\",\"productCategory\":\"Simple\",\"applicationNumber\":\"\",\"countryIdentifier\":\"\",\"dossierIdentifier\":\"\",\"procedureTypeCode\":\"PCT00014\",\"eCTDReceptionNumber\":\"\"}",
                  "markfor_delete": 0,
                  "created_by": "vijaykumar.ls@freyrsolutions.com",
                  "created_date": "2025-01-10T18:20:03.530014",
                  "updated_by": null,
                  "updated_date": null
              }
          ],
          "pageable": {
              "pageNumber": 0,
              "pageSize": 10,
              "sort": [],
              "offset": 0,
              "paged": true,
              "unpaged": false
          },
          "totalPages": 8,
          "totalElements": 73,
          "last": false,
          "size": 10,
          "number": 0,
          "sort": [],
          "numberOfElements": 10,
          "first": true,
          "empty": false
      },
      "message": "All applications retrieved successfully",
      "status": 200
  },
  "status": 200,
  "statusText": "",
  "headers": {
      "cache-control": "no-cache, no-store, max-age=0, must-revalidate",
      "content-type": "application/json",
      "expires": "0",
      "pragma": "no-cache"
  },
  "config": {
      "transitional": {
          "silentJSONParsing": true,
          "forcedJSONParsing": true,
          "clarifyTimeoutError": false
      },
      "adapter": [
          "xhr",
          "http"
      ],
      "transformRequest": [
          null
      ],
      "transformResponse": [
          null
      ],
      "timeout": 0,
      "xsrfCookieName": "XSRF-TOKEN",
      "xsrfHeaderName": "X-XSRF-TOKEN",
      "maxContentLength": -1,
      "maxBodyLength": -1,
      "env": {},
      "headers": {
          "Accept": "application/json, text/plain, */*",
          "X-TenantID": "0",
          "Authorization": "Bearer eyJraWQiOiJBT2YrTjNkWjNXdmxYN2VMeEtQN1c5ZVkwNkFcLzBIZ2VnalpsdXozNDRpcz0iLCJhbGciOiJSUzI1NiJ9.eyJzdWIiOiI4YmY5Y2EwYi0yYTFlLTQ0YWQtYjRiOS03NDc1NTZkYjg5ZmYiLCJjb2duaXRvOmdyb3VwcyI6WyJ1cy1lYXN0LTFfN2NOYjQwbVR1X0ZyZXlyQXp1cmVBRCJdLCJpc3MiOiJodHRwczpcL1wvY29nbml0by1pZHAudXMtZWFzdC0xLmFtYXpvbmF3cy5jb21cL3VzLWVhc3QtMV83Y05iNDBtVHUiLCJ2ZXJzaW9uIjoyLCJjbGllbnRfaWQiOiIxOWduNXRiMzE3OTlscGlmMmxiZDFkOHVjNiIsIm9yaWdpbl9qdGkiOiJmZTFkZTlmYS0zZTVmLTRmZjctODcyYS01ZDRhOTZjNDlkZDEiLCJ0b2tlbl91c2UiOiJhY2Nlc3MiLCJzY29wZSI6Im9wZW5pZCBlbWFpbCIsImF1dGhfdGltZSI6MTczNjc0MjM5MSwiZXhwIjoxNzM2Nzc4MzkxLCJpYXQiOjE3MzY3NDIzOTEsImp0aSI6IjYwMzk3OWEwLTEzYzEtNGUxMi05ZTFjLWM5ZjhmMzM2MmVkMyIsInVzZXJuYW1lIjoiZnJleXJhenVyZWFkX3ZpamF5a3VtYXIubHNAZnJleXJzb2x1dGlvbnMuY29tIn0.TVtRb5QUBcjmi-IsAHcubwZQeD-A7Q00MGaJdmZhLmKWZxtKnylRUyk5HhHhyECKoDOk2npmakeOid-yFA1xTPl11PH0qLGkkW5ns484ZdC7UQ7hXAGzgZqAkJ7ZXDAblFaTFg0GTePrjgL90_XdE5qFC7wtgVjwv7kAgCyj9eeDKtJFFXyuqTXMmlRV_WEwBfdILuYYHQ_M2bwwybgLbb2b8dxFmSGSb8COfMRGbju4QNX_X18_sQFeLOVmmK5tyYtVTndMlUsMIIFsEpT2D6mitybK3lDln4Fmr-w98M7olrIrLBSOjWRLdJ25JhSEApuqEWcbdIzU3WSZD6u5-w",
          "globalFilters": "[]",
          "Accept-Language": ""
      },
      "baseURL": "http://localhost:8104",
      "params": {
          "page": 0,
          "size": 10,
          "active": true,
          "inactive": true,
          "disable": false
      },
      "method": "get",
      "url": "application/v1/display-all/refresh-products"
  },
  "request": {}
}

describe('GetAllUsers', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('fetches users and sets them on mount', async () => {
(service.get as jest.Mock).mockResolvedValue(mockData);

    // Render the component with the mocked context
    render(
      <RowContext.Provider value={rowContextValue}>
        <GetAllUsers />
      </RowContext.Provider>
    );

    // Wait for the useEffect to run and the service call to resolve
    await waitFor(() => {
      expect(service.get).toHaveBeenCalledTimes(1); // Called for both getUsers and getDisabledRows
      expect(mockSetRows).toHaveBeenCalledWith(
        expect.arrayContaining([expect.any(Object)])
      );
      // expect(mockSetDisabledRows).toHaveBeenCalledWith(
      //   expect.arrayContaining([expect.any(Object)])
      // );
    });
  });

  it('handles the state when no users are returned', async () => {
    (service.get as jest.Mock).mockResolvedValue({ data: { data: [] } });

    render(
      <RowContext.Provider value={rowContextValue}>
        <GetAllUsers />
      </RowContext.Provider>
    );

    await waitFor(() => {
      expect(service.get).toHaveBeenCalled();
      //expect(mockSetRows).toHaveBeenCalledWith([]);
    });
  });

it('fetches disabled users and sets them correctly', async () => {
    (service.get as jest.Mock).mockResolvedValue(mockData); 
  
    render(
      <RowContext.Provider value={rowContextValue}>
        <GetAllUsers />
      </RowContext.Provider>
    );
  
    await waitFor(() => {
      expect(service.get).toHaveBeenCalledTimes(1); 
      // expect(mockSetDisabledRows).toHaveBeenCalledWith(
      //   expect.arrayContaining([expect.any(Object)])
      // );
    });
  });


});