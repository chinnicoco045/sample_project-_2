import React from 'react';
import { render, screen, waitFor, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom';
import axios from 'axios';
import MockAdapter from 'axios-mock-adapter';
import { RowContext } from '../App';
import LinkProducts from '../Components/Applications/wizard/LinkedProducts';
import service, { GET_API } from '../../src/Services/apiheader';
import { BrowserRouter } from 'react-router-dom';
import { mockRowContextValues } from './common.test';
import { getProductPhaseId } from '../apis/apiFunctions';
import { act } from 'react-dom/test-utils';
import { getGridFields } from '../DynamicGrid/headerConfig';
import userEvent from '@testing-library/user-event';

// Mocking axios
const mockAxios = new MockAdapter(axios);
const mockProductData = [
  {
    id: 1,
    productPhase: 'Phase 1',
    productCategory: 'Category A',
    productFamily: 'Family X',
    pharmaceuticalDoseForm: 'Form 1',
  },
  {
    id: 2,
    productPhase: 'Phase 1',
    productCategory: 'Category A',
    productFamily: 'Family X',
    pharmaceuticalDoseForm: 'Form 1',
  },
  {
    id: 3,
    productPhase: 'Phase 2', // Different phase
    productCategory: 'Category B', // Different category
    productFamily: 'Family Y', // Different family
    pharmaceuticalDoseForm: 'Form 2', // Different form
  },
];
const mockProducts = { 
  
  data: {
    data: mockProductData, // mockProductData is an array of product objects
  },

};
// Mock grid fields
const mockGridFields =  [
  {
      "id": "1821199435447484418",
      "column": "Product Family Name",
      "type": "Mandatory",
      "gridAvailability": true,
      "visibility": true,
      "fieldName": "productFamily",
      "order": 1
  },
  {
      "id": "1821199435464261634",
      "column": "Product Type",
      "type": "Mandatory",
      "gridAvailability": true,
      "visibility": true,
      "fieldName": "productType",
      "order": 2
  },
  {
      "id": "1821199435481038850",
      "column": "Product Family ID",
      "type": "Mandatory",
      "gridAvailability": true,
      "visibility": true,
      "fieldName": "productPhase",
      "order": 3
  },
  {
      "id": "1821199435502010369",
      "column": "Product Name",
      "type": "Mandatory",
      "gridAvailability": true,
      "visibility": true,
      "fieldName": "productName",
      "order": 4
  },
  {
      "id": "1821199435522981889",
      "column": "Product Category",
      "type": "Mandatory",
      "gridAvailability": true,
      "visibility": false,
      "fieldName": "productCategory",
      "order": 5
  }
];




jest.mock("../apis/apiFunctions", () => ({

  getProductPhaseId:jest.fn()
}));

jest.mock("../DynamicGrid/headerConfig",()=>({
  getGridFields:jest.fn()
}))


describe('LinkProducts Component', () => {
  beforeEach(() => {
    mockAxios.reset();
    mockAxios.onPost(`${GET_API}product/products/page`, {
      pageNum: 1,
      pageSize: 999999,
      showActive: true,
      showDisable: false,
      showInactive: false,
    }).reply(200, mockProducts);
    (getGridFields as jest.Mock).mockResolvedValueOnce(mockGridFields);
    (getProductPhaseId as jest.Mock).mockResolvedValueOnce("ProductPhase_PPS001")
  });

  test('renders Loading component while fetching data', () => {
    const { container } = render(
      <BrowserRouter>
        <RowContext.Provider value={{ ...mockRowContextValues, setSelectedRow: jest.fn() }}>
          <LinkProducts rowSelectionModel={[]} setRowSelectionModel={jest.fn()}  />
        </RowContext.Provider>
      </BrowserRouter>
    );

    const loadingIndicator = container.querySelector('.loading-spinner');
    expect(loadingIndicator).toBeInTheDocument();
  });

  test('displays no data available message when no products are returned', async () => {
    mockAxios.onPost(`${GET_API}product/products/page`).reply(200, { data: { data: [] } });

    render(
      <BrowserRouter>
        <RowContext.Provider value={{ ...mockRowContextValues, setSelectedRow: jest.fn() }}>
          <LinkProducts rowSelectionModel={[]} setRowSelectionModel={jest.fn()} />
        </RowContext.Provider>
      </BrowserRouter>
    );

    await waitFor(() => expect(screen.getByTestId('no-data-available')).toBeInTheDocument());
  });

  test('selects only one row at a time', async () => {
    const setRowSelectionModelMock = jest.fn();
    const setSelectedRowMock = jest.fn();

    render(
      <BrowserRouter>
        <RowContext.Provider value={{ ...mockRowContextValues, setSelectedRow: setSelectedRowMock }}>
          <LinkProducts  rowSelectionModel={[]} setRowSelectionModel={setRowSelectionModelMock}  />
        </RowContext.Provider>
      </BrowserRouter>
    );

    // Wait for the rows to be rendered
    await waitFor(() => expect(screen.getAllByRole('checkbox').length).toBeGreaterThan(1));

    // Simulate row selection
    const firstRowCheckbox = screen.getAllByRole('checkbox')[1];
    fireEvent.click(firstRowCheckbox);

    expect(setRowSelectionModelMock).toHaveBeenCalledWith([1]);

    const secondRowCheckbox = screen.getAllByRole('checkbox')[2];
    fireEvent.click(secondRowCheckbox);

    // expect(setRowSelectionModelMock).toHaveBeenCalledWith([2]);
    // expect(setSelectedRowMock).toHaveBeenCalledWith(expect.objectContaining({ id: 2 }));
  });

  // test('calls setRowSelectionModel with an empty array when no rows are selected', async () => {
  //   const setRowSelectionModelMock = jest.fn();
  //   const setSelectedRowMock = jest.fn();

  //   render(
  //     <BrowserRouter>
  //       <RowContext.Provider value={{ ...mockRowContextValues, setSelectedRow: setSelectedRowMock }}>

  //         <LinkProducts rowSelectionModel={[1]} setRowSelectionModel={setRowSelectionModelMock} dropdownValues={{}} setDropdownValues={jest.fn}  />
  //       </RowContext.Provider>
  //     </BrowserRouter>
  //   );

  //   // Wait for the rows to be rendered
  //   await waitFor(() => expect(screen.getAllByRole('checkbox').length).toBe(1));

  //   const firstRowCheckbox = screen.getAllByRole('checkbox')[1];
  //   fireEvent.click(firstRowCheckbox);
    
  //   // expect(setRowSelectionModelMock).toHaveBeenCalledWith([]);
  //   // expect(setSelectedRowMock).toHaveBeenCalledWith(undefined);
  // });

  test('test multi product', async () => {
    render(
      <BrowserRouter>
        <RowContext.Provider value={{ ...mockRowContextValues, setSelectedRow: jest.fn() }}>
          <LinkProducts rowSelectionModel={[]} setRowSelectionModel={jest.fn()}  />
        </RowContext.Provider>
      </BrowserRouter>
    );

    await waitFor(() => expect(screen.getByTestId('product-grid')).toBeInTheDocument());
  });
  
it('returns true when selected rows have matching attributes', async() => {
  const props = {
    rowSelectionModel: [],
    setRowSelectionModel: jest.fn(),
    dropdownValues: {},
    setDropdownValues: jest.fn(),
  };

  render(<LinkProducts {...props} />);
  

  // Mock the product data
  jest.spyOn(React, 'useState').mockImplementation(() => [mockProductData, jest.fn()]);

  
  const updatedProps = {
    ...props,
    rowSelectionModel: [1, 2], 
  };

  render(<LinkProducts {...updatedProps} />);

  const ref = React.createRef<{ validateSelection: () => boolean }>();
  render(<LinkProducts {...updatedProps} ref={ref} />);

 
  const result = ref?.current?.validateSelection();
  expect(result).toBe(true);
});
});
