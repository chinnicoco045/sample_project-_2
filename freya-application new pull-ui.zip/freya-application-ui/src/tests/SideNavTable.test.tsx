// src/Components/Applications/__tests__/SideNavTable.test.tsx

import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom';
import { MemoryRouter, Route, Routes } from 'react-router-dom';
import axios, { AxiosInstance } from 'axios';
import SideNavTable from '../Components/Applications/SideNavTable';
import { fetchCountryOptions, fetchReasons } from '../apis/apiFunctions';


// Mock axios
// const mock = new MockAdapter(service);
jest.mock('../apis/apiFunctions', () => ({
  fetchReasons: jest.fn(),
  fetchCountryOptions: jest.fn(),
  fetchRepeatUserwaves:jest.fn()
 }));
 const mockFetchReasons = fetchReasons as jest.MockedFunction<typeof fetchReasons>;
jest.mock('axios', () => {
  const axios = jest.requireActual('axios');
  const mockAxios: jest.Mocked<AxiosInstance> = {
    ...axios,
    get: jest.fn(),
    post: jest.fn(),
    put: jest.fn(), 
    create: jest.fn(() => mockAxios),
    interceptors: {
      request: {
        use: jest.fn(),
        eject: jest.fn(),
        clear: jest.fn(),
      },
      response: {
        use: jest.fn(),
        eject: jest.fn(),
        clear: jest.fn(),
      },
    },
  };
  return mockAxios;
});
const mockAxios = axios as jest.Mocked<typeof axios>;

const mockReasons = [
  { id: '1', name: 'Reason 1' },
  { id: '2', name: 'Reason 2' },
];

const mockSessionData={
  "region": "CountryGroup_CGCD0016",
  "status": "Active",
  "country": "Country_COCO0182",
  "productId": "20000572",
  "disabledMS": [],
  "formatType": "eCTD",
  "regionName": "Eurasian Economic Union (EAEU)",
  "eIdentifier": "",
  "productName": "Ivermectin",
  "productType": "Pharmaceuticals",
  "countryNames": "Russia",
  "memberStates": [
      "Kyrgyzstan"
  ],
  "producerType": "Decentralised Procedure",
  "productPhase": "Marketable",
  "applicationId": "765474",
  "msCountryCode": [
      "Country_COCO0119"
  ],
  "eSubIdentifier": "",
  "registrationId": "98797",
  "applicationName": "EAEU Application",
  "applicationType": "Abridged Applications",
  "procedureNumber": "6575",
  "productCategory": "Simple",
  "applicationNumber": "4345345",
  "countryIdentifier": "CMS",
  "dossierIdentifier": "",
  "sectionTree": {},
  "waveInfo": [
    {
      "comments": "te",
      "waveCode": "WAVE000005",
      "waveName": "Wave-5",
      "countryCode": "Country_COCO0056",
      "countryName": "Croatia"
    },
    {
      "comments": "",
      "waveCode": "WAVE000004",
      "waveName": "Wave-4",
      "countryCode": "Country_COCO0058"
    }
  ]
}

const mockCountryOptions=[{
  name:'country1',
  code:'code1'
},{
  name:'country2',
  code:'code2'
}]


describe('SideNavTable', () => {
  beforeEach(() => {
   sessionStorage.setItem('memberStates',JSON.stringify( [
    "Kyrgyzstan"
]))

sessionStorage.setItem('CellData',JSON.stringify({
  applicationData:mockSessionData}));

    mockAxios.get.mockResolvedValueOnce({
      "data": {
          "data": {
              "application_id": 1946,
              "application_identifier": "20000572_Russia_m4mbuvg1",
              "groupid": 1033,
              "markfor_delete": 0,
              "isExecuted": null,
              "errorMsg": null,
              "created_by": "praveen.emmadi@freyrsolutions.com",
              "created_date": "2024-12-13T05:48:31.951979",
              "updated_by": null,
              "updated_date": null,
              "success": false,
              "message": null,
              "applicationdata": 
                 mockSessionData
          },
          "message": "Application retrieved successfully",
          "status": 200
      }
  }).mockResolvedValueOnce({
    "data": {
        "data": {
            "application_id": 1880,
            "application_identifier": "20000566_Austria_m3zp55ux",
            "groupid": 975,
            "markfor_delete": 0,
            "isExecuted": null,
            "errorMsg": null,
            "created_by": "sohan.chakinarapu@freyrsolutions.com",
            "created_date": "2024-11-27T09:41:43.185875",
            "updated_by": "sohan.chakinrapu@freyesolutions.com",
            "updated_date": "2024-12-20T06:07:45.495683",
            "success": false,
            "message": null,
            "applicationdata": {
                "": "",
                "region": "CountryGroup_CGCD0001",
                "status": "Active",
                "country": "Country_COCO0015",
                "comments": "The importance of effective communication in both personal and professional settings cannot be overstated. Clear and concise communication fosters understanding, reduces misunderstandings, and builds strong relationships. In the workplace, communication is the foundation for collaboration, teamwork, and productivity. It ensures that everyone is aligned with organizational goals and can work towards them efficiently. Good communication also promotes a positive work culture, where employees feel valued and heard, boosting morale and job satisfaction. In personal life, effective communication strengthens bonds with family and friends, helping to resolve conflicts and build trust. Listening actively, expressing thoughts clearly, and being mindful of tone and body language are key aspects of good communication. In the digital age, where remote work and online interactions are common, the ability to communicate effectively through virtual channels is more critical than ever. Mastering these skills can lead to better relationships, improved outcomes, and greater success in every aspect of lifeThe importance of effective communication in both personal and professional settings cannot be overstated. Clear and concise communication fosters understanding, reduces misunderstandings, and builds strong relationships. In the workplace, communication is the foundation for collaboration, teamwork, and productivity. It ensures that everyone is aligned with organizational goals and can work towards them efficiently. Good communication also promotes a positive work culture, where employees feel valued and heard, boosting morale and job satisfaction. In personal life, effective communication strengthens bonds with family and friends, helping to resolve conflicts and build trust. Listening actively, expressing thoughts clearly, and being mindful of tone and body language are key aspects of good communication. In the digital age, where remote work and online interactions are common, the ability to communicate effectively through virtual channels is more critical than ever. Mastering these skills can lead to better relationships, improved outcomes, and greater success in every aspect of lifeThe importance of effective communication in both personal and professional settings cannot be overstated. Clear and concise communication fosters understanding, reduces misunderstandings, and builds strong relationships. In the workplace, communication is the foundation for collaboration, teamwork, and productivity. It ensures that everyone is aligned with organizational goals and can work towards them efficiently. Good communication also promotes a positive work culture, where employees feel valued and heard, boosting morale and job satisfaction. In personal life, effective communication strengthens bonds with family and friends, helping to resolve conflicts and build trust. Listening actively, expressing thoughts clearly, and being mindful of tone and body language are key aspects of good communication. In the digital age, where remote work and online interactions are common, the ability to communicate effectively through virtual channels is more critical than ever. Mastering these skills can lead to better relationships, improved outcomes, and greater success in every aspect of lifeThe importance of effective communication in both personal and professional settings cannot be overstated. Clear and concise communication fosters understanding, reduces misunderstandings, and builds strong relationships. In the workplace, communication is the foundation for collaboration, teamwork, and productivity. It ensures that everyone is aligned with organizational goals and can work towards them efficiently. Good communication also promotes a positive work culture, where employees feel valued and heard, boosting morale and job satisfaction. In personal life, effective communication strengthens bonds with family and friends, helping to resolve conflicts and build trust. Listening actively, expressing thoughts clearly, and being mindful of tone and body language are key aspects of good communication. In the digital age, where remote work and online interactions are common, the ability to communicate effectively through virtual channels is more critical than ever. Mastering these skills can lead to better relationships, improved outcomes, and greater success in every aspect of lifeThe importance of effective communication in both personal and professional settings cannot be overstated. Clear and concise communication fosters understanding, reduces misunderstandings, and builds strong relationships. In the workplace, communication is the foundation for collaboration, teamwork, and productivity. It ensures that everyone is aligned with organizational goals and can work towards them efficiently. Good communication also promotes a positive work culture, where employees feel valued and heard, boosting morale and job satisfaction.323456\n\nWikipediaThe Free Encyclop",
                "waveInfo": [
                    {
                        "comments": "aa233",
                        "waveCode": "WAVE000003",
                        "waveName": "Wave-3",
                        "countryCode": "Country_COCO0035",
                        "countryName": "Bulgaria"
                    }
                ],
                "productId": "20000566",
                "disabledMS": [
                    {
                        "comments": "",
                        "waveName": "Wave-3",
                        "countryCode": "Country_COCO0245",
                        "countryName": "Northern Ireland (UK)",
                        "commentsForDisable": "",
                        "reasonForDisableId": "ReasonForDisable_RFD00002",
                        "reasonForDisableLabel": "Created by mistake"
                    }
                ],
                "formatType": "NeES",
                "regionName": "European Union / European Economic Area",
                "eIdentifier": "",
                "productName": "Test_AK991133",
                "productType": "Herbal Medicines",
                "countryNames": "Austria",
                "memberStates": [
                    "Lithuania"],
                "producerType": "Decentralised Procedure",
                "productPhase": "Marketable",
                "applicationId": "",
                "msCountryCode": [
                    "Country_COCO0127",
                ],
                "eSubIdentifier": "",
                "registrationId": "",
                "applicationName": "App-test-123",
                "applicationType": "",
                "procedureNumber": "",
                "productCategory": "Reconstituted Simple",
                "applicationNumber": "",
                "countryIdentifier": "CMS",
                "dossierIdentifier": "",
                "reasonForInactive": "",
                "sectionTree": {
                    "Compositions": {
                        "1800458049685200898": [
                            "1800458049685200898"
                        ],
                        "1800458050310152194": [
                            "1800458050310152194"
                        ],
                        "1843648441043705858": [
                            "1843648441043705858"
                        ]
                    }
                }
            }
        },
        "message": "Application retrieved successfully",
        "status": 200
    }
});
  mockAxios.get.mockResolvedValueOnce({
    "data": {
      "code": 200,
        "message": null,
        "data": [
            {
                "id": "1853703534909784066",
                "column": "Country",
                "type": "Mandatory",
                "gridAvailability": true,
                "visibility": true,
                "fieldName": "memberState",
                "order": 1
            },
            {
                "id": "1853703626203004930",
                "column": "Country Identifier",
                "type": "Mandatory",
                "gridAvailability": true,
                "visibility": true,
                "fieldName": "countryIdentifier",
                "order": 2
            },
            {
                "id": "1853703687490174977",
                "column": "Group ID",
                "type": "Mandatory",
                "gridAvailability": true,
                "visibility": true,
                "fieldName": "groupid",
                "order": 3
            },
            {
                "id": "1853703758621376513",
                "column": "Wave",
                "type": "Mandatory",
                "gridAvailability": true,
                "visibility": true,
                "fieldName": "waveName",
                "order": 4
            },
            {
                "id": "1853703845804179458",
                "column": "Comments",
                "type": "Optional",
                "gridAvailability": true,
                "visibility": true,
                "fieldName": "comments",
                "order": 5
            }
        ]
    }
  
  });

mockAxios.post.mockResolvedValueOnce({
  "data": {
      "code": 200,
      "message": null,
      "data": {
          "id": "1853703105924759554",
          "tenantId": "0",
          "settingsJson": "[{\"field\":\"memberState\",\"label\":\"Country\",\"required\":true,\"readonly\":false,\"disabled\":false,\"description\":\"\",\"hide\":false,\"icon\":[],\"field_xs\":4,\"field_xl\":4,\"field_md\":4,\"field_lg\":4,\"originlabel\":\"Country\",\"id\":\"1853703534909784066\",\"systemDefault\":false,\"type\":\"select\",\"multiple\":true,\"asyncConfig\":{\"url\":\"/cm/dropdown-list?domain=MPR&module=applications&label=Country\",\"labelPath\":\"name\",\"valuePath\":\"id\"},\"order\":1,\"placeholder\":\"Select the Country\"}, {\"field\":\"countryIdentifier\",\"label\":\"Country Identifier\",\"required\":true,\"readonly\":true,\"disabled\":false,\"description\":\"\",\"hide\":false,\"icon\":[],\"field_xs\":4,\"field_xl\":4,\"field_md\":4,\"field_lg\":4,\"originlabel\":\"Country Identifier\",\"id\":\"1853703626203004930\",\"systemDefault\":false,\"type\":\"text\",\"maxLen\":\"20\",\"textArea\":false,\"maxRows\":1,\"order\":2,\"asyncConfig\":{},\"placeholder\":\"Input the Country Identifier\"}, {\"field\":\"groupid\",\"label\":\"Group ID\",\"required\":true,\"readonly\":true,\"disabled\":false,\"description\":\"\",\"hide\":false,\"icon\":[],\"field_xs\":4,\"field_xl\":4,\"field_md\":4,\"field_lg\":4,\"originlabel\":\"Group ID\",\"id\":\"1853703687490174977\",\"systemDefault\":false,\"type\":\"text\",\"maxLen\":\"20\",\"textArea\":false,\"maxRows\":1,\"order\":3,\"asyncConfig\":{},\"placeholder\":\"Input the Group ID\"}, {\"field\":\"waveName\",\"label\":\"Wave\",\"required\":true,\"readonly\":false,\"disabled\":false,\"description\":\"\",\"hide\":false,\"icon\":[],\"field_xs\":4,\"field_xl\":4,\"field_md\":4,\"field_lg\":4,\"originlabel\":\"Wave\",\"id\":\"1853703758621376513\",\"systemDefault\":false,\"type\":\"select\",\"multiple\":false,\"asyncConfig\":{\"url\":\"/cm/dropdown-list?domain=MPR&module=applications&label=RepeatUseWaves\",\"labelPath\":\"name\",\"valuePath\":\"id\"},\"order\":4,\"placeholder\":\"Select the Wave\"}, {\"field\":\"comments\",\"label\":\"Comments\",\"required\":false,\"readonly\":false,\"disabled\":false,\"description\":\"\",\"hide\":false,\"icon\":[],\"field_xs\":8,\"field_xl\":8,\"field_md\":8,\"field_lg\":8,\"originlabel\":\"Comments\",\"id\":\"1853703845804179458\",\"systemDefault\":false,\"type\":\"text\",\"maxLen\":\"5000\",\"textArea\":true,\"maxRows\":\"3\",\"order\":5,\"multiple\":false,\"asyncConfig\":{},\"placeholder\":\"Input the Comments\"}]"
      }
  },
});

mockAxios.put.mockResolvedValueOnce({
  "data": {
      "data": {
          "application_id": 1880,
          "application_identifier": null,
          "groupid": null,
          "markfor_delete": 0,
          "isExecuted": true,
          "errorMsg": null,
          "created_by": null,
          "created_date": null,
          "updated_by": null,
          "updated_date": null,
          "success": false,
          "message": null,
          "applicationdata": {
              "": "",
              "region": "CountryGroup_CGCD0001",
              "status": "Active",
              "country": "Country_COCO0015",
              "comments": "The importance of effective communication in both personal and professional settings cannot be overstated. Clear and concise communication fosters understanding, reduces misunderstandings, and builds strong relationships. In the workplace, communication is the foundation for collaboration, teamwork, and productivity. It ensures that everyone is aligned with organizational goals and can work towards them efficiently. Good communication also promotes a positive work culture, where employees feel valued and heard, boosting morale and job satisfaction. In personal life, effective communication strengthens bonds with family and friends, helping to resolve conflicts and build trust. Listening actively, expressing thoughts clearly, and being mindful of tone and body language are key aspects of good communication. In the digital age, where remote work and online interactions are common, the ability to communicate effectively through virtual channels is more critical than ever. Mastering these skills can lead to better relationships, improved outcomes, and greater success in every aspect of lifeThe importance of effective communication in both personal and professional settings cannot be overstated. Clear and concise communication fosters understanding, reduces misunderstandings, and builds strong relationships. In the workplace, communication is the foundation for collaboration, teamwork, and productivity. It ensures that everyone is aligned with organizational goals and can work towards them efficiently. Good communication also promotes a positive work culture, where employees feel valued and heard, boosting morale and job satisfaction. In personal life, effective communication strengthens bonds with family and friends, helping to resolve conflicts and build trust. Listening actively, expressing thoughts clearly, and being mindful of tone and body language are key aspects of good communication. In the digital age, where remote work and online interactions are common, the ability to communicate effectively through virtual channels is more critical than ever. Mastering these skills can lead to better relationships, improved outcomes, and greater success in every aspect of lifeThe importance of effective communication in both personal and professional settings cannot be overstated. Clear and concise communication fosters understanding, reduces misunderstandings, and builds strong relationships. In the workplace, communication is the foundation for collaboration, teamwork, and productivity. It ensures that everyone is aligned with organizational goals and can work towards them efficiently. Good communication also promotes a positive work culture, where employees feel valued and heard, boosting morale and job satisfaction. In personal life, effective communication strengthens bonds with family and friends, helping to resolve conflicts and build trust. Listening actively, expressing thoughts clearly, and being mindful of tone and body language are key aspects of good communication. In the digital age, where remote work and online interactions are common, the ability to communicate effectively through virtual channels is more critical than ever. Mastering these skills can lead to better relationships, improved outcomes, and greater success in every aspect of lifeThe importance of effective communication in both personal and professional settings cannot be overstated. Clear and concise communication fosters understanding, reduces misunderstandings, and builds strong relationships. In the workplace, communication is the foundation for collaboration, teamwork, and productivity. It ensures that everyone is aligned with organizational goals and can work towards them efficiently. Good communication also promotes a positive work culture, where employees feel valued and heard, boosting morale and job satisfaction. In personal life, effective communication strengthens bonds with family and friends, helping to resolve conflicts and build trust. Listening actively, expressing thoughts clearly, and being mindful of tone and body language are key aspects of good communication. In the digital age, where remote work and online interactions are common, the ability to communicate effectively through virtual channels is more critical than ever. Mastering these skills can lead to better relationships, improved outcomes, and greater success in every aspect of lifeThe importance of effective communication in both personal and professional settings cannot be overstated. Clear and concise communication fosters understanding, reduces misunderstandings, and builds strong relationships. In the workplace, communication is the foundation for collaboration, teamwork, and productivity. It ensures that everyone is aligned with organizational goals and can work towards them efficiently. Good communication also promotes a positive work culture, where employees feel valued and heard, boosting morale and job satisfaction.323456\n\nWikipediaThe Free Encyclop",
              "waveInfo": [
                  {
                      "comments": "",
                      "waveCode": "WAVE000007",
                      "waveName": "Wave-7",
                      "countryCode": "Country_COCO0022"
                  }
              ],
              "productId": "20000566",
              "disabledMS": [
              ],
              "formatType": "NeES",
              "regionName": "European Union / European Economic Area",
              "eIdentifier": "",
              "productName": "Test_AK99",
              "productType": "Herbal Medicines",
              "countryNames": "Austria",
              "memberStates": [
                  "Lithuania"
              ],
              "producerType": "Decentralised Procedure",
              "productPhase": "Marketable",
              "applicationId": "",
              "msCountryCode": [
                  "Country_COCO0127"
              ],
              "eSubIdentifier": "",
              "registrationId": "",
              "applicationName": "App-test-123",
              "applicationType": "",
              "procedureNumber": "",
              "productCategory": "Reconstituted Simple",
              "applicationNumber": "",
              "countryIdentifier": "CMS",
              "dossierIdentifier": "",
              "reasonForInactive": "",
              "sectionTree": {
                  "Compositions": {
                      "1800458049685200898": [
                          "1800458049685200898"
                      ],
                      "1800458050310152194": [
                          "1800458050310152194"
                      ],
                      "1843648441043705858": [
                          "1843648441043705858"
                      ]
                  }
              }
          }
      },
      "message": "Application updated successfully",
      "status": 200
  },
});

const memberStates=sessionStorage.getItem('memberStates');

    mockFetchReasons.mockResolvedValueOnce(mockReasons); // Use the correct mocked function
    (fetchCountryOptions as jest.Mock).mockResolvedValueOnce(mockCountryOptions);
  });

  it('renders SideNavTable with location state values', async () => {
    render(
      <MemoryRouter initialEntries={[{ pathname: '/', state: { id: 'mockId', label: 'Member States', menuname: 'Member States', url: '/application/v1/display/mockId', module: 'applications', mode:"edit" } }]}>
        <Routes>
      <Route path="/" element={<SideNavTable />} />
      </Routes>
     </MemoryRouter>
    );

    // Wait for the data to be loaded
    await waitFor(() => expect(mockAxios.get).toHaveBeenCalledTimes(2));


    
  }); 

  it('tests Edit, View, and Disable buttons in the actions column', async () => {
    
    render(
      <MemoryRouter initialEntries={[{ pathname: '/', state: { id: 'mockId', label: 'Member States', menuname: 'Member States', url: '/application/v1/display/mockId', module: 'applications', mode:"edit" } }]}>
      <Routes><Route path="/" element={<SideNavTable />} /></Routes>
     </MemoryRouter>
    );


    await waitFor(() => expect(mockAxios.get).toHaveBeenCalledTimes(2));
    const moreButton = await screen.findByRole('menuitem', { name: /more/i });
    fireEvent.click(moreButton);
    const editIcon = await screen.findByTestId('edit-button');
    fireEvent.click(editIcon);

  });

  it('tests  View buttons in the actions column', async () => {
    render(
      <MemoryRouter initialEntries={[{ pathname: '/', state: { id: 'mockId2', label: 'Member States', menuname: 'Member States', url: '/application/v1/display/mockId2', module: 'applications',mode:"edit" } }]}>
      <Routes><Route path="/" element={<SideNavTable />} /></Routes>
     </MemoryRouter>
    );


    await waitFor(() => expect(mockAxios.get).toHaveBeenCalledTimes(2));
    const moreButton = await screen.findByRole('menuitem', { name: /more/i });
    fireEvent.click(moreButton);
    const viewIcon = await screen.findByTestId('view-button');
    fireEvent.click(viewIcon);

  });

  it('tests  Disable buttons in the actions column', async () => {
    render(
      <MemoryRouter initialEntries={[{ pathname: '/', state: { id: 'mockId1', label: 'Member States', menuname: 'Member States', url: '/application/v1/display/mockId1', module: 'applications',mode:"edit" } }]}>
      <Routes><Route path="/" element={<SideNavTable />} /></Routes>
     </MemoryRouter>
    );


    await waitFor(() => expect(mockAxios.get).toHaveBeenCalledTimes(2));
    const moreButton = await screen.findByRole('menuitem', { name: /more/i });
    fireEvent.click(moreButton);
    const disableIcon = await screen.findByTestId('disable-button');
    fireEvent.click(disableIcon);
    const autocompleteInput =await screen.findByLabelText(
      /reasonForDisable/i
    );

    fireEvent.change(autocompleteInput, { target: { value: "Reason 1" } });

    await waitFor(() => screen.getByText("Reason 1"));

    fireEvent.click(screen.getByText("Reason 1"));

    const commentInput = screen.getByLabelText(/comment/i);
    fireEvent.change(commentInput, { target: { value: "Test comment" } });

    expect(screen.getByRole("button", { name: /yes/i })).toBeEnabled();

    const yesButton = screen.getByRole("button", { name: /yes/i });
    fireEvent.click(yesButton);



  });

  

  it('finds Actions and Add MS button in the top of the grid', async () => {
    render(
      <MemoryRouter initialEntries={[{ pathname: '/', state: { id: 'mockId', label: 'Member States', menuname: 'Member States', url: '/application/v1/display/mockId', module: 'applications',mode:"edit" } }]}>
      <Routes><Route path="/" element={<SideNavTable />} /></Routes>
     </MemoryRouter>
    );

    // Wait for the data to be loaded
    await waitFor(() => expect(mockAxios.get).toHaveBeenCalledTimes(2));

    // Check for Actions button
    const actionsButton = screen.getByText('actions');
    expect(actionsButton).toBeInTheDocument();

    // Check for Add MS button
    const addMSButton = screen.getByText('add_ms');
    expect(addMSButton).toBeInTheDocument();
  });

  it('render other than MS', async()=>{
    render(
<MemoryRouter  initialEntries={[{ pathname: '/', state:  {
      productId: '123',
      menuname: "Documents",
      url: '/test-url/${productId}',
      label:'Documents',
      mode:"edit"
  }}]}>
<Routes><Route path="/" element={<SideNavTable />} /></Routes>
</MemoryRouter>

    );
  const documentElement = screen.getAllByText('Documents');
    expect(documentElement[0]).toBeInTheDocument();

    const documentElements = screen.getAllByText('Documents');
    documentElements.forEach(element => {
      expect(element).toBeInTheDocument();
    });
  })
}); 