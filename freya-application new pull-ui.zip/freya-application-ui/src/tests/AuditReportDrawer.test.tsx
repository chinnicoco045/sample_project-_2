import axios from 'axios';
import { render, screen, fireEvent, waitFor, act } from '@testing-library/react';
import AuditReportDrawer from '../Audit/AuditReportDrawer';
import { useTranslation } from 'react-i18next';
import { useSnackbar } from 'notistack';
import MockAdapter from 'axios-mock-adapter';
import service, { GET_API } from '../Services/apiheader';

import { fetchAuditFieldModification, fetchOperationListByEntityId } from '../Audit/audit';

const mockAxios = new MockAdapter(axios);
jest.mock('react-i18next', () => ({
    useTranslation: jest.fn(),
}));
jest.mock('../Services/apiheader');
jest.mock('notistack', () => ({
    useSnackbar: jest.fn(),
}));

jest.mock('react-i18next', () => ({
    useTranslation: jest.fn(),
}));

jest.mock('../Audit/audit', () => ({
    fetchOperationListByEntityId: jest.fn(),
    getEntityIdentifiedInformation: jest.fn(),
    fetchAuditFieldModification: jest.fn(),
}));

describe('AuditReportDrawer', () => {
    const mockTranslation = { t: (key: string) => key };
    const mockSnackbar = { enqueueSnackbar: jest.fn() };
    const mockHandleCancel = jest.fn();
    const mockHandleClose = jest.fn();
    const mockChangePageInfo = jest.fn();

    const mocksectionTreeDataProps = [
        {
            "id": "136",
            "name": "Compositions",
            "displayName": "Compositions",
            "gridDataUrl": "/product/composition/page?pageNum=1&pageSize=1000000&productId=${id}",
            "formDataUrl": "/product/composition/${id}",
            "menuOrder": 1,
            "children": [
                {
                    "id": "1800458049685200898",
                    "name": "Compositions",
                    "displayName": "Compositions",
                    "gridDataUrl": "/product/composition/page?pageNum=1&pageSize=1000000&productId=${id}",
                    "formDataUrl": "/product/composition/${id}",
                    "data": [
                        {
                            "compositionName": "Test-Composition-010",
                            "compositionCategory": "Basic",
                            "productId": "20000548",
                            "id": "1850837844763688961"
                        },
                        {
                            "compositionName": "Test",
                            "compositionCategory": "Basic",
                            "productId": "20000548",
                            "id": "1849784791071539201"
                        }
                    ],
                    "labelPath": "compositionName",
                    "module": "product",
                    "menuOrder": 1,
                    "children": null
                },
                {
                    "id": "1843648441043705858",
                    "name": "Ingredients",
                    "displayName": "Ingredients",
                    "gridDataUrl": "/product/ingredient/page?pageNum=1&pageSize=1000000&productId=${id}",
                    "formDataUrl": "/product/ingredient/${id}",
                    "data": [],
                    "labelPath": "ingredientName",
                    "module": "product",
                    "menuOrder": 2,
                    "children": null
                },
                {
                    "id": "1800458050310152194",
                    "name": "Ingredients Quantity",
                    "displayName": "Ingredients Quantity",
                    "gridDataUrl": "/product/ingredient-quantity/page?pageNum=1&pageSize=1000000&productId=${id}",
                    "formDataUrl": "/product/ingredient-quantity/${id}",
                    "data": [],
                    "labelPath": "ingredientName",
                    "module": "product",
                    "menuOrder": 3,
                    "children": null
                },
                {
                    "id": "1800458048670179330",
                    "name": "Storage Conditions",
                    "displayName": "Storage Conditions",
                    "gridDataUrl": "/product/storage-condition/page?pageNum=1&pageSize=1000000&productId=${id}",
                    "formDataUrl": "/product/storage-condition/${id}",
                    "data": [],
                    "labelPath": "storageCondition",
                    "module": "product",
                    "menuOrder": 4,
                    "children": null
                },
                {
                    "id": "1840279548958924802",
                    "name": "Pharmaceutical Product",
                    "displayName": "Pharmaceutical Product",
                    "gridDataUrl": "/product/pharmaceutical-product/page?pageNum=1&pageSize=1000000&productId=${id}",
                    "formDataUrl": "/product/pharmaceutical-product/${id}",
                    "data": [
                        {
                            "routeOfAdmin": "Bath treatment",
                            "unitOfPresentation": "Ampoule",
                            "administrableDoseForm": "Aerosol, spray",
                            "pharmaceuticalProductName": "Product-test-001",
                            "productId": "20000548",
                            "id": "1850864560945053698"
                        }
                    ],
                    "labelPath": "pharmaceuticalProductName",
                    "module": "product",
                    "menuOrder": 5,
                    "children": null
                },
                {
                    "id": "1840279708271173634",
                    "name": "Pharmaceutical Product Description",
                    "displayName": "Pharmaceutical Product Description",
                    "gridDataUrl": "/product/pharmaceutical-product-description/page?pageNum=1&pageSize=1000000&productId=${id}",
                    "formDataUrl": "/product/pharmaceutical-product-description/${id}",
                    "data": [
                        {
                            "language": "Amharic",
                            "pharmaceuticalProductName": "Product-test-001",
                            "pharmaceuticalProductDescription": "Test Description",
                            "productId": "20000548",
                            "id": "1850864626376196098"
                        }
                    ],
                    "labelPath": "pharmaceuticalProductName",
                    "module": "product",
                    "menuOrder": 6,
                    "children": null
                },
                {
                    "id": "1840279796372529154",
                    "name": "Ing. Other Representation",
                    "displayName": "Ing. Other Representation",
                    "gridDataUrl": "/product/representations/page?pageNum=1&pageSize=1000000&productId=${id}",
                    "formDataUrl": "/product/representations/${id}",
                    "data": [
                        {
                            "ingredientName": "2 OCTYLDODECANOL",
                            "ingredientRole": "Excipient",
                            "compositionName": "Test-Composition-010",
                            "ingredientNameCode": "ANHYDRICAL CHLOROBUTANOL",
                            "representationType": "Specified Substance",
                            "productId": "20000548",
                            "id": "1850864730646593537"
                        }
                    ],
                    "labelPath": "ingredientName",
                    "module": "product",
                    "menuOrder": 7,
                    "children": null
                },
                {
                    "id": "1840279855357026306",
                    "name": "Ing. Other Representation Quantity",
                    "displayName": "Ing. Other Representation Quantity",
                    "gridDataUrl": "/product/representation-quantities/page?pageNum=1&pageSize=1000000&productId=${id}",
                    "formDataUrl": "/product/representation-quantities/${id}",
                    "data": [
                        {
                            "strengthType": "Concentration",
                            "ingredientName": "2 OCTYLDODECANOL",
                            "compositionName": "Test-Composition-010",
                            "ingredientNameCode": "ANHYDRICAL CHLOROBUTANOL",
                            "representationType": "Specified Substance",
                            "compositionCategory": "Basic",
                            "CompositionCategory_CMCY2_quantityOperator": "average",
                            "productId": "20000548",
                            "id": "1850864849722884097"
                        }
                    ],
                    "labelPath": "ingredientName",
                    "module": "product",
                    "menuOrder": 8,
                    "children": null
                }
            ]
        },
        {
            "id": "157",
            "name": "Packages",
            "displayName": "Packages",
            "gridDataUrl": "/product/package/page?pageNum=1&pageSize=1000000&productId=${id}",
            "formDataUrl": "/product/package/${id}",
            "menuOrder": 13,
            "children": [
                {
                    "id": "1801190614789378050",
                    "name": "Packages",
                    "displayName": "Packages",
                    "gridDataUrl": "/product/package/page?pageNum=1&pageSize=1000000&productId=${id}",
                    "formDataUrl": "/product/package/${id}",
                    "data": [
                        {
                            "packageName": "Package-Test-001",
                            "packageSize": "12",
                            "packageType": "Oral applicator",
                            "packageLevel": "Primary",
                            "packageCategory": "Basic",
                            "packageSizeUnit": "Ampoule",
                            "quantityOperator": "approximately equal to",
                            "productId": "20000548",
                            "id": "1850865221036228610"
                        }
                    ],
                    "labelPath": "packageName",
                    "module": "product",
                    "menuOrder": 13,
                    "children": null
                },
                {
                    "id": "1800458051333562369",
                    "name": "Batch Details",
                    "displayName": "Batch Details",
                    "gridDataUrl": "/product/package-batch-detail/page?pageNum=1&pageSize=1000000&productId=${id}",
                    "formDataUrl": "/product/package-batch-detail/${id}",
                    "data": [],
                    "labelPath": "batchNumber",
                    "module": "product",
                    "menuOrder": 14,
                    "children": null
                },
                {
                    "id": "1800458051589414913",
                    "name": "Components",
                    "displayName": "Components",
                    "gridDataUrl": "/product/package-component/page?pageNum=1&pageSize=1000000&productId=${id}",
                    "formDataUrl": "/product/package-component/${id}",
                    "data": [],
                    "labelPath": "componentMaterial",
                    "module": "product",
                    "menuOrder": 15,
                    "children": null
                },
                {
                    "id": "1800458048775036930",
                    "name": "Language",
                    "displayName": "Language",
                    "gridDataUrl": "/product/package-language/page?pageNum=1&pageSize=1000000&productId=${id}",
                    "formDataUrl": "/product/package-language/${id}",
                    "data": [],
                    "labelPath": "language",
                    "module": "product",
                    "menuOrder": 16,
                    "children": null
                },
                {
                    "id": "1800458049588731905",
                    "name": "Shelf-Life",
                    "displayName": "Shelf-Life",
                    "gridDataUrl": "/product/package-shelf-life/page?pageNum=1&pageSize=1000000&productId=${id}",
                    "formDataUrl": "/product/package-shelf-life/${id}",
                    "data": [],
                    "labelPath": "shelfLife",
                    "module": "product",
                    "menuOrder": 17,
                    "children": null
                },
                {
                    "id": "1800458051752992769",
                    "name": "Storages",
                    "displayName": "Storages",
                    "gridDataUrl": "/product/package-storage/page?pageNum=1&pageSize=1000000&productId=${id}",
                    "formDataUrl": "/product/package-storage/${id}",
                    "data": [],
                    "labelPath": "specialPrecautionsForStorage",
                    "module": "product",
                    "menuOrder": 18,
                    "children": null
                },
                {
                    "id": "1840309553642397698",
                    "name": "Manufactured Item",
                    "displayName": "Manufactured Item",
                    "gridDataUrl": "/product/manufactured-item/page?pageNum=1&pageSize=1000000&productId=${id}",
                    "formDataUrl": "/product/manufactured-item/${id}",
                    "data": [
                        {
                            "unitOfPresentation": "Ampoule",
                            "manufacturedItemName": "Test-Manufactured-01",
                            "productId": "20000548",
                            "id": "1850864946841993218",
                            "manufacturedDoseForm": null
                        }
                    ],
                    "labelPath": "manufacturedItemName",
                    "module": "product",
                    "menuOrder": 19,
                    "children": null
                },
                {
                    "id": "1840309617781694466",
                    "name": "Manufactured Item Description",
                    "displayName": "Manufactured Item Description",
                    "gridDataUrl": "/product/manufactured-item-description/page?pageNum=1&pageSize=1000000&productId=${id}",
                    "formDataUrl": "/product/manufactured-item-description/${id}",
                    "data": [
                        {
                            "language": "Afar",
                            "manufacturedItemName": "Test-Manufactured-01",
                            "manufacturedItemDescription": "Test Manufactured Description",
                            "productId": "20000548",
                            "id": "1850865036348440578"
                        }
                    ],
                    "labelPath": "manufacturedItemName",
                    "module": "product",
                    "menuOrder": 20,
                    "children": null
                },
                {
                    "id": "1840309698698207233",
                    "name": "Data Carrier Identifier",
                    "displayName": "Data Carrier Identifier",
                    "gridDataUrl": "/product/data-carrier-identifier/page?pageNum=1&pageSize=1000000&productId=${id}",
                    "formDataUrl": "/product/data-carrier-identifier/${id}",
                    "data": [
                        {
                            "packageName": "Package-Test-001",
                            "dataCarrierValue": "21",
                            "dataCarrierCodeSystem": "DC001",
                            "productId": "20000548",
                            "id": "1850865301629779970"
                        }
                    ],
                    "labelPath": "packageName",
                    "module": "product",
                    "menuOrder": 21,
                    "children": null
                }
            ]
        },
        {
            "id": "191",
            "name": "Therapeutic Details",
            "displayName": "Therapeutic Details",
            "gridDataUrl": "/product/therapeutic-detail/page?pageNum=1&pageSize=1000000&productId=${id}",
            "formDataUrl": "/product/therapeutic-detail/${id}",
            "menuOrder": 19,
            "children": [
                {
                    "id": "1800458051828490241",
                    "name": "Therapeutic Details",
                    "displayName": "Therapeutic Details",
                    "gridDataUrl": "/product/therapeutic-detail/page?pageNum=1&pageSize=1000000&productId=${id}",
                    "formDataUrl": "/product/therapeutic-detail/${id}",
                    "data": [],
                    "labelPath": "therapeuticArea",
                    "module": "product",
                    "menuOrder": 19,
                    "children": null
                },
                {
                    "id": "1800458051987873793",
                    "name": "Indication Details",
                    "displayName": "Indication Details",
                    "gridDataUrl": "/product/indication/page?pageNum=1&pageSize=1000000&productId=${id}",
                    "formDataUrl": "/product/indication/${id}",
                    "data": [],
                    "labelPath": "fullIndicationText",
                    "module": "product",
                    "menuOrder": 20,
                    "children": null
                },
                {
                    "id": "1800458052247920642",
                    "name": "Intended Effects",
                    "displayName": "Intended Effects",
                    "gridDataUrl": "/product/intended-effect/page?pageNum=1&pageSize=1000000&productId=${id}",
                    "formDataUrl": "/product/intended-effect/${id}",
                    "data": [],
                    "labelPath": "intendedEffect",
                    "module": "product",
                    "menuOrder": 21,
                    "children": null
                },
                {
                    "id": "1800458052344389634",
                    "name": "Co-Morbidity",
                    "displayName": "Co-Morbidity",
                    "gridDataUrl": "/product/comorbidity/page?pageNum=1&pageSize=1000000&productId=${id}",
                    "formDataUrl": "/product/comorbidity/${id}",
                    "data": [],
                    "labelPath": "comorbidity",
                    "module": "product",
                    "menuOrder": 22,
                    "children": null
                },
                {
                    "id": "1800458048863117314",
                    "name": "Contraindications",
                    "displayName": "Contraindications",
                    "gridDataUrl": "/product/contraindication/page?pageNum=1&pageSize=1000000&productId=${id}",
                    "formDataUrl": "/product/contraindication/${id}",
                    "data": [],
                    "labelPath": "contraindication",
                    "module": "product",
                    "menuOrder": 23,
                    "children": null
                },
                {
                    "id": "1800458052503773185",
                    "name": "Contraindication Details",
                    "displayName": "Contraindication Details",
                    "gridDataUrl": "/product/contraindication-detail/page?pageNum=1&pageSize=1000000&productId=${id}",
                    "formDataUrl": "/product/contraindication-detail/${id}",
                    "data": [],
                    "labelPath": "contraindicationTerm",
                    "module": "product",
                    "menuOrder": 24,
                    "children": null
                }
            ]
        },
        {
            "id": "211",
            "name": "Organisations",
            "displayName": "Organisations",
            "gridDataUrl": "/product/organization/page?pageNum=1&pageSize=1000000&productId=${productId}",
            "formDataUrl": "/product/organization/${id}",
            "menuOrder": 25,
            "children": [
                {
                    "id": "1800458052688322562",
                    "name": "Organisations",
                    "displayName": "Organisations",
                    "gridDataUrl": "/product/organization/page?pageNum=1&pageSize=1000000&productId=${productId}",
                    "formDataUrl": "/product/organization/${id}",
                    "data": [
                        {
                            "numberType": "123",
                            "organisationName": "Galderma SA",
                            "productId": "20000548",
                            "id": "1850869544843558914"
                        }
                    ],
                    "labelPath": "organisationName",
                    "module": "product",
                    "menuOrder": 25,
                    "children": null
                },
                {
                    "id": "1800458052948369409",
                    "name": "Business Operations",
                    "displayName": "Business Operations",
                    "gridDataUrl": "/product/business-operation/page?pageNum=1&pageSize=1000000&productId=${productId}",
                    "formDataUrl": "/product/business-operation/${id}",
                    "data": [
                        {
                            "operationType": "Quality control testing of medicinal product",
                            "organisationName": "Galderma SA",
                            "productId": "20000548",
                            "id": "1850869646286995458"
                        }
                    ],
                    "labelPath": "organisationName",
                    "module": "product",
                    "menuOrder": 26,
                    "children": null
                },
                {
                    "id": "1840365655599931394",
                    "name": "Specifications",
                    "displayName": "Specifications",
                    "gridDataUrl": "/product/specification/page?pageNum=1&pageSize=1000000&productId=${productId}",
                    "formDataUrl": "/product/specification/${id}",
                    "data": [],
                    "labelPath": "organisationName",
                    "module": "product",
                    "menuOrder": 27,
                    "children": null
                }
            ]
        },
        {
            "id": "255",
            "name": "Documents",
            "displayName": "Documents",
            "gridDataUrl": "/product/document/product/${id}",
            "menuOrder": 28,
            "children": [
                {
                    "id": "1800458049857167361",
                    "name": "Documents",
                    "displayName": "Documents",
                    "gridDataUrl": "/product/document/product/${id}",
                    "data": [],
                    "labelPath": "responseDocumentName",
                    "module": "product",
                    "menuOrder": 28,
                    "children": null
                }
            ]
        }
    ]
    const mockfielddata = {
        "status": 200,
        "message": null,
        "data": {
            "data":
            {
                "pageSize": 10,
                "pageNum": 1,
                "total": 12,
                "data": [
                    {
                        "id": "10209103",
                        "recordId": "AR-10209103",
                        "operationType": "Update",
                        "operatorUsername": "banda.geetha@freyrsolutions.com",
                        "operationDate": "29/Oct/2024 07:35:42",
                        "entityIdentifier": "1688",
                        "entityName": "application",
                        "fromService": "Application",
                        "moduleName": "Application",
                        "domainId": null
                    }
                ]
            }
        }
    }
    const mockData = {
        "status": 200,
        "message": null,
        "data": {
            "data": {
                "id": "10209103",
                "recordId": "AR-10209103",
                "operationType": "Update",
                "entityIdentifier": "1688",
                "entityName": "application",
                "operatorUsername": "banda.geetha@freyrsolutions.com",
                "moduleName": "Application",
                "domainId": null,
                "operationDate": "29/Oct/2024 07:35:42",
                "entityCreatedByName": "sohan.chakinarapu@freyrSolutions.com",
                "entityCreatedDate": "28/Oct/2024 11:53:51",
                "entityModifiedByName": "banda.geetha@freyrsolutions.com",
                "entityModifiedDate": "29/Oct/2024 07:35:42",
                "fieldModifications": [
                    {
                        "fieldName": "applicationdata",
                        "oldValue": "{\"\": \"\", \"ms\": [], \"cms\": [], \"lms\": \"\", \"msc\": [], \"rms\": \"\", \"msName\": [], \"region\": \"CountryGroup_CGCD0029\", \"status\": \"Active\", \"cmsName\": [], \"country\": \"Country_COCO0038\", \"lmsName\": \"\", \"mscName\": [], \"rmsName\": \"\", \"comments\": \"test\", \"language\": \"Armensk\", \"productId\": \"20000548\", \"formatType\": \"NeES\", \"regionName\": \"ASEAN\", \"eIdentifier\": \"\", \"productName\": \"Beta\", \"productType\": \"Pharmaceuticals\", \"sectionTree\": {\"Packages\": {\"Packages\": [\"1850865221036228610\"], \"Manufactured Item\": [\"1850864946841993218\"], \"1800458048775036930\": [\"1800458048775036930\"], \"1800458049588731905\": [\"1800458049588731905\"], \"1800458051333562369\": [\"1800458051333562369\"], \"1800458051589414913\": [\"1800458051589414913\"], \"1800458051752992769\": [\"1800458051752992769\"], \"Data Carrier Identifier\": [\"1850865301629779970\"], \"Manufactured Item Description\": [\"1850865036348440578\"]}, \"Compositions\": {\"Compositions\": [\"1850837844763688961\", \"1849784791071539201\"], \"1800458048670179330\": [\"1800458048670179330\"], \"1800458050310152194\": [\"1800458050310152194\"], \"1843648441043705858\": [\"1843648441043705858\"]}}, \"countryNames\": \"Cambodia\", \"memberStates\": \"-\", \"producerType\": \"National Procedure\", \"productPhase\": \"Marketable\", \"applicationId\": \"\", \"msCountryCode\": \"-\", \"eSubIdentifier\": \"\", \"registrationId\": \"\", \"applicationName\": \"test-2\", \"applicationType\": \"Abbreviated New Drug Application (ANDA)\", \"procedureNumber\": \"\", \"productCategory\": \"Simple\", \"applicationNumber\": \"\", \"applicationStatus\": \"Active\", \"countryIdentifier\": \"\", \"dossierIdentifier\": \"\", \"reasonForInactive\": \"\"}",
                        "newValue": "{\"\":\"\",\"ms\":[],\"cms\":[],\"lms\":\"\",\"msc\":[],\"rms\":\"\",\"msNames\":[],\"region\":\"CountryGroup_CGCD0029\",\"status\":\"Active\",\"cmsName\":[],\"country\":\"Country_COCO0038\",\"lmsName\":\"\",\"mscName\":[],\"rmsName\":\"\",\"comments\":\"test\",\"language\":\"Armensk\",\"productId\":\"20000548\",\"formatType\":\"NeES\",\"regionName\":\"ASEAN\",\"eIdentifier\":\"\",\"productName\":\"Beta\",\"productType\":\"Pharmaceuticals\",\"countryNames\":\"Cambodia\",\"memberStates\":\"-\",\"producerType\":\"National Procedure\",\"productPhase\":\"Marketable\",\"applicationId\":\"\",\"msCountryCode\":\"-\",\"eSubIdentifier\":\"\",\"registrationId\":\"\",\"applicationName\":\"test-2\",\"applicationType\":\"Abbreviated New Drug Application (ANDA)\",\"procedureNumber\":\"\",\"productCategory\":\"Simple\",\"applicationNumber\":\"\",\"applicationStatus\":\"Current\",\"countryIdentifier\":\"\",\"dossierIdentifier\":\"\",\"reasonForInactive\":\"\",\"sectionTree\":{\"Packages\":{\"Packages\":[\"1850865221036228610\"],\"Manufactured Item\":[\"1850864946841993218\"],\"1800458048775036930\":[\"1800458048775036930\"],\"1800458049588731905\":[\"1800458049588731905\"],\"1800458051333562369\":[\"1800458051333562369\"],\"1800458051589414913\":[\"1800458051589414913\"],\"1800458051752992769\":[\"1800458051752992769\"],\"Data Carrier Identifier\":[\"1850865301629779970\"],\"Manufactured Item Description\":[\"1850865036348440578\"]},\"Compositions\":{\"Compositions\":[\"1850837844763688961\",\"1849784791071539201\"],\"1800458048670179330\":[\"1800458048670179330\"],\"1800458050310152194\":[\"1800458050310152194\"],\"1843648441043705858\":[\"1843648441043705858\"]}}}"
                    },
                    {
                        "fieldName": "applicationdata",
                        "oldValue": "{\"\": \"\", \"ms\": [], \"cms\": [], \"lms\": \"\", \"msc\": [], \"rms\": \"\", \"msName\": [], \"region\": \"CountryGroup_CGCD0029\", \"status\": \"Active\", \"cmsName\": [], \"country\": \"Country_COCO0038\", \"lmsName\": \"\", \"mscName\": [], \"rmsName\": \"\", \"comments\": \"test\", \"language\": \"Armensk\", \"productId\": \"20000548\", \"formatType\": \"NeES\", \"regionName\": \"ASEAN\", \"eIdentifier\": \"\", \"productName\": \"Beta\", \"productType\": \"Pharmaceuticals\", \"sectionTree\": {\"Packages\": {\"Packages\": [\"1850865221036228610\"], \"Manufactured Item\": [\"1850864946841993218\"], \"1800458048775036930\": [\"1800458048775036930\"], \"1800458049588731905\": [\"1800458049588731905\"], \"1800458051333562369\": [\"1800458051333562369\"], \"1800458051589414913\": [\"1800458051589414913\"], \"1800458051752992769\": [\"1800458051752992769\"], \"Data Carrier Identifier\": [\"1850865301629779970\"], \"Manufactured Item Description\": [\"1850865036348440578\"]}, \"Compositions\": {\"Compositions\": [\"1850837844763688961\", \"1849784791071539201\"], \"1800458048670179330\": [\"1800458048670179330\"], \"1800458050310152194\": [\"1800458050310152194\"], \"1843648441043705858\": [\"1843648441043705858\"]}}, \"countryNames\": \"Cambodia\", \"memberStates\": \"-\", \"producerType\": \"National Procedure\", \"productPhase\": \"Marketable\", \"applicationId\": \"\", \"msCountryCode\": \"-\", \"eSubIdentifier\": \"\", \"registrationId\": \"\", \"applicationName\": \"test-2\", \"applicationType\": \"Abbreviated New Drug Application (ANDA)\", \"procedureNumber\": \"\", \"productCategory\": \"Simple\", \"applicationNumber\": \"\", \"applicationStatus\": \"Active\", \"countryIdentifier\": \"\", \"dossierIdentifier\": \"\", \"reasonForInactive\": \"\"}",
                        "newValue": "{\"\":\"\",\"ms\":[],\"cms\":[],\"lms\":\"\",\"msc\":[],\"rms\":\"\",\"msNames\":[],\"region\":\"CountryGroup_CGCD0029\",\"status\":\"Active\",\"cmsName\":[],\"country\":\"Country_COCO0038\",\"lmsName\":\"\",\"mscName\":[],\"rmsName\":\"\",\"comments\":\"test\",\"language\":\"Armensk\",\"productId\":\"20000548\",\"formatType\":\"NeES\",\"regionName\":\"ASEAN\",\"eIdentifier\":\"\",\"productName\":\"Beta\",\"productType\":\"Pharmaceuticals\",\"countryNames\":\"Cambodia\",\"memberStates\":\"-\",\"producerType\":\"National Procedure\",\"productPhase\":\"Marketable\",\"applicationId\":\"\",\"msCountryCode\":\"-\",\"eSubIdentifier\":\"\",\"registrationId\":\"\",\"applicationName\":\"test-2\",\"applicationType\":\"Abbreviated New Drug Application (ANDA)\",\"procedureNumber\":\"\",\"productCategory\":\"Simple\",\"applicationNumber\":\"\",\"applicationStatus\":\"Current\",\"countryIdentifier\":\"\",\"dossierIdentifier\":\"\",\"reasonForInactive\":\"\",\"sectionTree\":{\"Packages\":{\"Packages\":[\"1850865221036228610\"],\"Manufactured Item\":[\"1850864946841993218\"],\"1800458048775036930\":[\"1800458048775036930\"],\"1800458049588731905\":[\"1800458049588731905\"],\"1800458051333562369\":[\"1800458051333562369\"],\"1800458051589414913\":[\"1800458051589414913\"],\"1800458051752992769\":[\"1800458051752992769\"],\"Data Carrier Identifier\":[\"1850865301629779970\"],\"Manufactured Item Description\":[\"1850865036348440578\"]},\"Compositions\":{\"Compositions\":[\"1850837844763688961\",\"1849784791071539201\"],\"1800458048670179330\":[\"1800458048670179330\"],\"1800458050310152194\":[\"1800458050310152194\"],\"1843648441043705858\":[\"18436484410437058586\"]}}}"
                    },
                    {
                        "fieldName": "updated_date",
                        "oldValue": "2024-10-29T07:35:31.941024",
                        "newValue": "2024-10-29T07:35:42.062599179"
                    }
                ]
            }
        }
    };
    const mockResponse = {
        "id": "1841344255086092289",
        "tenantId": "0",
        "settingsJson": "[{\"type\":\"select\",\"field\":\"devicePhase\",\"businessField\":true,\"required\":true,\"readonly\":false,\"disabled\":false,\"hide\":false,\"systemDefault\":true,\"originlabel\":\"Device Phase\",\"label\":\"Device Phase\",\"multiple\":false,\"options\":[{\"label\":\"Marketable\",\"value\":\"Marketable\"},{\"label\":\"Investigational\",\"value\":\"Investigational\"}],\"asyncConfig\":{},\"icon\":[],\"description\":\"\",\"textArea\":false,\"maxRows\":1,\"field_xs\":4,\"field_xl\":4,\"field_md\":4,\"field_lg\":4,\"gridDefault\":true,\"Visibility\":true,\"tenantId\":0,\"order\":1,\"placeholder\":\"Select the Device Phase\"}, {\"type\":\"select\",\"field\":\"deviceCategory\",\"businessField\":true,\"required\":true,\"readonly\":false,\"disabled\":false,\"hide\":false,\"systemDefault\":true,\"originlabel\":\"Device Category\",\"label\":\"Device Category\",\"multiple\":false,\"options\":[{\"label\":\"Single use devices (i.e. Syringes, catheters)\",\"value\":\"Single use devices (i.e. Syringes, catheters)\"},{\"label\":\"Implantable (i.e. Hip prothesis, pacemakers)\",\"value\":\"Implantable (i.e. Hip prothesis, pacemakers)\"},{\"label\":\"Imaging (i.e. Ultrasound and ct scanners)\",\"value\":\"Imaging (i.e. Ultrasound and ct scanners)\"},{\"label\":\"Medical equipment (i.e. Anesthesia machines, patient monitors, hemodialysis machines)\",\"value\":\"Medical equipment (i.e. Anesthesia machines, patient monitors, hemodialysis machines)\"},{\"label\":\"Software (i.e. Computer aided diagnostics)\",\"value\":\"Software (i.e. Computer aided diagnostics)\"},{\"label\":\"In vitro diagnostics (i.e. Glucometer, hiv tests)\",\"value\":\"In vitro diagnostics (i.e. Glucometer, hiv tests)\"},{\"label\":\"Personal protective equipment (i.e. Mask, gowns, gloves)\",\"value\":\"Personal protective equipment (i.e. Mask, gowns, gloves)\"},{\"label\":\"Surgical and laboratory instruments\",\"value\":\"Surgical and laboratory instruments\"}],\"asyncConfig\":{},\"icon\":[],\"description\":\"\",\"textArea\":false,\"maxRows\":1,\"field_xs\":4,\"field_xl\":4,\"field_md\":4,\"field_lg\":4,\"gridDefault\":true,\"Visibility\":true,\"tenantId\":0,\"order\":2,\"placeholder\":\"Select the Device Category\"}, {\"type\":\"select\",\"field\":\"deviceType\",\"businessField\":true,\"required\":true,\"readonly\":false,\"disabled\":false,\"hide\":false,\"systemDefault\":true,\"originlabel\":\"Device Type\",\"label\":\"Device Type\",\"multiple\":false,\"options\":[{\"label\":\"Measuring Spoon\",\"value\":\"Measuring Spoon\"},{\"label\":\"Cup\",\"value\":\"Cup\"},{\"label\":\"Cannula\",\"value\":\"Cannula\"},{\"label\":\"Spatula\",\"value\":\"Spatula\"},{\"label\":\"Injection Needle\",\"value\":\"Injection Needle\"},{\"label\":\"Injection Syringe\",\"value\":\"Injection Syringe\"},{\"label\":\"Pre-filled syringe\",\"value\":\"Pre-filled syringe\"}],\"asyncConfig\":{},\"icon\":[],\"description\":\"\",\"textArea\":false,\"maxRows\":1,\"field_xs\":4,\"field_xl\":4,\"field_md\":4,\"field_lg\":4,\"gridDefault\":true,\"Visibility\":true,\"tenantId\":0,\"order\":3,\"placeholder\":\"Select the Device Type\"}, {\"field\":\"deviceFamilyName\",\"label\":\"Device Family Name\",\"required\":true,\"readonly\":false,\"disabled\":false,\"order\":4,\"description\":\"\",\"hide\":false,\"icon\":[],\"field_xs\":4,\"field_xl\":4,\"field_md\":4,\"field_lg\":4,\"gridDefault\":true,\"Visibility\":true,\"originlabel\":\"Device Family Name\",\"systemDefault\":true,\"type\":\"select\",\"options\":[{\"label\":\"Patch\",\"value\":\"Patch\"},{\"label\":\"Glass Syringe\",\"value\":\"Glass Syringe\"},{\"label\":\"Needles\",\"value\":\"Needles\"},{\"label\":\"Cartridge\",\"value\":\"Cartridge\"},{\"label\":\"Pre-filled syringe\",\"value\":\"Pre-filled syringe\"},{\"label\":\"Vaporizer\",\"value\":\"Vaporizer\"}],\"multiple\":false,\"asyncConfig\":{},\"placeholder\":\"Select the Device Family Name\"}, {\"field\":\"deviceFamilyCode\",\"label\":\"Device Family Code\",\"required\":true,\"readonly\":false,\"disabled\":false,\"order\":5,\"description\":\"\",\"hide\":false,\"icon\":[],\"field_xs\":8,\"field_xl\":8,\"field_md\":8,\"field_lg\":8,\"originlabel\":\"Device Family Code\",\"systemDefault\":true,\"type\":\"select\",\"options\":[{\"label\":\"DEV001\",\"value\":\"DEV001\"},{\"label\":\"DEV002\",\"value\":\"DEV002\"},{\"label\":\"DEV003\",\"value\":\"DEV003\"},{\"label\":\"DEV004\",\"value\":\"DEV004\"},{\"label\":\"DEV005\",\"value\":\"DEV005\"}],\"multiple\":false,\"asyncConfig\":{},\"placeholder\":\"Select the Device Family Code\"}, {\"field\":\"deviceName\",\"label\":\"Device Name\",\"required\":true,\"readonly\":false,\"disabled\":false,\"order\":6,\"description\":\"\",\"hide\":false,\"icon\":[],\"field_xs\":8,\"field_xl\":8,\"field_md\":8,\"field_lg\":8,\"originlabel\":\"Device Name\",\"systemDefault\":true,\"type\":\"text\",\"maxLen\":\"2000\",\"textArea\":false,\"maxRows\":1,\"asyncConfig\":{},\"placeholder\":\"Input the Device Name\"}, {\"type\":\"select\",\"field\":\"deviceUsage\",\"businessField\":false,\"required\":false,\"readonly\":false,\"disabled\":false,\"hide\":false,\"systemDefault\":true,\"originlabel\":\"Device Usage\",\"label\":\"Device Usage\",\"multiple\":false,\"options\":[{\"label\":\"Single\",\"value\":\"Single\"},{\"label\":\"Multiple\",\"value\":\"Multiple\"}],\"asyncConfig\":{},\"icon\":[],\"description\":\"\",\"textArea\":false,\"maxRows\":1,\"field_xs\":4,\"field_xl\":4,\"field_md\":4,\"field_lg\":4,\"gridDefault\":false,\"Visibility\":false,\"tenantId\":0,\"order\":7,\"placeholder\":\"Select the Device Usage\"}, {\"field\":\"internalBirthDate\",\"label\":\"International Birth Date\",\"required\":false,\"readonly\":false,\"disabled\":false,\"order\":8,\"description\":\"\",\"hide\":false,\"icon\":[],\"field_xs\":4,\"field_xl\":4,\"field_md\":4,\"field_lg\":4,\"originlabel\":\"Internal Birth Date\",\"systemDefault\":true,\"type\":\"date\",\"asyncConfig\":{},\"placeholder\":\"Select the International Birth Date\"}, {\"field\":\"latexInformation\",\"label\":\"Latex Information\",\"required\":false,\"readonly\":false,\"disabled\":false,\"order\":9,\"description\":\"\",\"hide\":false,\"icon\":[],\"field_xs\":8,\"field_xl\":8,\"field_md\":8,\"field_lg\":8,\"originlabel\":\"Latex Information\",\"systemDefault\":true,\"type\":\"text\",\"maxLen\":\"1000\",\"textArea\":false,\"maxRows\":1,\"asyncConfig\":{},\"placeholder\":\"Input the Latex Information\"}, {\"type\":\"select\",\"field\":\"sterilityIndicator\",\"businessField\":false,\"required\":false,\"readonly\":false,\"disabled\":false,\"hide\":false,\"systemDefault\":true,\"originlabel\":\"Sterility Indicator\",\"label\":\"Sterility Indicator\",\"multiple\":false,\"options\":[{\"label\":\"Non-sterile\",\"value\":\"Non-sterile\"},{\"label\":\"Not applicable\",\"value\":\"Not applicable\"},{\"label\":\"The device is supplied as sterile\",\"value\":\"The device is supplied as sterile\"}],\"asyncConfig\":{},\"icon\":[],\"description\":\"\",\"textArea\":false,\"maxRows\":1,\"field_xs\":4,\"field_xl\":4,\"field_md\":4,\"field_lg\":4,\"gridDefault\":false,\"Visibility\":false,\"tenantId\":0,\"order\":10,\"placeholder\":\"Select the Sterility Indicator\"}, {\"type\":\"checkbox\",\"field\":\"isSterilityRequired\",\"businessField\":true,\"required\":false,\"readonly\":false,\"disabled\":false,\"hide\":false,\"systemDefault\":true,\"originlabel\":\"Is Sterility Required\",\"label\":\"Is Sterility Required\",\"multiple\":false,\"options\":[],\"asyncConfig\":{},\"icon\":[],\"description\":\"\",\"textArea\":false,\"maxRows\":1,\"field_xs\":4,\"field_xl\":4,\"field_md\":4,\"field_lg\":4,\"gridDefault\":false,\"Visibility\":false,\"tenantId\":0,\"order\":11,\"placeholder\":\"Select the Is Sterility Required\"}, {\"type\":\"select\",\"field\":\"sterilityMethod\",\"businessField\":false,\"businessRule\":[{\"isSterilityRequired\":[\"true\"]}],\"required\":true,\"readonly\":false,\"disabled\":false,\"hide\":false,\"systemDefault\":true,\"originlabel\":\"Sterility Method\",\"label\":\"Sterility Method\",\"multiple\":false,\"options\":[{\"label\":\"Dry Heat Sterilization\",\"value\":\"Dry Heat Sterilization\"},{\"label\":\"Gamma Sterilization\",\"value\":\"Gamma Sterilization\"},{\"label\":\"Membrane Filtration\",\"value\":\"Membrane Filtration\"},{\"label\":\"Steam Sterilization\",\"value\":\"Steam Sterilization\"},{\"label\":\"Radiation Sterilization\",\"value\":\"Radiation Sterilization\"},{\"label\":\"Vaporized hydrogen peroxide sterilization\",\"value\":\"Vaporized hydrogen peroxide sterilization\"}],\"dependencies\":{\"show\":[{\"when\":\"isSterilityRequired\",\"eq\":true}]},\"asyncConfig\":{},\"icon\":[],\"description\":\"\",\"textArea\":false,\"maxRows\":1,\"field_xs\":4,\"field_xl\":4,\"field_md\":4,\"field_lg\":4,\"gridDefault\":false,\"Visibility\":false,\"tenantId\":0,\"order\":12,\"placeholder\":\"Select the Sterility Method\"}, {\"field\":\"sterilityInformation\",\"label\":\"Sterility Information\",\"required\":true,\"readonly\":false,\"disabled\":false,\"order\":13,\"description\":\"\",\"hide\":false,\"icon\":[],\"field_xs\":8,\"field_xl\":8,\"field_md\":8,\"field_lg\":8,\"originlabel\":\"Sterility Information\",\"systemDefault\":true,\"type\":\"text\",\"maxLen\":\"2000\",\"textArea\":false,\"maxRows\":1,\"multiple\":false,\"dependencies\":{\"show\":[{\"when\":\"isSterilityRequired\",\"eq\":true}]},\"asyncConfig\":{},\"placeholder\":\"Input the Sterility Information\"}, {\"type\":\"text\",\"field\":\"status\",\"businessField\":false,\"combination\":true,\"combinationFields\":[],\"required\":false,\"readonly\":true,\"disabled\":false,\"hide\":false,\"systemDefault\":true,\"originlabel\":\"Status\",\"label\":\"Status\",\"multiple\":false,\"options\":[],\"asyncConfig\":{},\"icon\":[],\"description\":\"\",\"textArea\":false,\"maxRows\":1,\"field_xs\":4,\"field_xl\":4,\"field_md\":4,\"field_lg\":4,\"gridDefault\":true,\"Visibility\":true,\"tenantId\":0,\"order\":14,\"placeholder\":\"Input the Status\"}, {\"field\":\"description\",\"label\":\"Description\",\"required\":false,\"readonly\":false,\"disabled\":false,\"order\":15,\"description\":\"\",\"hide\":false,\"icon\":[],\"field_xs\":12,\"field_xl\":12,\"field_md\":12,\"field_lg\":12,\"originlabel\":\"Description\",\"systemDefault\":true,\"type\":\"text\",\"maxLen\":\"5000\",\"textArea\":true,\"maxRows\":3,\"id\":\"1841344367245975553\",\"asyncConfig\":{},\"placeholder\":\"Input the Description\"}, {\"field\":\"Comments\",\"label\":\"Comments\",\"required\":false,\"readonly\":false,\"disabled\":false,\"order\":16,\"description\":\"\",\"hide\":false,\"icon\":[],\"field_xs\":12,\"field_xl\":12,\"field_md\":12,\"field_lg\":12,\"originlabel\":\"Comments\",\"systemDefault\":true,\"type\":\"text\",\"maxLen\":\"5000\",\"textArea\":true,\"maxRows\":3,\"asyncConfig\":{},\"placeholder\":\"Input the Comments\"}, {\"field\":\"inactive\",\"label\":\"Inactive\",\"required\":false,\"readonly\":false,\"disabled\":false,\"description\":\"\",\"hide\":false,\"icon\":[],\"field_xs\":4,\"field_xl\":4,\"field_md\":4,\"field_lg\":4,\"originlabel\":\"Inactive\",\"systemDefault\":false,\"type\":\"checkbox\",\"order\":17,\"asyncConfig\":{},\"placeholder\":\"Select the Inactive\"}, {\"field\":\"reasonForInactive\",\"label\":\"Reason For Inactive\",\"required\":true,\"readonly\":false,\"disabled\":false,\"description\":\"\",\"hide\":false,\"icon\":[],\"field_xs\":8,\"field_xl\":8,\"field_md\":8,\"field_lg\":8,\"originlabel\":\"Reason For Inactive\",\"systemDefault\":false,\"type\":\"select\",\"multiple\":false,\"asyncConfig\":{},\"options\":[{\"label\":\"Commercial reasons\",\"value\":\"Commercial reasons\"},{\"label\":\"Production discontinued\",\"value\":\"Production discontinued\"}],\"order\":18,\"dependencies\":{\"show\":[{\"when\":\"inactive\",\"eq\":true}]},\"id\":\"1841344367304695810\",\"placeholder\":\"Select the Reason For Inactive\"}]"
    }
    const mockdownloaddata = {
        "data": new ArrayBuffer(10),
        "status": 200,
        "statusText": "",
        "headers": {
            "access-control-allow-credentials": "true",
            "access-control-allow-origin": "http://localhost:3000",
            "access-control-expose-headers": "*,content-disposition,export-status,failed-records,import-status",
            "apigw-requestid": "AaSDrh-eIAMEJkg=",
            "content-disposition": "attachment;filename=Audit%20Entity%20Report_29%2FOct%2F2024.pdf",
            "content-length": "90980",
            "content-type": "application/pdf;charset=UTF-8",
            "date": "Tue, 29 Oct 2024 11:42:15 GMT",
            "export-status": 3,
            "vary": "Origin, Access-Control-Request-Method, Access-Control-Request-Headers"
        },
    }
    const mockBlobUrl = 'mocked-blob-url';
    
    const defaultProps = {
        openAddPopup: true,
        setOpenAddPopup: jest.fn(),
        setIdentifierData: jest.fn(),
        setReportDrawerList: jest.fn(),
        setIsEntityReport: jest.fn(),
        isEntity: false,
        isAuditIdentifierClicked: false,
        recordId: '123',
        identifierData: { formattedValue: 'DEV001', id: "123" },
        handleCancel: mockHandleCancel,
        handleClose: mockHandleClose,
        onPaginationModelChange: jest.fn(),
        pageSize: 10,
        pageNum: 1,
        changePageInfo: mockChangePageInfo,
        Audit_Id: "123",
        productId: "123",
        setOpenDrawer: jest.fn(),
        sectionTreeDataProps: mocksectionTreeDataProps
    };
    beforeEach(() => {
        jest.useFakeTimers();
    });

    afterEach(() => {
        jest.clearAllMocks();
        jest.useRealTimers();
    });
    let beforeeachmethod = true;
    beforeEach(async () => {
        (useTranslation as jest.Mock).mockReturnValue(mockTranslation);
        (useSnackbar as jest.Mock).mockReturnValue(mockSnackbar);
        (fetchOperationListByEntityId as jest.Mock).mockResolvedValue(mockfielddata);
        if(beforeeachmethod)
        (fetchAuditFieldModification as jest.Mock).mockResolvedValue(mockData);
        mockAxios.onPost(`${GET_API}cm/form-manager/forms/settings`).reply(200, {
            data: mockResponse,
        });
        window.URL.createObjectURL = jest.fn().mockReturnValue(mockBlobUrl);
        (service as unknown as jest.Mock).mockResolvedValue(mockdownloaddata);
    });


    it('Handle Identifier', async () => {
        await act(async () => {
            render(
                <AuditReportDrawer {...defaultProps} />
            );
        });
        await waitFor(() => {
            const linkElement = screen.getByRole('link', { name: /AR-10209103/i });

            fireEvent.click(linkElement);
        });
    });
    it('should download file when export-status is 3', async () => {
        await act(async () => {
            render(
                <AuditReportDrawer {...defaultProps} />
            );
        });
        const linkElement = screen.getAllByText('downloadPDF');
        jest.useFakeTimers();
        fireEvent.click(linkElement[0]);
        act(() => {
            jest.runAllTimers();
        });
    });
    it('fetchOperationListByEntityId handles unauthorized error gracefully', async () => {
        (fetchOperationListByEntityId as jest.Mock).mockRejectedValueOnce({
            response: { status: 401, data: { message: 'unauthorized' } },
        });

        (service.post as jest.Mock).mockRejectedValueOnce({
            response: { status: 401, data: { message: 'unauthorized' } },
        });
        await act(async () => {
            render(
                <AuditReportDrawer {...defaultProps} />
            );
        });
    });
    it('fetchOperationListByEntityId handles enqueueSnackbar error gracefully', async () => {
        (fetchOperationListByEntityId as jest.Mock).mockRejectedValueOnce({
            response: { status: 4010, data: { message: 'unauthorizedtest' } },
        });

        (service.post as jest.Mock).mockRejectedValueOnce({
            response: { status: 4010, data: { message: 'unauthorizedtest' } },
        });
        await act(async () => {
            render(
                <AuditReportDrawer {...defaultProps} />
            );
        });
    });
    it('should call handleClose when the close button is clicked', async () => {
        await act(async () => {
            render(
                <AuditReportDrawer {...defaultProps} />
            );
        });
        const buttonElement = await screen.findAllByTestId("CloseIcon");
        fireEvent.click(buttonElement[0]);

    });
    it('fetchAuditFieldModification handles unauthorized error gracefully', async () => {
        beforeeachmethod = false;
        (fetchAuditFieldModification as jest.Mock).mockRejectedValueOnce({
            response: { status: 401, data: { message: 'unauthorized' } },
        });

        (service.get as jest.Mock).mockRejectedValueOnce({
            response: { status: 401, data: { message: 'unauthorized' } },
        });
        await act(async () => {
            render(
                <AuditReportDrawer {...defaultProps} />
            );
        });
    });
    it('fetchAuditFieldModification handles enqueueSnackbar error gracefully', async () => {
        beforeeachmethod = false;
        (fetchAuditFieldModification as jest.Mock).mockRejectedValueOnce({
            response: { status: 4010, data: { message: 'unauthorizedtest' } },
        });

        (service.get as jest.Mock).mockRejectedValueOnce({
            response: { status: 4010, data: { message: 'unauthorizedtest' } },
        });
        await act(async () => {
            render(
                <AuditReportDrawer {...defaultProps} />
            );
        });
    });
});