import React from "react";
import { render, screen } from "@testing-library/react";
import '@testing-library/jest-dom/extend-expect';
import NoDataAvailable from "../Components/Applications/components/NoDataAvailable"; 

jest.mock('react-i18next', () => ({
  useTranslation: () => ({
    t: (key: string) => key === 'common.noDataAvailable' ? 'No data available' : key,
  }),
}));

describe('NoDataAvailable Component', () => {
  test('renders without crashing', () => {
    render(<NoDataAvailable />);
    const boxElement = screen.getByTestId('boxb');
    expect(boxElement).toBeInTheDocument();
  });

  test('displays custom text when text prop is provided', () => {
    const customText = "Custom no data message";
    render(<NoDataAvailable text={customText} />);
    expect(screen.getByText(customText)).toBeInTheDocument();
  });

  test('renders the image correctly', () => {
    render(<NoDataAvailable />);
    const imgElement = screen.getByRole('img');
    expect(imgElement).toBeInTheDocument();
    expect(imgElement).toHaveAttribute('src', 'no-data-anim2.webp'); // Adjust the src based on your file path
  });

  test('applies the correct styles to the outer Box', () => {
    render(<NoDataAvailable />);
    const outerBox = screen.getByTestId('boxb');
    expect(outerBox).toHaveStyle('height: 100%');
    expect(outerBox).toHaveStyle('width: 100%');
    expect(outerBox).toHaveStyle('display: flex');
    expect(outerBox).toHaveStyle('align-items: center');
    expect(outerBox).toHaveStyle('justify-content: center');
    expect(outerBox).toHaveStyle('max-width: 100%');
    expect(outerBox).toHaveStyle('max-height: 100%');
    expect(outerBox).toHaveStyle('overflow: hidden');
    expect(outerBox).toHaveStyle('box-sizing: border-box');
  });
});
