import { render, screen, fireEvent, within, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import DisableDialog from '../Components/Applications/DisableDialog';
import { I18nextProvider } from 'react-i18next';
import i18n from "i18next";

// Mock the fetchReasons function
jest.mock('../apis/apiFunctions', () => ({
  fetchReasons: jest.fn().mockResolvedValue([
    { id: '1', name: 'Reason 1' },
    { id: '2', name: 'Reason 2' }
  ])
}));

// Setup i18n
i18n.init({
  lng: 'en',
  resources: {
    en: {
      translation: {
        reasonForDisable: 'Reason for Disable',
        disable: 'Disable',
        app: 'App',
        comment: 'Comment',
        Yes: 'Yes',
        No: 'No',
        disableProductTitle: 'Are you sure you want to disable this product?'
      }
    }
  },
  fallbackLng: 'en',
  interpolation: { escapeValue: false }
});

describe('DisableDialog', () => {
  const defaultProps = {
    open: true,
    onClose: jest.fn(),
    onDisable: jest.fn(),
    selectedId: 1
  };

  const renderDialog = (props = {}) => {
    return render(
      <I18nextProvider i18n={i18n}>
        <DisableDialog {...defaultProps} {...props} />
      </I18nextProvider>
    );
  };

  beforeEach(() => {
    jest.clearAllMocks();
  });

  test('renders dialog with all elements', async () => {
    renderDialog();
    
    expect(screen.getByText('Disable App')).toBeInTheDocument();
    expect(screen.getByLabelText(/reason for disable/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/comment/i)).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /yes/i })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /no/i })).toBeInTheDocument();
  });
  
  

  test('calls onClose and resets form when No is clicked', () => {
    renderDialog();

    const noButton = screen.getByRole('button', { name: /no/i });
    fireEvent.click(noButton);

    expect(defaultProps.onClose).toHaveBeenCalled();
  });

  test('prevents closing dialog on backdrop click', () => {
    renderDialog();
    
    const dialog = screen.getByRole('dialog');
    fireEvent.click(dialog.parentElement!); // Click backdrop
    
    expect(defaultProps.onClose).not.toHaveBeenCalled();
  });

  test('handles comment character limit', async () => {
    renderDialog();
  
    const commentInput = screen.getByLabelText(/comment/i);
    const longComment = 'a'.repeat(2000);
    
    fireEvent.change(commentInput, { target: { value: longComment } });
    
    // Get the actual value from the input
    const actualValue = (commentInput as HTMLTextAreaElement).value;
    
    // Verify the length is not more than 2000
    expect(actualValue.length).toBeLessThanOrEqual(2000);
    
    // Verify that the displayed value matches our expectation
    expect(screen.getByText(`${actualValue.length} / 2000`)).toBeInTheDocument();
  });
 
  
 
});