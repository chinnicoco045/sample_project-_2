// src/config/gridHeaders.ts
import { useTranslation } from "react-i18next";
import { GET_API } from "../Services/apiheader";
import axios from "axios";
import { accessToken } from "../types";


export const getGridFields = async (setIsLoading: (loading: boolean) => void, params: any) => {
    try {
        const response = await axios.get(`${GET_API}cm/form-manager/grids/fields`, {
            params: params,
            headers: {
                Authorization: `Bearer ${accessToken}`,
                'Accept-Language': ''
            }
        });
        setIsLoading(false);
        return response.data.data;
    } catch (error) {
        setIsLoading(false);
        throw error;
    }
};

