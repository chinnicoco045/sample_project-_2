import {
  Button,
  FormControl,
  FormHelperText,
  Grid,
  InputLabel,
  MenuItem,
  Select,
  Stack,
  TextField,
  Tooltip
} from "@mui/material";
import axios from "axios";
import { useEffect, useRef, useState } from "react";
import { useTranslation } from "react-i18next";
import { useLocation } from "react-router-dom";
import service, { GET_API } from "../../Services/apiheader";
import { accessToken } from "../../types";
import { fetchCountryOptions, fetchRepeatUserwaves } from "../../apis/apiFunctions";
import Cookies from "js-cookie";
import { enqueueSnackbar, useSnackbar } from "notistack";
import _ from "lodash";

interface AddMSProps {
  infoData: any;
  applicationDetails: any;
  msName:any;
  setApplicationsDetails: React.Dispatch<React.SetStateAction<any>>;
  handleCancelEdit: () => void;
  setMsName:React.Dispatch<React.SetStateAction<any>>;
  id:any;
  setTrigger: (value: boolean) => void;
}

function EditMS({ infoData, applicationDetails,msName,setApplicationsDetails,handleCancelEdit,setMsName ,id,setTrigger}: AddMSProps) {
  const { t } = useTranslation();
  const [selectedValue, setSelectedValue] = useState<string | null>(null);
  const [countryOptions, setCountryOptions] = useState<any[]>([]);
  const [waveOptions, setWaveOptions] = useState<any[]>([]);
  const [invalidFields, setInvalidFields] = useState<string[]>([]);
  const [red, setRed] = useState<boolean>(false);
  console.log(applicationDetails);
  const leadCountry=applicationDetails?.applicationdata?.countryNames;
  const {enqueueSnackbar}=useSnackbar();
  let cell = JSON.parse(sessionStorage.getItem('CellData') || '{}');
  const memberStates=JSON.parse(sessionStorage.getItem("memberStates")||'[]');
  const beforeDetailsRef = useRef<any>(null); 
  console.log("beforeDetailsRef",beforeDetailsRef)


  useEffect(() => {

    const fetchOptions = async (fieldName: string) => {

      if (fieldName === "memberState") {
        const region=applicationDetails.applicationdata.region;
        const options = await fetchCountryOptions(region); // Pass necessary params like region
        const filteredOptions = options?.filter((option: any) => 
          option.value !== leadCountry &&
          (!memberStates.includes(option.label) ||
           option.label === msName.memberState)
        );
        setCountryOptions(filteredOptions);
      } else if (fieldName === "waveName") {
        const options = await fetchRepeatUserwaves();
        setWaveOptions(options?.map((option: any) => ({
          label: option.name,
          value: option.code
        })));
      }
    };

    // Trigger the API calls based on the field names in infoData
    infoData.forEach((component: any) => {
      if (component.field === "memberState" || component.field === "waveName") {
        fetchOptions(component.field);
      }
    });
  }, [infoData]);


  const handleEditMemberState = (oldValue: any, newValueObject: any) => {
    if (!applicationDetails || !applicationDetails.applicationdata) return;

    console.log(oldValue," ",newValueObject);
    // Step 1: Get the corresponding code for oldValue from msCountryCode
    const oldCountryCode = applicationDetails.applicationdata.msCountryCode.find(
        (code: string, idx: number) => applicationDetails.applicationdata.memberStates[idx] === oldValue
    );

    // Step 2: Update memberStates and msCountryCode
    const updatedMemberStates = applicationDetails.applicationdata.memberStates.map(
        (memberState: string, index: number) => {
            if (memberState === oldValue) {
                // Update msCountryCode at the same index
                applicationDetails.applicationdata.msCountryCode[index] = newValueObject.value;
                return newValueObject.label;  // Return updated country name for memberStates
            }
            return memberState;
        }
    );

    const existingMemberStates = JSON.parse(sessionStorage.getItem("memberStates") || "[]");

    // Step 4: Replace the oldValue in sessionStorage with newValueObject.label
    const updatedMemberStatesInSessionStorage = existingMemberStates.map(
        (state: string) => (state === oldValue ? newValueObject.label : state)
    );

    // Step 5: Update sessionStorage with the new memberStates
    sessionStorage.setItem("memberStates", JSON.stringify(updatedMemberStatesInSessionStorage));

    // Step 3: Update waveInfo where countryCode matches old code
    const updatedWaveInfo = applicationDetails.applicationdata.waveInfo.map((wave: any) => {
        if (wave.countryCode === oldCountryCode) {
            return {
                ...wave,
                countryCode: newValueObject.value,
                countryName:newValueObject.label // Update to new country code
            };
        }
        return wave;
    });

    // Step 4: Update applicationDetails with new values
    const updatedApplicationDetails = {
        ...applicationDetails,
        applicationdata: {
            ...applicationDetails.applicationdata,
            memberStates: applicationDetails.applicationdata.msCountryCode,
            msCountryCode: applicationDetails.applicationdata.msCountryCode,
            waveInfo: updatedWaveInfo
        }
    };

    // Log to confirm updates

    // Apply updates
    return updatedApplicationDetails;
};

const handleEditWaveForm = (oldValue: any, newValueObject: any) => {
  if (!applicationDetails || !applicationDetails.applicationdata) return applicationDetails;

  const countryName = msName.memberState;
  const countryIndex = memberStates.indexOf(countryName);

  if (countryIndex === -1) {
    console.warn("Country not found in memberStates array.");
    return applicationDetails;
  }

  // Step 2: Retrieve `countryCode` for the identified index
  const countryCode = applicationDetails.applicationdata.msCountryCode[countryIndex];

  // Step 3: Ensure `waveInfo` is not null or undefined
  const waveInfo = applicationDetails.applicationdata.waveInfo || [];

  // Step 4: Check if an entry already exists
  const existingWaveIndex = waveInfo.findIndex((wave: any) => wave.countryCode === countryCode);

  let updatedWaveInfo;
  
  if (existingWaveIndex !== -1) {
    // Update existing wave entry
    updatedWaveInfo = waveInfo.map((wave: any, index: number) => 
      index === existingWaveIndex 
        ? { ...wave, waveName: newValueObject.label, waveCode: newValueObject.value } 
        : wave
    );
  } else {
    // Add new entry only if it doesn't exist
    updatedWaveInfo = [
      ...waveInfo,
      { countryCode, waveName: newValueObject.label, waveCode: newValueObject.value, comments: "" }
    ];
  }
  // ** Ensure no accidental strings in the array **
  updatedWaveInfo = updatedWaveInfo.filter((entry:any) => typeof entry === "object");
  // Step 5: Create a new `applicationDetails` object with updated `waveInfo`
  const updatedApplicationDetails = {
    ...applicationDetails,
    applicationdata: {
      ...applicationDetails.applicationdata,
      memberStates: applicationDetails.applicationdata.msCountryCode,
      waveInfo: updatedWaveInfo
    }
  };

  cell.applicationData = updatedApplicationDetails.applicationdata;
  sessionStorage.setItem("CellData", JSON.stringify(cell));
  return updatedApplicationDetails;
};

const handleEditWaveComments = (oldValue: any, commentsValue: any) => {
  console.log(commentsValue);
  if (!applicationDetails || !applicationDetails.applicationdata) return applicationDetails;

  // Step 1: Find the index of the country name in `memberStates`
  const countryIndex = memberStates.indexOf(msName.memberState);

  if (countryIndex === -1) {
    console.warn("Country not found in memberStates array.");
    return applicationDetails;
  }

  // Step 2: Retrieve `countryCode` for the identified index
  const countryCode = applicationDetails.applicationdata.msCountryCode[countryIndex];

  // Step 3: Ensure `waveInfo` is always an array
  let waveInfo = applicationDetails.applicationdata.waveInfo || [];

  // Step 4: Find the existing wave entry by `countryCode`
  let existingWaveIndex = waveInfo.findIndex((wave: any) => wave.countryCode === countryCode);

  let updatedWaveInfo = [...waveInfo];

  if (existingWaveIndex !== -1) {
    // Update existing wave entry with new comments with keeping same wave details
    updatedWaveInfo[existingWaveIndex] = {
      ...updatedWaveInfo[existingWaveIndex],
      comments: commentsValue
    };
  } else {
    updatedWaveInfo.push({
      countryCode,
      waveName: "",  // Ensure empty, avoid adding string "waveName"
      waveCode: "", 
      comments: commentsValue
    });
  }

  // ** Ensure no accidental strings in the array **
  updatedWaveInfo = updatedWaveInfo.filter((entry) => typeof entry === "object");

  // Step 5: Create a new `applicationDetails` object with updated `waveInfo`
  const updatedApplicationDetails = {
    ...applicationDetails,
    applicationdata: {
      ...applicationDetails.applicationdata,
      memberStates: applicationDetails.applicationdata.msCountryCode,
      waveInfo: updatedWaveInfo
    }
  };

  cell.applicationData = updatedApplicationDetails.applicationdata;
  sessionStorage.setItem("CellData", JSON.stringify(cell));
  console.log(updatedApplicationDetails);
  return updatedApplicationDetails;
};

  
  
  
  const handleFieldChange = (currentValue:any,key: string, value: any) => {

    setMsName((prev:any) => ({
      ...prev,
      [key]: value.label
    }))
    let updatedApplicationDetails:any;
    if(key==='memberState'){
      updatedApplicationDetails= handleEditMemberState(currentValue,value);
    }
    else if(key==='waveName'){
      updatedApplicationDetails= handleEditWaveForm(currentValue,value);
    }
    else if(key==='comments'){
      updatedApplicationDetails= handleEditWaveComments(currentValue,value);
    }
    
    setApplicationsDetails(updatedApplicationDetails);
  };

  const isSaving = useRef(false); // Track if saving is in progress
  const [isFormModified, setIsFormModified] = useState(false);

  const removeUndefined = (obj: Record<string, any>) => {
    return Object.fromEntries(
      Object.entries(obj || {}).filter(
        ([_, value]) => value !== undefined && value !== "" && !(Array.isArray(value) && value.length === 0)
      )
    );
  };

  useEffect(() => {
    // if (applicationDetails) {
      // ✅ Always update `beforeDetailsRef` when creating a new record
      if (!beforeDetailsRef.current || Object.keys(beforeDetailsRef.current).length === 0) {
        console.log("Setting beforeDetailsRef for new record...");
        // beforeDetailsRef.current = structuredClone(applicationDetails);
        beforeDetailsRef.current = JSON.parse(JSON.stringify(applicationDetails));
      }
    // }
  }, []); 

  

  const handleSave=async()=>{
    if (isSaving.current) return; // Prevent duplicate execution
    isSaving.current = true;

    const cleanedDataRecord = removeUndefined(beforeDetailsRef.current.applicationdata.waveInfo);
    const cleanedRecordDetails = removeUndefined(applicationDetails.applicationdata.waveInfo);

    console.log("Cleaned Data Record:", cleanedDataRecord);
    console.log("Cleaned Initial Record:", cleanedRecordDetails);

    const isModified = !_.isEqual(cleanedDataRecord, cleanedRecordDetails);

    if (!isModified) {
      setIsFormModified(true)
      isSaving.current = false; // Reset flag
      return;
    }
    setIsFormModified(false)

    if (!msName.waveName) {
      setInvalidFields(applicationDetails.applicationdata.waveInfo);
      setRed(true);
      enqueueSnackbar("Fill all the required fields", { variant: "error", anchorOrigin: { vertical: 'top', horizontal: 'center' } });
      setApplicationsDetails(applicationDetails);
      isSaving.current = false; // Reset flag
      return;
    }   
   
    cell.applicationData = applicationDetails.applicationdata;
    sessionStorage.setItem("CellData", JSON.stringify(cell));
  
    applicationDetails.updated_by = Cookies.get('USER_EMAIL');
    console.log(applicationDetails);

    const response = await service.put(`application/v1/modification/${id}`, applicationDetails, {
      headers: {
        "X-TenantID": Cookies.get('USER_TENANT_ID')
      }
    });
    console.log(response);
    // beforeDetailsRef.current = JSON.parse(JSON.stringify(applicationDetails)); // ✅ Update only when saving
    enqueueSnackbar(t('EditMSSuccessTip'), { variant: "success", anchorOrigin: { vertical: 'top', horizontal: 'center' } });
    setTrigger(true);
    handleCancelEdit();
    isSaving.current = false; // Ensure flag resets even if an error occurs
  }

  const handleCancel=()=>{
    handleCancelEdit();
  }

  const renderFormComponents = (allcomponents: any[]) => {
    const components = allcomponents.sort((a, b) => a.order - b.order);
    return components.map((component, index) => {
      let currentValue: any;

      const required = component.required;
      if (component.hide) return null;
  
      
      if (component.field === "memberState") {
        currentValue = msName.memberState;
      } else if (component.field === "waveName") {
        currentValue = msName.waveName;
      } else if(component.field==='groupid'){
        currentValue=msName.groupid;
      }
      else if(component.field ==='comments'){
          currentValue=msName.comments;
      }
      else {
        currentValue = applicationDetails.applicationdata[component.field];
      }
      let error=false;
      if (required && !component.readonly && (currentValue===undefined || currentValue==="" || (Array.isArray(currentValue) && currentValue.length === 0))) {
        invalidFields.push(component.field);
          error = red ? true : false;
      }
      let options =
            component.field === "memberState" ? countryOptions : waveOptions;

      switch (component.type) {
        case "select":

          
  
          return (
            <Grid item xs={component.field_xs} key={index}>
              <FormControl fullWidth required={required} disabled={component.disabled}>
                <InputLabel id="demo-simple-select-label">
                  <Tooltip title={t(component.field)}>
                    <span style={{ color: "black" }}>{t(component.field)}</span>
                  </Tooltip>
                </InputLabel>
                <Select
                  error = {error}
                  labelId="demo-simple-select-label"
                  value={currentValue}
                  onChange={(event) => handleFieldChange(currentValue,component.field, event.target.value)}
                >
                   {currentValue && options.some(option => option.label === currentValue) && (
                    <MenuItem value={currentValue}>{currentValue}</MenuItem> // Display currentValue if not in options
                  )}
                  {options.filter((option: any) => option.label !== currentValue).map((option: any, idx: number) => (
                    <MenuItem key={idx} value={option}>{option.label}</MenuItem>
                  ))}
                </Select>
                {error && <FormHelperText>{t("fieldRequired", { field: t(component.field) })}</FormHelperText>}
              </FormControl>
            </Grid>
          );

          case "text":
            return (
              <Grid item xs={component.field_xs} key={index}>
                <FormControl fullWidth disabled={component.readonly}>
                <InputLabel id="demo-simple-select-label">
                  <Tooltip title={t(component.label)} ><span style={{ color: "black" }}>{t(component.field)}</span></Tooltip>
                  {required && <span> * </span>}
                  
                </InputLabel>
                  <TextField
                    disabled = {component.readonly}
                    multiline = {component.textArea}
                    
                    rows={component.maxRows}
                    size="small"
                    placeholder={t(component.placeholder)}
                    inputProps={{ maxLength: component.maxLen || undefined }}
                    value={currentValue}
                    onChange={(event) => handleFieldChange(currentValue,component.field, event.target.value)}
                  />
                  {error && <FormHelperText>{t("fieldRequired", { field: t(component.field) })}</FormHelperText>}
                </FormControl>
              </Grid>
            );        
      }
    });
  };
  

  return (<>
  <h4 className="mt-4 list-header-title">{t('edit')+" "+t('memberstate')}</h4>
  <div>{renderFormComponents(infoData)}</div>
  <Grid item xs={12} className="page-form-buttons mb-0 ">
  {(isFormModified) && <div style={{ fontSize: '12px', color: 'grey', position: 'relative', bottom: '-3px', right: '10px', width: '100%', textAlign: 'right', }}>{t("noDataUpdatedMessage")}</div>}
              <Grid item className='float-right m-t-8 mb-0 '>
                <Stack spacing={2} direction="row">

                  <Button variant="text" size="small" onClick={handleCancel} >{t("cancel")}</Button>

                  <Button
                    variant="contained"
                    size="small"
                    onClick={()=>handleSave()}
                    
                  >
                    {t("save")}
                  </Button>
                </Stack>
              </Grid>
            </Grid>
  </>);
}

export default EditMS;
