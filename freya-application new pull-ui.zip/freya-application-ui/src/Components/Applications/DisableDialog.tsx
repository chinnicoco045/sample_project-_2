// src/components/DisableDialog.tsx

import React, { useState, useEffect } from "react";
import {
  Autocomplete,
  Box,
  Button,
  Chip,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Grid,
  IconButton,
  TextField,
} from "@mui/material";
import GridCloseIcon from "@mui/icons-material/Close";
import axios from "axios";
import { useTranslation } from "react-i18next";
import { accessToken } from "../../types";
import { GET_API } from "../../Services/apiheader";
import disabledsvg from '../../assets/icon-disable.svg';
import { fetchReasons } from "../../apis/apiFunctions";


interface DisableDialogProps {
  open: boolean;
  onClose: () => void;
  onDisable: (reason: any, comments: string) => void;
  selectedId: number;
}

const DisableDialog: React.FC<DisableDialogProps> = ({
  open,
  onClose,
  onDisable,
  selectedId,
}) => {
  const { t } = useTranslation();
  const [reason, setReason] = useState({ id: "" });
  const [reasonList, setReasonList] = useState([]);
  const [comments, setComments] = useState("");

  useEffect(() => {
    const getReasons = async () => {
      const reasons = await fetchReasons();
      setReasonList(reasons);
    };

    if (open) {
      getReasons();
    }
  }, [open]);

  const handleDisable = () => {
  onDisable(reason, comments);  
  setComments('');
  setReason({ id: '' });
  };

  const onClickNo=()=>{
    setReason({id:''});
    setComments('');
    onClose();
  }

  return (
    <Dialog
      className="popup-dialog"
      open={open}
      onClose={(event, reason) => {
        if (reason !== 'backdropClick') {
          onClose();
        }
      }}
      disableEscapeKeyDown

    //   fullWidth
      maxWidth="md"
      sx={{
        '.MuiDialog-paper': { width: '600px' }
      }}
    >
      <DialogTitle>
        {t('disable')+" "+t('app')}
      </DialogTitle>
      <Box component="form" sx={{ display: 'flex', flexDirection: 'column' }}>
      <DialogContent className="form-group popup-content"  >
        
        <Grid>
              <img src={disabledsvg} style={{ width: '200px', marginLeft: 'calc(50% - 100px)', marginBottom: '10px' }}></img>
              {/* <h3 className='alert-notify-text text-center'>Are you sure you want to make the record <b className='alert-text'>disabled</b>?</h3> */}
              <h5 className='alert-notify-text mb-24 text-center'>{t('disableProductTitle')}</h5>
              <Grid>
          <Autocomplete
            sx={{
              "& .MuiOutlinedInput-root": { padding: 0, "flex-wrap": "nowrap" },
              "& .MuiTextField-root": {
                marginLeft: 0,
                marginTop: 0,
                marginBottom: 0,
              },
              "& .MuiOutlinedInput-root .MuiAutocomplete-input": { border: "none" },
              "& .MuiFormControl-root .MuiInputBase-root input:focus": {
                outline: "none !important",
              },
              "& .MuiAutocomplete-inputRoot": { paddingLeft: "10px" },
              flex: 1,
            }}
            className="custom-autocomplete"
            renderTags={(selectedOptions: any) => {
              return <Chip label={selectedOptions.length + " selected"} />;
            }}
            value={reason}
            options={reasonList}
            data-testid="autoCompleteBox"
            getOptionLabel={(option: any) => option.name || ""}
            renderInput={(params: any) => (
              <TextField
                {...params}
                required
                label={t("reasonForDisable")}
                inputProps={{
                  ...params.inputProps,
                  onKeyDown: (e) => {
                    if (e.keyCode === 13) {
                      e.preventDefault();
                    }
                  },
                }}
              />
            )}
            onChange={(event: any, value: any) => {
              setReason(value);
            }}
          />
        </Grid>
        <Grid
          item
       
          sx={{ position: "relative", marginTop:"24px",marginBottom: "20px"}}
        >
          <TextField
            size="small"
            label={t("comment")}
            inputProps={{ maxLength: 2000 }}
            multiline
            rows={4}
            value={comments}
            onChange={(event) => setComments(event.target.value)}

          />
          <span className="rtq-number-tips comment-count-right">
            {comments ? comments.length : 0} / 2000
          </span>
        </Grid>
            </Grid>
       
        
       
      </DialogContent>
      <DialogActions>
        <Button variant="text" size="small" data-testid="noButton" onClick={onClickNo}>
          {t('No')}
        </Button>
        <Button
          variant="contained"
          size="small"
          onClick={handleDisable}
          disabled={!(reason && reason.id)}
          data-testid="yesButton"
        >
          {t('Yes')}
        </Button>
      </DialogActions>
      </Box>
    </Dialog>
   
  );
};

export default DisableDialog;
