import React, { useContext, useEffect, useState } from "react";
import { styled } from '@mui/material/styles';
import { useTranslation } from "react-i18next";
import {
  Stack,
  Breadcrumbs,
  Typography,
  Grid,
  FormControl,
  Button,
  Box,
  Checkbox
} from "@mui/material";
import Tooltip, { TooltipProps, tooltipClasses } from '@mui/material/Tooltip';
import dayjs from 'dayjs';
import { useLocation } from "react-router-dom";
import SideNavigation from "./SideNavigation";
import NavigateNextIcon from "@mui/icons-material/NavigateNext";
import { useNavigate } from "react-router-dom";

import Links from "@mui/material/Link";

import service from "../../Services/apiheader";
import { RowContext } from "../../App";
import { fetchEditFormJson, fetchReasons,applyBusinessRules } from "../../apis/apiFunctions";
import Cookies from "js-cookie";
import { useUrfReceiveEvents } from "../../hooks/urfEvents";

interface SectionTree {
  [key: string]: string[] | { [key: string]: string[] };
}

const ViewApplication: React.FC = () => {
  const { t } = useTranslation();
  const { regionOptions,showDisabled,isEditPrivilege } = useContext(RowContext);
  const location = useLocation();
  //const { id, cellData } = location.state || {};
  const id = sessionStorage.getItem("id");
  const cell = JSON.parse(sessionStorage.getItem('CellData') || '{}');
  const [viewRecord, setViewRecord] = useState<any>({});
  const [fieldsdata, setFieldsdata] = useState<any>([]);
  const [reasonToDisable, setReasonToDisable] = useState<string | null>(null);
  const [disablerecord, setDisablerecord] = useState(false);
  let json = [{}];
  useUrfReceiveEvents();
  const linkTo = useNavigate();

  const fetchData = async () => {
    const response = await service.get(`application/v1/display/refresh-products/${id}`,{
      headers:{
        "X-TenantID":Cookies.get('USER_TENANT_ID')
      }
    });
    const groupId=response.data.data.groupid;
    console.log("View Response",groupId);
    let r = response.data.data.applicationdata;
    r.status === "Disable"?setDisablerecord(true):setDisablerecord(false);
    setViewRecord(r);
    setViewRecord({
        ...r,
        groupid: groupId, 
      });
    const sectionTree = r.sectionTree;

    function getAllIds(tree: SectionTree): string[] {
      const allIds: string[] = [];

      // Iterate over each key in sectionTree
      Object.keys(tree).forEach((key) => {
        const value = tree[key];

        // Check if the value is an array of IDs
        if (Array.isArray(value)) {
          allIds.push(...value); // Add all IDs to allIds array
        } else if (typeof value === "object") {
          // Recursively call getAllIds if the value is another object
          allIds.push(...getAllIds(value as SectionTree));
        }
      });

      return allIds;
    }
    const allIds = getAllIds(sectionTree);
    sessionStorage.setItem("allIds", JSON.stringify(allIds));

    json = JSON.parse(await fetchEditFormJson(viewRecord.region,t));
    
    setFieldsdata(json)
  };


  useEffect(() => {
    fetchData(); // Fetch data when component mounts
  }, [id]);

  const getNameForReason=async(id:any)=>{
    const reasons=await fetchReasons();
    reasons.map((reason:any)=>
      reason.id===id? setReasonToDisable(reason.name):""
    )
  }


  const handleCancel = () => {};

  const handleEdit = () => {
    linkTo("/editApplication");
  };

  const NoMaxWidthTooltip = styled(({ className, ...props }: TooltipProps) => (
    <Tooltip {...props} classes={{ popper: className }} />
  ))({
    [`& .${tooltipClasses.tooltip}`]: {
      maxWidth: 'none',
    },
  });

  const renderLabels = (rawcomponents: any[]) => {
    const components = rawcomponents
  .filter(
    (component) =>
      !['lmsName', 'rmsName', 'cmsName', 'mscName'].includes(component.field)
  )
  .sort((a, b) => a.order - b.order);
 
    const additionalFields = disablerecord
    ? [
        {
          field: "reasonToDisable",
          label: "Reason for Disable",
          field_xs: 12, // Adjust grid size as needed
        },
        {
          field: "commentsOnDisable",
          label: "Disable Comments",
          field_xs: 12, // Adjust grid size as needed
        },
      ]
    : [];

    let allComponents = [...components, ...additionalFields];
    // return Object.entries(viewRecord).map(([key, value]) => {
      // if (viewRecord.productPhase === 'ProductPhase_PDPS00001'){
      //   if( viewRecord.producerType && 
      //   !['ProcedureType_PCT00004', 'ProcedureType_PCT00003', 'ProcedureType_PCT00005'].includes(viewRecord.producerType)) {
      //     allComponents = allComponents.filter(component => component.field !== 'subjectToArbitration' || (component.type === "checkbox" && component.field === "inactiveFlg"));
      //   }}
      // else
      // {
      //   allComponents = allComponents.filter(component => component.field !== 'subjectToArbitration' || (component.type === "checkbox" && component.field === "inactiveFlg"));
      // }
      // allComponents = allComponents.filter(component => 
      //   !(viewRecord.inactiveFlg !== true && component.field === "reasonForInactive"))

      //   allComponents = allComponents.filter(component => 
      //     !(
      //       component.field === "eCTDReceptionNumber" &&
      //       !(
      //         (viewRecord.formatType === 'Formattype_FORY000009' || 
      //          viewRecord.formatType === 'Formattype_FORY000008') &&
      //         viewRecord.country === 'Country_COCO0111'
      //       )
      //     )
      //   );
        

      return allComponents.map((component, index) => {
       // if(component.label === "Application Name")
        if(!applyBusinessRules(component,viewRecord)){
          return null;
        }
        if(component.field === "regulatoryAuthority" && viewRecord.productPhase !== "ProductPhase_PDPS00002"){
          return null;
       }

      const key = component.field;
      let value = cell.applicationData[component.field];
      const type = component.type;
 
      if (key === "reasonToDisable") {
        getNameForReason(value);
        value = reasonToDisable;
      }

      let displayValue: any = "-"; // Default value to display

        if (typeof value === "string") {
            displayValue = value.trim() !== "" ? value : "-";
            if (component.type === "date"){
              displayValue = dayjs(value).format('DD/MMM/YYYY');
            }
        } else if (typeof value === "number") {
            displayValue = value.toString();
        } else if (Array.isArray(value)) {
            displayValue = value.length > 0 ? value.join(", ") : "-";
        }
        if(viewRecord.inactiveFlg === true && component.field === "inactiveFlg"){
          value = 'Yes';
        }

        switch (type) {
          case 'checkbox':
              return (
                  <Grid item xs={component.field_xs} key={key}>
                    <FormControl fullWidth disabled>
                      <div className='form-group'>
                      <Tooltip title={t(component.field)} placement="top">
                        <label className="form-label">
                        {t(component.field, { defaultValue: component.label })}
                        </label>
                        </Tooltip>
                        <span className="form-content">
                        <Checkbox
                          checked={value==='Yes'}
                          disabled
                        />
                        </span>
                      </div>
                    </FormControl>
                  </Grid>
              );
          default:
            return (
              <Grid item xs={component.field_xs} key={key}>
                <FormControl fullWidth disabled>
                  <div className="form-group">
                  <Tooltip title={t(component.field)} placement="top">
                    <label className="form-label">
                    {t(component.field, { defaultValue: component.label })}{/* Assuming you want to translate the key */}
                    </label>
                    </Tooltip>
                    <span className="form-content">
                    {displayValue === '-' ? (
                      displayValue
                    ) : (
                    <NoMaxWidthTooltip title={displayValue} placement="top">
                    {displayValue}
                    </NoMaxWidthTooltip>
                    )}
                    </span>
                  </div>
                </FormControl>
              </Grid>
            );
        }
    });
  };

  return (
    <>
      {/* Breadcrumb */}
      <div className="application-inner-page">
        <Box className="custom-bread-crumb">
          <Stack>
            <Breadcrumbs
              aria-label="breadcrumb"
              separator={<NavigateNextIcon />}
            >
              <Links href="/applicationdetails">{t("application")}</Links>

              <Typography>{t("view_application")}</Typography>
            </Breadcrumbs>
          </Stack>
        </Box>
      </div>
      {/*End Breadcrumb */}

      <div className="application_addform ">
        <Box className="display-flex">
          <Grid container className="form-group innerpage-container-content ">
            <Stack
              direction={{ xs: "column", sm: "row" }}
              alignItems={""}
              className="mb-16 ml-8 page-title"
            >
              <Typography variant="h6" className="">
                {" "}
                {t("view_application")}{" "}
              </Typography>
              {/* {(`rtq.tab.${pageTitle}`)} as per rtq */}
            </Stack>
            {renderLabels(fieldsdata)}
            <Grid item xs={12} className="page-form-buttons">
              <Grid item className="float-right mt-24">
                <Stack spacing={2} direction="row">
                  {/* <div style={{textAlign:'right',marginRight:'40px',marginTop:'100px'}}> */}
                 {!disablerecord && (<>
                 {/* <Button
                    variant="text"
                    size="small"
                    href="/"
                    onClick={handleCancel}
                  >
                    {t("cancel")}
                  </Button> */}
                  {isEditPrivilege && <Button variant="contained" size="small" onClick={handleEdit}>
                    {t('edit')}
                  </Button>}
                  </>)}
                  {/* </div> */}
                </Stack>
              </Grid>
            </Grid>
          </Grid>
        </Box>
      </div>
    </>
  );
};

export default ViewApplication;
