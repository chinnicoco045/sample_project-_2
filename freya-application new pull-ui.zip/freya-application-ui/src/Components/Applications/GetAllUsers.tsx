import React, { useContext, useEffect, useState } from "react";
import { RowContext } from "../../App";
import Row, { accessToken } from "../../types";
import service from "../../Services/apiheader";
import Loading from "./components/Loading";
import Cookies from "js-cookie";
import { useNonPersistentFilterItemsStore } from "../../Audit/config";
import { useUrfReceiveEvents } from "../../hooks/urfEvents";


function GetAllUsers() {
  const {
    disabledRows,
    setRows,
    setDisabledRows,
    setAllRows,
    isEdited,
    isDisabled,
    isAdded,
    setIsAdded,
    setinactiveRows,
    setactiveRows,
    paginationobject,
    setPaginationTotalRecord,
    gridstatus
  } = useContext(RowContext);

  const [isLoading, setIsLoading] = useState(false);

  const [filter, updateFilter] = useNonPersistentFilterItemsStore((state) => [
    state.filter,
    state.updateFilter,
  ]);
  useUrfReceiveEvents();
   const formatRow = (item: any) => {
    const applicationData = JSON.parse(item.applicationdata);
    const row: Row = {
      id: item.id,
      application_identifier: item.identifier,
      ...applicationData,
      groupid:item.groupid,
      mark_fordelete: item.markfor_delete,
      created_by: item.created_by,
      created_date: item.created_date,
      updated_by: item.updated_by,
      updated_date: item.updated_date,
      inactiveFlg: applicationData.inactiveFlg ? "Yes" : "No",
      status:applicationData.status
    };

    return row;
  };

  const getUsers = async () => {
    setIsLoading(true);
   
    try {
      console.log("Apply button for global filter clicked");
      const response = await service.get(`application/v1/display-all/refresh-products`,{
        params: {
          page:paginationobject.page,
          size:paginationobject.pageSize,
          active:gridstatus.active,
          inactive:gridstatus.inactive,
          disable:gridstatus.disable
        },
        headers:{
          "X-TenantID":Cookies.get('USER_TENANT_ID'),
          Authorization: `Bearer ${accessToken}`,
          globalFilters: JSON.stringify(filter),
        }
      });
      const data = response.data;
      setIsLoading(false);
      setPaginationTotalRecord(response.data.data.totalElements);
      let allRows: Row[] = [];
      //let inactiveRows: Row[]=[];
      let activeRows:Row[]=[];
      console.log(data);
      for (const item of data.data.content) {
        const row: Row = formatRow(item);

        allRows = [...allRows, row];
        const inrow:Row = formatRow(item);
      
        activeRows=[...activeRows,inrow];
      
      }
      //inactiveRows.sort((a, b) => new Date(b.updated_date).getTime() - new Date(a.updated_date).getTime());
      // allRows.sort((a, b) => new Date(b.updated_date).getTime() - new Date(a.updated_date).getTime());
      //setactiveRows(activeRows);
      const inactiveRows = allRows.filter((row:any) => row.inactiveFlg === "Yes");
      // inactiveRows.sort((a:any, b:any) => new Date(b.updated_date).getTime() - new Date(a.updated_date).getTime());
      setinactiveRows(inactiveRows);
      setAllRows(allRows);
      setRows(allRows);
    } catch (error) {
      console.error("Error fetching users:", error);
    } 
  };
  

//   const getDisabledRows = async function getDisabledRows() {
//   let disabledRows: Row[] = [];
//   try {
//     const response = await service.get(`application/v1/display-all-disable`,{
//       params: {
//         page:0,
//         size:paginationobject.pageSize,
//       },
//       headers:{
//          "X-TenantID":Cookies.get('USER_TENANT_ID'),
//          Authorization: `Bearer ${accessToken}`,
//          globalFilters: JSON.stringify(filter)
//       }
//     });
//     setPaginationTotalRecord(response.data.data.totalElements);
//     if (response && response.data) {
//       const data = response.data;
//       for (const item of data.data.content) {
//         const row: Row = formatRow(item);
//         disabledRows = [...disabledRows, row];
//       }
//       setDisabledRows(disabledRows);
//     } else {
//       console.error("Invalid response structure:", response);
//     }
//   } catch (error) {
//     console.error("Error fetching disabled rows:", error);
//   }
// }

  useEffect(() => {
    console.log(paginationobject);
    getUsers();
    //getDisabledRows();
  }, [isDisabled, isEdited, isAdded,filter,paginationobject,gridstatus]);

  return (
    <div>
      <Loading  open={isLoading} data-testid="loading-indicator"></Loading>
    </div>
  );
}

export default GetAllUsers;