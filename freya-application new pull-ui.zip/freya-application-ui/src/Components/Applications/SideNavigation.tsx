import React, { useState, useEffect, useRef, useMemo } from "react";
import { useCookies } from "react-cookie";
import { List, Typography } from "@mui/material";
import { TreeItem, TreeView } from "@mui/x-tree-view";
import "../../App.scss";
import { Collapse, IconButton, InputBase } from "@mui/material";
import FilterListIcon from "@mui/icons-material/FilterList";
import { Close } from "@mui/icons-material";
import { useNavigate, useLocation } from "react-router-dom";
import axios from "axios";
import { GET_API } from "../../Services/apiheader";
import AuditIcon from "../../assets/audit-icon.svg";
import AuditReportDrawer from "../../Audit/AuditReportDrawer";
import { useTranslation } from "react-i18next";
import { fetchSectionProductTree } from "../../apis/apiFunctions";


interface TreeItemType {
  id: string;
  label: string;
  children?: TreeItemType[];
  gridDataUrl?: string;
  formDataUrl?: string;
}

function SideNavigation ({ openDrawer, setOpenDrawer }: { openDrawer: boolean, setOpenDrawer: (value: boolean) => void })  {
  const location = useLocation();
  const {t} = useTranslation();
  const [keywords, setKeywords] = useState("");
  const [selectedItem, setSelectedItem] = useState<string>("");
  const [searchQuery, setSearchQuery] = useState("");
  const [productBasicInfo, setProductBasicInfo] = useState<TreeItemType[]>([]);
  const [applicationBasicInfo, setApplicationBasicInfo] = useState<TreeItemType[]>([]);
  const [expandedItems, setExpandedItems] = useState<string[]>([]);
  const [collapse, setCollapse] = useState(true);
  const [productId, setProductId] = useState("");
  const cellData = JSON.parse(sessionStorage.getItem('CellData') || '{}');
  const ms=cellData.applicationData?.countryIdentifier;
  const linkTo = useNavigate();
  const applicationItemRef = useRef<HTMLLIElement>(null);
  const [identifierData, setIdentifierData] = useState([]);
  const [selectedId, setSelectedId] = useState(""); // Define a new state for the ID
  const [sectionTreeData, setSectionTreeData] = useState<any>(null);
  const [deviceFlag, setDeviceFlag] = useState(false);


  const [cookies] = useCookies([
    "USER_TENANT_ID",
    "DOMAIN",
    "USER_PRIVILEGES",
    "ACCESS_TOKEN",
  ]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const productDetails = await axios.get(`${GET_API}product/products/${cellData.productId}`,{
          headers: {
            Authorization: `Bearer ${cookies.ACCESS_TOKEN}`,
            'Accept-Language': ""
          }
        })
        const details = productDetails.data.data.dynamicFieldJson
        let dynamicFieldData;
        if (details){
          dynamicFieldData = JSON.parse(productDetails.data.data.dynamicFieldJson)
          if (dynamicFieldData.includeDevice){
            setDeviceFlag(dynamicFieldData.includeDevice)
          }
        }
        const response = await axios.get(`${GET_API}cm/form-manager/menus/module?module=product`, {
          headers: {
            Authorization: `Bearer ${cookies.ACCESS_TOKEN}`
          }
        });
        const data = response.data.data;
        const parsedBasicInfo = parseTreeItems(data,dynamicFieldData,true);
        setProductBasicInfo(parsedBasicInfo);

        const applicationResponse = await axios.get(`${GET_API}cm/form-manager/menus/module?module=applications`, {
          headers: {
            Authorization: `Bearer ${cookies.ACCESS_TOKEN}`
          }
        });
        const applicationData = applicationResponse.data.data;
        const parsedApplicationInfo = parseTreeItems(applicationData,cellData.applicationData,false);
        setApplicationBasicInfo(parsedApplicationInfo);

        // Fetch dropdown list data
        const dropdownResponse = await axios.get(`${GET_API}product/products/dropdown-list`, {
          headers: {
            Authorization: `Bearer ${cookies.ACCESS_TOKEN}`
          }
        });
        const dropdownData = dropdownResponse.data.data;
        const matchingItem = dropdownData.find((item: any) => item.id === cellData.productId);
        setProductId(cellData.productId)
        if (matchingItem) {
          sessionStorage.setItem("productId", matchingItem.id);
        }
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    fetchData();

    // for audit ......
    if (cellData && cellData.id) {
      setSelectedId(cellData.id.toString());
    }
    // .....
    
    const currentPath = location.pathname;
    if (currentPath.includes("editApplication")){
      setSelectedItem("/editApplication")
    } else if (currentPath.includes("viewApplication")){
      setSelectedItem("/viewApplication")
    }

    // Simulate click on the 'Application' item
    if (applicationItemRef.current) {
      applicationItemRef.current.click();
    }
  }, []);

  const memoizedSectionTreeData = useMemo(() => {
    if (!productId) return null;
    
    const fetchData = async () => {
      try {
        const response = await fetchSectionProductTree(productId);
        return response.data.data; // Assuming the actual data is in response.data.data
      } catch (error) {
        console.error("Error fetching section tree data:", error);
        return null;
      }
    };
    
    return fetchData();
  }, [productId]);

  useEffect(() => {
    if (memoizedSectionTreeData) {
      memoizedSectionTreeData.then((data) => {
        setSectionTreeData(data);
      });
    }
  }, [memoizedSectionTreeData]);




  const handleExpandedItemsChange = (
    event: React.SyntheticEvent,
    itemIds: string[],
  ) => {
    setExpandedItems(itemIds);
  };
  type BusinessRule = {
    source: string;
    name: string;
    field: string;
    rule: "equals" | "exists" | "in";
    value: string;
  };
  
  type DataItem = Record<string, any>;
  const applyBusinessRules = (
    data: Record<string, any>,
    rules: BusinessRule[],
    fromProduct: boolean
  ): boolean => {
    if(fromProduct){
      return true;
    }
    for (let { field, rule, value, source, name } of rules) {
      let itemValue;

      if(source === "form"){
        if (field === "regionName") {
          field = "region";
        }
        if(field === "countryNames"){
          field = "country";
        }
      }

      if (fromProduct && source === "grid") {
        if (!cellData || !cellData.applicationData) {
          console.error("cellData or cellData.applicationData is undefined.");
          return false; // If data is missing, rule cannot be validated
        }
        itemValue = cellData.applicationData[field];
      } else {
        itemValue = data[field];
      }
  
      let isRuleValid = false;
  
      switch (rule) {
        case "equals":
          isRuleValid = Array.isArray(itemValue) ? itemValue.includes(value) : itemValue === value;
          break;
  
        case "exists":
          isRuleValid = itemValue !== undefined && itemValue !== null && itemValue !== "";
          break;
  
        case "in":
          try {
            const valuesArray = JSON.parse(value) as string[];
            isRuleValid =
              Array.isArray(valuesArray) &&
              (Array.isArray(itemValue)
                ? itemValue.some((val) => valuesArray.includes(val)) // Check for intersection
                : valuesArray.includes(itemValue)); // Check single value
          } catch (error) {
            console.error(`Error parsing "in" condition value:`, error);
            isRuleValid = false;
          }
          break;
  
        default:
          console.warn(`Unknown rule: ${rule}`);
          isRuleValid = false;
      }
  
      // If any rule fails, return false immediately
      if (!isRuleValid) {
        return false;
      }
    }
  
    // If all rules passed, return true
    return true;
  };
  

  const parseTreeItems = (data: any[], dynamicFieldData: any, fromproduct: any): TreeItemType[] => {
  const recursiveParse = (items: any[]): TreeItemType[] => {
    return items
      .filter(item => !item.businessRule || applyBusinessRules(dynamicFieldData, item.businessRule, fromproduct)) // Apply business rules
      .map(item => {
        const children = item.children ? recursiveParse(item.children) : undefined;

        // Exclude parent if children are empty after applying business rules
        if (children && children.length === 0) {
          return null;
        }

        return {
          id: item.id,
          label: item.displayName || item.name,
          children: children,
          ...(item.gridDataUrl && { gridDataUrl: item.gridDataUrl }),
          ...(item.formDataUrl && { formDataUrl: item.formDataUrl }),
        };
      })
      .filter(Boolean) as TreeItemType[]; // Remove null values
  };

  return recursiveParse(data);
};


  const initCurrentData = {
    productType: {
      id: '', name: ''
    },
    productTypeError: false,
    productNameError: false,
    productCodeError: false,
    id: '',
    productSubcategory: {
      id: '', name: ''
    },
    productCategory: {
      id: '', name: ''
    },
    productSubcategoryName: '',
    productCategoryName: '',
    productTypeName: '',
    reasonForInactive: {
      id: '', name: ''
    },
    recordId: '',
    createdDate: '',
    createdByName: '',
    modifiedDate: '',
    modifiedByName: '',
  };

  const [currentData, setCurrentData] = useState(initCurrentData);
  const [reportDrawerList, setReportDrawerList] = useState([]);
  const [isEntityReport, setIsEntityReport] = useState(false);
  const [openAddPopup, setOpenAddPopup] = useState(false);

  const handleCancel = () => {
    setOpenDrawer(false);
  }

  useEffect(() => {
    const currentId = location?.state?.id;
    const productValue = location?.state?.productValue;
    setCurrentData({
      ...currentData,
      ...productValue
    });
  }, [location]);

  const handleItemClick = (item: TreeItemType) => {
    const itemId = item.id;
    const menuname = item.label === "Include Products" ? "Product Information" : item.label;
  
    if (item.children) {
      // Handle the case where item.children is not null, if needed
      return;
    }
  
    if (item.label === "Application") {
      linkTo(selectedItem);
    }
    else if(item.label === "Member States"){
      linkTo("/sidenavTable",{
        state:{
         id: cellData.id,
         label:"Member States",
         menuname:"Member States",
         url:"/application/v1/display/refresh-products/"+cellData.id,
         module:"applications",
         mode:location?.state?.mode
        }
      });
    } else if (item.label === "Product Information") {
      linkTo("/sidenavView", {
        state: {
          productId: productId,
          menuname: menuname,
          url: item.formDataUrl || item.gridDataUrl,
        },
      });
    } else if (item.gridDataUrl) {
      linkTo("/sidenavTable", {
        state: {
          productId: productId,
          label: item.label,
          menuname: menuname,
          url: item.gridDataUrl,
          jsonurl: item.formDataUrl,
          module:"product"
        },
      });
    } else {
      if (itemId === "1") {
        linkTo(selectedItem);
      }
    }
  };

  const handleSearchBox = (event: React.ChangeEvent<HTMLInputElement>) => {
    const value = event.target.value;
    setKeywords(value);
    setSearchQuery(value.toLowerCase());
    updateExpandedItems(value.toLowerCase());
  };

  const handleClearSearch = () => {
    setKeywords("");
    setSearchQuery("");
    setExpandedItems([]); // Reset expanded items
  };

  const updateExpandedItems = (query: string) => {
    if (query === "") {
      setExpandedItems([]);
      return;
    }

    const expandItems = (items: TreeItemType[]): string[] => {
      let expanded: string[] = [];
      items.forEach((item) => {
        let shouldExpand = false;

        if (item.label.toLowerCase().includes(query)) {
          shouldExpand = true;
        }

        if (item.children) {
          const childExpanded = expandItems(item.children);
          if (childExpanded.length > 0) {
            shouldExpand = true;
            expanded = [...expanded, ...childExpanded];
          }
        }

        if (shouldExpand) {
          expanded.push(item.id);
        }
      });
      return expanded;
    };

    const newExpandedItems = expandItems(combinedTreeItems);
    setExpandedItems(newExpandedItems);
  };

  const combinedTreeItems = [
    ...applicationBasicInfo,
    ...productBasicInfo
  ];

  const currentPath = location.pathname;

  const filteredTreeItems = combinedTreeItems
  .filter(item => {
    // Exclude "Member States" if the condition is met
    if (item.label === "Member States" && !ms) {
      return false;
    }
    return true;
  })
  .map(item => ({
    ...item,
    children: item.children?.filter(child => {
      if (currentPath.includes("editApplication") && child.id === "3") return false;
      if (currentPath.includes("viewApplication") && child.id === "4") return false;
      return true;
    }),
  }));


  // Recursive function to render TreeItems
  const renderTreeItems = (items: TreeItemType[]): React.ReactNode => {
    return items.map((item) => (
      <TreeItem
        key={item.id}
        itemId={item.id}
        label={<Typography className="tab-title">{t(item.label)}</Typography>}
        onClick={() => handleItemClick(item)}
        ref={item.id === "1" ? applicationItemRef : undefined}
        sx={{ paddingY: 1 }}
      >
        {item.children && renderTreeItems(item.children)}
      </TreeItem>
    ));
  };

  // Filter function
  const filterTreeItems = (items: TreeItemType[], query: string, productPhase: string): TreeItemType[] => {
    return items.filter(item => (item.label !== "Protocols" || productPhase === "Investigational")  && (item.label !== "Devices" || (deviceFlag ?? false)))
      .map((item) => {
        if (item.children) {
          const filteredChildren: TreeItemType[] = filterTreeItems(item.children, query, productPhase);
          if (filteredChildren.length > 0) {
            return { ...item, children: filteredChildren };
          }
        }
        if (item.label.toLowerCase().includes(query)) {
          return item;
        }
        return null;
      })
      .filter((item): item is TreeItemType => item !== null);
  };
 
  const filteredItems = filterTreeItems(filteredTreeItems, searchQuery, cellData.applicationData.productPhase);

  return (
    <div className="sidenavigation-component">
 
      <List
        className="rightsidesearch-list"
        component="nav"
        aria-labelledby="nested-list-subheader"
        subheader={
          <div className="collapse-header search-width">
            <IconButton type="button">
              {!keywords && <FilterListIcon color="inherit" />}
            </IconButton>

            <InputBase
              placeholder={t("search")}
              value={keywords}
              onChange={handleSearchBox}
            />
            <IconButton type="button">
              {!!keywords && (
                <Close
                  onClick={handleClearSearch}
                />
              )}
            </IconButton>
          </div>
        }
      >
        <Collapse
          in={collapse}
          timeout="auto"
          unmountOnExit
          sx={{ flex: 1, overflow: "auto" }}
        >
          <TreeView 
            disabledItemsFocusable={true}
            aria-label="file system navigator" 
            className="sidenav-tabs"
            expandedItems={expandedItems}
            onExpandedItemsChange={handleExpandedItemsChange}
            sx={{
              height: "100%",
              flexGrow: 1,
              maxWidth: 400,
              overflowY: "auto",
            }}
          >
            {renderTreeItems(filteredItems)}
          </TreeView>
        </Collapse>
      </List>
      {openDrawer && (
            <AuditReportDrawer
              identifierData={identifierData}
              setIdentifierData={setIdentifierData}
              handleCancel={handleCancel}
              recordId={currentData.recordId}
              setIsEntityReport={setIsEntityReport}
              setReportDrawerList={setReportDrawerList}
              isEntity={isEntityReport}
              reportDrawerList={reportDrawerList}
              openAddPopup ={openAddPopup}
              setOpenAddPopup={setOpenAddPopup}
              Audit_Id={selectedId}
              productId={productId}
              sectionTreeDataProps={sectionTreeData}
              setOpenDrawer={setOpenDrawer}
            />
          )}
    </div>
  );
}

export default SideNavigation;
