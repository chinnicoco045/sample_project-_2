import React, {useEffect, useState} from 'react';
import { useCookies } from "react-cookie";
import { useTranslation } from 'react-i18next';
import { Stack, Breadcrumbs, Typography, Grid, FormControl, Button, Checkbox, FormControlLabel, Box, Tooltip, Chip } from '@mui/material';
import { useLocation } from 'react-router-dom';
import SideNavigation from './SideNavigation';
import NavigateNextIcon from '@mui/icons-material/NavigateNext';
import { useNavigate } from "react-router-dom";
import axios from "axios";
import TagIcon from '@mui/icons-material/LocalOfferOutlined'; // Icon for the tag

import Links from "@mui/material/Link";
import Loading from "./components/Loading";

import service, { GET_API } from "../../Services/apiheader";
import Cookies from 'js-cookie';

interface FieldData {
  field: string;
  label: string;
  type: string;
  field_xs: number;
  hide: boolean;
  order: number;
  asyncConfig?: {
      url?: string;
      labelPath?: string;
      valuePath?: string;
  };
  options?: {
    label: string;
    value: string;
  }[];
}

 
const SideNavView: React.FC = () => {

    const [cookies] = useCookies([
        "USER_TENANT_ID",
        "DOMAIN",
        "USER_PRIVILEGES",
        "ACCESS_TOKEN",
      ]);

    const {t}=useTranslation();

    //const data_api_header =  process.env.REACT_APP_API;
    const data_api_header = GET_API.slice(0, -1);
    const tags = ["Application", "Angular", "Agency"]; // Example tag labels


    const location=useLocation();
    const { productId, menuname, url } = location.state || {};
    const [headData, setHeadData] = useState<any[]>([]);
    const [dynamicFieldData, setDynamicFieldData] = useState<any>({});
    const [asyncDataMap, setAsyncDataMap] = useState<{ [key: string]: any[] }>({});
    const [isLoading, setIsLoading] = useState<boolean>(true);

    const linkTo = useNavigate();

    useEffect(() => {

        const fullUrl = `${data_api_header}${url.replace("${productId}", productId)}`;
        const fetchData = async () => {
          try {
            const response = await axios.get(fullUrl, {
              headers: {
                Authorization: `Bearer ${cookies.ACCESS_TOKEN}`,
                'Accept-Language': ""
              },
            });
            const response_data = response.data.data
            if (response_data.length === 0) {

            } else {
                setDynamicFieldData(JSON.parse(response_data.dynamicFieldJson));
                
            }
            

            const requestData = {
              module: "product",
              formName: menuname,
              businessRule: {
                  productType: dynamicFieldData.productType,
                  productCategory: dynamicFieldData.productCategory,
                  productPhase: dynamicFieldData.productPhase,
                  includeDevice: dynamicFieldData.includeDevice
              }
          };

              const response2 = await axios.post(data_api_header+`/cm/form-manager/forms/settings`, requestData, {
                headers: {
                  Authorization: `Bearer ${cookies.ACCESS_TOKEN}`,
                },
              });
            const parsedHeadData = JSON.parse(response2.data.data.settingsJson);
                setHeadData(parsedHeadData);
                
                const asyncDataPromises = parsedHeadData
                .filter((fieldData: FieldData) => fieldData.asyncConfig && fieldData.asyncConfig.url)
                .map(async (fieldData: FieldData) => {
                  const response = await axios.get(data_api_header+fieldData.asyncConfig!.url!, {
                    headers: {
                      Authorization: `Bearer ${cookies.ACCESS_TOKEN}`,
                      'Accept-Language': ""
                    },
                  });
                  return { [fieldData.field]: response.data.data };
                });

                
      
              const asyncDataResults = await Promise.all(asyncDataPromises);
              const asyncDataMap = Object.assign({}, ...asyncDataResults);
              setAsyncDataMap(asyncDataMap);
              setIsLoading(false);

          } catch (error) {
            console.error("Error fetching data:", error);
            setIsLoading(false);
          }
        };
    
        fetchData();
      }, [cookies.ACCESS_TOKEN, data_api_header, url]);
 
    const renderLabels = () => {
      const sortedHeadData = headData.sort((a: FieldData, b: FieldData) => a.order - b.order);
        return sortedHeadData.map((fieldData: FieldData) => {
          const { field, label, type, field_xs, asyncConfig, hide, options } = fieldData;
          if (hide === true){
            return null;
          }
          let value = dynamicFieldData[field] !== undefined ? dynamicFieldData[field] : "";

          if (asyncConfig && asyncConfig.url) {
            const asyncData = asyncDataMap[field];
            if (asyncData) {
              const selectedValue = asyncData.find((item: any) => item.id === value);
                    value = selectedValue ? selectedValue.name : value;
            }
        }


        switch (type) {
          case 'checkbox':
              return (
                  <Grid item xs={field_xs} key={field}>
                      <FormControl fullWidth disabled>
                                <div className='form-group'>
                                <Tooltip title={t(field,{defaultValue:label})} >
                                    <label className="form-label">
                                    {t(field,{defaultValue:label})}
                                    </label>
                                    </Tooltip>
                                    <span className="form-content">
                                    <Checkbox
                                        checked={value}
                                        disabled
                                    />
                                    </span>
                                </div>
                            </FormControl>
                  </Grid>
              );
          case 'date':
            const dateValue = value !== "" ? new Date(value).toLocaleDateString() : "-";
            return (
                <Grid item xs={field_xs} key={field}>
                    <FormControl fullWidth disabled>
                        <div className='form-group'>
                        <Tooltip title={t(field,{defaultValue:label})} >
                            <label className="form-label">
                            {t(field,{defaultValue:label})}
                            </label>
                            </Tooltip>
                            <Tooltip title={dateValue} >
                            <span className="form-content">
                                {dateValue}
                            </span>
                            </Tooltip>
                        </div>
                    </FormControl>
                </Grid>
            );
          default:

                return (
                  <Grid item xs={field_xs} key={field}>
                      <FormControl fullWidth disabled>
                          <div className='form-group'>
                          <Tooltip title={t(field,{defaultValue:label})} >
                              <label className="form-label">
                                  {t(field,{defaultValue:label})}
                              </label>
                              </Tooltip>
                              <span className="form-content">
                                  <Tooltip title={value} >
                                  {value !== "" ? value : "-"}
                                  </Tooltip>
                              </span>                              
                          </div>
                      </FormControl>
                  </Grid>
              );
                }
        });
    };
 
    const [detailData, setDetailData] = useState(""); // State to store the fetched data
  const [productName, setProductName] = useState('');
  const [countryName, setCountryName] = useState('');
  const cellData = JSON.parse(sessionStorage.getItem('CellData') || '{}');

  useEffect(() => {
    const Data = async () => {
      try {
        const response = await service.get(`/application/v1/display/refresh-products/`+ cellData.id, {
          headers: {
            "X-TenantID": Cookies.get('USER_TENANT_ID')
          }
        });
  
        console.log("Fetched Response Data:", response);
  
        if (response && response.data && response.data.data && response.data.data.applicationdata) {
          const data = response.data.data.applicationdata;
          console.log("Fetched Application Data:", data);
  
          setDetailData(data);
          setProductName(data.productName);
          setCountryName(cellData.applicationData.countryNames);
  
        }
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };
  
    Data();
  }, []);

  const productnames = productName.length > 6 ? `${productName.slice(0, 6)}...` : productName;
  const countrynames = countryName.length > 6 ? `${countryName.slice(0, 6)}...` : countryName;

  return (
    <>
        {/* Breadcrumb */}
        {isLoading && <Loading open={isLoading}></Loading>}
        <div className='application-inner-page'>
      <Box className='custom-bread-crumb'>
    <Stack>
        <Breadcrumbs aria-label="breadcrumb" separator={<NavigateNextIcon />} >
            <Links href="/applicationdetails">
                {t('application')}
            </Links>
           
                <Typography>
                    {t(menuname)}
                </Typography>
        </Breadcrumbs>
      
    </Stack>
    </Box>
    </div>
    {/*End Breadcrumb */}

   
    <div className="application_addform ">
    <Box  className=' custom-bread-crumb display-flex'>
    <Grid container className='form-group innerpage-container-content '>
    <Stack direction={{ xs:'column', sm:'row'}} alignItems ={ ""} className = "mb-16 ml-8 page-title">
    <Typography variant='h4' className='list-header-title mt-4'>  {t("view") + t("Product Information")}  </Typography>
    <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
      <Tooltip title={productName} placement="bottom-start">
          <Chip
            icon={<TagIcon style={{ fontSize: 16, color: '#2e5aac', transform: 'rotate(133deg)', }} />}  
            label={productnames}                      
            style={{
              backgroundColor: '#EAF0FB',                    
              color: '#3F51B5',                              
              fontWeight: '500',                             
              borderRadius: '16px',                          
              fontSize: '2.25rem',                              
              padding: '2px 6px',                            
              height: '22px',  
              width : "100px",
              display: 'flex',                               
              alignItems: 'center',                         
            }}
          />
      </Tooltip>
      <Tooltip title={countryName} placement="bottom-start">
        <Chip
            icon={<TagIcon style={{ fontSize: 16, color: '#2e5aac', transform: 'rotate(133deg)', }} />}  
            label={countrynames}                              
            style={{
              width : "100px",
              backgroundColor: '#EAF0FB',                    
              color: '#3F51B5',                              
              fontWeight: '500',                             
              borderRadius: '16px',                          
              fontSize: '2.25rem',                              
              padding: '2px 6px',                            
              height: '22px',                                
              display: 'flex',                               
              alignItems: 'center',                         
            }}
          />
      </Tooltip> 
    </div>
    {/* {(`rtq.tab.${pageTitle}`)} as per rtq */}
     </Stack>
 
      {renderLabels()}
        </Grid>
      </Box>
    </div>
    </>
  );
};
 
export default SideNavView;