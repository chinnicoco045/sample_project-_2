import React, { useContext, useState, useEffect } from "react";
import { Box, FormControl, Grid, MenuItem, Select, TextField, Typography, Button, InputLabel, Checkbox, RadioGroup, FormControlLabel, Radio, Tooltip, FormHelperText, IconButton, Dialog, DialogTitle, DialogContent, DialogContentText, DialogActions } from "@mui/material";
import { DemoContainer } from '@mui/x-date-pickers/internals/demo';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import dayjs, { Dayjs } from 'dayjs';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { useTranslation } from "react-i18next";
import NavigateNextIcon from "@mui/icons-material/NavigateNext";
import { CheckBox, CheckBoxOutlineBlank } from "@mui/icons-material";
import { Breadcrumbs, Stack } from "@mui/material";
import Links from "@mui/material/Link";
import { Link, useLocation, useNavigate } from "react-router-dom";
import service from "../../Services/apiheader";
import { RowContext } from "../../App";
import newJson from "../../jsons/new_json.json";
import {fetchEditFormJson, fetchDataSource, fetchApplicationTypeValues, applyBusinessRules} from "../../apis/apiFunctions"
import HighlightOffOutlinedIcon from '@mui/icons-material/HighlightOffOutlined';
import CalendarMonthOutlinedIcon from '@mui/icons-material/CalendarMonthOutlined';
import Cookies from "js-cookie";
import { useSnackbar } from "notistack";
import { useUrfReceiveEvents } from "../../hooks/urfEvents";
import _ from "lodash";

interface FormData {
  productCategory: string;
  productPhase: string;
  productType: string;
  productName: string;
  region: string;
  procedureType: string;
  country: string;
  applicationType: string;
  procedureNumber: string;
  applicationName: string;
  applicationNumber: string;
  eIdentifier: string;
  dossierIdentifier: string;
  applicationId: string;
  eSubmissionIdentifier: string;
  registrationId: string;
  status: string;
  language: string;
  subjectToArbitration: boolean;
  description: string;
  comments: string;
}

interface SectionTree {
  [key: string]: string[] | { [key: string]: string[] };
}

interface NewJson {
  [key: string]: {
    placeholder: string;
    conditional?: null | any;
  };
}

const EditApplication: React.FC = () => {
  const { t } = useTranslation();
  const location = useLocation();
  const navigate = useNavigate();
  const { isEdited, setIsEdited, rows, setRows } = useContext(RowContext);
  const [dataRecord, setDataRecord] = useState<any>({});
  const [fieldsdata, setFieldsdata] = useState<any>([])
  const [invalidFields, setInvalidFields] = useState<string[]>([]);
  const [red, setRed] = useState<boolean>(false);
  const [urloptions, setOptions] = useState<any>([])
  const [ApptypeOptions,setApptypeOptions] = useState<any>([])
  const { enqueueSnackbar } = useSnackbar();
  const [recordDetails,setRecordDetails]=useState<any>({})
  const [alertOpenCancelDialog, setAlertOpenCancelDialog] = useState(false);
  const [inactiveAlert, setinactiveAlert] = useState(false);
  const [initialDataRecord, setInitialDataRecord] = useState<any>({});
  const [dropdownLabel,setDropdownLabel]=useState("");
  useUrfReceiveEvents();
  let json = [{}];

  const id = sessionStorage.getItem('id');
  const cell = JSON.parse(sessionStorage.getItem('CellData') || '{}');
  const fetchData = async () => {
    const response=await service.get(`application/v1/display/refresh-products/${id}`,
      {
        headers:{
          "X-TenantID":Cookies.get('USER_TENANT_ID')
        }
      }
    );
    const r = response.data.data.applicationdata;
    const application_identifier=response.data.data.identifier;
    const sectionTree = r.sectionTree;
    const region = r.region
    sessionStorage.setItem('formattedCheckedValues', JSON.stringify(sectionTree));
    // setDataRecord(r)
    const mergedObj = { ...r, ...(cell?.applicationData.inactiveFlg !== undefined ? { inactiveFlg: cell?.applicationData.inactiveFlg } : {}) };
    setRecordDetails(mergedObj);
    setDataRecord({
      ...cell?.applicationData,
      application_identifier: application_identifier,
    });

    function getAllIds(tree: SectionTree): string[] {
      const allIds: string[] = [];

      // Iterate over each key in sectionTree
      Object.keys(tree).forEach(key => {
        const value = tree[key];

        // Check if the value is an array of IDs
        if (Array.isArray(value)) {
          allIds.push(...value); // Add all IDs to allIds array
        } else if (typeof value === 'object') {
          // Recursively call getAllIds if the value is another object
          allIds.push(...getAllIds(value as SectionTree));
        }
      });

      return allIds;
    }
    const allIds = getAllIds(sectionTree);
    sessionStorage.setItem('allIds', JSON.stringify(allIds));

    json = JSON.parse(await fetchEditFormJson(region,t));
    console.log(json,'setting json')
    setFieldsdata(json)

    const options = await json
    .filter((data: any) => data.asyncConfig && data.asyncConfig.url && (data.type !== 'select' || (data.type === 'select' && !data.readonly)))
    .reduce(async (accPromise: any, data: any) => {
        const acc = await accPromise;
        const result = await fetchDataSource(data.asyncConfig.url,region);
        acc[data.field] = result;
        return acc;
    }, Promise.resolve({}));

setOptions(options)

  };

  useEffect(() => {
    // Set the initial data record when the component mounts
    setInitialDataRecord(cell?.applicationData || {});
  }, []);

  useEffect(() => {
    fetchData();// Fetch data when component mounts
    const apifunction = async () => {
        const response = await fetchApplicationTypeValues(); 
        if(response!= undefined){
        let AppTypeOptions = response.data.data;
        setApptypeOptions(AppTypeOptions);
        }
    }
    apifunction();
  },[id]);

  const initialFormData: FormData = {
    productCategory: cell?.applicationData?.productCategory,
    productPhase: cell?.applicationData?.productPhase,
    productType: cell?.applicationData?.productType,
    productName: cell?.productName,
    region: cell?.region,
    procedureType: cell?.procedureType,
    country: cell?.country,
    applicationType: cell?.applicationData?.applicationType,
    procedureNumber: cell?.applicationData?.procedureNumber,
    applicationName:  cell?.applicationData?.applicationName,
    applicationNumber:  cell?.applicationData?.applicationNumber,
    eIdentifier: cell?.applicationData?.eIdentifier,
    dossierIdentifier: cell?.applicationData?.dossierIdentifier,
    applicationId: cell?.applicationData?.applicationId,
    eSubmissionIdentifier: cell?.applicationData?.eSubmissionIdentifier,
    registrationId: cell?.applicationData?.registrationId,
    status: cell?.applicationData?.status,
    language: cell?.applicationData?.language,
    subjectToArbitration :cell?.applicationData?.subjectToArbitration,
    description: cell?.applicationData?.description,
    comments: cell?.applicationData?.comments,
  };

  // State to store form data
  const [formData, setFormData] = useState<FormData>(initialFormData);
  const [isFormModified, setIsFormModified] = useState(false);
  const removeUndefined = (obj: Record<string, any>) => {
    return Object.fromEntries(
      Object.entries(obj || {}).filter(
        ([_, value]) => value !== undefined && value !== "" && !(Array.isArray(value) && value.length === 0)
      )
    );
  };
  // Function to handle form field changes
  const handleFieldChange = (key: string, value: any,label:any,type:any) => {
    setDataRecord((prevData: any) => ({
      ...prevData,
      [key]: type==="select" ? label : value
    }));
    recordDetails[key]=value;
    // Check if the form is modified
    if(key == "inactiveFlg" && value === true)
       setinactiveAlert(true);
    if(key == "inactiveFlg" && value === false)
      setinactiveAlert(false);
  };

  // Function to  form submission
  const handleSubmit = async () => {
    cell.applicationData = dataRecord;

// Update sessionStorage with the modified object
sessionStorage.setItem("CellData", JSON.stringify(cell));
    const cleanedDataRecord = removeUndefined(dataRecord);
    const cleanedrecordDetails = removeUndefined(initialDataRecord);
 
    console.log("dataRecorddataRecord", cleanedDataRecord);
    console.log("dataRecords", cleanedrecordDetails);
 
    const isModified = !_.isEqual(cleanedDataRecord, cleanedrecordDetails);
 
    if (!isModified) {
      setIsFormModified(true)
      // enqueueSnackbar("No changes detected", { variant: "info", anchorOrigin: { vertical: 'top', horizontal: 'center' } });
      return; // Exit if no changes
    }
    setIsFormModified(false)
    const unfilledFields = invalidFields.filter(field => {
      const value = dataRecord[field as keyof typeof dataRecord];
      return value === undefined || value === "" || (Array.isArray(value) && value.length === 0);
    });
    if (unfilledFields.length > 0) {
      setInvalidFields(unfilledFields);
      setRed(true);
      enqueueSnackbar("Fill all the required fields", { variant: "error", anchorOrigin: { vertical: 'top', horizontal: 'center' } });
      return;
    }
    let Statusvalue;
    if(dataRecord.inactiveFlg===true){
      Statusvalue = "Inactive";
    }else{
      Statusvalue = "Active";
      dataRecord.reasonForInactive = '';
    }
    const updatedRow = {
      application_identifier:cell.application_identifier,
      // groupid: dataRecord.groupid,
      applicationdata: {
            ...recordDetails,status:Statusvalue
      },
      created_by: cell?.created_by,
      updated_by: Cookies.get("USER_EMAIL"),
      domain_id: Cookies.get("DOMAIN")
    };
    const response = await service.put(`application/v1/modification/${cell.id}`, updatedRow,{
      headers:{
        "X-TenantID":Cookies.get('USER_TENANT_ID')
      }
    });
    const updatedData = response.data;
    setIsEdited(true);

        updateRow(updatedData);
    enqueueSnackbar(t("editSuccessMessage"), { variant: "success", anchorOrigin: { vertical: 'top', horizontal: 'center' } });
    navigate(-1);
  };

  const updateRow = (updatedRow: any) => {
    const updatedRows = rows.map((row: any) =>
      row.id === updatedRow.id ? updatedRow : row
    );
    setRows(updatedRows);
  };


  const getSuperscriptText = (icon: string) => {

    switch (icon) {
        case "IDMPC":
            return <span style={{ float: 'right', color:'blue' }}>I<sup>C</sup></span>;
        case "xEVMPDC":
            return <span style={{ float: 'right', color:'blue' }}>X<sup>C</sup></span>;
        case "IDMPO":
            return <span style={{ float: 'right', color:'green' }}>I<sup>O</sup></span>;
        case "xEVMPDO":
            return <span style={{ float: 'right', color:'green' }}>X<sup>O</sup></span>;
        case "IDMPM":
            return <span style={{ float: 'right', color:'red' }}>I<sup>*</sup></span>;
        case "xEVMPDM":
            return <span style={{ float: 'right', color:'red' }}>X<sup>*</sup></span>;
        default:
            return "";
    }
};

const handleAlertCancelClose = () => {
  setAlertOpenCancelDialog(false);
};

const handleAlertCancelConfirm = () => {
  setAlertOpenCancelDialog(false);
  handleSubmit();
};

const isRequired = (component:any) => {
  if (!component.required) {
    return false;
  }
  const conditions = component.required;
  // if (!Array.isArray(conditions)) {
  //   return false;
  // }
  return conditions.some((condition: any) => {
    const formDataValue = dataRecord[condition.when as keyof typeof dataRecord];
    if (Array.isArray(formDataValue)) {
      // if (condition.eq !== undefined) {
      //   return formDataValue.includes(condition.eq);
      // }
      if (condition.in !== undefined) {
        return condition.in.some((val: any) => formDataValue.includes(val));
      }
    } else {
      // if (condition.eq !== undefined) {
      //   return formDataValue === condition.eq;
      // }
      if (condition.in !== undefined) {
        return condition.in.includes(formDataValue);
      }
    }
    return false;
  });
}

  // const evaluateCondition = (condition:any) => {
  //   const formDataValue = recordDetails[condition.when as keyof typeof recordDetails];
  //   if (Array.isArray(formDataValue)) {
  //     if (condition.eq !== undefined) {
  //       return formDataValue.includes(condition.eq);
  //     }
  //     if (condition.in !== undefined) {
  //       return condition.in.some((val: any) => formDataValue.includes(val));
  //     }
  //   } else {
  //     if (condition.eq !== undefined) {
  //       return formDataValue === condition.eq;
  //     }
  //     if (condition.in !== undefined) {
  //       return condition.in.includes(formDataValue);
  //     }
  //   }
  //   return false;
  // };
  
  // const evaluateConditions = (conditions:any) => {
  //   if (conditions.when) {
  //     return evaluateCondition(conditions);
  //   } else if (conditions.and) {
  //     return conditions.and.every((subCondition:any) => evaluateConditions(subCondition));
  //   } else if (conditions.or) {
  //     return conditions.or.some((subCondition:any) => evaluateConditions(subCondition));
  //   }
  //   return false;
  // };
  // const shouldShowComponent = (component:any) => {
  //   if (!component.show) {
  //     return true;
  //   }
  //   return false;
  //   // const flag=evaluateConditions(component.show);
  //   // return flag;
  // };
 
  // Function to render form components dynamically
  const renderFormComponents = (rawcomponents: any[]) => {
    const components = rawcomponents
    .sort((a, b) => a.order - b.order)
    .filter((element) => !['lmsName', 'cmsName', 'rmsName', 'mscName','countryIdentifier','memberStates'].includes(element.field));
    return components.map((component, index) => {
      const fieldData = newJson[component.field as keyof typeof newJson];
      // if ((fieldData && !shouldShowComponent(fieldData)) || component.hide){
      //   return null;
      // }
      if (!applyBusinessRules(component, recordDetails)) {
        return null;
      }
      console.log(recordDetails," ",dataRecord);
      let currentValue = dataRecord[component.field as keyof typeof dataRecord] ?? formData[component.field as keyof typeof formData];
      
      const icons = component.icon
      const additionalText = icons.length > 0 ? icons.map((icon:any) => getSuperscriptText(icon)) : "";
      const required = (fieldData && isRequired(fieldData)) || component.required;

      let error = false;
      if (required && !component.readonly && (currentValue===undefined || currentValue==="" || (Array.isArray(currentValue) && currentValue.length === 0))) {
        invalidFields.push(component.field);
          error = red ? true : false;
      }
      
      let options = component.options || [] 
      if (component.asyncConfig && component.asyncConfig.url && (component.type !== 'select' || (component.type === 'select' && !component.readonly))) {
        //loadOptions(component.asyncConfig.url);
        options = urloptions[component.field] || [];
      }
      let isCurrentValueInOptions = options.some((option: any) => option.value === currentValue);
      if (!currentValue || currentValue==="" || (Array.isArray(currentValue) && currentValue.length === 0)){
        if (component.readonly && component.required){
          return null
        }
      }

      switch (component.type) {
        case "select":
          //  if(component.field === "regulatoryAuthority" && recordDetails.productPhase !== "ProductPhase_PDPS00002"){
          //     return null;
          //  }
           if(component.field === "applicationType"){
            let finaldata: { label: any; value: any; code: any; }[] = [];
            let countrymatched = false;
            let countrycode = recordDetails.country.replace("Country_", "");
            for (const apptype of ApptypeOptions || []) {
              for (const apptypechild of apptype.children || []) {
                if (countrycode === apptypechild.code) {
                  finaldata.push({ label: apptype.name, value:  "ApplicationType_"+apptype.code, code:  "ApplicationType_"+apptype.code })
                  countrymatched = true;
                }
              }
            }
            if(countrymatched){
              options = [...finaldata];
            }else{
              ApptypeOptions.map((apptype:any) =>{
                finaldata.push({ label: apptype.name, value: "ApplicationType_"+apptype.code, code: "ApplicationType_"+apptype.code });
              })
              options = [...finaldata];  
            }
            isCurrentValueInOptions = options.some((option: any) => option.value === currentValue);
           }
          if (!currentValue && component.multiple){
            currentValue=[]
          }
          if (currentValue && (Array.isArray(currentValue)) && !component.multiple) {
            currentValue = currentValue.join(", ");
          }

          return (
            <Grid item xs={component.field_xs} key={index}>
              <FormControl fullWidth disabled={component.readonly} error={error}>
              <InputLabel id="demo-simple-select-label">
                <Tooltip title={t(component.label)} ><span style={{ color: "black" }}>{t(component.field, { defaultValue: component.label })}</span></Tooltip>
                {required && <span> * </span>}
                {additionalText}
              </InputLabel>
                <Select
                  error = {error}
                  labelId="demo-simple-select-label"
                  value={currentValue}
                  multiple={component.multiple}
                  onChange={(event) => {
                    const selectedValue = event.target.value;
                    const selectedOption = options.find((opt:any) => opt.value === selectedValue);
                    setDropdownLabel(selectedOption?.label);
                    handleFieldChange(component.field, selectedValue,selectedOption?.label ,"select");
                  }}
                  MenuProps={{
                    PaperProps: {
                      style: {
                        overflowY: "auto",
                        maxWidth:300
                      },
                    },
                  }}
                >
                  {options.map((option: any, idx: number) => (
                    <MenuItem key={idx} value={option.value} style={{
                      whiteSpace: 'normal',
                    }}>{option.label}</MenuItem>
                  ))}
                  {!isCurrentValueInOptions && currentValue && !component.multiple && ( 
                    <MenuItem value={currentValue}>{currentValue}</MenuItem>
                  )}
                </Select>
                {error && <FormHelperText>{component.label} is required</FormHelperText>}
              </FormControl>
            </Grid>
          )
        case "text":
          if(component.field==='groupid')
            return null;
          return (
            <Grid item xs={component.field_xs} key={index}>
              <FormControl fullWidth disabled={component.readonly} error={error}>
              <InputLabel id="demo-simple-select-label">
                <Tooltip title={t(component.label)} ><span style={{ color: "black" }}>{t(component.field, { defaultValue: component.label })}</span></Tooltip>
                {required && <span> * </span>}
                {additionalText}
              </InputLabel>
                <TextField
                  error = {error}
                  disabled = {component.readonly}
                  multiline = {component.textArea}
                  rows={component.maxRows}
                  size="small"
                  placeholder={t(component.placeholder)}
                  inputProps={{ maxLength: component.maxLen || undefined, "data-testid": "content-input" }}
                  value={currentValue}
                  onChange={(event) => handleFieldChange(component.field, event.target.value,"","")}
                />
                {error && <FormHelperText>{component.label} is required</FormHelperText>}
              </FormControl>
            </Grid>
          );
          case "checkbox":

          return (
            <Grid item xs={component.field_xs} key={index}>
              <FormControl fullWidth disabled={component.readonly} error={error}>
              <InputLabel id="demo-simple-select-label">
                <Tooltip title={t(component.label)} ><span style={{ color: "black" }}>{t(component.field, { defaultValue: component.label })}</span></Tooltip>
                {required && <span> * </span>}
                {additionalText}
              </InputLabel>
                <Checkbox
                  inputProps={{ "data-testid": "checkbox-input" } as any} 
                style={{ marginRight: 500 }}
                icon = {<CheckBoxOutlineBlank fontSize="small" />}
                checkedIcon = {<CheckBox fontSize="small" />}
                  checked={component.label!=="Inactive" ? currentValue === "Yes" : currentValue} 
                  onChange={(event) => handleFieldChange(component.field, component.label!=="Inactive"?event.target.checked ? "Yes" : "No" : event.target.checked,"" ,"")}
                />
                {error && <FormHelperText>{component.label} is required</FormHelperText>}
              </FormControl>
            </Grid>
          );

          case "radio":
            return(
              <Grid item xs={component.field_xs} key={index}>
                <FormControl fullWidth disabled={component.readonly} error={error}>
                <InputLabel id="demo-simple-select-label">
                <Tooltip title={t(component.label)} ><span style={{ color: "black" }}>{t(component.field, { defaultValue: component.label })}</span></Tooltip>
                {required && <span> * </span>}
                {additionalText}
              </InputLabel>
                  <RadioGroup
                    aria-labelledby="demo-controlled-radio-buttons-group"
                    name="controlled-radio-buttons-group"
                    value={currentValue}
                    onChange={(event) => handleFieldChange(component.field, event.target.value,"","")}
                  >
                    {options.map((option:any) => (
                      <div key={option.value} style={{ display: 'flex', alignItems: 'center' }}>
                        <Radio
                          value={option.value}
                        />
                        <span style={{ color: component.readonly ? 'grey' : 'black' }}>{option.label}</span>
                      </div>
                    ))}
                  </RadioGroup>
                {error && <FormHelperText>{component.label} is required</FormHelperText>}
                </FormControl>
              </Grid>
            )
          
          case "date":
          return (
            <Grid item xs={component.field_xs} key={index}>
              <FormControl fullWidth disabled={component.readonly} error={error}>
              <InputLabel id="demo-simple-select-label">
                <Tooltip title={t(component.label)} ><span style={{ color: "black" }}>{t(component.field, { defaultValue: component.label })}</span></Tooltip>
                {required && <span> * </span>}
                {additionalText}
              </InputLabel>
                <LocalizationProvider dateAdapter={AdapterDayjs}>
                {/* <span onClick={(ev) => {setDateopen((prev) => !prev)}}> */}
                <DatePicker
                value={currentValue ? dayjs(currentValue) : null}
                format="DD/MMM/YYYY"
                readOnly={component.readonly}
                // open={dateopen}
                // onOpen={() => setDateopen(true)}
                // onClose={() => setDateopen(false)}
                slotProps={{
                  field: { clearable: true },
                  textField: { placeholder: t(component.placeholder) ,disabled: component.readonly},
                }}
                slots={{
                  clearIcon:HighlightOffOutlinedIcon,
                  openPickerIcon:CalendarMonthOutlinedIcon,
                }}
                onChange={(newValue) => handleFieldChange(component.field, newValue,"","")}
                />
                {/* </span> */}
                </LocalizationProvider>
                {error && <FormHelperText>{component.label} is required</FormHelperText>}
              </FormControl>
            </Grid>
          );
        default:
          return null;
      }
    });
  };

  return (
    <>
      <div className='application-inner-page'>
        <Box className='custom-bread-crumb'>
          <Stack>
            <div className="custom-bread-crumb-list">
              <Breadcrumbs aria-label="breadcrumb" separator={<NavigateNextIcon fontSize="small" />}>
                <Links href="/applicationdetails">{t("application")}</Links>
                <Typography data-testid="breadcrumb-edit-app">{t("edit_app")}</Typography>
              </Breadcrumbs>
            </div>
          </Stack>
        </Box>
      </div>
      <div className="application_addform">
        <Box className='display-flex'>
          <Grid container className='form-group innerpage-container-content '>
          <Stack
                  direction={{ xs: 'column', sm: 'row' }}
                  alignItems="center"
                  justifyContent="space-between" 
                  className="mb-16 ml-8 page-title"
                  sx={{ width: '100%' }} 
                >
                  <Typography variant='h6'>{t("edit_app")}</Typography>

                </Stack>
            {renderFormComponents(fieldsdata)}
            <Grid item xs={12} className="page-form-buttons mb-0 " style={{ paddingTop: "50px" }}>
              {(isFormModified) && <div style={{ fontSize: '12px', color: 'grey', position: 'relative', bottom: '-3px', right: '10px', width: '100%', textAlign: 'right', }}>{t("noDataUpdatedMessage")}</div>}
              <Grid item className='float-right m-t-8 mb-0 '>
                <Stack spacing={2} direction="row">

                  <Button variant="text" size="small" href="/">{t("cancel")}</Button>

                  <Button
                    variant="contained"
                    size="small"
                    onClick={()=>!inactiveAlert?handleSubmit():setAlertOpenCancelDialog(true)}
                  >
                    {t("save")}
                  </Button>
                </Stack>
              </Grid>
            </Grid>
          </Grid>
        </Box>
        <Dialog 
      sx={{
        '.MuiDialog-paper': { width: '600px',height:"150px" }
      }}
        open={alertOpenCancelDialog}
        onClose={handleAlertCancelClose}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
        <DialogTitle id="alert-dialog-title">{t("Confirm Inactive")}</DialogTitle>
        <DialogContent>
          <DialogContentText id="alert-dialog-description" sx={{textAlign:"center"}}>
          {t('makeRecordInactive')}
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleAlertCancelClose} color="primary">
            {t('No')}
          </Button>
          <Button variant="contained"
          size="small" onClick={handleAlertCancelConfirm} color="primary" autoFocus>
            {t('Yes')}
          </Button>
        </DialogActions>
      </Dialog>
      </div>
    </>
  );
};

export default EditApplication;