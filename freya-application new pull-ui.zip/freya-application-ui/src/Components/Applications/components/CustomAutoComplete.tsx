import { CheckBox, CheckBoxOutlineBlank } from "@mui/icons-material";
import {
  Autocomplete,
  AutocompleteChangeDetails,
  AutocompleteChangeReason,
  AutocompleteProps,
  AutocompleteRenderOptionState,
  Checkbox,
  Chip,
} from "@mui/material";
import { useEffect, useState } from "react";

interface ComponentProps extends AutocompleteProps<any, any, any, any, any> {

  valuePrimitive?: boolean;
  labelField?: string;
  valueField?: string;
  multipleChip?: boolean;
  onChange: (
    event: React.SyntheticEvent<Element, Event>,
    value: any,
    reason: AutocompleteChangeReason,
    details?: AutocompleteChangeDetails<any> | undefined
  ) => void;
}

const CustomAutoComplete: React.FC<ComponentProps> = (props) => {
  const {
    valuePrimitive,
    valueField,
    labelField,
    onChange,
    multipleChip,
    ...otherProps
  } = props;
  const initValue = props.multiple ? [] : null;
  const [actualValue, setActualValue] = useState(initValue);

  const handleValueChange = (
    event: React.SyntheticEvent<Element, Event>,
    value: any,
    reason: AutocompleteChangeReason,
    details?: AutocompleteChangeDetails<any> | undefined
  ) => {
    // if (props.multiple) {
    //   const valueNew =
    //     valuePrimitive && valueField
    //       ? value.map((item: any) => item[valueField]) || []
    //       : value;
    //   onChange(event, valueNew, reason, details);
    // } else {
    //   if (valuePrimitive && valueField) {
    //     const valueNew = value ? value?.[valueField] : null;
    //     onChange(event, valueNew, reason, details);
    //   } else {
    //     onChange(event, value, reason, details);
    //   }
    // }
    if (valuePrimitive && valueField) {
      if (props.multiple) {
        const primitiveValueArr = value
          ? value.map((item: any) => item[valueField])
          : [];
        onChange(event, primitiveValueArr, reason, details);
      } else {
        const primitiveValue = value ? value?.[valueField] : null;
        onChange(event, primitiveValue, reason, details);
      }
    } else {
      onChange(event, value, reason, details);
    }
  };

  useEffect(() => {
    let valueNew = props.multiple ? props.value ?? [] : props.value ?? null;
    if (valuePrimitive && valueField) {
      if (props.multiple) {
        if (props.value?.length) {
          const valueArr = props.options?.filter((item) =>
            props.value.includes(item[valueField])
          );
          valueNew = valueArr ?? [];
        } else {
          valueNew = [];
        }
      } else {
        if (props.value !== null) {
          const valueObj = props.options?.find(
            (item) => item[valueField] === props.value
          );
          valueNew = valueObj ?? null;
        } else {
          valueNew = null;
        }
      }
    }
    setActualValue(valueNew);
  }, [props.value, props.options]);

  const sx = {
    "& .MuiOutlinedInput-root": {
      padding: 0,
      // border: 1,
      borderColor: "#ced4da",
    },
    "& .MuiOutlinedInput-root .MuiAutocomplete-input": {
      border: "none",
      paddingLeft: "4px!important",
    },
    "& .MuiFormControl-root .MuiInputBase-root input:focus": {
      outline: "none !important",
    },
  };
  const icon = <CheckBoxOutlineBlank fontSize="small" />;
  const checkedIcon = <CheckBox fontSize="small" />;
  const defaultRenderOption = (
    props: React.HTMLAttributes<HTMLLIElement>,
    option: any,
    { selected }: AutocompleteRenderOptionState
  ) => {
    return (
      <li {...props} key={option.id}>
        <Checkbox
          icon={icon}
          checkedIcon={checkedIcon}
          style={{ marginRight: 8 }}
          checked={selected}
        />
        {labelField && option[labelField]}
      </li>
    );
  };

  return (
    <>
      {otherProps.multiple && labelField ? (
        <Autocomplete
          {...otherProps}
          sx={{
            ...sx,
            ...otherProps.sx,
          }}
          value={actualValue}
          onChange={handleValueChange}
          renderTags={(selectedOptions: any) => {
            if (!multipleChip) {
              return <Chip label={selectedOptions?.length + " selected"} />;
            }
            return <></>;
          }}
          renderOption={otherProps.renderOption || defaultRenderOption}
        />
      ) : (
        <Autocomplete
          {...otherProps}
          sx={{
            ...sx,
            ...otherProps.sx,
          }}
          className="autocomplete-custom"
          value={actualValue}
          onChange={handleValueChange}
        />
      )}
    </>
  );
};

export default CustomAutoComplete;
