import CloseIcon from '@mui/icons-material/Close';
import { Button, Dialog, DialogActions, DialogContent, DialogProps, DialogTitle, Grid, IconButton, Stack, Typography } from "@mui/material";
import Warningimg from '../assets/images/message-warning.svg';

export interface IProps {
    children?: JSX.Element[] | JSX.Element;
}

interface IDialogProps extends IProps {
    openDialog: boolean;
    title: string;
    content?: string;
    isDeleteDialog: boolean;
    handleSecondaryBtn?: () => void;
    secondaryBtnName?: string;
    handlePrimaryBtn?: (event: any) => void;
    primaryBtnName?: string;
    handleCloseBtn?: () => void;
    maxWidth?: DialogProps['maxWidth'];
    disabledPrimaryBtn?: boolean;
    containerStyle?: string;
    formControl?: boolean;
    dialogPaperWidth?: string | number
}

const CommonDialog = (props: IDialogProps): JSX.Element => {

    const submit = (event: React.FormEvent<HTMLFormElement>) => {
        event.preventDefault();
        event.stopPropagation();
        props.handlePrimaryBtn && props.handlePrimaryBtn(event)
    }

    return (
        <Dialog
            sx={{
                ' .MuiDialog-paper': props.dialogPaperWidth ? { maxWidth: props.dialogPaperWidth } : {},
            }}
            className={`dialog-customization ${props.containerStyle}`} fullWidth={true} maxWidth={props.maxWidth || 'xs'} open={props.openDialog}>
            <DialogTitle sx={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                <h5>{props.title}</h5>
                {
                    props.handleCloseBtn && (<IconButton onClick={props.handleCloseBtn}>
                        <CloseIcon />
                    </IconButton>)
                }
            </DialogTitle>
            {props.formControl ? 
                <form autoComplete="off" onSubmit={submit}>
                    <DialogContent className='form-group'>
                      
                            <Grid item xs={12} >
                                <>
                                    {props.content &&
                                    <Typography variant="subtitle2" sx={{ my: 2 }} className="alert-notify-text text-center" dangerouslySetInnerHTML={{ __html: `${props.content}` }}></Typography>
                                    }
                                </>
                            </Grid>
                            <Grid item xs={12} >
                                {props.children}
                            </Grid>
                        
                        <Stack   direction={{ xs: 'column', sm: 'row' }} alignItems="center">
                        </Stack>
                    </DialogContent>
                    <DialogActions>
                        <>
                            {
                                props.handleSecondaryBtn && (<Button variant="text"  onClick={props.handleSecondaryBtn}>{props.secondaryBtnName}</Button>)
                            }
                            {
                                props.handlePrimaryBtn && (<Button variant="contained"  disabled={props.disabledPrimaryBtn || false} type="submit">{props.primaryBtnName}</Button>)
                            }
                        </>
                    </DialogActions>
                </form> :
                <>
                    <DialogContent className='form-group'>
                        
                            <Grid  item xs={12}>
                                <>
                                    {props.content &&
                                    <Typography variant="subtitle2" sx={{ my: 2 }} className="alert-notify-text text-center" dangerouslySetInnerHTML={{ __html: `${props.content}` }}></Typography>
                                    }
                                </>
                            </Grid>
                            <Grid item xs={12} >
                                {props.children}
                            </Grid>
                         
                        <Stack  direction={{ xs: 'column', sm: 'row' }} alignItems="center">
                        </Stack>
                    </DialogContent>
                    <DialogActions>
                        <>
                            {
                                props.handleSecondaryBtn && (<Button variant="text"  onClick={props.handleSecondaryBtn}>{props.secondaryBtnName}</Button>)
                            }
                            {
                                props.handlePrimaryBtn && (<Button variant="contained"  disabled={props.disabledPrimaryBtn || false} onClick={props.handlePrimaryBtn}>{props.primaryBtnName}</Button>)
                            }

                        </>
                    </DialogActions></>
            }

        </Dialog>
    )
}

export default CommonDialog