import {
  Box,
  Button,
  Chip,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  Link,
  Step,
  StepLabel,
  Stepper,
  Typography,
} from "@mui/material";
import React, { useContext, useEffect, useRef, useState } from "react";
import { useTranslation } from "react-i18next";
import Row, {
  IApplicationData,
  Product,
  useLazyTabs,
  accessToken,
} from "../../../types";
import { useNavigate, useParams, useSearchParams } from "react-router-dom";
import LinkProducts from "./LinkedProducts";
import LinkCountry, { FormTypes } from "./LinkCountry";
import { useForm } from "react-hook-form";
import LinkSection from "./LinkSection";
import { GridRowSelectionModel, esES } from "@mui/x-data-grid-premium";
import { RowContext } from "../../../App";
import service from "../../../Services/apiheader";
import Cookies from "js-cookie";
import { useSnackbar } from "notistack";
import {
  getProductCategoryId,
  getProductFamilyId,
  getProductPhaseId,
  getProductTypeId,
} from "../../../apis/apiFunctions";
import _ from "lodash";



export interface LinkSectionRef {
  getFormatCheckedValues: (
    productId: any
  ) => Record<string, Record<string, string[]>>;
}

function AddApplicationsGrid() {
  const {
    selectedRow,
    setIsAdded,
    applicationIdentifier,
    setApplicationIdentifier,
    setIsEdited,
    activeRows,
  } = useContext(RowContext);
  const { t } = useTranslation();
  const steps = [
    {
      id: 0,
      label: t("Select Products"),
      description: "Products",
      conent: "linkProduct",
    },
    {
      id: 1,
      label: t("Choose Countries"),
      description: "Region and Country",
      conent: "linkCountry",
    },
    {
      id: 2,
      label: t("Details to Register"),
      description: "",
      conent: "detailsToRegister",
    },
  ];
  const [rowSelectionModel, setRowSelectionModel] =
    useState<GridRowSelectionModel>([]);
  const { id } = useParams();
  const navigate = useNavigate();
  const linkSectionRef = useRef<LinkSectionRef>(null);

  const [basicInfo, setBasicInfo] = useState<FormTypes>();
  const { activeStep, handleTabClick, renderedTabs } = useLazyTabs(
    steps,
    id ? 2 : undefined
  );

  const {  setChecked, error } = useContext(RowContext);
  const [currentApplication, setCurrentApplication] = useState<any>();
  const [masterData, setMasterData] = useState<any>();
  const { enqueueSnackbar } = useSnackbar();
  const [alertMessage, setalertMessage] = useState("");
  const [byPassAddDupRecord, setbyPassAddDupRecord] = useState(false);
  const [dupcountries, setdupcountries] = useState<(string | undefined)[]>([]);
  const [showMore, setShowMore] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  let currentApplicationTemp: any;
  const formMethods = useForm<FormTypes>({
    mode: "onSubmit",
    reValidateMode: "onSubmit",
  });

  const fetchApplicationData = async () => {
    const response = await service.get(`application/v1/display/${id}`, {
      headers: {
        "X-TenantID": Cookies.get("USER_TENANT_ID"),
      },
    });
    const data = response.data.data;
    setMasterData(data);
    currentApplicationTemp = data.applicationdata;
    const cell = JSON.parse(sessionStorage.getItem("CellData") || "{}");
    setCurrentApplication(cell.applicationData);
  };

  useEffect(() => {
    if (id && id != "multiProduct") fetchApplicationData();
  }, [id]);

  const productSelectId = id ? currentApplication?.productId : undefined;
  useEffect(() => {
    setRowSelectionModel([productSelectId]);
  }, [productSelectId]);

  const linkProductsRef = useRef<{ validateSelection: () => boolean }>(null);


  const tabs = [
    {
      id: 0,
      content: (
        <LinkProducts
          ref={linkProductsRef}
          rowSelectionModel={rowSelectionModel}
          setRowSelectionModel={setRowSelectionModel}
        />
      ),
    },
    {
      id: 1,
      content: (
        <LinkCountry
          productId={rowSelectionModel[0] as string}
          formMethods={formMethods}
          multiProduct={rowSelectionModel.length>1}
          productNames={selectedRow?.map((row) => row.productName) || []}
        />
      ),
    },
    {
      id: 2,
      content: (
        <LinkSection
          ref={linkSectionRef}
          productId={rowSelectionModel[0] as string}
          basicInfo={basicInfo}
          currentApplication={currentApplication}
          multiProduct={rowSelectionModel.length>1}
          products={
            selectedRow?.map((row) => ({
              id: row.id,
              name: row.productName,
            })) || []
          }
        />
      ),
    },
  ];


  const handleBack = () => {
    if (activeStep > 0) {
      handleTabClick(activeStep - 1);
    }
  };

  const [openCancelDialog, setOpenCancelDialog] = useState(false);

  const handleCancel = () => {
    if (!id && Array.isArray(selectedRow) && selectedRow.length > 0) {
      setOpenCancelDialog(true);
      setalertMessage(t("confirmCancelMessage"));
    } else {
      navigate("/applicationdetails");
    }
  };

  const handleCancelConfirm = () => {
    setOpenCancelDialog(false);
    setalertMessage("");
    if (byPassAddDupRecord) {
      handleNext();
    } else {
      navigate("/applicationdetails");
    }
  };

  const handleCancelClose = () => {
    setOpenCancelDialog(false);
    setbyPassAddDupRecord(false);
    setalertMessage("");
  };

  const handleSave = async () => {
    if (isSubmitting || !selectedRow) return;
    setIsSubmitting(true);

    try {
      // const formatCheckedValues = linkSectionRef.current?.getFormatCheckedValues();
      const formValues = formMethods.getValues();
      const ptype = formValues?.procedureType?.code ?? ""; // Ensure procedureType is not undefined, default to empty string if undefined

      const countryDataList = await Promise.all(
        selectedRow.map(async (row, index) => {
          const productPhaseId = await getProductPhaseId(
            row?.productPhase ?? ""
          );
          const productCategoryId = await getProductCategoryId(
            row?.productCategory ?? ""
          );
          const productFamilyId = await getProductFamilyId(row?.productFamily ?? "");
          const productTypeId = await getProductTypeId(row?.productType ?? "");
          const formatCheckedValues =
            linkSectionRef.current?.getFormatCheckedValues(row.id);
          let appData = {
            productId: row.id,
            productType: productTypeId || "",
            productName: row?.productName || "",
            productPhase: productPhaseId || "",
            productCategory: productCategoryId,
            productFamily: productFamilyId,
            producerType: formValues.procedureType?.code ?? "", // Fallback to empty string if undefined
            applicationType: formValues.applicationType?.value ?? "",
            formatType: formValues.formatType?.value ?? "",
            region: formValues.region?.value ?? "",
            country:
            ptype === "" ||
            formValues.procedureType?.code === "ProcedureType_PCT00006" || // National Procedure
            formValues.procedureType?.code === "ProcedureType_PCT00014" || // Jordan Procedure
            formValues.procedureType?.code === "ProcedureType_PCT00015" || // Company Registration / Tender
            (productPhaseId === 'ProductPhase_PDPS00001' && formValues.procedureType?.code === "ProcedureType_PCT00003") // Centralised Procedure
      ? Array.isArray(formValues.country)
       ? formValues.country?.map((item) => item.value)
       : []
      : [formValues.rmsCountry?.value ?? formValues.lmsCountry?.value ?? ""],
      
            regionName: formValues.region?.value || "",
            applicationName: formValues?.applicationName || "",
            applicationId: formValues?.applicationId || "",
            applicationNumber: formValues?.applicationNumber || "",
            procedureNumber: formValues?.procedureNumber || "",
            registrationId: formValues?.registrationId || "",
            countryIdentifier:
              formValues.cmsCountry?.length ||
              formValues.countryIdentifier?.includes("CMS")
                ? "CMS"
                : formValues.msCountry?.length ||
                  formValues.countryIdentifier?.includes("MS")
                ? "MS"
                : formValues.mscCountry?.length ||
                  formValues.countryIdentifier?.includes("MSC")
                ? "MSC"
                : "",
            dossierIdentifier: formValues.dossierIdentifier || "",
            eIdentifier: formValues.eIdentifier || "",
            eSubIdentifier: formValues.eSubIdentifier || "",
            status: "Active",
            countryNames:
            ptype === "" ||
            formValues.procedureType?.code === "ProcedureType_PCT00006" || // National Procedure
            formValues.procedureType?.code === "ProcedureType_PCT00014" || // Jordan Procedure
            formValues.procedureType?.code === "ProcedureType_PCT00015" || // Company Registration / Tender
            (productPhaseId === 'ProductPhase_PDPS00001' && formValues.procedureType?.code === "ProcedureType_PCT00003") // Centralised Procedure
      ? Array.isArray(formValues.country)
       ? formValues.country?.map((item) => item.value)
       : [] 
      : [formValues.rmsCountry?.value ?? formValues.lmsCountry?.value ?? ""],
            memberStates: formValues.cmsCountry?.length
              ? formValues.cmsCountry.map((item) => item.value)
              : formValues.msCountry?.length
              ? formValues.msCountry.map((item) => item.value)
              : formValues.mscCountry?.map((item) => item.value) || [],
            msCountryCode: formValues.cmsCountry?.length
              ? formValues.cmsCountry.map((item) => item.value)
              : formValues.msCountry?.length
              ? formValues.msCountry.map((item) => item.value)
              : formValues.mscCountry?.map((item) => item.value) || [],

            waveInfo: [],
            disabledMS: [],
            eCTDReceptionNumber: formValues?.eCTDReceptionNumber ?? "",
          };

          return (appData.countryNames || []).map((countryName, index) => ({
            application_identifier:
              appData.productId +
              "_" +
              countryName +
              "_" +
              Date.now().toString(36),
            applicationdata: {
              ...appData,
              countryNames: countryName,
              country: Array.isArray(appData.country) ? appData.country[index] : appData.country, 
              sectionTree: { ...formatCheckedValues },
            },
            created_by: Cookies.get("USER_EMAIL"),
            updated_by: Cookies.get("USER_EMAIL"),
            domain_id: Cookies.get("DOMAIN"),
          }));
          
        })
      );
      console.log(countryDataList);
      await handleSaveData(countryDataList.flat());
    } catch (error) {
      console.error("Error saving application data:", error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleSaveData = async (countryDataList: any) => {
    try {
      const response = await service.post(
        "application/v1/addition",
        countryDataList,
        {
          headers: {
            "X-TenantID": Cookies.get("USER_TENANT_ID"),
          },
        }
      );

      setIsAdded(true);
      setChecked({});
      setApplicationIdentifier({ label: "", value: "" });

      if (response.data.status === 200) {
        enqueueSnackbar(t("AddApplicationSuccessTip"), {
          variant: "success",
          anchorOrigin: { vertical: "top", horizontal: "center" },
        });
        navigate("/applicationdetails");
      }
    } catch (error) {
      enqueueSnackbar(t("AddApplicationFailureTip"), {
        variant: "error",
        anchorOrigin: { vertical: "top", horizontal: "center" },
      });
      console.error("Error:", error);
    }
  };

  const removeUndefined = (obj: Record<string, any>) => {
    return Object.fromEntries(
      Object.entries(obj || {}).filter(
        ([_, value]) => value !== undefined && value !== "" && !(Array.isArray(value) && value.length === 0)
      )
    );
  };

  // useEffect(() => {
  //   if (linkSectionRef.current) {
  //     beforeCheckedRef.current = linkSectionRef.current.getFormatCheckedValues(currentApplication.productId);
  //     console.log("Initial Checked Values:", beforeCheckedRef.current);
  //   }
  // }, [linkSectionRef, currentApplication]); // Run when `currentApplication` changes
  
  // useEffect(() => {
  //   if (linkSectionRef.current && currentApplication?.productId) {
  //     beforeCheckedRef.current = linkSectionRef.current.getFormatCheckedValues(currentApplication.productId);
  //     console.log("Initial Checked Values:", beforeCheckedRef.current);
  //   }
  // }, [linkSectionRef, currentApplication]);

  useEffect(() => {
    if (linkSectionRef.current && currentApplication?.productId) {
      const initialValues = linkSectionRef.current.getFormatCheckedValues(currentApplication.productId);
      beforeCheckedRef.current = _.cloneDeep(initialValues);
      console.log("Initial Checked Values:", beforeCheckedRef.current);
    }
  }, [linkSectionRef, currentApplication]);
  
  const beforeCheckedRef = useRef<any>(null);
  const [isFormModified, setIsFormModified] = useState(false);


  const handleUpdate = async () => {
    if (!linkSectionRef.current) return;

    const formatCheckedValues = linkSectionRef.current?.getFormatCheckedValues(
      currentApplication.productId
    );

    // const cleanedDataRecord = removeUndefined(beforeCheckedRef.current);
    // const cleanedrecordDetails = removeUndefined(formatCheckedValues);


    // console.log("Before Checked Values:",  cleanedDataRecord);
    // console.log("After Checked Values:", cleanedrecordDetails);
  
    // if (
    //   beforeCheckedRef.current === null ||
    //   beforeCheckedRef.current === "" ||
    //   Object.keys(cleanedDataRecord).length === 0 ||  // Added check for empty object
    //   (_.isObject(beforeCheckedRef.current) && _.isEmpty(beforeCheckedRef.current))
    // )
    //  {
    //   beforeCheckedRef.current = formatCheckedValues;
    //   console.warn("beforeCheckedRef was null or empty, initialized now.");
    // }
    // // Compare before and after checked values
    // const isModified = !_.isEqual(cleanedDataRecord, cleanedrecordDetails);
  
    // if (!isModified) {
    //   setIsFormModified(true);
    //   return;
    // }
  
    // setIsFormModified(false);

    
  // First ensure beforeCheckedRef has initial values if empty
  if (
    beforeCheckedRef.current === null ||
    beforeCheckedRef.current === "" ||
    Object.keys(beforeCheckedRef.current || {}).length === 0 ||
    (_.isObject(beforeCheckedRef.current) && _.isEmpty(beforeCheckedRef.current))
  ) {
    // beforeCheckedRef.current = formatCheckedValues;
    // console.warn("beforeCheckedRef was null or empty, initialized now.");
    const initialValues = linkSectionRef.current?.getFormatCheckedValues(currentApplication.productId);
    beforeCheckedRef.current = _.cloneDeep(initialValues); // Make a deep copy to ensure no reference issues
    console.warn("beforeCheckedRef was null or empty, initialized with:", beforeCheckedRef.current);  
  }

  // Clean both objects to remove undefined values
  const cleanedDataRecord = removeUndefined(beforeCheckedRef.current);
  const cleanedrecordDetails = removeUndefined(formatCheckedValues);

  console.log("Before Checked Values:", cleanedDataRecord);
  console.log("After Checked Values:", cleanedrecordDetails);

  // Deep comparison of the cleaned objects
  const isModified = !_.isEqual(cleanedDataRecord, cleanedrecordDetails);

  if (!isModified) {
    setIsFormModified(true);
    return; // Exit early if no modifications detected
  }

  setIsFormModified(false);


       const dynamicField = {
      ...masterData,
      applicationdata: {
        ...currentApplication,
        sectionTree: formatCheckedValues,
      },
      updated_by: Cookies.get("USER_EMAIL"),
    };
    if (!currentApplication) return;

    const response = await service.put(
      `application/v1/modification/${id}`,
      dynamicField,
      {
        headers: {
          "X-TenantID": Cookies.get("USER_TENANT_ID"),
        },
      }
    );
    setChecked({});
    enqueueSnackbar("Application updated successfully", {
      variant: "success",
      anchorOrigin: { vertical: "top", horizontal: "center" },
    });
    setIsEdited(true);
    navigate("/applicationdetails");
  };

  const validateForDuplicateRecords = async () => {
    const response = await service.get(
      `application/v1/display-all/refresh-products`,
      {
        params: {
          page: 0,
          size: 1000,
          active: true,
          inactive: false,
          disable: false,
        },
        headers: {
          "X-TenantID": Cookies.get("USER_TENANT_ID"),
          Authorization: `Bearer ${accessToken}`,
          globalFilters: JSON.stringify([]),
        },
      }
    );
    const data = response.data;

    const parsedContent = data.data.content?.map(
      (item: { applicationdata: string }) => {
        try {
          // Parse the applicationdata JSON string into an object
          const parsedApplicationData = JSON.parse(item.applicationdata);

          // Return a new object with the parsed applicationdata
          return JSON.parse(item.applicationdata);
        } catch (error) {
          console.error("Error parsing applicationdata for item:", item, error);

          // Handle invalid JSON: Return the item as is or modify according to your needs
          return item;
        }
      }
    );

    const duplicatecountries: (string | undefined)[] = [];
    const formValues = formMethods.getValues();
    let finalrows: any[] = [];
    const filteredRows = parsedContent?.filter(
      (item: {
        producerType: string | undefined;
        productName: string | undefined;
        applicationdata: {
          productName: string | undefined;
          producerType: string | undefined;
        };
      }) => {
        try {
          //const parsedData = JSON.parse(item.applicationdata);

          // Ensure parsedData contains the fields you need
          return (
            item.productName === formValues.productName?.label &&
            item.producerType === formValues.procedureType?.value
          );
        } catch (error) {
          console.error("Error parsing applicationdata for item:", item, error);
          return false; // Exclude items with invalid applicationdata
        }
      }
    );
    if (Array.isArray(formValues.country)) {
      formValues.country?.forEach((element) => {
        filteredRows?.forEach((row: any) => {
          if (row.country === element.value) {
            //finalrows.push(row);
            duplicatecountries.push(element.label);
          }
        });
      });
    }
    // filteredRows.forEach((row:any)=>{
    //   if(row.lms === formValues.lmsCountry?.value){
    //    //finalrows.push(row);
    //    duplicatecountries.push(formValues.lmsCountry?.label);
    //   }else if( row.rms === formValues.rmsCountry?.value){
    //     duplicatecountries.push(formValues.rmsCountry?.label);
    //   }
    // })
    // if (Array.isArray(formValues.msCountry)) {
    //   formValues.msCountry.forEach(element => {
    //     filteredRows.forEach((row: any) => {
    //       row.ms.forEach((mscountry: any) => {
    //         if (mscountry === element.value) {
    //           //finalrows.push(row);
    //           duplicatecountries.push(element.label);
    //         }
    //       })
    //     })
    //   });
    // }
    // const mergedmscountryobject = filteredRows[0].msCountryCode.reduce((obj: { [x: string]: any; }, key: string | number, index: string | number) => {
    //   obj[key] = filteredRows[0].memberStates[index];
    //   return obj;
    // }, {});

    if (Array.isArray(formValues.cmsCountry)) {
      formValues.cmsCountry?.forEach((element) => {
        filteredRows?.forEach((row: any) => {
          if (Array.isArray(row.msCountryCode)) {
            const mergedmscountryobject = row.msCountryCode.reduce(
              (
                obj: { [x: string]: any },
                key: string | number,
                index: string | number
              ) => {
                obj[key] = row.memberStates[index];
                return obj;
              },
              {}
            );
            for (const key in mergedmscountryobject) {
              if (key === element.value) {
                duplicatecountries.push(mergedmscountryobject[key]);
              }
            }
          }
        });
      });
    }
    if (Array.isArray(formValues.mscCountry)) {
      formValues.mscCountry?.forEach((element) => {
        filteredRows?.forEach((row: any) => {
          if (Array.isArray(row.msCountryCode)) {
            const mergedmscountryobject = row.msCountryCode.reduce(
              (
                obj: { [x: string]: any },
                key: string | number,
                index: string | number
              ) => {
                obj[key] = row.memberStates[index];
                return obj;
              },
              {}
            );
            for (const key in mergedmscountryobject) {
              if (key === element.value) {
                duplicatecountries.push(mergedmscountryobject[key]);
              }
            }
          }
        });
      });
    }

    return duplicatecountries;
  };
  


  const handleNext = async () => {
    if (activeStep === 0) {
      // Validate selection in LinkedProducts
      if (linkProductsRef.current && !linkProductsRef.current.validateSelection()) {
        return; // Stop if validation fails
      }
    }
    if (activeStep < steps.length - 1) {
      
      if (activeStep === 1) {
        const isValid = await formMethods.trigger();
        if (isValid) {
          const existingrec = await validateForDuplicateRecords();
          const uniqueArray = [...new Set(existingrec)];
          if (uniqueArray.length === 0 || byPassAddDupRecord) {
            const formValues = formMethods.getValues();
            const updatedBasicInfo = {
              ...formValues,
              [applicationIdentifier.label]: applicationIdentifier.value,
            };
            setBasicInfo(updatedBasicInfo);
            handleTabClick(activeStep + 1);
            setbyPassAddDupRecord(false);
          } else {
            let countrystring = "";
            uniqueArray.forEach((item) => {
              countrystring = countrystring + "," + item;
            });
            countrystring = countrystring.trim().slice(1);
            setOpenCancelDialog(true);
            setbyPassAddDupRecord(true);
            let allcountries = [];
            for (var i = 0; i < uniqueArray.length; i++) {
              allcountries.push(uniqueArray[i]);
            }
            setdupcountries(allcountries);
            setalertMessage(
              `Below countries have already Application with selected product and procedure.`
            );
          }
        }
      } else {
        handleTabClick(activeStep + 1);
      }
    } else {
      handleSave();
    }
    console.log(activeStep);
  };


  const isNextDisabled = () => {
    if (activeStep === 1) return !!error;

    if (activeStep === 0) {

      return rowSelectionModel.length === 0;
    }

    return false;
  };

  const visibleCountries = showMore ? dupcountries : dupcountries.slice(0, 4);
  const remainingCountriesCount = dupcountries.length - visibleCountries.length;

  return (
    <div>
      <Box>
        <Box textAlign={"center"}>
          <h4 className="list-header">{id ? t("edit_app") : t("add_app")}</h4>
        </Box>
        <Stepper activeStep={activeStep} alternativeLabel>
          {steps.map((item, index) => (
            <Step key={item.id}>
              <StepLabel>{item.label}</StepLabel>
            </Step>
          ))}
        </Stepper>
        <Box
          className="stepper-container"
          display={"flex"}
          flexDirection={"column"}
        >
          <Box className="stepper-content" flex={1}>
            {tabs.map((tab, index) => (
              <div
                key={index}
                style={{ display: activeStep === index ? "block" : "none" }}
              >
                {renderedTabs[index] && tab.content}
              </div>
            ))}
          </Box>
          {isFormModified && (
          <div
            style={{
              fontSize: "12px",
              color: "grey",
              position: "relative",
              bottom: "-3px",
              right: "10px",
              width: "100%",
              textAlign: "right",
            }}
          >
           {t("noDataUpdatedMessage")}
          </div>
        )}
          <Box
            sx={{
              marginTop: 2,
              display: "flex",
              flexDirection: "row",
              justifyContent: "flex-end",
            }}
          >
            <Button
              variant="text"
              size="small"
              type="button"
              onClick={handleCancel}
              sx={{ mr: 1 }}
            >
              
              {t("cancel")}
            </Button>
            {activeStep !== steps.length &&
              activeStep !== 0 &&
              (id === "multiProduct" || id === undefined) && (
                <Button
                  variant="outlined"
                  disabled={activeStep === 0}
                  onClick={handleBack}
                  sx={{ mr: 1 }}
                >
                  {t("back")}
                </Button>
              )}
            {activeStep === steps.length - 1 ? (
              <Button
                variant="contained"
                onClick={
                  id && id !== "multiProduct" ? handleUpdate : handleSave
                }
                disabled={isSubmitting}
              >
                {t("finish")}
              </Button>
            ) : (
              <Button
                variant="contained"
                onClick={handleNext}
                disabled={isNextDisabled()}
              >
                {t("next")}
              </Button>
            )}
          </Box>
        </Box>
      </Box>

      <Dialog
        // sx={{
        //   '.MuiDialog-paper': { width: '600px',height:"150px" }
        // }}
        open={openCancelDialog}
        onClose={handleCancelClose}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
        <DialogTitle id="alert-dialog-title">
          {byPassAddDupRecord
            ? "Duplicate Application Found"
            : t("Confirm Cancel")}
        </DialogTitle>
        {!byPassAddDupRecord ? (
          <DialogContent>
            <DialogContentText
              id="alert-dialog-description"
              sx={{ textAlign: "center" }}
            >
              {alertMessage}
            </DialogContentText>
          </DialogContent>
        ) : (
          <>
            <DialogContent>
              <Typography>{alertMessage}</Typography>
              <Box sx={{ display: "flex", flexWrap: "wrap", gap: 1, mt: 2 }}>
                {visibleCountries.map((country, index) => (
                  <Chip
                    key={index}
                    label={country}
                    style={{ backgroundColor: "white" }}
                    sx={{
                      border: "1px solid #000",
                      borderRadius: "16px",
                    }}
                  />
                ))}
              </Box>
              {remainingCountriesCount > 0 && (
                <Box sx={{ mt: 2 }}>
                  <Link
                    component="button"
                    variant="body2"
                    onClick={() => setShowMore(!showMore)}
                  >
                    {showMore
                      ? "Show less"
                      : `Show more (${remainingCountriesCount})`}
                  </Link>
                </Box>
              )}
              <Typography sx={{ mt: 2 }}>Do you want to continue?</Typography>
            </DialogContent>
          </>
        )}
        <DialogActions>
          <Button onClick={handleCancelClose} color="primary">
            {byPassAddDupRecord ? t("cancel") : t("No")}
          </Button>
          <Button
            variant="contained"
            size="small"
            onClick={handleCancelConfirm}
            color="primary"
            autoFocus
          >
            {byPassAddDupRecord ? t("next") : t("Yes")}
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
}

export default AddApplicationsGrid;