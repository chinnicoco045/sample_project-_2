import { Box, FormLabel, Grid, List, ListItemButton, Tab, Tabs, Tooltip } from "@mui/material";
import React, {
  useEffect,
  useState,
  forwardRef,
  useImperativeHandle,
  useContext,
  useMemo,  
  useRef
} from "react";
import { useTranslation } from "react-i18next";
import CheckboxTree from "react-checkbox-tree";
import {
  CheckBox,
  CheckBoxOutlineBlank,
  ExpandMore,
  IndeterminateCheckBox,
  NavigateNext,
} from "@mui/icons-material";
import Loading from "../components/Loading";
import axios from "axios";
import {  accessToken } from "../../../types";
import { RowContext } from "../../../App";
import  { GET_API } from "../../../Services/apiheader";
import { DynamicFormCompBasicJsonSchema } from "@freyr/freyr-react-common";
import {  useFormData } from "../../../hooks/useFormConfig";
import CustomViewField from "../components/CustomViewField";
import { useParams } from "react-router-dom";
import { fetchSectionProductTree } from "../../../apis/apiFunctions";

interface ComponentsProps {
  basicInfo?: any;
  productId?: string;
  currentApplication?:any;
  multiProduct:boolean;
  products:{id:string;name:string}[];
}

interface Node {
  label: string;
  value: string;
  name?: string;
  children?: Node[];
}


const LinkProduct = forwardRef((props: ComponentsProps, ref) => {
  
  const { t } = useTranslation();
  const { productId, currentApplication,multiProduct,products } = props;
  const {id}=useParams();
  const [tabValue, setTabValue] = useState<string>("");
  const { checked, setChecked ,applicationIdentifier} = useContext(RowContext);
  const [checkedForMulti, setCheckedForMulti] = useState<Record<string, Record<string, string[]>>>({});
  const [selectedProductId,setSelectedProductId]=useState(products[0]?.id);
  const [BeforeCheckedValues, setBeforeCheckedValues] = useState<Record<string, string[]>>({});
  const [AfterCheckedValues, setAfterCheckedValues] = useState<Record<string, string[]>>({});


  const [expanded, setExpanded] = useState<Record<string, string[]>>({});
  const [detailRecord, setDetailRecord] = useState<{
    formDataUrl: string;
    formName: string;
    [key: string]: any;
  } | null>();
  const [sectionTree, setSectionTree] = useState<Node[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  
  
  
  const getFormatCheckedValues = (productId:any) => {
    const sectionData = checkedForMulti[productId] ?? {};
    const keysToCheck =  Object.keys(sectionData) ;
    if(!keysToCheck.length)
       return {};
    let result: Record<string, Record<string, string[]>>[] = [];
    
    for (let key of keysToCheck) {
      const currentSectionTree = sectionTree?.find((tree) => tree.name === key);
      const data = filterAndBuildTree(
        currentSectionTree?.children ?? [],
        checkedForMulti[productId]?.[key] || []
      );
      if (data) result.push(data);
    }
    return Object.assign({}, ...result);
  };

 

  const transDetailCheckedData = (
    obj: Record<string, Record<string, any>>,
    result: Record<string, string[]>,
    path = ""
  ) => {
    for (const key in obj) {
      if (Array.isArray(obj[key])) {
        obj[key].forEach((item: any) => {
          const newKey = path ? `${path}_${key}_${item}` : `${key}_${item}`;
          if (!result[path]) {
            result[path] = [];
          }
          result[path].push(newKey);
        });
      } else if (typeof obj[key] === "object") {
        transDetailCheckedData(
          obj[key],
          result,
          path ? `${path}_${key}` : key
        );
      }
    }
  };

  useEffect(() => {

    if(currentApplication){
      setSelectedProductId(currentApplication?.productId);
    const sectionTree = currentApplication?.sectionTree;
    if (sectionTree) {
      const result: Record<string, string[]> = {};
      transDetailCheckedData(sectionTree, result);
      for (let key in result) {
        if (result.hasOwnProperty(key)) {
          let value = result[key];
          result[key] = value.map(val => {
            let [parent, child, id] = val.split("_");
            if (child === id) {
              val = parent + "_" + id;
            }
            return val; // Ensure the modified value is returned
          });
        }
      }
      setChecked(result);
      setCheckedForMulti(prev => ({
        ...prev,
        [currentApplication.productId]: result
      }));
    

    }
  }
  }, [currentApplication]);


  const filterAndBuildTree = (
    treeList: any[],
    selectedNodeValues: string[]
  ): any => {
    const leafNodeValues: { name: string; value: string }[] = [];
  
    function traverseTree(nodes: any[]) {
      for (const node of nodes) {
        if (node.children && node.children.length > 0) {
          traverseTree(node.children);
        } else {
          // Store node.name and node.value separately
          // if (node.name !== undefined && node.value !== undefined) {
            leafNodeValues.push({ name: node.name, value: node.value });
          // }
        }
      }
    }
  
    traverseTree(treeList);
  
    // // Example logic: filter selectedNodeValues based on leafNodeValues
    // const filteredSelectedNodeValues = leafNodeValues.filter((node) =>
    //   selectedNodeValues.includes(node.value)
    // );

    // Ensure all selectedNodeValues are included in the result
    const allSelectedNodeValues = selectedNodeValues.map(value => {
      const node = leafNodeValues.find(node => node.value === value);
      return node ? node : { name: '', value }; // Include nodes not found in leafNodeValues
    });
  
    // Return or process filteredSelectedNodeValues as needed
    return buildSelectedNodesObject(allSelectedNodeValues);
  };
  
  

  const transformData = (data: any[]) => {
    const treeNew = data?.map((parent) => {
      const children = parent.children?.map((child: any) => {
        const childData = child.data?.map((item: any) => ({
          ...item,
          label: (
            <Tooltip title={item[child.labelPath]}>
              <div>
                {item[child.labelPath]?.length > 10 ? `${item[child.labelPath].slice(0, 10)}...` : item[child.labelPath]}
              </div>
            </Tooltip>
          ),
          value: `${parent.name}_${child.name}_${item.id}`,
        }));
        return {
          ...child,
          value: `${parent.name}_${child.id}`,
          label: t(child.displayName),
          children: childData,
        };
      });

      return {
        ...parent,
        value: parent.id,
        label: t(parent.displayName),
        children: children,
      };
    });
    return treeNew;
  };
  

  const beforeCheckedRef = useRef<any>();


  const fetchSectionTree = async (productId:any) => {
    try {
      setIsLoading(true);
      setExpanded({});
      const response=await fetchSectionProductTree(productId);
      let transformedData = response.data.data
        .map((item: any) => transformData([item])) 
        .flat();
      setSectionTree(transformedData);

      const initialCheckedState: Record<string, any> = {}; // Explicit type

      transformedData.forEach((item: { name: string }) => {
        initialCheckedState[item.name] = checkedForMulti[selectedProductId]?.[item.name] || [];
      });
      

      setBeforeCheckedValues(initialCheckedState);
      beforeCheckedRef.current = initialCheckedState;
      console.log(initialCheckedState)

      if(!id || multiProduct)
      setChecked({});
      setIsLoading(false);
    } catch (error) {
      console.error("Error fetching section tree:", error);
    }
  };


  const handleTabChange = (event: React.SyntheticEvent, newValue: string) => {
    setTabValue(newValue);
    // setDetailRecord({formDataUrl:"",formName:"",id:""});
    setDetailRecord(null);
  };

  useEffect(() => {
    setIsLoading(true);
    const id = multiProduct ? selectedProductId : productId;
    fetchSectionTree(id);
  }, [ selectedProductId, productId]);
  

  useEffect(() => {
    if (sectionTree.length > 0) {
    setTabValue(sectionTree?.[0]?.name ?? "");
    }
  }, [sectionTree]);


    useImperativeHandle(ref, () => ({
      getFormatCheckedValues: (productId: any) => getFormatCheckedValues(productId),
      // treeChanged,
      resetTreeView:() => {
        setChecked({});
        setExpanded({})
      },
    }));

    const handleProductSelection=(productId:any)=>{
      setSelectedProductId(productId);
    }

//     const handleProductSelection = (productId: string) => {
//     if (productId) {
//         setSelectedProductId(productId);
//         fetchSectionTree(productId); // Fetch the section tree for the selected product
//         setChecked(checkedForMulti[productId] || {}); // Set the checked state for the selected product
//         setTabValue(""); // Reset tab value to ensure correct section is loaded
//     }
// };


  const mateBasicInfo = [
    { label: "Selected Product(s)", key: "productName", optionKey: currentApplication?.productName  },
    { label: t("region"), key: "region",optionKey: currentApplication?.regionName },
    { label: t("procedureType"), key: "procedureType",optionKey:currentApplication?.producerType},
    { label: t("country"), key: "country",optionKey:currentApplication?.countryNames },
    { label: t("lms")+" "+t("Country"), key: "lmsCountry",optionKey:"" },
    { label: t("ms")+" "+t("Country")+"(s)", key: "msCountry",optionKey:"" },
    { label: t("rms")+" "+t("Country"), key: "rmsCountry" ,optionKey:""},
    { label: t("cms")+" "+t("Country")+"(s)", key: "cmsCountry",optionKey:"" },
    { label: t("msc")+" "+t("Country")+"(s)", key: "mscCountry",optionKey:"" },
    // { label: t(proxyNameAI), key:  applicationIdentifier.label },
    {label : t("applicationType"),key : "applicationType",optionKey:currentApplication?.applicationType},
    {label : t("applicationName"),key : "applicationName",optionKey:currentApplication?.applicationName},
    {label:t("applicationNumber"), key:"applicationNumber",optionKey:currentApplication?.applicationNumber},
    {label:t("applicationId"), key :"applicationId",optionKey:currentApplication?.applicationId},
    {label:t("procedureNumber"), key:"procedureNumber",optionKey:currentApplication?.procedureNumber},
    {label:t("registrationId"),key:"registrationId",optionKey:currentApplication?.registrationId},
    {label:t("formatType"),key:"formatType",optionKey:currentApplication?.formatType},
    {label:t("eIdentifier"), key:"eIdentifier",optionKey:currentApplication?.eIdentifier},
    {label:t("country")+"(s)",key:"countries",optionKey:""},
    {label:t("eSubmissionIdentifier"),key:"eSubIdentifier",optionKey:currentApplication?.eSubIdentifier},
    {label:t("dossierIdentifier"),key:"dossierIdentifier",optionKey:currentApplication?.dossierIdentifier},
    {label:t("eCTDReceptionNumber"),key:'eCTDReceptionNumber',optionKey:currentApplication?.eCTDReceptionNumber}
  ];
  
  const filteredMateBasicInfo = mateBasicInfo.filter(
    (item) => !(multiProduct && item.key === "productName")
  );
  

  
  const getValue = (item: { label: string; key: keyof any , optionKey : any}) => {
    const fieldValue = props.basicInfo?.[item.key];
    if(item.optionKey){
        return item.optionKey
    }
    else{
    return typeof fieldValue === 'string' ? fieldValue : (
      Array.isArray(fieldValue)
        ? fieldValue.map((item) => item.label).join(" ,")
        : fieldValue?.label ?? ""
    );
  }
  };
  
  

  const buildSelectedNodesObject = (selectedNodeValues: {name:string,value:string}[]) => {
    let result: Record<string, Record<string, string[]>> = {};
    for (let {name,value} of selectedNodeValues) {
      if(value.split("_").length === 2) {
        let [parent, id] = value.split("_");
        if (parent && id) { 
        result[parent] = result[parent] || {};
        result[parent][id] = result[parent][id] || [];
        result[parent][id].push(id);
        }
      }
      else{
        let [parent,child,id]=value.split("_");
        if (parent && child && id) { // Ensure parent, child, and id are defined
        result[parent] = result[parent] || {};
        result[parent][child] = result[parent][child] || [];
        result[parent][child].push(id);
        }
      }
    }
    return result;
  };
  const [formConfig, setFormConfig] = useState<any>([]);






const getFormConfig = async () => {
  
  try {
    if (!detailRecord?.formName) {
      throw new Error('Form name is required');
    }

    const response = await axios.post(
      `${GET_API}cm/form-manager/forms/settings`,
      {
        module: "product",
        formName: detailRecord.formName,
      },
      {
        headers: {
          Authorization: `Bearer ${accessToken}`,
          "Accept-Language": "",
        }
      }
    );

    const data = response.data.data;


    // Assuming settingsJson is an array in the response data
    const settingsJson = Array.isArray(data.settingsJson) ? data.settingsJson : JSON.parse(data.settingsJson);

    setFormConfig(settingsJson);
    // setSettingJson(settingsJson);
   
    return settingsJson;
  } catch (error) {
    console.error("Error fetching form configuration:", error);
    return []; 
  }
};

// Usage example:

useEffect(()=>{
  if(detailRecord)
  getFormConfig();
},[detailRecord]);


  
  
      const formDataUrltemp = detailRecord?.formName!=="Documents"? detailRecord?.formDataUrl.replace("${id}", detailRecord?.id ?? ""):"";
      
      const { data: formData, isFetching: formDataLoading } = useFormData(
        formDataUrltemp || "",
        !!formDataUrltemp
      );

      const documentViewFields = useMemo(() => {
        return [
          {
            label: "Document Number",
            value: detailRecord?.responseDocumentNumber,
            xs: 6,
          },
          {
            label: "Document Name",
            value: detailRecord?.responseDocumentName,
            xs: 6,
          },
          {
            label: "URL",
            value: detailRecord?.responseUrl,
          },
        ];
      }, [detailRecord]);
  

      





  return (
    <Box className="link-section wizard-tabs">
     
      <Box
        className="form-group field field-string m-l-08"
        display={"flex"}
        justifyContent={"space-between"}
      >
        <Grid container>
          {filteredMateBasicInfo?.map((item) => {
            const value = getValue(item);
            return value ? (
              <Grid item xs={3} spacing={2} marginBottom={2} key={item.key}>
                <FormLabel>
                  <span className="text-ellipsis">{item.label}</span>
                </FormLabel>
                <Tooltip title={value}>
                  <Box className="text-ellipsis">{value}</Box>
                </Tooltip>
              </Grid>
            ) : null
          })}
        </Grid>
      </Box>
      <Box  className="app" data-testId="test1">
      <Box flex={1} display="flex" flexDirection="column">
        <Box display="flex">
          {props.multiProduct && (
            <Box
              sx={{ width: 250, borderRight: "1px solid #ddd", padding: 2 }}
              data-testid="selected-products"
            >
              <Box fontWeight="normal" marginBottom={2}>
                {t("Selected Products")} ({products.length})
              </Box>
              <List>
                {products.map((product) => (
                  <ListItemButton
                  key={product.id} selected={selectedProductId === product.id} onClick={() => handleProductSelection(product.id)}  sx={{
                    "&.Mui-selected": { backgroundColor: "#e3f2fd", color: "#000" },  // Light blue
                    "&.Mui-selected:hover": { backgroundColor: "#bbdefb" },  // Slightly darker on hover
                    fontSize: '0.75rem' 
                  }}>
                     {product.name}
                 </ListItemButton>
                ))}
              </List>
            </Box>
          )}
          <Box flex={1}>
        <Tabs
          className="tabName"
          value={tabValue}
          onChange={handleTabChange}
          aria-label="basic tabs example"
        >
          {sectionTree?.map((item) => {

            return(
            <Tab label={t(item.label)} value={item.name} key={item.name} />)
})}
        </Tabs>
        <Box display={"flex"} marginTop={2} >
          <Box sx={{ flexGrow: 1, maxWidth: 400 }} data-testid='checkbox-tree'>
            {sectionTree?.map((item) => {

              const treeRoot = item;
              return treeRoot.name === tabValue ? (
                
                <Box key={treeRoot.name} className="checkBox"> 
                  <CheckboxTree
                    nodes={[treeRoot]}
                    expandOnClick
                    checkModel="all"
                    checked={checkedForMulti[selectedProductId]?.[treeRoot.name]}
                    expanded={expanded[treeRoot.name]}
                    onCheck={(value: any) => {
                      const key = treeRoot.name || "defaultKey";
                      setCheckedForMulti(prev => ({
                        ...prev,
                        [selectedProductId]: {
                          ...(prev[selectedProductId] || {}),
                          [key]: value
                        }
                      }));
                      setChecked({
                        ...checkedForMulti[selectedProductId],
                        [key]: value
                    });
                     // Store updated checked values
                     setAfterCheckedValues((prev) => ({
                      ...prev,
                      [key]: value,
                    }));
                    console.log(checkedForMulti);
                    }}
                    
                    
                    onExpand={(value: any) => {
                      const key = treeRoot.name || "defaultKey";
                      setExpanded({ ...expanded, [key]: value });
                    }}
                    onClick={(record: any) => {
                      if (!!record.children) return;
                      const recordBak: any = record;
                      const formUrl = recordBak.parent.formDataUrl;
                      const recordDetail = {
                        formDataUrl: formUrl,
                        formName: recordBak.parent.name,
                        id:recordBak.id,
                        ...recordBak.parent.children[recordBak.index],
                      };
                      setDetailRecord(recordDetail);
                    }}
                    icons={{
                      check: (
                        <CheckBox sx={{ fontSize: "20px", color: "#295ef1" }} />
                      ),
                      uncheck: (
                        <CheckBoxOutlineBlank
                          sx={{ fontSize: "20px", color: "#bfbfbf" }}
                        />
                      ),
                      halfCheck: (
                        <IndeterminateCheckBox
                          sx={{ fontSize: "20px", color: "#295ef1" }}
                        />
                      ),
                      expandClose: <NavigateNext sx={{ fontSize: "20px" }} />,
                      expandOpen: <ExpandMore sx={{ fontSize: "20px" }} />,
                      expandAll: null,
                      collapseAll: null,
                      parentClose: null,
                      parentOpen: null,
                      leaf: null,
                    }}
                  />
                </Box>
              ) : null;
            })}
          </Box>
          <Box flex={1}>
          {detailRecord ? (
                <>
                  <h1 className="list-header">{detailRecord.formName}</h1>
                  {detailRecord.formName === "Documents" ? (
                    <CustomViewField
                      fields={documentViewFields}
                    ></CustomViewField>
                  ) : (
                    <DynamicFormCompBasicJsonSchema
                      jsonData={formConfig}
                      initialFormData={
                        formData?.data.dynamicFieldJson ?? undefined
                      }
                      buttonPosition="center"
                      okKey="save"
                      cancelKey="cancel"
                      removeButtons
                      viewType={true}
                      extraState={{ productId: productId }}
                    ></DynamicFormCompBasicJsonSchema>
                  )}
                </>
              ) : null}
          </Box>
          </Box>
          </Box>
        </Box>
      </Box>
      </Box>
      <div>
      <Loading open={isLoading||  formDataLoading}></Loading>
      </div>
    </Box>
  );
});

export default LinkProduct;