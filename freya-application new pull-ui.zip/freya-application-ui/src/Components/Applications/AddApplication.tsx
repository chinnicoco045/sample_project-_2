import React, { useContext, useEffect, useState } from "react";
import Button from "@mui/material/Button";
import { styled, alpha } from "@mui/material/styles";
import Menu, { MenuProps } from "@mui/material/Menu";
import Box from "@mui/material/Box";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import Switch from "@mui/material/Switch";
import { Link } from "react-router-dom";

import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import { useTranslation } from "react-i18next";
import { RowContext } from "../../App";


export const StyledMenu = styled((props: MenuProps) => (
  <Menu
    elevation={0}
    anchorOrigin={{
      vertical: "bottom",
      horizontal: "right",
    }}
    transformOrigin={{
      vertical: "top",
      horizontal: "right",
    }}
    {...props}
  />
))(({ theme }) => ({
  "& .MuiPaper-root": {
    borderRadius: 6,
    marginTop: theme.spacing(1),
    minWidth: 180,
    color:
      theme.palette.mode === "light"
        ? "rgb(55, 65, 81)"
        : theme.palette.grey[300],
    boxShadow:
      "rgb(255, 255, 255) 0px 0px 0px 0px, rgba(0, 0, 0, 0.05) 0px 0px 0px 1px, rgba(0, 0, 0, 0.1) 0px 10px 15px -3px, rgba(0, 0, 0, 0.05) 0px 4px 6px -2px",
    "& .MuiMenu-list": {
      padding: "4px 0",
    },
    "& .MuiMenuItem-root": {
      "& .MuiSvgIcon-root": {
        fontSize: 18,
        color: theme.palette.text.secondary,
        marginRight: theme.spacing(1.5),
      },
      "&:active": {
        backgroundColor: alpha(
          theme.palette.primary.main,
          theme.palette.action.selectedOpacity
        ),
      },
    },
  },
}));

const AddApplication: React.FC = () => {
  const {
    disabledRows,
    setRows,
    isAddPrivileged,
    setShowDisabled,
    inactiveRows,
    activeRows,
    setisActiveEnabled,
    setisInactiveEnabled,
    setGridStatus,
    gridstatus,
    setPaginationobject
  } = useContext(RowContext);
  // const [disabledRows,setDisabledRows]=useState([]);
  const [checked, setChecked] = React.useState(false);
  const [Activechecked, setActivechecked] = React.useState(true);
  const [Inactivechecked, setInactivechecked] = React.useState(false);
  const { t } = useTranslation();

  // const filterRows = (disableCheked:boolean,activechecked:boolean,inactivechecked:boolean) =>{
  //   if(activechecked && !inactivechecked && !disableCheked){
  //     setRows(activeRows);
  //   }else if(!activechecked && inactivechecked && !disableCheked){
  //     setRows(inactiveRows);
  //   }else if(!activechecked && !inactivechecked && disableCheked){
  //     setRows(disabledRows);
  //   }else if(activechecked && inactivechecked && !disableCheked){
  //     setRows([...activeRows,...inactiveRows])
  //   }else if(activechecked && !inactivechecked && disableCheked){
  //     setRows([...activeRows,...disabledRows])
  //   }else if(!activechecked && inactivechecked && disableCheked){
  //     setRows([...inactiveRows,...disabledRows])
  //   }else if(activechecked && inactivechecked && disableCheked){
  //     setRows([...activeRows,...inactiveRows,...disabledRows])
  //   }else{
  //     setRows([]);
  //   }
  // }

  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setGridStatus({
      ...gridstatus,
      [event.target.name]: event.target.checked
    })
    setPaginationobject({page:0,pageSize:10});
  };

  // const handleActiveChange = (event: React.ChangeEvent<HTMLInputElement>) =>{
  //   const isChecked = event.target.checked;
  //   setisActiveEnabled(isChecked);
  //   setActivechecked(isChecked);
    
  //   filterRows(checked,isChecked,Inactivechecked);
  // }

  // const handleInactiveChange = (event: React.ChangeEvent<HTMLInputElement>) =>{
  //   const isChecked = event.target.checked;
  //   setisInactiveEnabled(isChecked);
  //   setInactivechecked(isChecked);
    
  //   filterRows(checked,Activechecked,isChecked);
  // }

  const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null);
  const open = Boolean(anchorEl);
  const handleClick = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };

  // useEffect(() => {
  //  // filterRows(checked, Activechecked, Inactivechecked);
  // }, [disabledRows, activeRows, inactiveRows]);

  return (
    <>
      <Box className="main-page-title">
        <h4 className="list-header-title">{t("application")}</h4>
        <Box sx={{ flex: "1" }} />
        <FormControl>
          <Button
            id="demo-customized-button"
            aria-controls={open ? "demo-customized-menu" : undefined}
            aria-haspopup="true"
            aria-expanded={open ? "true" : undefined}
            variant="contained"
            color="secondary"
            disableElevation
            onClick={handleClick}
            endIcon={<KeyboardArrowDownIcon />}
          >
            {t("actions")}
          </Button>
          <StyledMenu
            id="demo-customized-menu"
            MenuListProps={{ "aria-labelledby": "demo-customized-button" }}
            anchorEl={anchorEl}
            open={open}
            onClose={handleClose}
          >
            <MenuItem onClick={handleClose} disableRipple>
              {t("show_dis")}{" "}
              <Switch checked={gridstatus.disable} onChange={handleChange} name="disable"/>
            </MenuItem>
            <MenuItem onClick={handleClose} disableRipple>
              {t("show_active")}{" "}
              <Switch checked={gridstatus.active} onChange={handleChange} name="active"/>
            </MenuItem>
            <MenuItem onClick={handleClose} disableRipple>
              {t("show_inact")}{" "}
              <Switch checked={gridstatus.inactive} onChange={handleChange} name="inactive"/>
            </MenuItem>
          </StyledMenu> 
        </FormControl>
        {isAddPrivileged && (
          <Link to="/addApplication">
            <Button variant="contained">{t("add_app")}</Button>
          </Link>
        )}
      </Box>
    </>
  );
};

export default AddApplication;
