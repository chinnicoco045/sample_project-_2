import Box from "@mui/material/Box";
import { useCookies } from "react-cookie";
import "../../App.scss";
import * as React from "react";
import {
  DataGridPremium,
  GridToolbar,
  GridActionsCellItem,
} from "@mui/x-data-grid-premium";
import { Autocomplete, Chip, Dialog, DialogActions, DialogContent, DialogTitle, FormHelperText, FormLabel, Grid, InputLabel, MenuItem, Select, TextField } from "@mui/material";
import EditIcon from "@mui/icons-material/Edit";
import RemoveRedEyeIcon from "@mui/icons-material/RemoveRedEye";
import NotInterestedIcon from "@mui/icons-material/NotInterested";
import { useState, useEffect } from "react";

import { Stack, Breadcrumbs, Typography, FormControl, Button, Tooltip, Link } from "@mui/material";
import NavigateNextIcon from "@mui/icons-material/NavigateNext";

import Links from "@mui/material/Link";
import {  useLocation } from "react-router-dom";
import axios from "axios";
import { useTranslation } from "react-i18next";
import service, { basicUrl, GET_API } from "../../Services/apiheader";
import Loading from "./components/Loading";
import NoDataAvailable from "./components/NoDataAvailable";
import { useDataGridLocalText } from "../../Audit/useDataGridLocalText";
import AddMS from "./AddMS";
import EditMS from "./EditMS";
import disabledsvg from '../../assets/icon-disable.svg';
import Cookies from "js-cookie";
import { fetchReasons } from "../../apis/apiFunctions";
import TagIcon from '@mui/icons-material/LocalOfferOutlined'; // Icon for the tag
import { useSnackbar } from "notistack";



interface DisableRowType {
  memberState: string;
  msCountryCode: string;
  waveName:string
  comments:string;
}

interface WaveInfoType{
  countryCode:string;
  waveName:string;
  waveCode:string;
  comments:string
}

const SideNavTable: React.FC = () => {

  const {t}=useTranslation();
  const noFilterMenuNames = ["Product Information"];
  const menuNamesForCustomMapping = ["Active Ingredient/Substance", "Route of Admin", "Trade Name"];
  const location=useLocation();
  const { productId, label, menuname, url, jsonurl,module,id } = location.state || {};
  const mode=location.state?.mode;
  const [data, setData] = useState<any[]>([]);
  const [headData, setHeadData] = useState<any[]>([]);
  const [infoData, setInfoData] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [showGrid, setShowGrid] = useState(true); // Initially show the grid
  const [showDetailView, setShowDetailView] = useState(false); // Initially hide the detailed view
  const [showDetailEdit,setShowDetailEdit]=useState(false);
  const [selectedRow, setSelectedRow] = useState<any>(null); // Store the selected row data
  const [disableDialogOpen,setDisableDialogOpen]=useState(false);
  const [error, setError] = useState<string | null>(null);
  const cell = JSON.parse(sessionStorage.getItem('CellData') || '{}');
  const ids = JSON.parse(sessionStorage.getItem('allIds') || '[]');
  const memberStates=JSON.parse(sessionStorage.getItem("memberStates")||'[]');
  const[applicationDetails,setApplicationsDetails]=useState<any>();
  const [msName,setmsName]=useState('');
  const [memberState,setMemberState]=useState<any[]>([]);
  const[trigger,setTrigger]=useState(false);
  const[checked,setChecked]=useState(false);
  const pid = sessionStorage.getItem('productId') || productId;
  const {localeText}=useDataGridLocalText();
  const data_api_header = productId ? GET_API.slice(0, -1) : basicUrl;
  const head_api_header = GET_API+"cm/form-manager/grids/fields?module="+module+"&gridName=";
  const info_api_header = GET_API+"cm/form-manager/forms/settings";
  const [reason, setReason] = useState<any|null>();
  const [reasonList, setReasonList] = useState([]);
  const [comments, setComments] = useState("");
  const [disableRow, setDisableRow] = useState<DisableRowType | null>(null);
  const {enqueueSnackbar}=useSnackbar();

  const [cookies] = useCookies([
    "USER_TENANT_ID",
    "DOMAIN",
    "USER_PRIVILEGES",
    "ACCESS_TOKEN",
  ]);

  const formatGridName = (menuname: string) => {
    return encodeURIComponent(menuname).replace(/%20/g, '+');
  }

  useEffect(() => {

    const getFullUrl = (url: string, productId: string) => {
      if(id)
        return url;
      if (url.includes("${productId}")) {
        return url.replace("${productId}", productId);
      } else if (url.includes("${id}")) {
        return url.replace("${id}", productId);
      }else if (url.includes("NULL")) {
        return url.replace("NULL", productId);
      }
      return url;
    };

    const fullDataUrl = `${data_api_header}${getFullUrl(url, pid)}`;
    const fetchData = async () => {
     
      const headers: Record<string, string> = {
        Authorization: `Bearer ${cookies.ACCESS_TOKEN}`,
        'Accept-Language': "",
      };
    
      if (!productId) {
        headers["X-TenantID"] = Cookies.get('USER_TENANT_ID') || "";
      }
      try {
        setIsLoading(true);
        const data_response = await service.get(fullDataUrl, {
          headers: headers,
        });
        let response_data = data_response.data.data;
        if(id){
          
          response_data.applicationdata.memberStates=memberStates;
          response_data.applicationdata.disabledMS= cell.applicationData.disabledMS;
          setApplicationsDetails(response_data);
         response_data= formatMemberStateGrid(response_data);

        }
        let d = []
        if (Array.isArray(response_data)) {
          d = response_data
        } else if (response_data.data && Array.isArray(response_data.data)) {
          d = response_data.data
        } else{
          d = []
        }

        let newData:any;
        if(productId){
         newData = noFilterMenuNames.includes(menuname) ? d : d.filter((item: any) => ids.includes(item.id));
        }
         else{
            newData=d;
         }

        const head_response = await axios.get(`${head_api_header}${formatGridName(menuname)}`, {
          headers: {
            Authorization: `Bearer ${cookies.ACCESS_TOKEN}`,
          },
        });
        setHeadData(head_response.data.data)

      if (!menuNamesForCustomMapping.includes(menuname)) {
        const requestData = {
          formName: menuname,
          module: module,
        };

        const info_response = await axios.post(info_api_header, requestData, {
          headers: {
            Authorization: `Bearer ${cookies.ACCESS_TOKEN}`,
          },
        });
        const parsedInfoData = JSON.parse(info_response.data.data.settingsJson);
        const additionalFields = checked
    ? [
        {
          field: "reasonForDisableLabel",
          label: "Reason for Disable",
          field_xs: 12, // Adjust grid size as needed
        },
        {
          field: "commentsForDisable",
          label: "Disable Comments",
          field_xs: 12, // Adjust grid size as needed
        },
      ]
    : [];

    let allComponents = [...parsedInfoData, ...additionalFields];
        setInfoData(allComponents)
      }
 
     
        setData(newData)

      } catch (error) {
// console.error("Error fetching data:", error);
        setError("Network Error"); // Set error message
      } finally {
        setShowGrid(true);
        setShowDetailView(false);
        setIsLoading(false);
        setTrigger(false);
      }

    };

  fetchData();
  }, [cookies.ACCESS_TOKEN, data_api_header, url,trigger,head_api_header,checked]);

  const formatMemberStateGrid = (data: any) => {
    const { msCountryCode, waveInfo, countryIdentifier, disabledMS } = data.applicationdata;
    const { groupid } = data;

    // const memberStates = cellData.applicationData.memberStates;

    // Create a map of countryCode to waveName from waveInfo
    const waveMap = (checked ? disabledMS : waveInfo)?.reduce(
      (acc: Record<string, string>, { countryCode, waveName }: WaveInfoType) => {
        acc[countryCode] = waveName;
        return acc;
      }, 
      {}
    );
    
    const waveComm = (checked ? disabledMS : waveInfo)?.reduce(
      (acc: Record<string, string>, { countryCode, comments }: any) => {
        acc[countryCode] = comments;
        return acc;
      }, 
      {}
    );
    // Extract country names from disabledMS array
    const disabledCountries = new Set(disabledMS?.map((ms: any) => ms.countryName));
    let idCounter=0;
    // Map over memberStates to create gridData, excluding disabled ones
   
    const gridData = !checked
    ? memberStates
        // Exclude disabled member states
        // .filter((memberState: string) => !disabledCountries?.has(memberState))
        .filter((memberState: string) => memberState !== "-") // Filter out memberState equal to "-"
        .map((memberState: string, index: number) => ({
          id: memberState + "_" + idCounter++,
          memberState,
          countryIdentifier,
          groupid,
          msCountryCode: msCountryCode[index],
          waveName: waveMap[msCountryCode[index]] || "",
          comments: waveComm[msCountryCode[index]],
        }))
    : disabledMS
        ?.filter((ms: any) => ms.countryName !== "-") // Filter out memberState equal to "-"
        .map((ms: any) => ({
          id: ms.countryName + "_" + idCounter++,
          memberState: ms.countryName,
          countryIdentifier,
          groupid,
          msCountryCode: ms.countryCode,
          waveName: waveMap[ms.countryCode] || "",
          comments: waveComm[ms.countryCode],
          // reasonForDisableId: ms.reasonForDisableId,
          // reasonForDisableLabel: ms.reasonForDisableLabel,
          // commentsForDisable: ms.commentsForDisable
        })) ?? [];
  
      if(!checked){
        setMemberState(gridData);
      }

    return gridData.reverse();
};

  

  const getColumnWidth = (numColumns: number) => {
    return Math.max(Math.floor(800 / numColumns), 200); // Ensure a minimum width of 150
  };

  const data_columns = headData.filter(item => item.visibility).map(item => ({
    field: item.fieldName,
    headerName: t(item.fieldName, { defaultValue: item.column }),
    width: getColumnWidth(headData.filter(item => item.visibility).length), // Set the width as needed
    renderCell: (params: any) => (
      <Tooltip title={params.value}>
        <span>{params.value}</span>
      </Tooltip>
    ),
    renderHeader: (params: any) => (
      <Tooltip title={params.colDef.headerName}>
        <span>{params.colDef.headerName}</span>
      </Tooltip>
    ),
  }));

  if (menuname === "Documents") {
    data_columns.length = 0; // Clear existing columns for Documents
    data_columns.push({
      field: 'responseDocumentNumber',
      headerName: 'Document Number',
      width: getColumnWidth(2),
      renderCell: (params: any) => (
        <Tooltip title={params.value}>
          <span>{params.value}</span>
        </Tooltip>
      ),
      renderHeader: (params: any) => (
        <Tooltip title={params.colDef.headerName}>
          <span>{params.colDef.headerName}</span>
        </Tooltip>
      ),
    },
    {
      field: 'responseDocumentName',
      headerName: 'Document Name',
      width: getColumnWidth(2),
      renderCell: (params: any) => (
        <Tooltip title={params.value}>
        <Link href={params.row.downloadFileHyperlink} target="_blank" rel="noopener">
          {params.value}
        </Link>
        </Tooltip>
      ),
      renderHeader: (params: any) => (
        <Tooltip title={params.colDef.headerName}>
          <span>{params.colDef.headerName}</span>
        </Tooltip>
      ),
    });
  }

  const showView = (row:any) => {
    return infoData.map((fieldData: any) => {
      const { field, label, field_xs } = fieldData;
      let value = row[field] !== undefined ? row[field] : "";

      return (
        // <FormLabel className="text-ellipsis">
        <Grid item xs={field_xs} key={field} data-testid={`info-${field}`}>
          <FormControl fullWidth className="text-ellipsis">
            <div className='form-group'>
            <Tooltip title={t(field,{ defaultValue: label })} >
              <label className="form-label">
                {t(field, { defaultValue: label })}
              </label>
              </Tooltip>
              <span className="form-content">
              <Tooltip title={value} placement="bottom-start">
                {typeof value === 'string' || typeof value === 'number' ? (
                  String(value) !== "" ? String(value) as any : "-"
                ) : (
                  "-"
                )}
                </Tooltip>
              </span>
            </div>
            {/* <br></br> */}
           
          </FormControl>
        </Grid>
        // </FormLabel>
      );
    });
  }

  const handleEdit=(id: any, cell: any)=>{
    setmsName(cell.row);
    setShowGrid(false);
    setShowDetailEdit(true);
  }

  const handleDisable=(cell: any)=>{
      setDisableRow(cell.row);
      setDisableDialogOpen(true);
  }

  const handleView = async (id: number, cell: any) => {

    const row = applicationDetails?.applicationdata?.disabledMS?.find((ms: any) => ms.countryName === cell.row.memberState);
  

    const updatedRow = checked
      ? {
          ...cell.row,
          reasonForDisableLabel: row.reasonForDisableLabel,
          commentsForDisable: row.commentsForDisable,
        }
      : cell.row;
  
    setSelectedRow(updatedRow); 
    setShowGrid(false);
    setShowDetailView(true);
  };
  


  const action_column = [

    {
      field: "actions",
      type: "actions" as const,
      width: 70,
      headerName: t("actions"),
      getActions: (cell: any) => {
        const actions = [];
        if(id && !checked && mode==="edit")
        actions.push(
          <GridActionsCellItem
            showInMenu
            label={t("edit")}
            onClick={()=>handleEdit(cell.id, cell)}
            icon={<EditIcon />}
            data-testid="edit-button" // Add this line
          />
        );
        actions.push(
          <GridActionsCellItem
            showInMenu
            label={t("view")}
            onClick={()=>handleView(cell.id, cell)}
            icon={<RemoveRedEyeIcon />}
            data-testid="view-button" // Add this line
          />
        );
        if(id && !checked && mode==="edit")
        actions.push(
          <GridActionsCellItem
            showInMenu
            label={t("disable")}
            onClick={()=>handleDisable(cell)}
            icon={<NotInterestedIcon />}
            data-testid="disable-button" // Add this line
          />
        );
        return actions;
      },
    },
  ];

  const columns = [...data_columns, ...(menuNamesForCustomMapping.includes(menuname) ? [] : action_column)];


  const CustomNoRowsOverlay = () => {
    return (
      <Box className="empty-data-container">
{/* <img src={emptyImage} alt="No Data" /> */}
        <NoDataAvailable></NoDataAvailable>
      </Box>
    );
  };

  const onClose=()=>{
    setDisableDialogOpen(false);
  }

  useEffect(() => {
    const getReasons = async () => {
      const reasons = await fetchReasons();
      setReasonList(reasons);
    };

    if (disableDialogOpen) {
      getReasons();
    }
  }, [disableDialogOpen]);
 
  const handleDisableSaveButton=async()=>{
    const disabledMS = {
      countryName: disableRow?.memberState,
      countryCode: disableRow?.msCountryCode,
      waveName: disableRow?.waveName,
      comments:disableRow?.comments,
      reasonForDisableId: reason?.id,
      reasonForDisableLabel: reason?.name,
      commentsForDisable: comments,
  };


  // Filter out disabled country from memberStates and msCountryCode
  const updatedMemberStates = applicationDetails.applicationdata.memberStates.filter(
      (memberState: string) => memberState !== disabledMS.countryName
  );
  const existingMemberStates = JSON.parse(sessionStorage.getItem("memberStates") || "[]");

    // Step 4: Replace the oldValue in sessionStorage with newValueObject.label
 const updatedMemberStatesInSessionStorage=existingMemberStates.filter(
  (memberState: string) => memberState !== disabledMS.countryName
);

    // Step 5: Update sessionStorage with the new memberStates
  sessionStorage.setItem("memberStates", JSON.stringify(updatedMemberStatesInSessionStorage));

  const updatedMsCountryCode = applicationDetails.applicationdata.msCountryCode.filter(
      (code: string) => code !== disabledMS.countryCode
  );  
  


  const updatedRow = {
      ...applicationDetails,
      applicationdata: {
          ...applicationDetails.applicationdata,
          memberStates: updatedMemberStates,    // Updated memberStates
          msCountryCode: updatedMsCountryCode,  // Updated msCountryCode
          disabledMS:  [
              ...(applicationDetails.applicationdata.disabledMS || []),  // Use existing values if they exist
              disabledMS,   // Add new disabledMS entry
          ],
      },
      updated_by:Cookies.get('USER_EMAIL')
  };
  const existingCellData = JSON.parse(sessionStorage.getItem("CellData") || "{}");

  // Merge disabledMS with existing disabledMS in sessionStorage
  const updatedDisabledMS = [
      ...(existingCellData.applicationData?.disabledMS || []), // Preserve existing disabledMS
      disabledMS, // Add new entry
  ];
  existingCellData.applicationData = {
    ...existingCellData.applicationData,
    disabledMS: updatedDisabledMS, // Ensure sessionStorage contains updated disabledMS
};
sessionStorage.setItem("CellData", JSON.stringify(existingCellData));
 

  
    const response = await service.put(`application/v1/modification/${id}`, updatedRow, {
      headers: {
        "X-TenantID": Cookies.get('USER_TENANT_ID')
      }
    });
    console.log(response);
    enqueueSnackbar(t('DisableMSSuccessTip'), { variant: "success", anchorOrigin: { vertical: 'top', horizontal: 'center' } });
    setTrigger(true);

    setReason(null);
    setComments("");
    setDisableRow(null);
    setDisableDialogOpen(false);
  }

  const handleCancelEdit=()=>{ 
    setShowDetailEdit(false);
    setShowGrid(true);
  }

  const [detailData, setDetailData] = useState(""); // State to store the fetched data
  const [productName, setProductName] = useState('');
  const [countryName, setCountryName] = useState('');
  const cellData = JSON.parse(sessionStorage.getItem('CellData') || '{}');

  useEffect(() => {
    const Data = async () => {
      try {
        const response = await service.get(`/application/v1/display/refresh-products/`+ cellData.id, {
          headers: {
            "X-TenantID": Cookies.get('USER_TENANT_ID')
          }
        });
  
  
        if (response && response.data && response.data.data && response.data.data.applicationdata) {
          const data = response.data.data.applicationdata;
  
          setDetailData(data);
          setProductName(data.productName);
          setCountryName(cell.applicationData.countryNames);
  
        }
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };
  
    Data();
  }, []);
  
  const productnames = productName.length > 6 ? `${productName.slice(0, 6)}...` : productName;
  const countrynames = countryName.length > 6 ? `${countryName.slice(0, 6)}...` : countryName;

  return (
    <div>

      {/* Grid Breadcrumb */}
      <Box className="custom-bread-crumb ">
        <Stack >
          <div className="custom-bread-crumb-list">
            <Breadcrumbs aria-label="breadcrumb" separator={<NavigateNextIcon />}>
              <Links className="" href="/applicationdetails">
                {t('application')}
              </Links>
              <Typography>
                {t(label)}
              </Typography>
            </Breadcrumbs>
          </div>
        </Stack>
      </Box>
      {/*End Grid Breadcrumb */}

      <Grid container className="grid-page">
        <Grid className=" grid-left">

          {showGrid && (
            <>
            <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
              {!id && <><h4 className="mt-4 list-header-title" style={{ fontSize: '1rem', marginBottom: '8px' }}>{t(label)} </h4>
                <Tooltip title={productName} placement="bottom-start">
                    <Chip
                      icon={<TagIcon style={{ fontSize: 16, color: '#2e5aac', transform: 'rotate(133deg)', }} />}  
                      label={productnames}                      
                      style={{
                        backgroundColor: '#EAF0FB',                    
                        color: '#3F51B5',                              
                        fontWeight: '500',                             
                        borderRadius: '16px',                          
                        fontSize: '2.25rem',                              
                        padding: '2px 6px',                            
                        height: '22px',  
                        width : "100px",
                        display: 'flex',                               
                        alignItems: 'center',                         
                      }}
                    />
                </Tooltip>
                <Tooltip title={countryName} placement="bottom-start">
                  <Chip
                      icon={<TagIcon style={{ fontSize: 16, color: '#2e5aac', transform: 'rotate(133deg)', }} />}  
                      label={countrynames}                              
                      style={{
                        width : "100px",
                        backgroundColor: '#EAF0FB',                    
                        color: '#3F51B5',                              
                        fontWeight: '500',                             
                        borderRadius: '16px',                          
                        fontSize: '2.25rem',                              
                        padding: '2px 6px',                            
                        height: '22px',                                
                        display: 'flex',                               
                        alignItems: 'center',                         
                      }}
                    />
                </Tooltip></>}
              </div>
              {id && <AddMS mode={mode} memberState={memberState} data={data} applicationDetails={applicationDetails} setTrigger={() => setTrigger(prev => !prev)} checked={checked} setChecked={setChecked} productName={productName} countryName={countryName}/>}
              {data && data.length > 0 &&
              <Box className="application-table" >
                {isLoading ? (
                  <Loading open={isLoading} />
                ) : (
                  <DataGridPremium
                  disableAggregation
                    checkboxSelection
                    columns={columns}
                    rows={data}
                    className="react-table table_size-has--row1"
                    slots={{
                      toolbar: GridToolbar,
                      noRowsOverlay: CustomNoRowsOverlay,
                    }}
                    initialState={{
                      pinnedColumns:
                  {
                right:
                ["actions"]
                },
                pagination: { paginationModel: { pageSize: 10 } },
              }}
              slotProps={{
                toolbar: {
                  showQuickFilter: true,
                  utf8WithBom: true,   
                  csvOptions: {
                    utf8WithBom: true,
                        },
                      },
                    }}
                    
                    localeText={localeText}
              pagination
              pageSizeOptions={[5, 10, 15, 20]}
                />
                )}
              </Box>
              }
              <Box>
              {
                (!data || data.length === 0) && !isLoading && <Box sx={{ height: 'calc(100vh - 350px)', width: '100%' }}>
                  <CustomNoRowsOverlay />
                </Box>
              }
            </Box>
            <Loading open={isLoading}></Loading>
            </>
          )}
          {showDetailView && ( // Render detailed view if showGrid is false
            <>
              <h4 className="mt-4 list-header-title">{t('view')+" "+t(label)}</h4>
                  <div className="detail-view-container form-group">
                    <Grid container>
              {showView(selectedRow)}
            </Grid>
                      <Grid item className='float-right mt-24'>
                      <Button variant="text" size="small"
                        onClick={() => {
                          setShowGrid(true);
                          setShowDetailView(false); // Show the grid again
              }}
              data-testid="cancel-button" // Add this line
            >
              Cancel
            </Button>
              </Grid>
         </div>
         <Loading open={isLoading}></Loading>
            </>
          )}
           {showDetailEdit && menuname==="Member States" && 
           
           <EditMS infoData={infoData} applicationDetails={applicationDetails} msName={msName} setApplicationsDetails={setApplicationsDetails} handleCancelEdit={handleCancelEdit} setMsName={setmsName} id={id} setTrigger={() => setTrigger(prev => !prev)} />}
            <Dialog
      className="popup-dialog"
      open={disableDialogOpen}
      onClose={(event, reason) => {
        if (reason !== 'backdropClick') {
          onClose();
        }
      }}
      disableEscapeKeyDown

    //   fullWidth
      maxWidth="md"
      sx={{
        '.MuiDialog-paper': { width: '600px' }
      }}
    >
      <DialogTitle>
        {t('disable')+" "+t('app')}
      </DialogTitle>
      <Box component="form" sx={{ display: 'flex', flexDirection: 'column' }}>
      <DialogContent className="form-group popup-content"  >
        
        <Grid>
              <img src={disabledsvg}
               style={{ width: '200px', marginLeft: 'calc(50% - 100px)', marginBottom: '10px' }}></img>
              {/* <h3 className='alert-notify-text text-center'>Are you sure you want to make the record <b className='alert-text'>disabled</b>?</h3> */}
              <h5 className='alert-notify-text mb-24 text-center'>{t('disableMemberStateTitle')}</h5>
              <Grid>
          <Autocomplete
            sx={{
              "& .MuiOutlinedInput-root": { padding: 0, "flex-wrap": "nowrap" },
              "& .MuiTextField-root": {
                marginLeft: 0,
                marginTop: 0,
                marginBottom: 0,
              },
              "& .MuiOutlinedInput-root .MuiAutocomplete-input": { border: "none" },
              "& .MuiFormControl-root .MuiInputBase-root input:focus": {
                outline: "none !important",
              },
              "& .MuiAutocomplete-inputRoot": { paddingLeft: "10px" },
              flex: 1,
            }}
            className="custom-autocomplete"
            renderTags={(selectedOptions: any) => {
              return <Chip label={selectedOptions.length + " selected"} />;
            }}
            value={reason}
            options={reasonList}
            getOptionLabel={(option: any) => option.name || ""}
            renderInput={(params: any) => (
              <TextField
                {...params}
                required
                label={t("reasonForDisable")}
                inputProps={{
                  ...params.inputProps,
                  onKeyDown: (e) => {
                    if (e.keyCode === 13) {
                      e.preventDefault();
                    }
                  },
                }}
              />
            )}
            onChange={(event: any, value: any) => {
              setReason(value);
              console.log(value);
            }}
          />
        </Grid>
        <Grid
          item
       
          sx={{ position: "relative", marginTop:"24px",marginBottom: "20px"}}
        >
          <TextField
            size="small"
            label={t("comment")}
            inputProps={{ maxLength: 2000 }}
            multiline
            rows={4}
            value={comments}
            onChange={(event) => setComments(event.target.value)}

          />
          <span className="rtq-number-tips comment-count-right">
            {comments ? comments.length : 0} / 2000
          </span>
        </Grid>
            </Grid>
       
        
       
      </DialogContent>
      <DialogActions>
        <Button variant="text" size="small" onClick={onClose}>
          {t('No')}
        </Button>
        <Button
          variant="contained"
          size="small"
          onClick={handleDisableSaveButton}
          disabled={!(reason && reason.id)}
        >
          {t('Yes')}
        </Button>
      </DialogActions>
      </Box>
    </Dialog>
        </Grid>
      </Grid>
    </div>
  );
};

export default SideNavTable;


