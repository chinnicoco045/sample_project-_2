import React, { createContext, useState, useMemo } from "react";

import "./App.scss";
import { RouterProvider } from "react-router-dom";
import Row, { Product } from "./types";
import { Router } from "./routes/route";
import GetAllUsers from "./Components/Applications/GetAllUsers";
import { LicenseInfo } from '@mui/x-license';
import { Option } from "./Components/Applications/wizard/LinkCountry";
const licenseKey=process.env.REACT_APP_MUI_LICENSE_KEY;
LicenseInfo.setLicenseKey(licenseKey ?? "");

export const RowContext = createContext<{
  rows: Row[];
  setRows: React.Dispatch<React.SetStateAction<Row[]>>;
  disabledRows: Row[];
  setDisabledRows: React.Dispatch<React.SetStateAction<Row[]>>;
  allRows: Row[];
  setAllRows: React.Dispatch<React.SetStateAction<Row[]>>;
  isEdited: boolean;
  setIsEdited: React.Dispatch<React.SetStateAction<boolean>>;
  isDisabled: boolean;
  setIsDisabled: React.Dispatch<React.SetStateAction<boolean>>;
  isAddPrivileged: boolean;
  setIsAddPrivileged: React.Dispatch<React.SetStateAction<boolean>>;
  showDisabled: boolean;
  setShowDisabled: React.Dispatch<React.SetStateAction<boolean>>;
  isAdded: boolean;
  setIsAdded: React.Dispatch<React.SetStateAction<boolean>>;
  selectedRow: Product[]| undefined;
  setSelectedRow: React.Dispatch<React.SetStateAction<Product[] | undefined>>;
  checked: Record<string, string[]>;
  setChecked: React.Dispatch<React.SetStateAction<Record<string, string[]>>>;
  applicationIdentifier: { label: string; value: string };
  setApplicationIdentifier: React.Dispatch<React.SetStateAction<{ label: string; value: string }>>;
  error: boolean;
  setError: React.Dispatch<React.SetStateAction<boolean>>;
  regionOptions: Option[];
  setRegionOptions: React.Dispatch<React.SetStateAction<Option[]>>;
  countryOptions: Option[];
  setCountryOptions: React.Dispatch<React.SetStateAction<Option[]>>;
  selectedCountry: string[];
  setSelectedCountry: React.Dispatch<React.SetStateAction<string[]>>;
  inactiveRows: Row[];
  setinactiveRows: React.Dispatch<React.SetStateAction<Row[]>>;
  activeRows: Row[];
  setactiveRows: React.Dispatch<React.SetStateAction<Row[]>>;
  isActiveEnabled: boolean;
  setisActiveEnabled: React.Dispatch<React.SetStateAction<boolean>>;
  isInactiveEnabled: boolean;
  setisInactiveEnabled: React.Dispatch<React.SetStateAction<boolean>>;
  isEditPrivilege:boolean;
  setIsEditPrivilege: React.Dispatch<React.SetStateAction<boolean>>;
  paginationobject:{ page: number; pageSize: number };
  setPaginationobject: React.Dispatch<React.SetStateAction<{ page: number; pageSize: number }>>;
  paginationTotalRecord:number;
  setPaginationTotalRecord:React.Dispatch<React.SetStateAction<number>>;
  gridstatus:{ active: boolean; inactive: boolean;disable: boolean};
  setGridStatus: React.Dispatch<React.SetStateAction<{ active: boolean; inactive: boolean;disable: boolean}>>;
}>({
  rows: [],
  setRows: () => {},
  disabledRows: [],
  setDisabledRows: () => {},
  allRows: [],
  setAllRows: () => {},
  isEdited: false,
  setIsEdited: () => {},
  isDisabled: false,
  setIsDisabled: () => {},
  isAddPrivileged: false,
  setIsAddPrivileged: () => {},
  showDisabled: false,
  setShowDisabled: () => {},
  isAdded: false,
  setIsAdded: () => {},
  selectedRow: undefined,
  setSelectedRow: () => {},
  checked: {},
  setChecked: () => {},
  applicationIdentifier: { label: "", value: "" },
  setApplicationIdentifier: () => {},
  error: false,
  setError: () => {},
  regionOptions: [],
  setRegionOptions: () => {},
  countryOptions: [],
  setCountryOptions: () => {},
  selectedCountry: [],
  setSelectedCountry: () => {},
  inactiveRows: [],
  setinactiveRows: () => {},
  activeRows: [],
  setactiveRows: () => {},
  isActiveEnabled: false,
  setisActiveEnabled: () => {},
  isInactiveEnabled: false,
  setisInactiveEnabled: () => {},
  isEditPrivilege:false,
  setIsEditPrivilege:()=>{},
  paginationobject: { page: 0, pageSize: 50 },
  setPaginationobject: () => {},
  paginationTotalRecord:0,
  setPaginationTotalRecord:() => {},
  gridstatus:{ active: true, inactive: false,disable: false},
  setGridStatus: ()=>{},
});

function App() {
  const [rows, setRows] = useState<Row[]>([]);
  const [disabledRows, setDisabledRows] = useState<Row[]>([]);
  const [allRows, setAllRows] = useState<Row[]>([]);
  const [isDisabled, setIsDisabled] = useState(false);
  const [isEdited, setIsEdited] = useState(false);
  const [isAdded, setIsAdded] = useState(false);
  const [isAddPrivileged, setIsAddPrivileged] = useState(false);
  const [showDisabled, setShowDisabled] = useState<boolean>(false);
  const [selectedRow, setSelectedRow] = useState<Product[] | undefined>();
  const [checked, setChecked] = useState<Record<string, string[]>>({});
  const [applicationIdentifier, setApplicationIdentifier] = useState<{ label: string; value: string }>({ label: "", value: "" });
  const [error, setError] = useState(false);
  const [regionOptions, setRegionOptions] = useState<Option[]>([]);
  const [countryOptions, setCountryOptions] = useState<Option[]>([]);
  const [selectedCountry, setSelectedCountry] = useState<string[]>([]);
  const [inactiveRows, setinactiveRows] = useState<Row[]>([]);
  const [activeRows, setactiveRows] = useState<Row[]>([]);
  const [isActiveEnabled, setisActiveEnabled] = useState(true);
  const [isInactiveEnabled, setisInactiveEnabled] = useState(false);
  const [isEditPrivilege,setIsEditPrivilege]=useState(false);
  const [paginationobject, setPaginationobject] = useState<{ page: number; pageSize: number }>({ page: 0, pageSize: 50 });
  const [paginationTotalRecord,setPaginationTotalRecord]=useState(0);
  const [gridstatus, setGridStatus] = useState<{ active: boolean; inactive: boolean;disable: boolean} >({ active: true, inactive: false,disable: false});

  const contextValue = useMemo(() => ({
    rows,
    setRows,
    disabledRows,
    setDisabledRows,
    allRows,
    setAllRows,
    isEdited,
    setIsEdited,
    isDisabled,
    setIsDisabled,
    isAddPrivileged,
    setIsAddPrivileged,
    showDisabled,
    setShowDisabled,
    isAdded,
    setIsAdded,
    selectedRow,
    setSelectedRow,
    checked,
    setChecked,
    applicationIdentifier,
    setApplicationIdentifier,
    error,
    setError,
    regionOptions,
    setRegionOptions,
    countryOptions,
    setCountryOptions,
    selectedCountry,
    setSelectedCountry,
    inactiveRows,
    setinactiveRows,
    activeRows,
    setactiveRows,
    isActiveEnabled,
    setisActiveEnabled,
    isInactiveEnabled,
    setisInactiveEnabled,
    isEditPrivilege,
    setIsEditPrivilege,
    paginationobject,
    setPaginationobject,
    paginationTotalRecord,
    setPaginationTotalRecord,
    gridstatus, 
    setGridStatus
  }), [
    rows, disabledRows, allRows, isEdited, isDisabled, isAddPrivileged, showDisabled, isAdded, selectedRow, checked,
    applicationIdentifier, error, regionOptions, countryOptions, selectedCountry, inactiveRows, activeRows,
    isActiveEnabled, isInactiveEnabled,isEditPrivilege,setIsEditPrivilege,paginationobject,setPaginationobject,paginationTotalRecord,setPaginationTotalRecord,
    gridstatus, setGridStatus
  ]);

  return (
    <div className="App">
      <RowContext.Provider value={contextValue}>
        <GetAllUsers />
        <RouterProvider router={Router}></RouterProvider>
      </RowContext.Provider>
    </div>
  );
}

export default App;
