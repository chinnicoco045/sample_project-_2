import { enUS, jaJP } from "@mui/x-data-grid-premium";
import { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { useConfigStore } from "../Audit/config";

export const useDataGridLocalText = () => {
  const [language] = useConfigStore((state) => [state.language]);
  const { t } = useTranslation();
  const [localeText, setLocaleText] = useState<any>();

  useEffect(() => {
    const meta: Record<string, any> = {
      en: enUS,
      jp: jaJP,
    };
    setLocaleText({
      ...meta[language].components.MuiDataGrid.defaultProps.localeText,
      toolbarExportPrint: t("downloadPDF"),
    });
  }, [language]);

  return { localeText };
};
