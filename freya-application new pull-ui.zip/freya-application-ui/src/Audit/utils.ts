import { RIMS_LOCAL_STG_CONSTANTS, RTQ_EVENTS, MENU_MODULE_NAME_MAP } from "../constants";
import eventBus from "./eventBus";

export function translateStatus(status: any) {
  if (status === '') {
    return ''
  } else {
    switch (Number(status)) {
      case 0:
        return 'In-Draft';
      case 1:
        return 'Active';
      case 2:
        return 'Inactive'
      case 3:
        return 'Archived'
      default:
        return 'In-Draft'
    }
  }
}

export function mappingAdminType(type: string) {
  switch (type) {
    case 'user':
      return 0;
    case 'role':
      return 1;
    case 'group':
      return 2;
    case 'acl':
      return 3;
    default:
      return 0
  }
}

export function uniqueArray(arr: any[], propName?: string) {
  const res = new Map();
  if (propName) {
    return arr.filter((a) => !res.has(a[propName]) && res.set(a[propName], 1));
  } else {
    return arr.filter((a) => !res.has(a) && res.set(a, 1));
  }
}

export function titleCase(str: string) {
  let newStr = str.split(" ");
  for (let i = 0; i < newStr.length; i++) {
    newStr[i] = newStr[i].slice(0, 1).toUpperCase() + newStr[i].slice(1).toLowerCase();
  }
  return newStr.join(" ");
}

export function firstWordCase(parameter: string) {
  return parameter.slice(0, 1).toUpperCase() + parameter.slice(1).toLowerCase();
}

export function handleExportByType(api: string, enqueueSnackbar: any, data?: any) {
  let params = {
    api: api,
    data: data ? data : {},
    enqueueSnackbar: enqueueSnackbar
  }
  eventBus.emit(RTQ_EVENTS.COMMON.EXPORT_FILE_START, params)
}

export function logoutFunction() {
  localStorage.clear();
}

const isObject = (target: any) => {
  return (typeof target === 'object' || typeof target === 'function')
    && (target !== null);
};

export function deepClone(target: any, map = new WeakMap()) {
  if (map.get(target)) {
    return target;
  }
  if (isObject(target)) {
    map.set(target, true);
    const cloneTarget: any = Array.isArray(target) ? [] : {};
    for (let prop in target) {
      if (target.hasOwnProperty(prop)) {
        cloneTarget[prop] = deepClone(target[prop], map);
      }
    }
    return cloneTarget;
  } else {
    return target;
  }
};

export function getObjectDataType(data: any) {
  const temp = Object.prototype.toString.call(data);
  const type = temp?.match(/\b\w+\b/g) || [];
  return (type.length < 2) ? 'Undefined' : type[1];
}

export function isObjectChanged(source: any, comparison: any): any {
  const iterable = (data: any) => ['Object', 'Array'].includes(getObjectDataType(data));
  if (getObjectDataType(source) !== getObjectDataType(comparison)) {
    return true;
  }
  const sourceKeys = Object.keys(source);
  const comparisonKeys = Object.keys({ ...source, ...comparison });
  if (sourceKeys.length !== comparisonKeys.length) {
    return true;
  }
  return comparisonKeys.some((key: any) => {
    if (iterable(source[key])) {
      return isObjectChanged(source[key], comparison[key]);
    } else {
      return source[key] !== comparison[key];
    }
  });
}

export const uploadFileSize = (input: any) => {
  let Sys = {
    ie: false,
    firefox: false,
    Chrome: false
  };
  let filesize = 0;
  const userAgent = navigator.userAgent;

  if (userAgent.indexOf("MSIE") > 0 || userAgent.indexOf("rv:11.0") > 0) {
    Sys.ie = true;
  }
  if (userAgent.indexOf("Firefox") > 0) {
    Sys.firefox = true;
  }
  if (userAgent.indexOf("Chrome") > 0) {
    Sys.Chrome = true;
  }

  if (Sys.firefox || Sys.Chrome) {
    filesize = input.files[0].size;
  } else if (Sys.ie) {
    //@ts-ignore
    const fileobject = new ActiveXObject("Scripting.FileSystemObject");
    const file = fileobject.GetFile(input.value);
    filesize = file.Size;
  }
  return filesize / (1024 * 1024)
}

export function dateSortComparator(a: any, b: any): any {
  return Date.parse(a ?? 0) - Date.parse(b ?? 0)
}

export function operatorName(name: any) {
  switch (name) {
    case "contains":
      return 'Contains'
    case "equals":
      return 'Equals'
    case "startsWith":
      return 'Starts With'
    case "endsWith":
      return 'Ends With'
    case "isEmpty":
      return 'is Empty'
    case "isNotEmpty":
      return 'is Not Empty'
    default:
      return '';
  }
}

export function handleAPICommonError(err: any) {
  if (err?.response?.status == 401 || err?.response?.data?.message === "unauthorized") {
    return;
  }
}

export const getAllIds = (tree: any, result: any) => {
  if (!Array.isArray(tree)) return [];
  for (let i = 0; i < tree.length; i++) {
    const node = tree[i];
    result.push(node.id);
    if (Array.isArray(node.children)) {
      getAllIds(node.children, result);
    }
  }
  return result;
}

export const canParseToJson = (str: any) => {
  if (typeof str == 'string') {
    try {
      var obj = JSON.parse(str);
      if (typeof obj == 'object' && obj) {
        return true;
      } else {
        return false;
      }
    } catch (e) {
      return false;
    }
  }
}

export function dependencyTypeName(type: any) {
  switch (type) {
    case 0:
      return 'User'
    case 1:
      return 'User Group'
    case 2:
      return 'Role'
    case 3:
      return 'ACL'
    case 4:
      return 'RTQ'
    case 5:
      return 'Question'
    case 6:
      return 'Workflow'
    default:
      return '';
  }
}

export function changeProductPageTitle(value: string) {
  switch (value) {
    case 'Product Information':
      return 'Product Information';
    case 'Active Ingredient/Substance':
      return 'Active Ingredient/Substance'
    case 'Trade Name':
      return 'Trade Name'
    default:
      return 'Trade Name'
  }
}

export function changeRTQPageTitle(value: number) {
  switch (value) {
    case 0:
      return 'basicInformation';
    case 1:
      return 'questionResponseDetails'
    case 2:
      return 'products'
    case 3:
      return 'submissions'
    case 4:
      return 'categories'
    case 5:
      return 'documents'
    case 6:
      return 'workflow'
    default:
      return 'basicInformation'
  }
}

export function getModuleName(path: string) {
  // @ts-ignore
  for (let [module, paths] of MENU_MODULE_NAME_MAP.entries()) {
    if (path && paths.includes(path)) {
      return module;
    }
  }
  return null; // If no match is found
};

export function getURLDomain() {
  const domain = process.env.REACT_APP_STG_DOMAIN || '';
  const splitByDomain = window.location.hostname.split(domain);
  const splitByDot = splitByDomain[0]?.split('.');
  const domainName = splitByDot[1] ? `${splitByDot[1]}.${domain}` : `${domain}`

  return domainName
}

export function firstLetterCapitalize(str: string) {
  if (!str) return "";
  const modifiedString = str.replace(/\b\w/g, function (match) {
    return match.toUpperCase();
  });
  return modifiedString;
}


const fieldMappings: { [key: string]: string } = {
  Compositions: "compositionName",
  Ingredients: "ingredientName",
  "Ingredients Quantity": "ingredientName",
  "Storage Conditions": "storageCondition",
  Packages: "packageName",
  "Batch Details": "batchNumber",
  Components: "componentMaterial",
  Language: "language",
  "Shelf-Life": "shelfLife",
  Storages: "specialPrecautionsForStorage",
  "Therapeutic Details": "therapeuticArea",
  "Indication Details": "fullIndicationText",
  "Intended Effects": "intendedEffect",
  "Co-Morbidity": "comorbidity",
  Contraindications: "contraindication",
  "Contraindication Details": "contraindicationTerm",
  Organisations: "organisationName",
  "Business Operations": "manufacturedItem",
  Documents: "responseDocumentName",
  Protocols:"protocolNumber",
  Studies : "number",
  "Device Information": "deviceName",
  "Pharmaceutical Product":"pharmaceuticalProductName",
  "Pharmaceutical Product Description":"pharmaceuticalProductName",
  "Ing. Other Representation":"ingredientName",
  "Ing. Other Representation Quantity":"ingredientName",
  "Manufactured Item":"manufacturedItemName",
  "Manufactured Item Description":"manufacturedItemName",
  "Data Carrier Identifier":"packageName",
  "Other Names":"nameType",
  "Classification":"atcName"
};

export const getFieldValue = (fieldName: string): string | undefined => {
  return fieldMappings[fieldName];
};

