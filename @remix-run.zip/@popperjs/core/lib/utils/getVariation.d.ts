import { Variation, Placement } from "../enums";
export default function getVariation(placement: Placement): Variation | null | undefined;
