// // import React from "react";
// // const GlobalSearchList: React.FC = () => {
// //     return (
// //         <div>
// //             <p>Global Search Page</p>
// //         </div>)

// // }

// // export default GlobalSearchList;


// import React, { useEffect, useRef, useState } from 'react';
// import {
//   Box,
//   Typography,
//   Grid,
//   Paper,
//   Chip,
//   Tooltip,
//   Pagination,
//   Select,
//   MenuItem,
//   FormControl,
//   Stack
// } from '@mui/material';
// import LanguageIcon from '@mui/icons-material/Language';
// import RoomIcon from '@mui/icons-material/Room';
// import { useSearchStore } from '../../Audit/config';
// import { isEqual } from 'lodash';

// const mockData = Array.from({ length: 25 }).map((_, i) => ({
//   id: `APP${436 - i}`,
//   title: `Nicorette 2mg chewing gum, Nicotine 4 mg (Nicotine Resinate ${5 + i * 5} mg) Chewing Gum, Nicorette 1 mg / Spray, Oromu...`,
//   procedure: 'MRP (P001)',
//   productFamily: 'Nicorette',
//   country: 'Germany',
//   phase: 'Marketable',
//   workflowStatus: 'Draft',
//   applicationType: 'MAA',
//   region: 'European Union',
// }));
// type DateFilterParams = {
//   dateFlag: boolean;
//   fieldId: number;
//   le?: number;
//   ge?: number;
// };
//  type SelectFilterParams = {
//   field: string;
//   value: (string | number)[];
// };
// type SelectConditionParams = { field: string; value: (string | number)[] };

// type DateConditionParams = { field: string; gte?: string; lte?: string };

// type ConditionItem = SelectConditionParams | DateConditionParams;

//  type FilterParamsItem = SelectFilterParams | DateFilterParams;

//  export interface GlobalSearchParams {
//   query: string;
//   semantic_search: boolean;
//   conditions: ConditionItem[];
// }

// interface ApplicationSource {
//   sid: number;
//   domain_name: string;
//   recordID: string;
//   productPhase: string;
//   applicationType: string;
//   productFamily: string;
//   productName: string;
//   regionName: string;
//   countryNames: string;
//   memberStates: string;
//   producerType: string;
//   applicationStatus: string;
//   applicationStatusDate: string;
//   status: string;
// }

// interface Highlight {
//   productPhase: string[];
// }

// interface Record {
//   source: ApplicationSource;
//   highlight: Highlight;
// }

// interface ApiResponse {
//   total: number;
//   page: number;
//   size: number;
//   records: Record[];
// }

// const GlobalSearchList = () => {
//   const [page, setPage] = useState(1);
//   const [rowsPerPage, setRowsPerPage] = useState(3);
//   const [data, setData] = useState<ApiResponse | null>(null);
//   useEffect(() => {
//     const fetchData = async () => {
//       try {
//         const response = await fetch('https://applicationsapi.devsecops.freyafusion.com/application/v1/search', {
//           method: 'POST',
//           headers: {
//             'tenant-id': '0',
//             'user-id': 'vijaykumar.ls@FreyrSolutions.com',
//             'Content-Type': 'application/json',
//             'domain-name': 'MPR',
//             'module-name': 'applications',
//             'Cookie': 'JSESSIONID=B48991A0647B213530FF53C011BC6EC4'
//           },
//           body: JSON.stringify({
//             page: 1,
//             pagesize: 200,
//             semantic_search: false,
//             query: 'Marketable',
//             conditions: [],
//             includes: [],
//             excludes: []
//           }),
//           credentials: 'include' // Optional: sends cookies if needed
//         });

//         const data = await response.json();
//         setData(data.data);
//         console.log('API Response:', data);
//       } catch (error) {
//         console.error('Error fetching data:', error);
//       }
//     };

//     fetchData();
//   }, []);

//   const handlePageChange = (_: any, value: number) => {
//     setPage(value);
//   };

//   const handleRowsPerPageChange = (event: any) => {
//     setRowsPerPage(event.target.value);
//     setPage(1);
//   };

//   const [search] = useSearchStore((state) => [state.search]);
//   const prevSearchRef = useRef<GlobalSearchParams | null>();
//   useEffect(() => {
//     console.log("Searchdata = ",search);
//     if (isEqual(search, prevSearchRef.current)) return;
//     prevSearchRef.current = search;
//     //getData();
//   }, [search]);

//   const startIndex = (page - 1) * rowsPerPage;
//   const endIndex = startIndex + rowsPerPage;
//   const currentItems = mockData.slice(startIndex, endIndex);

//   return (
//     <Box p={3}>
//       <Grid container spacing={2}>
//         {data?.records.map((item, index) => (
//           <Grid item xs={12} key={index}>
//             <Paper elevation={1} sx={{ p: 2 }}>
//               <Grid container spacing={2}>
//                 <Grid item xs={12} md={9}>
//                   <Box display="flex" alignItems="center" gap={1} flexWrap="wrap">
//                     <Tooltip title={`Application ID: ${item.source.recordID}`} arrow>
//                       <Typography color="primary" fontWeight="bold">
//                         {item.source.recordID}
//                       </Typography>
//                     </Tooltip>
//                     <Tooltip title={item.source.productName} arrow>
//                       <Typography fontWeight="500" noWrap maxWidth="calc(100% - 100px)">
//                         - {item.source.productName}
//                       </Typography>
//                     </Tooltip>
//                     <Chip label="Approved" color="success" size="small" />
//                   </Box>

//                   <Box mt={1}>
//                     <Typography variant="body2">
//                       Procedure: <strong>{item.source.producerType}</strong>
//                     </Typography>
//                     <Box display="flex" alignItems="center" gap={1} mt={0.5}>
//                       <LanguageIcon fontSize="small" />
//                       <Typography variant="body2">{item.source.regionName}</Typography>
//                       <RoomIcon fontSize="small" />
//                       <Typography variant="body2">{item.source.countryNames}</Typography>
//                     </Box>
//                     <Typography variant="body2" mt={0.5}>
//                       Product Family: <strong>{item.source.productFamily}</strong>
//                     </Typography>
//                   </Box>
//                 </Grid>

//                 <Grid item xs={12} md={3}>
//                   <Typography variant="body2">
//                     Phase: <strong>{item.source.productPhase}</strong>
//                   </Typography>
//                   <Typography variant="body2">
//                     Workflow Status: <strong>{item.source.applicationStatus}</strong>
//                   </Typography>
//                   <Typography variant="body2">
//                     Application Type: <strong>{item.source.applicationType}</strong>
//                   </Typography>
//                 </Grid>
//               </Grid>
//             </Paper>
//           </Grid>
//         ))}
//       </Grid>

//       {/* Pagination Controls */}
//       <Grid container justifyContent="space-between" alignItems="center" mt={3}>
//         <Grid item>
//           <Stack direction="row" alignItems="center" spacing={1}>
//             <Typography variant="body2">Rows per page:</Typography>
//             <FormControl size="small">
//               <Select value={rowsPerPage} onChange={handleRowsPerPageChange}>
//                 {[3, 5, 10].map((count) => (
//                   <MenuItem key={count} value={count}>
//                     {count}
//                   </MenuItem>
//                 ))}
//               </Select>
//             </FormControl>
//             <Typography variant="body2">
//               {startIndex + 1}–{Math.min(endIndex, mockData.length)} of {mockData.length}
//             </Typography>
//           </Stack>
//         </Grid>
//         <Grid item>
//           <Pagination
//             count={Math.ceil(mockData.length / rowsPerPage)}
//             page={page}
//             onChange={handlePageChange}
//             color="primary"
//             shape="rounded"
//           />
//         </Grid>
//       </Grid>
//     </Box>
//   );
// };

// export default GlobalSearchList;




import React, { useEffect, useRef, useState } from 'react';
import {
  Box,
  Typography,
  Grid,
  Paper,
  Chip,
  Tooltip,
  Pagination,
  Select,
  MenuItem,
  FormControl,
  Stack,
  Divider
} from '@mui/material';
import LanguageIcon from '@mui/icons-material/Language';
import RoomIcon from '@mui/icons-material/Room';
import { isEqual } from 'lodash';
import { useSearchStore } from '../../Audit/config'; // Keep your custom hook if needed

type DateFilterParams = { dateFlag: boolean; fieldId: number; le?: number; ge?: number };
type SelectFilterParams = { field: string; value: (string | number)[] };
type SelectConditionParams = { field: string; value: (string | number)[] };
type DateConditionParams = { field: string; gte?: string; lte?: string };
type ConditionItem = SelectConditionParams | DateConditionParams;
type FilterParamsItem = SelectFilterParams | DateFilterParams;

export interface GlobalSearchParams {
  query: string;
  semantic_search: boolean;
  conditions: ConditionItem[];
}

interface ApplicationSource {
  sid: number;
  domain_name: string;
  recordID: string;
  productPhase: string;
  applicationType: string;
  productFamily: string;
  productName: string;
  regionName: string;
  countryNames: string;
  memberStates: string;
  producerType: string;
  applicationStatus: string;
  applicationStatusDate: string;
  status: string;
}

interface Highlight {
  productPhase: string[];
}

interface Record {
  source: ApplicationSource;
  highlight: Highlight;
}

interface ApiResponse {
  total: number;
  page: number;
  size: number;
  records: Record[];
}

const GlobalSearchList = () => {
  const [page, setPage] = useState(1);
  const [rowsPerPage, setRowsPerPage] = useState(5);
  const [data, setData] = useState<Record[] | null>(null);
  const [totalCount, setTotalCount] = useState(0);
  const [search] = useSearchStore((state) => [state.search]);
  const prevSearchRef = useRef<GlobalSearchParams | null>();

  const fetchData = async () => {
    try {
      const response = await fetch('https://applicationsapi.devsecops.freyafusion.com/application/v1/search', {
        method: 'POST',
        headers: {
          'tenant-id': '0',
          'user-id': 'vijaykumar.ls@FreyrSolutions.com',
          'Content-Type': 'application/json',
          'domain-name': 'MPR',
          'module-name': 'applications',
          'Cookie': 'JSESSIONID=B48991A0647B213530FF53C011BC6EC4'
        },
        body: JSON.stringify({
          page,
          pagesize: rowsPerPage,
          semantic_search: search?.semantic_search,
          query:search?.query,
          conditions: [],
          includes: [],
          excludes: []
        }),
        credentials: 'include'
      });
console.log(response)
      const result = await response.json();
      const highlightedRecords = result?.data?.records.map((item:any) => {
        const highlighted = { ...item, source: { ...item.source } };
      
        if (item.highlight) {
          for (const key in item.highlight) {
            if (highlighted.source.hasOwnProperty(key)) {
              highlighted.source[key] = item.highlight[key][0];
            }
          }
        }
      
        return highlighted;
      });
      setData(highlightedRecords || []);
      setTotalCount(result?.data?.total || 0);
    } catch (error) {
      console.error('API fetch error:', error);
    }
  };

  const viewApplication = (rowItem: any) => {
    window.open(
      `https://app.${process.env.REACT_APP_STG_DOMAIN}/applications?modulePath=/applications/view&id=${rowItem.recordID}`
    );
  };

  useEffect(() => {
    fetchData();
  }, [page, rowsPerPage]);

  useEffect(() => {
    if (isEqual(search, prevSearchRef.current)) return;
    prevSearchRef.current = search;
    fetchData();
  }, [search]);

  const handlePageChange = (_: any, value: number) => {
    setPage(value);
  };

  const handleRowsPerPageChange = (event: any) => {
    setRowsPerPage(event.target.value);
    setPage(1);
  };

  return (
    <Box p={3}>
      <Grid container spacing={2}>
        {(data || []).map((item, index) => (
          <Grid item xs={12} key={index}>
            {/* <Paper
            elevation={0}
            sx={{
              p: 2,
              borderRadius: 2,
              border: '1px solid #e0e0e0',
              boxShadow: '0 1px 3px rgba(0,0,0,0.05)',
            }}
          > */}
            <Grid
              container
              sx={{
                py: 2,
                borderBottom: '1px solid #e0e0e0',
                alignItems: 'flex-start',
              }}
            >
              {/* Left Section */}
              <Grid item xs={12} md={9}>
                {/* Header Row: Title + Chip */}
                <Box display="flex" alignItems="center" gap={1} flexWrap="wrap">
                  <Tooltip title={`Application ID: ${item.source.recordID}`} arrow>
                    <Typography
                      component="a"
                      href="#"
                      onClick={(e) => {
                        e.preventDefault(); // prevent default anchor behavior
                        viewApplication(item.source);
                      }}
                      sx={{
                        color: 'primary.main',
                        fontWeight: 500,
                        textDecoration: 'none',
                        '&:hover': { textDecoration: 'underline' },
                      }}
                    >
                      <span
                        dangerouslySetInnerHTML={{
                          __html: item.source.recordID,
                        }}
                      />
                    </Typography>
                  </Tooltip>

                  <Tooltip title={item.source.productName} arrow>
                    <Typography
                      fontWeight={500}
                      noWrap
                      sx={{
                        color: 'primary.main',
                        maxWidth: 'calc(100% - 150px)',
                        overflow: 'hidden',
                        textOverflow: 'ellipsis',
                        whiteSpace: 'nowrap',
                      }}
                      component="span"
                      dangerouslySetInnerHTML={{
                        __html: `- ${item.source.productName}`,
                      }}
                    />
                  </Tooltip>

                  <Box
                    sx={{
                      backgroundColor: 'success.main',
                      color: 'common.white',
                      fontWeight: 500,
                      borderRadius: '8px',
                      height: 24,
                      px: 1,
                      ml: 'auto',
                      display: 'inline-flex',
                      alignItems: 'center',
                      fontSize: '0.75rem',
                    }}
                    dangerouslySetInnerHTML={{
                      __html: item.source.status || 'Active',
                    }}
                  />
                </Box>

                {/* Info Stack */}
                <Box mt={1} display="flex" gap={0.75}>
                  <Box display="flex" alignItems="center" gap={1}>
                    <Typography variant="body2" color="text.secondary" >
                      Procedure: <Box component="span" fontWeight={500} dangerouslySetInnerHTML={{ __html: item.source.producerType }}></Box>
                    </Typography>
                  </Box>
                  <Box sx={{
                      fontWeight: 500,
                      borderRadius: '8px',
                      height: 24,
                      ml: 'auto',
                    }}>
                    <Typography variant="body2" color="text.secondary">
                      Product Family: <Box component="span" fontWeight={500} dangerouslySetInnerHTML={{ __html: item.source.productFamily }}></Box>
                    </Typography>
                  </Box>
                  <Box sx={{
                      fontWeight: 500,
                      borderRadius: '8px',
                      height: 24,
                      ml: 'auto',
                    }}>
                    <Typography variant="body2" color="text.secondary">
                      Phase: <Box component="span" fontWeight={500} dangerouslySetInnerHTML={{ __html: item.source.productPhase }}></Box>
                    </Typography>
                  </Box>
                </Box>
                <Box mt={1} display="flex" gap={0.75}>
                  <LanguageIcon fontSize="small" sx={{ color: 'text.secondary' }} />
                  <Typography variant="body2" fontWeight={500} dangerouslySetInnerHTML={{ __html: item.source.regionName }}></Typography>
                  <Box display="flex" alignItems="center" gap={0.5} ml="auto">
                      <RoomIcon fontSize="small" sx={{ color: 'text.secondary' }} />
                      <Typography
                        variant="body2"
                        fontWeight={500}
                        dangerouslySetInnerHTML={{ __html: item.source.countryNames }}
                      />
                    </Box>
                </Box>
              </Grid>

              {/* Right Section with Side Divider */}
              <Grid
                item
                xs={12}
                md={3}
                sx={{
                  pl: 5,
                  borderLeft: '1px solid #e0e0e0',
                  display: 'flex',
                  flexDirection: 'column',
                  gap: 1,
                }}
              >
                <Typography variant="body2" color="text.secondary">
                  Workflow Status: <Box component="span" fontWeight={500} dangerouslySetInnerHTML={{ __html: item.source.applicationStatus }}></Box>
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  Application Type: <Box component="span" fontWeight={500} dangerouslySetInnerHTML={{ __html: item.source.applicationType }}></Box>
                </Typography>
              </Grid>
            </Grid>


            {/* Divider */}
            {/* <Divider sx={{ mt: 3 }} /> */}
            {/* </Paper> */}
          </Grid>
        ))}
      </Grid>

      {/* Pagination Controls */}
      <Box display="flex" justifyContent="flex-end" mt={2}>
        <Stack direction="row" spacing={1} alignItems="center">
          <Typography variant="body2" color="text.secondary">Rows per page:</Typography>

          <FormControl size="small" variant="standard">
            <Select
              value={rowsPerPage}
              onChange={handleRowsPerPageChange}
              disableUnderline
              sx={{ minWidth: 60, fontSize: '0.875rem' }}
            >
              {[5, 10, 25, 50].map((count) => (
                <MenuItem key={count} value={count}>
                  {count}
                </MenuItem>
              ))}
            </Select>
          </FormControl>

          <Typography variant="body2" color="text.secondary">
            {Math.min((page - 1) * rowsPerPage + 1, totalCount)}–
            {Math.min(page * rowsPerPage, totalCount)} of {totalCount}
          </Typography>

          <Pagination
            count={Math.ceil(totalCount / rowsPerPage)}
            page={page}
            onChange={handlePageChange}
            siblingCount={0}
            boundaryCount={0}
            size="small"
            shape="rounded"
            variant="text"
            showFirstButton={false}
            showLastButton={false}
            sx={{
              '& .MuiPagination-ul': {
                gap: 0.5,
              },
              '& .MuiPaginationItem-root': {
                minWidth: 30,
                height: 30,
                fontSize: '0.75rem',
              }
            }}
          />
        </Stack>
      </Box>
    </Box>
  
  );
};

export default GlobalSearchList;



