# Installation
> `npm install --save @types/diff`

# Summary
This package contains type definitions for diff (https://github.com/kpdecker/jsdiff).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/diff.

### Additional Details
 * Last updated: Mon, 06 May 2024 19:06:39 GMT
 * Dependencies: none

# Credits
These definitions were written by [vvakame](https://github.com/vvakame), [szdc](https://github.com/szdc), [BendingBender](https://github.com/BendingBender), and [Piotr Błażejewicz](https://github.com/peterblazejewicz).
