# Installation
> `npm install --save @types/js-cookie`

# Summary
This package contains type definitions for js-cookie (https://github.com/js-cookie/js-cookie).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/js-cookie.

### Additional Details
 * Last updated: Tue, 07 Nov 2023 03:09:37 GMT
 * Dependencies: none

# Credits
These definitions were written by [Theodore Brown](https://github.com/theodorejb), [BendingBender](https://github.com/BendingBender), [Antoine Lépée](https://github.com/alepee), [Yuto Doi](https://github.com/yutod), [Nicolas Reynis](https://github.com/nreynis), and [Piotr Błażejewicz](https://github.com/peterblazejewicz).
