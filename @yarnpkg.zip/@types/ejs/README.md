# Installation
> `npm install --save @types/ejs`

# Summary
This package contains type definitions for ejs (http://ejs.co/).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/ejs.

### Additional Details
 * Last updated: Mon, 06 Nov 2023 22:41:05 GMT
 * Dependencies: none

# Credits
These definitions were written by [Ben Liddicott](https://github.com/benliddicott), [ExE Boss](https://github.com/ExE-Boss), and [Piotr Błażejewicz](https://github.com/peterblazejewicz).
