# Installation
> `npm install --save @types/emscripten`

# Summary
This package contains type definitions for emscripten (https://emscripten.org).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/emscripten.

### Additional Details
 * Last updated: Tue, 28 May 2024 20:07:23 GMT
 * Dependencies: none

# Credits
These definitions were written by [Kensuke Matsuzaki](https://github.com/zakki), [Periklis Tsirakidis](https://github.com/periklis), [Bumsik Kim](https://github.com/kbumsik), and [Louis DeScioli](https://github.com/lourd).
