# Installation
> `npm install --save @types/format-util`

# Summary
This package contains type definitions for format-util (https://github.com/tmpfs/format-util#readme).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/format-util.
## [index.d.ts](https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/format-util/index.d.ts)
````ts
declare function format(message: string, ...optionalParams: any[]): string;

export = format;

````

### Additional Details
 * Last updated: Tue, 07 Nov 2023 03:09:37 GMT
 * Dependencies: none

# Credits
These definitions were written by .
