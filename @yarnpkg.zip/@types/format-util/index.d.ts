declare function format(message: string, ...optionalParams: any[]): string;

export = format;
