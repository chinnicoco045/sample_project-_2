import { get } from "../fp";
export = get;
