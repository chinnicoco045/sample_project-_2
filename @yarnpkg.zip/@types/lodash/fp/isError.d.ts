import { isError } from "../fp";
export = isError;
