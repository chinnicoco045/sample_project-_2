import { assignIn } from "../fp";
export = assignIn;
