import { dropRightWhile } from "../fp";
export = dropRightWhile;
