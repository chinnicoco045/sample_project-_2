import { extend } from "../fp";
export = extend;
