import { max } from "../fp";
export = max;
