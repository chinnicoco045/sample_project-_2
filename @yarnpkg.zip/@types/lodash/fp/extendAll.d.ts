import { extendAll } from "../fp";
export = extendAll;
