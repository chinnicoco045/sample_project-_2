import { allPass } from "../fp";
export = allPass;
