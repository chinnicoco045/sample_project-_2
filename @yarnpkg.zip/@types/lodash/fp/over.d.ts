import { over } from "../fp";
export = over;
