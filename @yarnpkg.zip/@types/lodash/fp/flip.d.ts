import { flip } from "../fp";
export = flip;
