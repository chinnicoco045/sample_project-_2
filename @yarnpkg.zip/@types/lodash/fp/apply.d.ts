import { apply } from "../fp";
export = apply;
