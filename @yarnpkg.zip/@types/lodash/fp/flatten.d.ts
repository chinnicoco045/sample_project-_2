import { flatten } from "../fp";
export = flatten;
