import { dropRight } from "../fp";
export = dropRight;
