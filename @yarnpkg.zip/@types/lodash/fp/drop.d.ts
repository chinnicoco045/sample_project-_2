import { drop } from "../fp";
export = drop;
