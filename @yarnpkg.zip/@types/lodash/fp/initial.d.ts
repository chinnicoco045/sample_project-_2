import { initial } from "../fp";
export = initial;
