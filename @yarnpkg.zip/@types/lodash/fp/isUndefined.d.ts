import { isUndefined } from "../fp";
export = isUndefined;
