import { isEqual } from "../fp";
export = isEqual;
