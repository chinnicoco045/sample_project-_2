import { assignAllWith } from "../fp";
export = assignAllWith;
