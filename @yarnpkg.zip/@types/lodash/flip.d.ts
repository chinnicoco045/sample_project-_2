import { flip } from "./index";
export = flip;
