import { extendWith } from "./index";
export = extendWith;
