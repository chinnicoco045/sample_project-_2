import { divide } from "./index";
export = divide;
