import { flattenDeep } from "./index";
export = flattenDeep;
