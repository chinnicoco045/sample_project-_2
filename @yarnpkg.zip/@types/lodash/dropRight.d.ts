import { dropRight } from "./index";
export = dropRight;
