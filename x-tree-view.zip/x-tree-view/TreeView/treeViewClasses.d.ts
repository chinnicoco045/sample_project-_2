export interface TreeViewClasses {
    /** Styles applied to the root element. */
    root: string;
}
export type TreeViewClassKey = keyof TreeViewClasses;
export declare function getTreeViewUtilityClass(slot: string): string;
export declare const treeViewClasses: TreeViewClasses;
