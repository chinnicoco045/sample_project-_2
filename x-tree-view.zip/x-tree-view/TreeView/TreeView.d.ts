import * as React from 'react';
import { TreeViewProps } from './TreeView.types';
type TreeViewComponent = (<Multiple extends boolean | undefined = undefined>(props: TreeViewProps<Multiple> & React.RefAttributes<HTMLUListElement>) => React.JSX.Element) & {
    propTypes?: any;
};
/**
 * This component has been deprecated in favor of the new `SimpleTreeView` component.
 * You can have a look at how to migrate to the new component in the v7 [migration guide](https://mui.com/x/migration/migration-tree-view-v6/#use-simpletreeview-instead-of-treeview)
 *
 * Demos:
 *
 * - [Tree View](https://mui.com/x/react-tree-view/)
 *
 * API:
 *
 * - [TreeView API](https://mui.com/x/api/tree-view/tree-view/)
 *
 * @deprecated
 */
declare const TreeView: TreeViewComponent;
export { TreeView };
