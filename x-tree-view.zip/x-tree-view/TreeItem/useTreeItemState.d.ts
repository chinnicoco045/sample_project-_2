import * as React from 'react';
export declare function useTreeItemState(itemId: string): {
    disabled: boolean;
    expanded: boolean;
    selected: boolean;
    focused: boolean;
    handleExpansion: (event: React.MouseEvent<HTMLDivElement>) => void;
    handleSelection: (event: React.MouseEvent<HTMLDivElement>) => void;
    preventSelection: (event: React.MouseEvent<HTMLDivElement>) => void;
};
