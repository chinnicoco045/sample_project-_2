import * as React from 'react';
export declare const TreeViewChildrenItemContext: React.Context<TreeViewChildrenItemContextValue | null>;
interface TreeViewChildrenItemProviderProps {
    itemId?: string;
    children: React.ReactNode;
}
export declare function TreeViewChildrenItemProvider(props: TreeViewChildrenItemProviderProps): React.JSX.Element;
export declare namespace TreeViewChildrenItemProvider {
    var propTypes: any;
}
interface TreeViewChildrenItemContextValue {
    registerChild: (idAttribute: string, itemId: string) => void;
    unregisterChild: (idAttribute: string) => void;
    parentId: string | null;
}
export {};
