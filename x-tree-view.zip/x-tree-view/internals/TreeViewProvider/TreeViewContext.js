import * as React from 'react';
/**
 * @ignore - internal component.
 */
export const TreeViewContext = /*#__PURE__*/React.createContext(null);
if (process.env.NODE_ENV !== 'production') {
  TreeViewContext.displayName = 'TreeViewContext';
}