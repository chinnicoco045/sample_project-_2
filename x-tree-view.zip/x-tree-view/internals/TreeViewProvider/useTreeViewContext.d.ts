import { TreeViewAnyPluginSignature } from '../models';
import { TreeViewContextValue } from './TreeViewProvider.types';
export declare const useTreeViewContext: <TPlugins extends readonly TreeViewAnyPluginSignature[]>() => NonNullable<TreeViewContextValue<TPlugins>>;
