import * as React from 'react';
import { TreeViewContext } from './TreeViewContext';
import { jsx as _jsx } from "react/jsx-runtime";
/**
 * Sets up the contexts for the underlying TreeItem components.
 *
 * @ignore - do not document.
 */
export function TreeViewProvider(props) {
  const {
    value,
    children
  } = props;
  return /*#__PURE__*/_jsx(TreeViewContext.Provider, {
    value: value,
    children: value.wrapRoot({
      children
    })
  });
}