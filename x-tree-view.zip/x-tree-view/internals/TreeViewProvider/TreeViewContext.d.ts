import * as React from 'react';
/**
 * @ignore - internal component.
 */
export declare const TreeViewContext: React.Context<{
    instance: {};
    publicAPI: {};
    rootRef: React.RefObject<HTMLUListElement>;
    wrapItem: import("../models").TreeItemWrapper;
    wrapRoot: import("../models").TreeRootWrapper;
    runItemPlugins: <TProps extends {}>(props: TProps) => Required<import("../models").TreeViewItemPluginResponse>;
} | null>;
