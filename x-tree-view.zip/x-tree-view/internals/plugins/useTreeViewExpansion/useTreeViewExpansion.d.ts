import { TreeViewPlugin } from '../../models';
import { UseTreeViewExpansionSignature } from './useTreeViewExpansion.types';
export declare const useTreeViewExpansion: TreeViewPlugin<UseTreeViewExpansionSignature>;
