import { TreeViewPlugin } from '../../models';
import { UseTreeViewFocusSignature } from './useTreeViewFocus.types';
export declare const useTreeViewFocus: TreeViewPlugin<UseTreeViewFocusSignature>;
