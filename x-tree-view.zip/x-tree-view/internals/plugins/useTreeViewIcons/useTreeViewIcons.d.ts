import { TreeViewPlugin } from '../../models';
import { UseTreeViewIconsSignature } from './useTreeViewIcons.types';
export declare const useTreeViewIcons: TreeViewPlugin<UseTreeViewIconsSignature>;
