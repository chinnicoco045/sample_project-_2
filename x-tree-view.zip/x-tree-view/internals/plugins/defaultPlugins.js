import { useTreeViewId } from './useTreeViewId';
import { useTreeViewItems } from './useTreeViewItems';
import { useTreeViewExpansion } from './useTreeViewExpansion';
import { useTreeViewSelection } from './useTreeViewSelection';
import { useTreeViewFocus } from './useTreeViewFocus';
import { useTreeViewKeyboardNavigation } from './useTreeViewKeyboardNavigation';
import { useTreeViewIcons } from './useTreeViewIcons';
export const DEFAULT_TREE_VIEW_PLUGINS = [useTreeViewId, useTreeViewItems, useTreeViewExpansion, useTreeViewSelection, useTreeViewFocus, useTreeViewKeyboardNavigation, useTreeViewIcons];

// We can't infer this type from the plugin, otherwise we would lose the generics.