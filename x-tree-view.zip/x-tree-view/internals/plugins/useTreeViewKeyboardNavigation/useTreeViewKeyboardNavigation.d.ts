import { TreeViewPlugin } from '../../models';
import { UseTreeViewKeyboardNavigationSignature } from './useTreeViewKeyboardNavigation.types';
export declare const useTreeViewKeyboardNavigation: TreeViewPlugin<UseTreeViewKeyboardNavigationSignature>;
