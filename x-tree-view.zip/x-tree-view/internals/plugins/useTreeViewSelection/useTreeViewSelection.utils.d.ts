/**
 * Transform the `selectedItems` model to be an array if it was a string or null.
 * @param {string[] | string | null} model The raw model.
 * @returns {string[]} The converted model.
 */
export declare const convertSelectedItemsToArray: (model: string[] | string | null) => string[];
export declare const getLookupFromArray: (array: string[]) => {
    [itemId: string]: boolean;
};
