import { TreeViewPlugin } from '../../models';
import { UseTreeViewSelectionSignature } from './useTreeViewSelection.types';
export declare const useTreeViewSelection: TreeViewPlugin<UseTreeViewSelectionSignature>;
