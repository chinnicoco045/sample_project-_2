import { TreeViewPlugin } from '../../models';
import { UseTreeViewIdSignature } from './useTreeViewId.types';
export declare const useTreeViewId: TreeViewPlugin<UseTreeViewIdSignature>;
