import { TreeViewPlugin } from '../../models';
import { UseTreeViewJSXItemsSignature } from './useTreeViewJSXItems.types';
export declare const useTreeViewJSXItems: TreeViewPlugin<UseTreeViewJSXItemsSignature>;
