export declare const TREE_VIEW_ROOT_PARENT_ID = "__TREE_VIEW_ROOT_PARENT_ID__";
export declare const buildSiblingIndexes: (siblings: string[]) => {
    [itemId: string]: number;
};
