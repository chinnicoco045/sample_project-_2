import { TreeViewPlugin } from '../../models';
import { UseTreeViewItemsSignature } from './useTreeViewItems.types';
export declare const useTreeViewItems: TreeViewPlugin<UseTreeViewItemsSignature>;
