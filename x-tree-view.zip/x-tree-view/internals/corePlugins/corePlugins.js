import { useTreeViewInstanceEvents } from './useTreeViewInstanceEvents';
/**
 * Internal plugins that create the tools used by the other plugins.
 * These plugins are used by the tree view components.
 */
export const TREE_VIEW_CORE_PLUGINS = [useTreeViewInstanceEvents];