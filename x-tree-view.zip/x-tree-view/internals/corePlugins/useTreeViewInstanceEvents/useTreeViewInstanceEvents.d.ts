import type { TreeViewPlugin } from '../../models';
import { UseTreeViewInstanceEventsSignature } from './useTreeViewInstanceEvents.types';
export declare const useTreeViewInstanceEvents: TreeViewPlugin<UseTreeViewInstanceEventsSignature>;
