import { UseTreeViewInstanceEventsInstance } from '../corePlugins/useTreeViewInstanceEvents/useTreeViewInstanceEvents.types';
import { TreeViewAnyPluginSignature, TreeViewUsedEvents } from '../models';
export declare const publishTreeViewEvent: <Instance extends UseTreeViewInstanceEventsInstance & {
    $$signature: TreeViewAnyPluginSignature;
}, E extends keyof Instance["$$signature"]["events"] | keyof import("../models").MergePluginsProperty<[import("../corePlugins").TreeViewCorePluginsSignature, ...Instance["$$signature"]["dependantPlugins"]], "events">>(instance: Instance, eventName: E, params: TreeViewUsedEvents<Instance['$$signature']>[E]['params']) => void;
