export declare const buildWarning: (message: string | string[], gravity?: 'warning' | 'error') => () => void;
