import * as React from 'react';
import { ConvertPluginsIntoSignatures, MergePluginsProperty, TreeViewPlugin, TreeViewPublicAPI } from '../models';
import { UseTreeViewBaseParameters } from '../useTreeView/useTreeView.types';
export declare const extractPluginParamsFromProps: <TPlugins extends readonly TreeViewPlugin<any>[], TSlots extends MergePluginsProperty<TPlugins, "slots">, TSlotProps extends MergePluginsProperty<TPlugins, "slotProps">, TProps extends {
    slots?: TSlots | undefined;
    slotProps?: TSlotProps | undefined;
    apiRef?: React.MutableRefObject<TreeViewPublicAPI<ConvertPluginsIntoSignatures<TPlugins>> | undefined> | undefined;
}>({ props: { slots, slotProps, apiRef, ...props }, plugins, rootRef, }: {
    props: TProps;
    plugins: TPlugins;
    rootRef?: React.Ref<HTMLUListElement>;
}) => {
    pluginParams: UseTreeViewBaseParameters<TPlugins> & MergePluginsProperty<ConvertPluginsIntoSignatures<TPlugins>, "params">;
    slots: TSlots | undefined;
    slotProps: TSlotProps | undefined;
    otherProps: Omit<TProps, keyof MergePluginsProperty<ConvertPluginsIntoSignatures<TPlugins>, "params">>;
};
