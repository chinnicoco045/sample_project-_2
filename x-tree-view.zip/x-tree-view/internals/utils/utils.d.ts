export declare const getActiveElement: (root?: Document | ShadowRoot) => Element | null;
