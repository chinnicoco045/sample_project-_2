import { CleanupTracking } from '../utils/cleanupTracking/CleanupTracking';
import { TreeViewAnyPluginSignature, TreeViewUsedEvents } from '../models';
import { TreeViewEventListener } from '../models/events';
import { UseTreeViewInstanceEventsInstance } from '../corePlugins/useTreeViewInstanceEvents/useTreeViewInstanceEvents.types';
interface RegistryContainer {
    registry: CleanupTracking | null;
}
export declare function createUseInstanceEventHandler(registryContainer: RegistryContainer): <Instance extends UseTreeViewInstanceEventsInstance & {
    $$signature: TreeViewAnyPluginSignature;
}, E extends keyof Instance["$$signature"]["events"] | keyof import("../models").MergePluginsProperty<[import("../corePlugins").TreeViewCorePluginsSignature, ...Instance["$$signature"]["dependantPlugins"]], "events">>(instance: Instance, eventName: E, handler: TreeViewEventListener<TreeViewUsedEvents<Instance['$$signature']>[E]>) => void;
export declare const unstable_resetCleanupTracking: () => void;
export declare const useInstanceEventHandler: <Instance extends UseTreeViewInstanceEventsInstance & {
    $$signature: TreeViewAnyPluginSignature;
}, E extends keyof Instance["$$signature"]["events"] | keyof import("../models").MergePluginsProperty<[import("../corePlugins").TreeViewCorePluginsSignature, ...Instance["$$signature"]["dependantPlugins"]], "events">>(instance: Instance, eventName: E, handler: TreeViewEventListener<TreeViewUsedEvents<Instance['$$signature']>[E]>) => void;
export {};
