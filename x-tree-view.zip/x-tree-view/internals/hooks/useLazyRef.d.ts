export { default as useLazyRef } from '@mui/utils/useLazyRef';
