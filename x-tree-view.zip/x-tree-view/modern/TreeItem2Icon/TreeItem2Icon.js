import _extends from "@babel/runtime/helpers/esm/extends";
import * as React from 'react';
import PropTypes from 'prop-types';
import { resolveComponentProps, useSlotProps } from '@mui/base/utils';
import { useTreeViewContext } from '../internals/TreeViewProvider/useTreeViewContext';
import { TreeViewCollapseIcon, TreeViewExpandIcon } from '../icons';
import { jsx as _jsx } from "react/jsx-runtime";
function TreeItem2Icon(props) {
  const {
    slots,
    slotProps,
    status
  } = props;
  const context = useTreeViewContext();
  const contextIcons = _extends({}, context.icons.slots, {
    expandIcon: context.icons.slots.expandIcon ?? TreeViewExpandIcon,
    collapseIcon: context.icons.slots.collapseIcon ?? TreeViewCollapseIcon
  });
  const contextIconProps = context.icons.slotProps;
  let iconName;
  if (slots?.icon) {
    iconName = 'icon';
  } else if (status.expandable) {
    if (status.expanded) {
      iconName = 'collapseIcon';
    } else {
      iconName = 'expandIcon';
    }
  } else {
    iconName = 'endIcon';
  }
  const Icon = slots?.[iconName] ?? contextIcons[iconName];
  const iconProps = useSlotProps({
    elementType: Icon,
    externalSlotProps: tempOwnerState => _extends({}, resolveComponentProps(contextIconProps[iconName], tempOwnerState), resolveComponentProps(slotProps?.[iconName], tempOwnerState)),
    // TODO: Add proper ownerState
    ownerState: {}
  });
  if (!Icon) {
    return null;
  }
  return /*#__PURE__*/_jsx(Icon, _extends({}, iconProps));
}
process.env.NODE_ENV !== "production" ? TreeItem2Icon.propTypes = {
  // ----------------------------- Warning --------------------------------
  // | These PropTypes are generated from the TypeScript type definitions |
  // | To update them edit the TypeScript types and run "yarn proptypes"  |
  // ----------------------------------------------------------------------
  /**
   * The props used for each component slot.
   * @default {}
   */
  slotProps: PropTypes.object,
  /**
   * Overridable component slots.
   * @default {}
   */
  slots: PropTypes.object,
  status: PropTypes.shape({
    disabled: PropTypes.bool.isRequired,
    expandable: PropTypes.bool.isRequired,
    expanded: PropTypes.bool.isRequired,
    focused: PropTypes.bool.isRequired,
    selected: PropTypes.bool.isRequired
  }).isRequired
} : void 0;
export { TreeItem2Icon };