import PropTypes from 'prop-types';
import { useTreeViewContext } from '../internals/TreeViewProvider/useTreeViewContext';
function TreeItem2Provider(props) {
  const {
    children,
    itemId
  } = props;
  const {
    wrapItem
  } = useTreeViewContext();
  return wrapItem({
    children,
    itemId
  });
}
TreeItem2Provider.propTypes = {
  // ----------------------------- Warning --------------------------------
  // | These PropTypes are generated from the TypeScript type definitions |
  // | To update them edit the TypeScript types and run "yarn proptypes"  |
  // ----------------------------------------------------------------------
  children: PropTypes.node,
  itemId: PropTypes.string.isRequired
};
export { TreeItem2Provider };