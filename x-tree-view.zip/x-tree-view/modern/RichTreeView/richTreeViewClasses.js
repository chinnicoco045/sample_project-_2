import generateUtilityClass from '@mui/utils/generateUtilityClass';
import generateUtilityClasses from '@mui/utils/generateUtilityClasses';
export function getRichTreeViewUtilityClass(slot) {
  return generateUtilityClass('MuiRichTreeView', slot);
}
export const richTreeViewClasses = generateUtilityClasses('MuiRichTreeView', ['root']);