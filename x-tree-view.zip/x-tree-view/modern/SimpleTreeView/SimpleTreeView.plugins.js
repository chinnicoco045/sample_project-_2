import { DEFAULT_TREE_VIEW_PLUGINS } from '../internals/plugins/defaultPlugins';
import { useTreeViewJSXItems } from '../internals/plugins/useTreeViewJSXItems';
export const SIMPLE_TREE_VIEW_PLUGINS = [...DEFAULT_TREE_VIEW_PLUGINS, useTreeViewJSXItems];

// We can't infer this type from the plugin, otherwise we would lose the generics.