import generateUtilityClass from '@mui/utils/generateUtilityClass';
import generateUtilityClasses from '@mui/utils/generateUtilityClasses';
export function getSimpleTreeViewUtilityClass(slot) {
  return generateUtilityClass('MuiSimpleTreeView', slot);
}
export const simpleTreeViewClasses = generateUtilityClasses('MuiSimpleTreeView', ['root']);