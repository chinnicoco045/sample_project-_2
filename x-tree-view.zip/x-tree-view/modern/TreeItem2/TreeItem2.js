import _objectWithoutPropertiesLoose from "@babel/runtime/helpers/esm/objectWithoutPropertiesLoose";
import _extends from "@babel/runtime/helpers/esm/extends";
const _excluded = ["id", "itemId", "label", "disabled", "children", "slots", "slotProps"];
import * as React from 'react';
import PropTypes from 'prop-types';
import clsx from 'clsx';
import unsupportedProp from '@mui/utils/unsupportedProp';
import { alpha, styled, useThemeProps } from '@mui/material/styles';
import Collapse from '@mui/material/Collapse';
import { useSlotProps } from '@mui/base/utils';
import { shouldForwardProp } from '@mui/system';
import composeClasses from '@mui/utils/composeClasses';
import { unstable_useTreeItem2 as useTreeItem2 } from '../useTreeItem2';
import { getTreeItemUtilityClass, treeItemClasses } from '../TreeItem';
import { TreeItem2Icon } from '../TreeItem2Icon';
import { TreeItem2Provider } from '../TreeItem2Provider';
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
export const TreeItem2Root = styled('li', {
  name: 'MuiTreeItem2',
  slot: 'Root',
  overridesResolver: (props, styles) => styles.root
})({
  listStyle: 'none',
  margin: 0,
  padding: 0,
  outline: 0
});
export const TreeItem2Content = styled('div', {
  name: 'MuiTreeItem2',
  slot: 'Content',
  overridesResolver: (props, styles) => styles.content,
  shouldForwardProp: prop => shouldForwardProp(prop) && prop !== 'status'
})(({
  theme
}) => ({
  padding: theme.spacing(0.5, 1),
  borderRadius: theme.shape.borderRadius,
  width: '100%',
  boxSizing: 'border-box',
  // prevent width + padding to overflow
  display: 'flex',
  alignItems: 'center',
  gap: theme.spacing(1),
  cursor: 'pointer',
  WebkitTapHighlightColor: 'transparent',
  '&:hover': {
    backgroundColor: (theme.vars || theme).palette.action.hover,
    // Reset on touch devices, it doesn't add specificity
    '@media (hover: none)': {
      backgroundColor: 'transparent'
    }
  },
  [`& .${treeItemClasses.groupTransition}`]: {
    margin: 0,
    padding: 0,
    paddingLeft: 12
  },
  variants: [{
    props: ({
      status
    }) => status.disabled,
    style: {
      opacity: (theme.vars || theme).palette.action.disabledOpacity,
      backgroundColor: 'transparent'
    }
  }, {
    props: ({
      status
    }) => status.focused,
    style: {
      backgroundColor: (theme.vars || theme).palette.action.focus
    }
  }, {
    props: ({
      status
    }) => status.selected,
    style: {
      backgroundColor: theme.vars ? `rgba(${theme.vars.palette.primary.mainChannel} / ${theme.vars.palette.action.selectedOpacity})` : alpha(theme.palette.primary.main, theme.palette.action.selectedOpacity),
      '&:hover': {
        backgroundColor: theme.vars ? `rgba(${theme.vars.palette.primary.mainChannel} / calc(${theme.vars.palette.action.selectedOpacity} + ${theme.vars.palette.action.hoverOpacity}))` : alpha(theme.palette.primary.main, theme.palette.action.selectedOpacity + theme.palette.action.hoverOpacity),
        // Reset on touch devices, it doesn't add specificity
        '@media (hover: none)': {
          backgroundColor: theme.vars ? `rgba(${theme.vars.palette.primary.mainChannel} / ${theme.vars.palette.action.selectedOpacity})` : alpha(theme.palette.primary.main, theme.palette.action.selectedOpacity)
        }
      }
    }
  }, {
    props: ({
      status
    }) => status.selected && status.focused,
    style: {
      backgroundColor: theme.vars ? `rgba(${theme.vars.palette.primary.mainChannel} / calc(${theme.vars.palette.action.selectedOpacity} + ${theme.vars.palette.action.focusOpacity}))` : alpha(theme.palette.primary.main, theme.palette.action.selectedOpacity + theme.palette.action.focusOpacity)
    }
  }]
}));
export const TreeItem2Label = styled('div', {
  name: 'MuiTreeItem2',
  slot: 'Label',
  overridesResolver: (props, styles) => styles.label
})(({
  theme
}) => _extends({
  width: '100%',
  boxSizing: 'border-box',
  // prevent width + padding to overflow
  // fixes overflow - see https://github.com/mui/material-ui/issues/27372
  minWidth: 0,
  position: 'relative'
}, theme.typography.body1));
export const TreeItem2IconContainer = styled('div', {
  name: 'MuiTreeItem2',
  slot: 'IconContainer',
  overridesResolver: (props, styles) => styles.iconContainer
})({
  width: 16,
  display: 'flex',
  flexShrink: 0,
  justifyContent: 'center',
  '& svg': {
    fontSize: 18
  }
});
export const TreeItem2GroupTransition = styled(Collapse, {
  name: 'MuiTreeItem2GroupTransition',
  slot: 'GroupTransition',
  overridesResolver: (props, styles) => styles.groupTransition
})({
  margin: 0,
  padding: 0,
  paddingLeft: 12
});
const useUtilityClasses = ownerState => {
  const {
    classes
  } = ownerState;
  const slots = {
    root: ['root'],
    content: ['content'],
    expanded: ['expanded'],
    selected: ['selected'],
    focused: ['focused'],
    disabled: ['disabled'],
    iconContainer: ['iconContainer'],
    label: ['label'],
    groupTransition: ['groupTransition']
  };
  return composeClasses(slots, getTreeItemUtilityClass, classes);
};
/**
 *
 * Demos:
 *
 * - [Tree View](https://mui.com/x/react-tree-view/)
 *
 * API:
 *
 * - [TreeItem2 API](https://mui.com/x/api/tree-view/tree-item-2/)
 */
export const TreeItem2 = /*#__PURE__*/React.forwardRef(function TreeItem2(inProps, forwardedRef) {
  const props = useThemeProps({
    props: inProps,
    name: 'MuiTreeItem2'
  });
  const {
      id,
      itemId,
      label,
      disabled,
      children,
      slots = {},
      slotProps = {}
    } = props,
    other = _objectWithoutPropertiesLoose(props, _excluded);
  const {
    getRootProps,
    getContentProps,
    getIconContainerProps,
    getLabelProps,
    getGroupTransitionProps,
    status
  } = useTreeItem2({
    id,
    itemId,
    children,
    label,
    disabled
  });
  const ownerState = _extends({}, props, status);
  const classes = useUtilityClasses(ownerState);
  const Root = slots.root ?? TreeItem2Root;
  const rootProps = useSlotProps({
    elementType: Root,
    getSlotProps: getRootProps,
    externalForwardedProps: other,
    externalSlotProps: slotProps.root,
    additionalProps: {
      ref: forwardedRef
    },
    ownerState: {},
    className: classes.root
  });
  const Content = slots.content ?? TreeItem2Content;
  const contentProps = useSlotProps({
    elementType: Content,
    getSlotProps: getContentProps,
    externalSlotProps: slotProps.content,
    ownerState: {},
    className: clsx(classes.content, status.expanded && classes.expanded, status.selected && classes.selected, status.focused && classes.focused, status.disabled && classes.disabled)
  });
  const IconContainer = slots.iconContainer ?? TreeItem2IconContainer;
  const iconContainerProps = useSlotProps({
    elementType: IconContainer,
    getSlotProps: getIconContainerProps,
    externalSlotProps: slotProps.iconContainer,
    ownerState: {},
    className: classes.iconContainer
  });
  const Label = slots.label ?? TreeItem2Label;
  const labelProps = useSlotProps({
    elementType: Label,
    getSlotProps: getLabelProps,
    externalSlotProps: slotProps.label,
    ownerState: {},
    className: classes.label
  });
  const GroupTransition = slots.groupTransition ?? undefined;
  const groupTransitionProps = useSlotProps({
    elementType: GroupTransition,
    getSlotProps: getGroupTransitionProps,
    externalSlotProps: slotProps.groupTransition,
    ownerState: {},
    className: classes.groupTransition
  });
  return /*#__PURE__*/_jsx(TreeItem2Provider, {
    itemId: itemId,
    children: /*#__PURE__*/_jsxs(Root, _extends({}, rootProps, {
      children: [/*#__PURE__*/_jsxs(Content, _extends({}, contentProps, {
        children: [/*#__PURE__*/_jsx(IconContainer, _extends({}, iconContainerProps, {
          children: /*#__PURE__*/_jsx(TreeItem2Icon, {
            status: status,
            slots: slots,
            slotProps: slotProps
          })
        })), /*#__PURE__*/_jsx(Label, _extends({}, labelProps))]
      })), children && /*#__PURE__*/_jsx(TreeItem2GroupTransition, _extends({
        as: GroupTransition
      }, groupTransitionProps))]
    }))
  });
});
process.env.NODE_ENV !== "production" ? TreeItem2.propTypes = {
  // ----------------------------- Warning --------------------------------
  // | These PropTypes are generated from the TypeScript type definitions |
  // | To update them edit the TypeScript types and run "yarn proptypes"  |
  // ----------------------------------------------------------------------
  /**
   * The content of the component.
   */
  children: PropTypes.node,
  /**
   * Override or extend the styles applied to the component.
   */
  classes: PropTypes.object,
  className: PropTypes.string,
  /**
   * If `true`, the item is disabled.
   * @default false
   */
  disabled: PropTypes.bool,
  /**
   * The id attribute of the item. If not provided, it will be generated.
   */
  id: PropTypes.string,
  /**
   * The id of the item.
   * Must be unique.
   */
  itemId: PropTypes.string.isRequired,
  /**
   * The label of the item.
   */
  label: PropTypes.node,
  /**
   * This prop isn't supported.
   * Use the `onItemFocus` callback on the tree if you need to monitor a item's focus.
   */
  onFocus: unsupportedProp,
  /**
   * The props used for each component slot.
   * @default {}
   */
  slotProps: PropTypes.object,
  /**
   * Overridable component slots.
   * @default {}
   */
  slots: PropTypes.object
} : void 0;