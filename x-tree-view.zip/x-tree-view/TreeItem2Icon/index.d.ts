export { TreeItem2Icon } from './TreeItem2Icon';
export type { TreeItem2IconProps, TreeItem2IconSlots, TreeItem2IconSlotProps, } from './TreeItem2Icon.types';
