import * as React from 'react';
import { TreeItem2IconProps } from './TreeItem2Icon.types';
declare function TreeItem2Icon(props: TreeItem2IconProps): React.JSX.Element | null;
declare namespace TreeItem2Icon {
    var propTypes: any;
}
export { TreeItem2Icon };
