import * as React from 'react';
/**
 * Hook that instantiates a [[TreeViewApiRef]].
 */
export const useTreeViewApiRef = () => React.useRef(undefined);