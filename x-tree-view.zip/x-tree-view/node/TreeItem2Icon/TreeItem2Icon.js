"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.TreeItem2Icon = TreeItem2Icon;
var _extends2 = _interopRequireDefault(require("@babel/runtime/helpers/extends"));
var React = _interopRequireWildcard(require("react"));
var _propTypes = _interopRequireDefault(require("prop-types"));
var _utils = require("@mui/base/utils");
var _useTreeViewContext = require("../internals/TreeViewProvider/useTreeViewContext");
var _icons = require("../icons");
var _jsxRuntime = require("react/jsx-runtime");
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function (e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != typeof e && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
function TreeItem2Icon(props) {
  const {
    slots,
    slotProps,
    status
  } = props;
  const context = (0, _useTreeViewContext.useTreeViewContext)();
  const contextIcons = (0, _extends2.default)({}, context.icons.slots, {
    expandIcon: context.icons.slots.expandIcon ?? _icons.TreeViewExpandIcon,
    collapseIcon: context.icons.slots.collapseIcon ?? _icons.TreeViewCollapseIcon
  });
  const contextIconProps = context.icons.slotProps;
  let iconName;
  if (slots?.icon) {
    iconName = 'icon';
  } else if (status.expandable) {
    if (status.expanded) {
      iconName = 'collapseIcon';
    } else {
      iconName = 'expandIcon';
    }
  } else {
    iconName = 'endIcon';
  }
  const Icon = slots?.[iconName] ?? contextIcons[iconName];
  const iconProps = (0, _utils.useSlotProps)({
    elementType: Icon,
    externalSlotProps: tempOwnerState => (0, _extends2.default)({}, (0, _utils.resolveComponentProps)(contextIconProps[iconName], tempOwnerState), (0, _utils.resolveComponentProps)(slotProps?.[iconName], tempOwnerState)),
    // TODO: Add proper ownerState
    ownerState: {}
  });
  if (!Icon) {
    return null;
  }
  return /*#__PURE__*/(0, _jsxRuntime.jsx)(Icon, (0, _extends2.default)({}, iconProps));
}
process.env.NODE_ENV !== "production" ? TreeItem2Icon.propTypes = {
  // ----------------------------- Warning --------------------------------
  // | These PropTypes are generated from the TypeScript type definitions |
  // | To update them edit the TypeScript types and run "yarn proptypes"  |
  // ----------------------------------------------------------------------
  /**
   * The props used for each component slot.
   * @default {}
   */
  slotProps: _propTypes.default.object,
  /**
   * Overridable component slots.
   * @default {}
   */
  slots: _propTypes.default.object,
  status: _propTypes.default.shape({
    disabled: _propTypes.default.bool.isRequired,
    expandable: _propTypes.default.bool.isRequired,
    expanded: _propTypes.default.bool.isRequired,
    focused: _propTypes.default.bool.isRequired,
    selected: _propTypes.default.bool.isRequired
  }).isRequired
} : void 0;