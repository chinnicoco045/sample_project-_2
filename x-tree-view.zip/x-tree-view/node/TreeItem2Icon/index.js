"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "TreeItem2Icon", {
  enumerable: true,
  get: function () {
    return _TreeItem2Icon.TreeItem2Icon;
  }
});
var _TreeItem2Icon = require("./TreeItem2Icon");