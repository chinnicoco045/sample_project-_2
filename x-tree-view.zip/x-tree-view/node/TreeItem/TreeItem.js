"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.TreeItem = void 0;
var _objectWithoutPropertiesLoose2 = _interopRequireDefault(require("@babel/runtime/helpers/objectWithoutPropertiesLoose"));
var _extends2 = _interopRequireDefault(require("@babel/runtime/helpers/extends"));
var React = _interopRequireWildcard(require("react"));
var _propTypes = _interopRequireDefault(require("prop-types"));
var _clsx = _interopRequireDefault(require("clsx"));
var _Collapse = _interopRequireDefault(require("@mui/material/Collapse"));
var _utils = require("@mui/base/utils");
var _useForkRef = _interopRequireDefault(require("@mui/utils/useForkRef"));
var _styles = require("@mui/material/styles");
var _unsupportedProp = _interopRequireDefault(require("@mui/utils/unsupportedProp"));
var _elementTypeAcceptingRef = _interopRequireDefault(require("@mui/utils/elementTypeAcceptingRef"));
var _base = require("@mui/base");
var _TreeItemContent = require("./TreeItemContent");
var _treeItemClasses = require("./treeItemClasses");
var _useTreeViewContext = require("../internals/TreeViewProvider/useTreeViewContext");
var _icons = require("../icons");
var _TreeItem2Provider = require("../TreeItem2Provider");
var _jsxRuntime = require("react/jsx-runtime");
const _excluded = ["children", "className", "slots", "slotProps", "ContentComponent", "ContentProps", "itemId", "id", "label", "onClick", "onMouseDown", "onFocus", "onBlur", "onKeyDown"],
  _excluded2 = ["ownerState"],
  _excluded3 = ["ownerState"],
  _excluded4 = ["ownerState"];
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function (e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != typeof e && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
const useUtilityClasses = ownerState => {
  const {
    classes
  } = ownerState;
  const slots = {
    root: ['root'],
    content: ['content'],
    expanded: ['expanded'],
    selected: ['selected'],
    focused: ['focused'],
    disabled: ['disabled'],
    iconContainer: ['iconContainer'],
    label: ['label'],
    groupTransition: ['groupTransition']
  };
  return (0, _base.unstable_composeClasses)(slots, _treeItemClasses.getTreeItemUtilityClass, classes);
};
const TreeItemRoot = (0, _styles.styled)('li', {
  name: 'MuiTreeItem',
  slot: 'Root',
  overridesResolver: (props, styles) => styles.root
})({
  listStyle: 'none',
  margin: 0,
  padding: 0,
  outline: 0
});
const StyledTreeItemContent = (0, _styles.styled)(_TreeItemContent.TreeItemContent, {
  name: 'MuiTreeItem',
  slot: 'Content',
  overridesResolver: (props, styles) => {
    return [styles.content, styles.iconContainer && {
      [`& .${_treeItemClasses.treeItemClasses.iconContainer}`]: styles.iconContainer
    }, styles.label && {
      [`& .${_treeItemClasses.treeItemClasses.label}`]: styles.label
    }];
  }
})(({
  theme
}) => ({
  padding: theme.spacing(0.5, 1),
  borderRadius: theme.shape.borderRadius,
  width: '100%',
  boxSizing: 'border-box',
  // prevent width + padding to overflow
  display: 'flex',
  alignItems: 'center',
  gap: theme.spacing(1),
  cursor: 'pointer',
  WebkitTapHighlightColor: 'transparent',
  '&:hover': {
    backgroundColor: (theme.vars || theme).palette.action.hover,
    // Reset on touch devices, it doesn't add specificity
    '@media (hover: none)': {
      backgroundColor: 'transparent'
    }
  },
  [`&.${_treeItemClasses.treeItemClasses.disabled}`]: {
    opacity: (theme.vars || theme).palette.action.disabledOpacity,
    backgroundColor: 'transparent'
  },
  [`&.${_treeItemClasses.treeItemClasses.focused}`]: {
    backgroundColor: (theme.vars || theme).palette.action.focus
  },
  [`&.${_treeItemClasses.treeItemClasses.selected}`]: {
    backgroundColor: theme.vars ? `rgba(${theme.vars.palette.primary.mainChannel} / ${theme.vars.palette.action.selectedOpacity})` : (0, _styles.alpha)(theme.palette.primary.main, theme.palette.action.selectedOpacity),
    '&:hover': {
      backgroundColor: theme.vars ? `rgba(${theme.vars.palette.primary.mainChannel} / calc(${theme.vars.palette.action.selectedOpacity} + ${theme.vars.palette.action.hoverOpacity}))` : (0, _styles.alpha)(theme.palette.primary.main, theme.palette.action.selectedOpacity + theme.palette.action.hoverOpacity),
      // Reset on touch devices, it doesn't add specificity
      '@media (hover: none)': {
        backgroundColor: theme.vars ? `rgba(${theme.vars.palette.primary.mainChannel} / ${theme.vars.palette.action.selectedOpacity})` : (0, _styles.alpha)(theme.palette.primary.main, theme.palette.action.selectedOpacity)
      }
    },
    [`&.${_treeItemClasses.treeItemClasses.focused}`]: {
      backgroundColor: theme.vars ? `rgba(${theme.vars.palette.primary.mainChannel} / calc(${theme.vars.palette.action.selectedOpacity} + ${theme.vars.palette.action.focusOpacity}))` : (0, _styles.alpha)(theme.palette.primary.main, theme.palette.action.selectedOpacity + theme.palette.action.focusOpacity)
    }
  },
  [`& .${_treeItemClasses.treeItemClasses.iconContainer}`]: {
    width: 16,
    display: 'flex',
    flexShrink: 0,
    justifyContent: 'center',
    '& svg': {
      fontSize: 18
    }
  },
  [`& .${_treeItemClasses.treeItemClasses.label}`]: (0, _extends2.default)({
    width: '100%',
    boxSizing: 'border-box',
    // prevent width + padding to overflow
    // fixes overflow - see https://github.com/mui/material-ui/issues/27372
    minWidth: 0,
    position: 'relative'
  }, theme.typography.body1)
}));
const TreeItemGroup = (0, _styles.styled)(_Collapse.default, {
  name: 'MuiTreeItem',
  slot: 'GroupTransition',
  overridesResolver: (props, styles) => styles.groupTransition
})({
  margin: 0,
  padding: 0,
  paddingLeft: 12
});

/**
 *
 * Demos:
 *
 * - [Tree View](https://mui.com/x/react-tree-view/)
 *
 * API:
 *
 * - [TreeItem API](https://mui.com/x/api/tree-view/tree-item/)
 */
const TreeItem = exports.TreeItem = /*#__PURE__*/React.forwardRef(function TreeItem(inProps, inRef) {
  const {
    icons: contextIcons,
    runItemPlugins,
    selection: {
      multiSelect
    },
    disabledItemsFocusable,
    instance
  } = (0, _useTreeViewContext.useTreeViewContext)();
  const props = (0, _styles.useThemeProps)({
    props: inProps,
    name: 'MuiTreeItem'
  });
  const {
      children,
      className,
      slots: inSlots,
      slotProps: inSlotProps,
      ContentComponent = _TreeItemContent.TreeItemContent,
      ContentProps,
      itemId,
      id,
      label,
      onClick,
      onMouseDown,
      onBlur,
      onKeyDown
    } = props,
    other = (0, _objectWithoutPropertiesLoose2.default)(props, _excluded);
  const {
    contentRef,
    rootRef
  } = runItemPlugins(props);
  const handleRootRef = (0, _useForkRef.default)(inRef, rootRef);
  const handleContentRef = (0, _useForkRef.default)(ContentProps?.ref, contentRef);
  const slots = {
    expandIcon: inSlots?.expandIcon ?? contextIcons.slots.expandIcon ?? _icons.TreeViewExpandIcon,
    collapseIcon: inSlots?.collapseIcon ?? contextIcons.slots.collapseIcon ?? _icons.TreeViewCollapseIcon,
    endIcon: inSlots?.endIcon ?? contextIcons.slots.endIcon,
    icon: inSlots?.icon,
    groupTransition: inSlots?.groupTransition
  };
  const isExpandable = reactChildren => {
    if (Array.isArray(reactChildren)) {
      return reactChildren.length > 0 && reactChildren.some(isExpandable);
    }
    return Boolean(reactChildren);
  };
  const expandable = isExpandable(children);
  const expanded = instance.isItemExpanded(itemId);
  const focused = instance.isItemFocused(itemId);
  const selected = instance.isItemSelected(itemId);
  const disabled = instance.isItemDisabled(itemId);
  const ownerState = (0, _extends2.default)({}, props, {
    expanded,
    focused,
    selected,
    disabled
  });
  const classes = useUtilityClasses(ownerState);
  const GroupTransition = slots.groupTransition ?? undefined;
  const groupTransitionProps = (0, _utils.useSlotProps)({
    elementType: GroupTransition,
    ownerState: {},
    externalSlotProps: inSlotProps?.groupTransition,
    additionalProps: {
      unmountOnExit: true,
      in: expanded,
      component: 'ul',
      role: 'group'
    },
    className: classes.groupTransition
  });
  const ExpansionIcon = expanded ? slots.collapseIcon : slots.expandIcon;
  const _useSlotProps = (0, _utils.useSlotProps)({
      elementType: ExpansionIcon,
      ownerState: {},
      externalSlotProps: tempOwnerState => {
        if (expanded) {
          return (0, _extends2.default)({}, (0, _utils.resolveComponentProps)(contextIcons.slotProps.collapseIcon, tempOwnerState), (0, _utils.resolveComponentProps)(inSlotProps?.collapseIcon, tempOwnerState));
        }
        return (0, _extends2.default)({}, (0, _utils.resolveComponentProps)(contextIcons.slotProps.expandIcon, tempOwnerState), (0, _utils.resolveComponentProps)(inSlotProps?.expandIcon, tempOwnerState));
      }
    }),
    expansionIconProps = (0, _objectWithoutPropertiesLoose2.default)(_useSlotProps, _excluded2);
  const expansionIcon = expandable && !!ExpansionIcon ? /*#__PURE__*/(0, _jsxRuntime.jsx)(ExpansionIcon, (0, _extends2.default)({}, expansionIconProps)) : null;
  const DisplayIcon = expandable ? undefined : slots.endIcon;
  const _useSlotProps2 = (0, _utils.useSlotProps)({
      elementType: DisplayIcon,
      ownerState: {},
      externalSlotProps: tempOwnerState => {
        if (expandable) {
          return {};
        }
        return (0, _extends2.default)({}, (0, _utils.resolveComponentProps)(contextIcons.slotProps.endIcon, tempOwnerState), (0, _utils.resolveComponentProps)(inSlotProps?.endIcon, tempOwnerState));
      }
    }),
    displayIconProps = (0, _objectWithoutPropertiesLoose2.default)(_useSlotProps2, _excluded3);
  const displayIcon = DisplayIcon ? /*#__PURE__*/(0, _jsxRuntime.jsx)(DisplayIcon, (0, _extends2.default)({}, displayIconProps)) : null;
  const Icon = slots.icon;
  const _useSlotProps3 = (0, _utils.useSlotProps)({
      elementType: Icon,
      ownerState: {},
      externalSlotProps: inSlotProps?.icon
    }),
    iconProps = (0, _objectWithoutPropertiesLoose2.default)(_useSlotProps3, _excluded4);
  const icon = Icon ? /*#__PURE__*/(0, _jsxRuntime.jsx)(Icon, (0, _extends2.default)({}, iconProps)) : null;
  let ariaSelected;
  if (multiSelect) {
    ariaSelected = selected;
  } else if (selected) {
    /* single-selection trees unset aria-selected on un-selected items.
     *
     * If the tree does not support multiple selection, aria-selected
     * is set to true for the selected item and it is not present on any other item in the tree.
     * Source: https://www.w3.org/WAI/ARIA/apg/patterns/treeview/
     */
    ariaSelected = true;
  }
  function handleFocus(event) {
    const canBeFocused = !disabled || disabledItemsFocusable;
    if (!focused && canBeFocused && event.currentTarget === event.target) {
      instance.focusItem(event, itemId);
    }
  }
  function handleBlur(event) {
    onBlur?.(event);
    instance.removeFocusedItem();
  }
  const handleKeyDown = event => {
    onKeyDown?.(event);
    instance.handleItemKeyDown(event, itemId);
  };
  const idAttribute = instance.getTreeItemIdAttribute(itemId, id);
  const tabIndex = instance.canItemBeTabbed(itemId) ? 0 : -1;
  return /*#__PURE__*/(0, _jsxRuntime.jsx)(_TreeItem2Provider.TreeItem2Provider, {
    itemId: itemId,
    children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(TreeItemRoot, (0, _extends2.default)({
      className: (0, _clsx.default)(classes.root, className),
      role: "treeitem",
      "aria-expanded": expandable ? expanded : undefined,
      "aria-selected": ariaSelected,
      "aria-disabled": disabled || undefined,
      id: idAttribute,
      tabIndex: tabIndex
    }, other, {
      ownerState: ownerState,
      onFocus: handleFocus,
      onBlur: handleBlur,
      onKeyDown: handleKeyDown,
      ref: handleRootRef,
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(StyledTreeItemContent, (0, _extends2.default)({
        as: ContentComponent,
        classes: {
          root: classes.content,
          expanded: classes.expanded,
          selected: classes.selected,
          focused: classes.focused,
          disabled: classes.disabled,
          iconContainer: classes.iconContainer,
          label: classes.label
        },
        label: label,
        itemId: itemId,
        onClick: onClick,
        onMouseDown: onMouseDown,
        icon: icon,
        expansionIcon: expansionIcon,
        displayIcon: displayIcon,
        ownerState: ownerState
      }, ContentProps, {
        ref: handleContentRef
      })), children && /*#__PURE__*/(0, _jsxRuntime.jsx)(TreeItemGroup, (0, _extends2.default)({
        as: GroupTransition
      }, groupTransitionProps, {
        children: children
      }))]
    }))
  });
});
process.env.NODE_ENV !== "production" ? TreeItem.propTypes = {
  // ----------------------------- Warning --------------------------------
  // | These PropTypes are generated from the TypeScript type definitions |
  // | To update them edit the TypeScript types and run "yarn proptypes"  |
  // ----------------------------------------------------------------------
  /**
   * The content of the component.
   */
  children: _propTypes.default.node,
  /**
   * Override or extend the styles applied to the component.
   */
  classes: _propTypes.default.object,
  className: _propTypes.default.string,
  /**
   * The component used to render the content of the item.
   * @default TreeItemContent
   */
  ContentComponent: _elementTypeAcceptingRef.default,
  /**
   * Props applied to ContentComponent.
   */
  ContentProps: _propTypes.default.object,
  /**
   * If `true`, the item is disabled.
   * @default false
   */
  disabled: _propTypes.default.bool,
  /**
   * The id of the item.
   */
  itemId: _propTypes.default.string.isRequired,
  /**
   * The tree item label.
   */
  label: _propTypes.default.node,
  /**
   * This prop isn't supported.
   * Use the `onItemFocus` callback on the tree if you need to monitor a item's focus.
   */
  onFocus: _unsupportedProp.default,
  /**
   * The props used for each component slot.
   * @default {}
   */
  slotProps: _propTypes.default.object,
  /**
   * Overridable component slots.
   * @default {}
   */
  slots: _propTypes.default.object,
  /**
   * The system prop that allows defining system overrides as well as additional CSS styles.
   */
  sx: _propTypes.default.oneOfType([_propTypes.default.arrayOf(_propTypes.default.oneOfType([_propTypes.default.func, _propTypes.default.object, _propTypes.default.bool])), _propTypes.default.func, _propTypes.default.object])
} : void 0;