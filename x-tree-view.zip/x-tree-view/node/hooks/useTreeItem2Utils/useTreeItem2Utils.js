"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.useTreeItem2Utils = void 0;
var _useTreeViewContext = require("../../internals/TreeViewProvider/useTreeViewContext");
const useTreeItem2Utils = ({
  itemId,
  children
}) => {
  const {
    instance,
    selection: {
      multiSelect
    }
  } = (0, _useTreeViewContext.useTreeViewContext)();
  const status = {
    expandable: Boolean(Array.isArray(children) ? children.length : children),
    expanded: instance.isItemExpanded(itemId),
    focused: instance.isItemFocused(itemId),
    selected: instance.isItemSelected(itemId),
    disabled: instance.isItemDisabled(itemId)
  };
  const handleExpansion = event => {
    if (status.disabled) {
      return;
    }
    if (!status.focused) {
      instance.focusItem(event, itemId);
    }
    const multiple = multiSelect && (event.shiftKey || event.ctrlKey || event.metaKey);

    // If already expanded and trying to toggle selection don't close
    if (status.expandable && !(multiple && instance.isItemExpanded(itemId))) {
      instance.toggleItemExpansion(event, itemId);
    }
  };
  const handleSelection = event => {
    if (status.disabled) {
      return;
    }
    if (!status.focused) {
      instance.focusItem(event, itemId);
    }
    const multiple = multiSelect && (event.shiftKey || event.ctrlKey || event.metaKey);
    if (multiple) {
      if (event.shiftKey) {
        instance.expandSelectionRange(event, itemId);
      } else {
        instance.selectItem(event, itemId, true);
      }
    } else {
      instance.selectItem(event, itemId);
    }
  };
  const interactions = {
    handleExpansion,
    handleSelection
  };
  return {
    interactions,
    status
  };
};
exports.useTreeItem2Utils = useTreeItem2Utils;