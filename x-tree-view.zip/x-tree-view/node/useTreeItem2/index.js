"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "unstable_useTreeItem2", {
  enumerable: true,
  get: function () {
    return _useTreeItem.useTreeItem2;
  }
});
var _useTreeItem = require("./useTreeItem2");