"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.SIMPLE_TREE_VIEW_PLUGINS = void 0;
var _defaultPlugins = require("../internals/plugins/defaultPlugins");
var _useTreeViewJSXItems = require("../internals/plugins/useTreeViewJSXItems");
const SIMPLE_TREE_VIEW_PLUGINS = exports.SIMPLE_TREE_VIEW_PLUGINS = [..._defaultPlugins.DEFAULT_TREE_VIEW_PLUGINS, _useTreeViewJSXItems.useTreeViewJSXItems];

// We can't infer this type from the plugin, otherwise we would lose the generics.