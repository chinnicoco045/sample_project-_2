"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "TreeViewProvider", {
  enumerable: true,
  get: function () {
    return _TreeViewProvider.TreeViewProvider;
  }
});
var _TreeViewProvider = require("./TreeViewProvider");