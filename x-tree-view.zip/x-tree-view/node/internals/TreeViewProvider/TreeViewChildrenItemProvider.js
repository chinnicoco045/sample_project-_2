"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.TreeViewChildrenItemContext = void 0;
exports.TreeViewChildrenItemProvider = TreeViewChildrenItemProvider;
var React = _interopRequireWildcard(require("react"));
var _propTypes = _interopRequireDefault(require("prop-types"));
var _useTreeViewContext = require("./useTreeViewContext");
var _jsxRuntime = require("react/jsx-runtime");
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function (e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != typeof e && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
const TreeViewChildrenItemContext = exports.TreeViewChildrenItemContext = /*#__PURE__*/React.createContext(null);
if (process.env.NODE_ENV !== 'production') {
  TreeViewChildrenItemContext.displayName = 'TreeViewChildrenItemContext';
}
function TreeViewChildrenItemProvider(props) {
  const {
    children,
    itemId = null
  } = props;
  const {
    instance,
    rootRef
  } = (0, _useTreeViewContext.useTreeViewContext)();
  const childrenIdAttrToIdRef = React.useRef(new Map());
  React.useEffect(() => {
    if (!rootRef.current) {
      return;
    }
    let idAttr = null;
    if (itemId == null) {
      idAttr = rootRef.current.id;
    } else {
      // Undefined during 1st render
      const itemMeta = instance.getItemMeta(itemId);
      if (itemMeta !== undefined) {
        idAttr = instance.getTreeItemIdAttribute(itemId, itemMeta.idAttribute);
      }
    }
    if (idAttr == null) {
      return;
    }
    const previousChildrenIds = instance.getItemOrderedChildrenIds(itemId ?? null) ?? [];
    const childrenElements = rootRef.current.querySelectorAll(`${itemId == null ? '' : `*[id="${idAttr}"] `}[role="treeitem"]:not(*[id="${idAttr}"] [role="treeitem"] [role="treeitem"])`);
    const childrenIds = Array.from(childrenElements).map(child => childrenIdAttrToIdRef.current.get(child.id));
    const hasChanged = childrenIds.length !== previousChildrenIds.length || childrenIds.some((childId, index) => childId !== previousChildrenIds[index]);
    if (hasChanged) {
      instance.setJSXItemsOrderedChildrenIds(itemId ?? null, childrenIds);
    }
  });
  const value = React.useMemo(() => ({
    registerChild: (childIdAttribute, childItemId) => childrenIdAttrToIdRef.current.set(childIdAttribute, childItemId),
    unregisterChild: childIdAttribute => childrenIdAttrToIdRef.current.delete(childIdAttribute),
    parentId: itemId
  }), [itemId]);
  return /*#__PURE__*/(0, _jsxRuntime.jsx)(TreeViewChildrenItemContext.Provider, {
    value: value,
    children: children
  });
}
process.env.NODE_ENV !== "production" ? TreeViewChildrenItemProvider.propTypes = {
  children: _propTypes.default.node,
  id: _propTypes.default.string
} : void 0;