"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.buildSiblingIndexes = exports.TREE_VIEW_ROOT_PARENT_ID = void 0;
const TREE_VIEW_ROOT_PARENT_ID = exports.TREE_VIEW_ROOT_PARENT_ID = '__TREE_VIEW_ROOT_PARENT_ID__';
const buildSiblingIndexes = siblings => {
  const siblingsIndexLookup = {};
  siblings.forEach((childId, index) => {
    siblingsIndexLookup[childId] = index;
  });
  return siblingsIndexLookup;
};
exports.buildSiblingIndexes = buildSiblingIndexes;