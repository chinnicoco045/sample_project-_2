"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.useTreeViewFocus = void 0;
var _extends2 = _interopRequireDefault(require("@babel/runtime/helpers/extends"));
var React = _interopRequireWildcard(require("react"));
var _useEventCallback = _interopRequireDefault(require("@mui/utils/useEventCallback"));
var _ownerDocument = _interopRequireDefault(require("@mui/utils/ownerDocument"));
var _useInstanceEventHandler = require("../../hooks/useInstanceEventHandler");
var _utils = require("../../utils/utils");
var _tree = require("../../utils/tree");
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function (e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != typeof e && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
const useTabbableItemId = (instance, selectedItems) => {
  const isItemVisible = itemId => {
    const itemMeta = instance.getItemMeta(itemId);
    return itemMeta && (itemMeta.parentId == null || instance.isItemExpanded(itemMeta.parentId));
  };
  let tabbableItemId;
  if (Array.isArray(selectedItems)) {
    tabbableItemId = selectedItems.find(isItemVisible);
  } else if (selectedItems != null && isItemVisible(selectedItems)) {
    tabbableItemId = selectedItems;
  }
  if (tabbableItemId == null) {
    tabbableItemId = (0, _tree.getFirstNavigableItem)(instance);
  }
  return tabbableItemId;
};
const useTreeViewFocus = ({
  instance,
  params,
  state,
  setState,
  models,
  rootRef
}) => {
  const tabbableItemId = useTabbableItemId(instance, models.selectedItems.value);
  const setFocusedItemId = (0, _useEventCallback.default)(itemId => {
    const cleanItemId = typeof itemId === 'function' ? itemId(state.focusedItemId) : itemId;
    if (state.focusedItemId !== cleanItemId) {
      setState(prevState => (0, _extends2.default)({}, prevState, {
        focusedItemId: cleanItemId
      }));
    }
  });
  const isTreeViewFocused = React.useCallback(() => !!rootRef.current && rootRef.current.contains((0, _utils.getActiveElement)((0, _ownerDocument.default)(rootRef.current))), [rootRef]);
  const isItemFocused = React.useCallback(itemId => state.focusedItemId === itemId && isTreeViewFocused(), [state.focusedItemId, isTreeViewFocused]);
  const isItemVisible = itemId => {
    const itemMeta = instance.getItemMeta(itemId);
    return itemMeta && (itemMeta.parentId == null || instance.isItemExpanded(itemMeta.parentId));
  };
  const innerFocusItem = (event, itemId) => {
    const itemMeta = instance.getItemMeta(itemId);
    const itemElement = document.getElementById(instance.getTreeItemIdAttribute(itemId, itemMeta.idAttribute));
    if (itemElement) {
      itemElement.focus();
    }
    setFocusedItemId(itemId);
    if (params.onItemFocus) {
      params.onItemFocus(event, itemId);
    }
  };
  const focusItem = (0, _useEventCallback.default)((event, itemId) => {
    // If we receive an itemId, and it is visible, the focus will be set to it
    if (isItemVisible(itemId)) {
      innerFocusItem(event, itemId);
    }
  });
  const focusDefaultItem = (0, _useEventCallback.default)(event => {
    let itemToFocusId;
    if (Array.isArray(models.selectedItems.value)) {
      itemToFocusId = models.selectedItems.value.find(isItemVisible);
    } else if (models.selectedItems.value != null && isItemVisible(models.selectedItems.value)) {
      itemToFocusId = models.selectedItems.value;
    }
    if (itemToFocusId == null) {
      itemToFocusId = (0, _tree.getFirstNavigableItem)(instance);
    }
    innerFocusItem(event, itemToFocusId);
  });
  const removeFocusedItem = (0, _useEventCallback.default)(() => {
    if (state.focusedItemId == null) {
      return;
    }
    const itemMeta = instance.getItemMeta(state.focusedItemId);
    if (itemMeta) {
      const itemElement = document.getElementById(instance.getTreeItemIdAttribute(state.focusedItemId, itemMeta.idAttribute));
      if (itemElement) {
        itemElement.blur();
      }
    }
    setFocusedItemId(null);
  });
  const canItemBeTabbed = itemId => itemId === tabbableItemId;
  (0, _useInstanceEventHandler.useInstanceEventHandler)(instance, 'removeItem', ({
    id
  }) => {
    if (state.focusedItemId === id) {
      instance.focusDefaultItem(null);
    }
  });
  const createRootHandleFocus = otherHandlers => event => {
    otherHandlers.onFocus?.(event);
    if (event.defaultMuiPrevented) {
      return;
    }

    // if the event bubbled (which is React specific) we don't want to steal focus
    if (event.target === event.currentTarget) {
      instance.focusDefaultItem(event);
    }
  };
  return {
    getRootProps: otherHandlers => ({
      onFocus: createRootHandleFocus(otherHandlers)
    }),
    publicAPI: {
      focusItem
    },
    instance: {
      isItemFocused,
      canItemBeTabbed,
      focusItem,
      focusDefaultItem,
      removeFocusedItem
    }
  };
};
exports.useTreeViewFocus = useTreeViewFocus;
useTreeViewFocus.getInitialState = () => ({
  focusedItemId: null
});
useTreeViewFocus.params = {
  onItemFocus: true
};