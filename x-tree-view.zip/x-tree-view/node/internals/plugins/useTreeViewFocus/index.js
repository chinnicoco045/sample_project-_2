"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "useTreeViewFocus", {
  enumerable: true,
  get: function () {
    return _useTreeViewFocus.useTreeViewFocus;
  }
});
var _useTreeViewFocus = require("./useTreeViewFocus");