"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "DEFAULT_TREE_VIEW_PLUGINS", {
  enumerable: true,
  get: function () {
    return _defaultPlugins.DEFAULT_TREE_VIEW_PLUGINS;
  }
});
var _defaultPlugins = require("./defaultPlugins");