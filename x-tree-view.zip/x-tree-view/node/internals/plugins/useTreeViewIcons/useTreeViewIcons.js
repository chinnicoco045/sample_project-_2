"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.useTreeViewIcons = void 0;
const useTreeViewIcons = ({
  slots,
  slotProps
}) => {
  return {
    contextValue: {
      icons: {
        slots: {
          collapseIcon: slots.collapseIcon,
          expandIcon: slots.expandIcon,
          endIcon: slots.endIcon
        },
        slotProps: {
          collapseIcon: slotProps.collapseIcon,
          expandIcon: slotProps.expandIcon,
          endIcon: slotProps.endIcon
        }
      }
    }
  };
};
exports.useTreeViewIcons = useTreeViewIcons;
useTreeViewIcons.params = {};