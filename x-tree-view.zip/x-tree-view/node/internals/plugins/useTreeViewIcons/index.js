"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "useTreeViewIcons", {
  enumerable: true,
  get: function () {
    return _useTreeViewIcons.useTreeViewIcons;
  }
});
var _useTreeViewIcons = require("./useTreeViewIcons");