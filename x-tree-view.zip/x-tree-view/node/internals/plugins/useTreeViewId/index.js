"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "useTreeViewId", {
  enumerable: true,
  get: function () {
    return _useTreeViewId.useTreeViewId;
  }
});
var _useTreeViewId = require("./useTreeViewId");