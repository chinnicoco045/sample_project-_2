"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.getLookupFromArray = exports.convertSelectedItemsToArray = void 0;
/**
 * Transform the `selectedItems` model to be an array if it was a string or null.
 * @param {string[] | string | null} model The raw model.
 * @returns {string[]} The converted model.
 */
const convertSelectedItemsToArray = model => {
  if (Array.isArray(model)) {
    return model;
  }
  if (model != null) {
    return [model];
  }
  return [];
};
exports.convertSelectedItemsToArray = convertSelectedItemsToArray;
const getLookupFromArray = array => {
  const lookup = {};
  array.forEach(itemId => {
    lookup[itemId] = true;
  });
  return lookup;
};
exports.getLookupFromArray = getLookupFromArray;