"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.useTreeViewJSXItems = void 0;
var _extends2 = _interopRequireDefault(require("@babel/runtime/helpers/extends"));
var React = _interopRequireWildcard(require("react"));
var _useEventCallback = _interopRequireDefault(require("@mui/utils/useEventCallback"));
var _useForkRef = _interopRequireDefault(require("@mui/utils/useForkRef"));
var _useEnhancedEffect = _interopRequireDefault(require("@mui/utils/useEnhancedEffect"));
var _publishTreeViewEvent = require("../../utils/publishTreeViewEvent");
var _useTreeViewContext = require("../../TreeViewProvider/useTreeViewContext");
var _TreeViewChildrenItemProvider = require("../../TreeViewProvider/TreeViewChildrenItemProvider");
var _useTreeViewItems = require("../useTreeViewItems/useTreeViewItems.utils");
var _jsxRuntime = require("react/jsx-runtime");
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function (e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != typeof e && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
const useTreeViewJSXItems = ({
  instance,
  setState
}) => {
  instance.preventItemUpdates();
  const insertJSXItem = (0, _useEventCallback.default)(item => {
    setState(prevState => {
      if (prevState.items.itemMetaMap[item.id] != null) {
        throw new Error(['MUI X: The Tree View component requires all items to have a unique `id` property.', 'Alternatively, you can use the `getItemId` prop to specify a custom id for each item.', `Two items were provided with the same id in the \`items\` prop: "${item.id}"`].join('\n'));
      }
      return (0, _extends2.default)({}, prevState, {
        items: (0, _extends2.default)({}, prevState.items, {
          itemMetaMap: (0, _extends2.default)({}, prevState.items.itemMetaMap, {
            [item.id]: item
          }),
          // For `SimpleTreeView`, we don't have a proper `item` object, so we create a very basic one.
          itemMap: (0, _extends2.default)({}, prevState.items.itemMap, {
            [item.id]: {
              id: item.id,
              label: item.label
            }
          })
        })
      });
    });
  });
  const setJSXItemsOrderedChildrenIds = (parentId, orderedChildrenIds) => {
    const parentIdWithDefault = parentId ?? _useTreeViewItems.TREE_VIEW_ROOT_PARENT_ID;
    setState(prevState => (0, _extends2.default)({}, prevState, {
      items: (0, _extends2.default)({}, prevState.items, {
        itemOrderedChildrenIds: (0, _extends2.default)({}, prevState.items.itemOrderedChildrenIds, {
          [parentIdWithDefault]: orderedChildrenIds
        }),
        itemChildrenIndexes: (0, _extends2.default)({}, prevState.items.itemChildrenIndexes, {
          [parentIdWithDefault]: (0, _useTreeViewItems.buildSiblingIndexes)(orderedChildrenIds)
        })
      })
    }));
  };
  const removeJSXItem = (0, _useEventCallback.default)(itemId => {
    setState(prevState => {
      const newItemMetaMap = (0, _extends2.default)({}, prevState.items.itemMetaMap);
      const newItemMap = (0, _extends2.default)({}, prevState.items.itemMap);
      delete newItemMetaMap[itemId];
      delete newItemMap[itemId];
      return (0, _extends2.default)({}, prevState, {
        items: (0, _extends2.default)({}, prevState.items, {
          itemMetaMap: newItemMetaMap,
          itemMap: newItemMap
        })
      });
    });
    (0, _publishTreeViewEvent.publishTreeViewEvent)(instance, 'removeItem', {
      id: itemId
    });
  });
  const mapFirstCharFromJSX = (0, _useEventCallback.default)((itemId, firstChar) => {
    instance.updateFirstCharMap(firstCharMap => {
      firstCharMap[itemId] = firstChar;
      return firstCharMap;
    });
    return () => {
      instance.updateFirstCharMap(firstCharMap => {
        const newMap = (0, _extends2.default)({}, firstCharMap);
        delete newMap[itemId];
        return newMap;
      });
    };
  });
  return {
    instance: {
      insertJSXItem,
      removeJSXItem,
      setJSXItemsOrderedChildrenIds,
      mapFirstCharFromJSX
    }
  };
};
exports.useTreeViewJSXItems = useTreeViewJSXItems;
const isItemExpandable = reactChildren => {
  if (Array.isArray(reactChildren)) {
    return reactChildren.length > 0 && reactChildren.some(isItemExpandable);
  }
  return Boolean(reactChildren);
};
const useTreeViewJSXItemsItemPlugin = ({
  props,
  rootRef,
  contentRef
}) => {
  const {
    instance
  } = (0, _useTreeViewContext.useTreeViewContext)();
  const {
    children,
    disabled = false,
    label,
    itemId,
    id
  } = props;
  const parentContext = React.useContext(_TreeViewChildrenItemProvider.TreeViewChildrenItemContext);
  if (parentContext == null) {
    throw new Error(['MUI X: Could not find the Tree View Children Item context.', 'It looks like you rendered your component outside of a SimpleTreeView parent component.', 'This can also happen if you are bundling multiple versions of the Tree View.'].join('\n'));
  }
  const {
    registerChild,
    unregisterChild,
    parentId
  } = parentContext;
  const expandable = isItemExpandable(children);
  const pluginContentRef = React.useRef(null);
  const handleContentRef = (0, _useForkRef.default)(pluginContentRef, contentRef);

  // Prevent any flashing
  (0, _useEnhancedEffect.default)(() => {
    const idAttributeWithDefault = instance.getTreeItemIdAttribute(itemId, id);
    registerChild(idAttributeWithDefault, itemId);
    return () => {
      unregisterChild(idAttributeWithDefault);
    };
  }, [instance, registerChild, unregisterChild, itemId, id]);
  React.useEffect(() => {
    instance.insertJSXItem({
      id: itemId,
      idAttribute: id,
      parentId,
      expandable,
      disabled
    });
    return () => instance.removeJSXItem(itemId);
  }, [instance, parentId, itemId, expandable, disabled, id]);
  React.useEffect(() => {
    if (label) {
      return instance.mapFirstCharFromJSX(itemId, (pluginContentRef.current?.textContent ?? '').substring(0, 1).toLowerCase());
    }
    return undefined;
  }, [instance, itemId, label]);
  return {
    contentRef: handleContentRef,
    rootRef
  };
};
useTreeViewJSXItems.itemPlugin = useTreeViewJSXItemsItemPlugin;
useTreeViewJSXItems.wrapItem = ({
  children,
  itemId
}) => /*#__PURE__*/(0, _jsxRuntime.jsx)(_TreeViewChildrenItemProvider.TreeViewChildrenItemProvider, {
  itemId: itemId,
  children: children
});
useTreeViewJSXItems.wrapRoot = ({
  children
}) => /*#__PURE__*/(0, _jsxRuntime.jsx)(_TreeViewChildrenItemProvider.TreeViewChildrenItemProvider, {
  children: children
});
useTreeViewJSXItems.params = {};