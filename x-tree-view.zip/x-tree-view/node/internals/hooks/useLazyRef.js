"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "useLazyRef", {
  enumerable: true,
  get: function () {
    return _useLazyRef.default;
  }
});
var _useLazyRef = _interopRequireDefault(require("@mui/utils/useLazyRef"));