"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "useOnMount", {
  enumerable: true,
  get: function () {
    return _useOnMount.default;
  }
});
var _useOnMount = _interopRequireDefault(require("@mui/utils/useOnMount"));