"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "useTimeout", {
  enumerable: true,
  get: function () {
    return _useTimeout.default;
  }
});
var _useTimeout = _interopRequireDefault(require("@mui/utils/useTimeout"));