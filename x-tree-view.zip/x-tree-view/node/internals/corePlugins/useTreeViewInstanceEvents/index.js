"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "useTreeViewInstanceEvents", {
  enumerable: true,
  get: function () {
    return _useTreeViewInstanceEvents.useTreeViewInstanceEvents;
  }
});
var _useTreeViewInstanceEvents = require("./useTreeViewInstanceEvents");