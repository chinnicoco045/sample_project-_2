"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "TREE_VIEW_CORE_PLUGINS", {
  enumerable: true,
  get: function () {
    return _corePlugins.TREE_VIEW_CORE_PLUGINS;
  }
});
var _corePlugins = require("./corePlugins");