"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.extractPluginParamsFromProps = void 0;
var _objectWithoutPropertiesLoose2 = _interopRequireDefault(require("@babel/runtime/helpers/objectWithoutPropertiesLoose"));
const _excluded = ["slots", "slotProps", "apiRef"];
const extractPluginParamsFromProps = _ref => {
  let {
      props: {
        slots,
        slotProps,
        apiRef
      },
      plugins,
      rootRef
    } = _ref,
    props = (0, _objectWithoutPropertiesLoose2.default)(_ref.props, _excluded);
  const paramsLookup = {};
  plugins.forEach(plugin => {
    Object.assign(paramsLookup, plugin.params);
  });
  const pluginParams = {
    plugins,
    rootRef,
    slots: slots ?? {},
    slotProps: slotProps ?? {},
    apiRef
  };
  const otherProps = {};
  Object.keys(props).forEach(propName => {
    const prop = props[propName];
    if (paramsLookup[propName]) {
      pluginParams[propName] = prop;
    } else {
      otherProps[propName] = prop;
    }
  });
  return {
    pluginParams,
    slots,
    slotProps,
    otherProps
  };
};
exports.extractPluginParamsFromProps = extractPluginParamsFromProps;