"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.TreeItem2Root = exports.TreeItem2Label = exports.TreeItem2IconContainer = exports.TreeItem2GroupTransition = exports.TreeItem2Content = exports.TreeItem2 = void 0;
var _objectWithoutPropertiesLoose2 = _interopRequireDefault(require("@babel/runtime/helpers/objectWithoutPropertiesLoose"));
var _extends2 = _interopRequireDefault(require("@babel/runtime/helpers/extends"));
var React = _interopRequireWildcard(require("react"));
var _propTypes = _interopRequireDefault(require("prop-types"));
var _clsx = _interopRequireDefault(require("clsx"));
var _unsupportedProp = _interopRequireDefault(require("@mui/utils/unsupportedProp"));
var _styles = require("@mui/material/styles");
var _Collapse = _interopRequireDefault(require("@mui/material/Collapse"));
var _utils = require("@mui/base/utils");
var _system = require("@mui/system");
var _composeClasses = _interopRequireDefault(require("@mui/utils/composeClasses"));
var _useTreeItem = require("../useTreeItem2");
var _TreeItem = require("../TreeItem");
var _TreeItem2Icon = require("../TreeItem2Icon");
var _TreeItem2Provider = require("../TreeItem2Provider");
var _jsxRuntime = require("react/jsx-runtime");
const _excluded = ["id", "itemId", "label", "disabled", "children", "slots", "slotProps"];
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function (e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != typeof e && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
const TreeItem2Root = exports.TreeItem2Root = (0, _styles.styled)('li', {
  name: 'MuiTreeItem2',
  slot: 'Root',
  overridesResolver: (props, styles) => styles.root
})({
  listStyle: 'none',
  margin: 0,
  padding: 0,
  outline: 0
});
const TreeItem2Content = exports.TreeItem2Content = (0, _styles.styled)('div', {
  name: 'MuiTreeItem2',
  slot: 'Content',
  overridesResolver: (props, styles) => styles.content,
  shouldForwardProp: prop => (0, _system.shouldForwardProp)(prop) && prop !== 'status'
})(({
  theme
}) => ({
  padding: theme.spacing(0.5, 1),
  borderRadius: theme.shape.borderRadius,
  width: '100%',
  boxSizing: 'border-box',
  // prevent width + padding to overflow
  display: 'flex',
  alignItems: 'center',
  gap: theme.spacing(1),
  cursor: 'pointer',
  WebkitTapHighlightColor: 'transparent',
  '&:hover': {
    backgroundColor: (theme.vars || theme).palette.action.hover,
    // Reset on touch devices, it doesn't add specificity
    '@media (hover: none)': {
      backgroundColor: 'transparent'
    }
  },
  [`& .${_TreeItem.treeItemClasses.groupTransition}`]: {
    margin: 0,
    padding: 0,
    paddingLeft: 12
  },
  variants: [{
    props: ({
      status
    }) => status.disabled,
    style: {
      opacity: (theme.vars || theme).palette.action.disabledOpacity,
      backgroundColor: 'transparent'
    }
  }, {
    props: ({
      status
    }) => status.focused,
    style: {
      backgroundColor: (theme.vars || theme).palette.action.focus
    }
  }, {
    props: ({
      status
    }) => status.selected,
    style: {
      backgroundColor: theme.vars ? `rgba(${theme.vars.palette.primary.mainChannel} / ${theme.vars.palette.action.selectedOpacity})` : (0, _styles.alpha)(theme.palette.primary.main, theme.palette.action.selectedOpacity),
      '&:hover': {
        backgroundColor: theme.vars ? `rgba(${theme.vars.palette.primary.mainChannel} / calc(${theme.vars.palette.action.selectedOpacity} + ${theme.vars.palette.action.hoverOpacity}))` : (0, _styles.alpha)(theme.palette.primary.main, theme.palette.action.selectedOpacity + theme.palette.action.hoverOpacity),
        // Reset on touch devices, it doesn't add specificity
        '@media (hover: none)': {
          backgroundColor: theme.vars ? `rgba(${theme.vars.palette.primary.mainChannel} / ${theme.vars.palette.action.selectedOpacity})` : (0, _styles.alpha)(theme.palette.primary.main, theme.palette.action.selectedOpacity)
        }
      }
    }
  }, {
    props: ({
      status
    }) => status.selected && status.focused,
    style: {
      backgroundColor: theme.vars ? `rgba(${theme.vars.palette.primary.mainChannel} / calc(${theme.vars.palette.action.selectedOpacity} + ${theme.vars.palette.action.focusOpacity}))` : (0, _styles.alpha)(theme.palette.primary.main, theme.palette.action.selectedOpacity + theme.palette.action.focusOpacity)
    }
  }]
}));
const TreeItem2Label = exports.TreeItem2Label = (0, _styles.styled)('div', {
  name: 'MuiTreeItem2',
  slot: 'Label',
  overridesResolver: (props, styles) => styles.label
})(({
  theme
}) => (0, _extends2.default)({
  width: '100%',
  boxSizing: 'border-box',
  // prevent width + padding to overflow
  // fixes overflow - see https://github.com/mui/material-ui/issues/27372
  minWidth: 0,
  position: 'relative'
}, theme.typography.body1));
const TreeItem2IconContainer = exports.TreeItem2IconContainer = (0, _styles.styled)('div', {
  name: 'MuiTreeItem2',
  slot: 'IconContainer',
  overridesResolver: (props, styles) => styles.iconContainer
})({
  width: 16,
  display: 'flex',
  flexShrink: 0,
  justifyContent: 'center',
  '& svg': {
    fontSize: 18
  }
});
const TreeItem2GroupTransition = exports.TreeItem2GroupTransition = (0, _styles.styled)(_Collapse.default, {
  name: 'MuiTreeItem2GroupTransition',
  slot: 'GroupTransition',
  overridesResolver: (props, styles) => styles.groupTransition
})({
  margin: 0,
  padding: 0,
  paddingLeft: 12
});
const useUtilityClasses = ownerState => {
  const {
    classes
  } = ownerState;
  const slots = {
    root: ['root'],
    content: ['content'],
    expanded: ['expanded'],
    selected: ['selected'],
    focused: ['focused'],
    disabled: ['disabled'],
    iconContainer: ['iconContainer'],
    label: ['label'],
    groupTransition: ['groupTransition']
  };
  return (0, _composeClasses.default)(slots, _TreeItem.getTreeItemUtilityClass, classes);
};
/**
 *
 * Demos:
 *
 * - [Tree View](https://mui.com/x/react-tree-view/)
 *
 * API:
 *
 * - [TreeItem2 API](https://mui.com/x/api/tree-view/tree-item-2/)
 */
const TreeItem2 = exports.TreeItem2 = /*#__PURE__*/React.forwardRef(function TreeItem2(inProps, forwardedRef) {
  const props = (0, _styles.useThemeProps)({
    props: inProps,
    name: 'MuiTreeItem2'
  });
  const {
      id,
      itemId,
      label,
      disabled,
      children,
      slots = {},
      slotProps = {}
    } = props,
    other = (0, _objectWithoutPropertiesLoose2.default)(props, _excluded);
  const {
    getRootProps,
    getContentProps,
    getIconContainerProps,
    getLabelProps,
    getGroupTransitionProps,
    status
  } = (0, _useTreeItem.unstable_useTreeItem2)({
    id,
    itemId,
    children,
    label,
    disabled
  });
  const ownerState = (0, _extends2.default)({}, props, status);
  const classes = useUtilityClasses(ownerState);
  const Root = slots.root ?? TreeItem2Root;
  const rootProps = (0, _utils.useSlotProps)({
    elementType: Root,
    getSlotProps: getRootProps,
    externalForwardedProps: other,
    externalSlotProps: slotProps.root,
    additionalProps: {
      ref: forwardedRef
    },
    ownerState: {},
    className: classes.root
  });
  const Content = slots.content ?? TreeItem2Content;
  const contentProps = (0, _utils.useSlotProps)({
    elementType: Content,
    getSlotProps: getContentProps,
    externalSlotProps: slotProps.content,
    ownerState: {},
    className: (0, _clsx.default)(classes.content, status.expanded && classes.expanded, status.selected && classes.selected, status.focused && classes.focused, status.disabled && classes.disabled)
  });
  const IconContainer = slots.iconContainer ?? TreeItem2IconContainer;
  const iconContainerProps = (0, _utils.useSlotProps)({
    elementType: IconContainer,
    getSlotProps: getIconContainerProps,
    externalSlotProps: slotProps.iconContainer,
    ownerState: {},
    className: classes.iconContainer
  });
  const Label = slots.label ?? TreeItem2Label;
  const labelProps = (0, _utils.useSlotProps)({
    elementType: Label,
    getSlotProps: getLabelProps,
    externalSlotProps: slotProps.label,
    ownerState: {},
    className: classes.label
  });
  const GroupTransition = slots.groupTransition ?? undefined;
  const groupTransitionProps = (0, _utils.useSlotProps)({
    elementType: GroupTransition,
    getSlotProps: getGroupTransitionProps,
    externalSlotProps: slotProps.groupTransition,
    ownerState: {},
    className: classes.groupTransition
  });
  return /*#__PURE__*/(0, _jsxRuntime.jsx)(_TreeItem2Provider.TreeItem2Provider, {
    itemId: itemId,
    children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(Root, (0, _extends2.default)({}, rootProps, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(Content, (0, _extends2.default)({}, contentProps, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(IconContainer, (0, _extends2.default)({}, iconContainerProps, {
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_TreeItem2Icon.TreeItem2Icon, {
            status: status,
            slots: slots,
            slotProps: slotProps
          })
        })), /*#__PURE__*/(0, _jsxRuntime.jsx)(Label, (0, _extends2.default)({}, labelProps))]
      })), children && /*#__PURE__*/(0, _jsxRuntime.jsx)(TreeItem2GroupTransition, (0, _extends2.default)({
        as: GroupTransition
      }, groupTransitionProps))]
    }))
  });
});
process.env.NODE_ENV !== "production" ? TreeItem2.propTypes = {
  // ----------------------------- Warning --------------------------------
  // | These PropTypes are generated from the TypeScript type definitions |
  // | To update them edit the TypeScript types and run "yarn proptypes"  |
  // ----------------------------------------------------------------------
  /**
   * The content of the component.
   */
  children: _propTypes.default.node,
  /**
   * Override or extend the styles applied to the component.
   */
  classes: _propTypes.default.object,
  className: _propTypes.default.string,
  /**
   * If `true`, the item is disabled.
   * @default false
   */
  disabled: _propTypes.default.bool,
  /**
   * The id attribute of the item. If not provided, it will be generated.
   */
  id: _propTypes.default.string,
  /**
   * The id of the item.
   * Must be unique.
   */
  itemId: _propTypes.default.string.isRequired,
  /**
   * The label of the item.
   */
  label: _propTypes.default.node,
  /**
   * This prop isn't supported.
   * Use the `onItemFocus` callback on the tree if you need to monitor a item's focus.
   */
  onFocus: _unsupportedProp.default,
  /**
   * The props used for each component slot.
   * @default {}
   */
  slotProps: _propTypes.default.object,
  /**
   * Overridable component slots.
   * @default {}
   */
  slots: _propTypes.default.object
} : void 0;