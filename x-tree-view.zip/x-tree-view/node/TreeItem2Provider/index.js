"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "TreeItem2Provider", {
  enumerable: true,
  get: function () {
    return _TreeItem2Provider.TreeItem2Provider;
  }
});
var _TreeItem2Provider = require("./TreeItem2Provider");