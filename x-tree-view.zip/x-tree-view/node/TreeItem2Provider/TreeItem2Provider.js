"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.TreeItem2Provider = TreeItem2Provider;
var _propTypes = _interopRequireDefault(require("prop-types"));
var _useTreeViewContext = require("../internals/TreeViewProvider/useTreeViewContext");
function TreeItem2Provider(props) {
  const {
    children,
    itemId
  } = props;
  const {
    wrapItem
  } = (0, _useTreeViewContext.useTreeViewContext)();
  return wrapItem({
    children,
    itemId
  });
}
TreeItem2Provider.propTypes = {
  // ----------------------------- Warning --------------------------------
  // | These PropTypes are generated from the TypeScript type definitions |
  // | To update them edit the TypeScript types and run "yarn proptypes"  |
  // ----------------------------------------------------------------------
  children: _propTypes.default.node,
  itemId: _propTypes.default.string.isRequired
};