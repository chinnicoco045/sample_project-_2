import * as React from 'react';
import { SimpleTreeViewProps } from './SimpleTreeView.types';
export declare const SimpleTreeViewRoot: import("@emotion/styled").StyledComponent<import("@mui/system").MUIStyledCommonProps<import("@mui/material/styles").Theme> & {
    ownerState: SimpleTreeViewProps<any>;
}, Pick<React.DetailedHTMLProps<React.HTMLAttributes<HTMLUListElement>, HTMLUListElement>, keyof React.ClassAttributes<HTMLUListElement> | keyof React.HTMLAttributes<HTMLUListElement>>, {}>;
type SimpleTreeViewComponent = (<Multiple extends boolean | undefined = undefined>(props: SimpleTreeViewProps<Multiple> & React.RefAttributes<HTMLUListElement>) => React.JSX.Element) & {
    propTypes?: any;
};
/**
 *
 * Demos:
 *
 * - [Tree View](https://mui.com/x/react-tree-view/)
 *
 * API:
 *
 * - [SimpleTreeView API](https://mui.com/x/api/tree-view/simple-tree-view/)
 */
declare const SimpleTreeView: SimpleTreeViewComponent;
export { SimpleTreeView };
