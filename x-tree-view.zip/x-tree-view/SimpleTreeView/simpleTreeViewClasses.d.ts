export interface SimpleTreeViewClasses {
    /** Styles applied to the root element. */
    root: string;
}
export type SimpleTreeViewClassKey = keyof SimpleTreeViewClasses;
export declare function getSimpleTreeViewUtilityClass(slot: string): string;
export declare const simpleTreeViewClasses: SimpleTreeViewClasses;
