import { DefaultTreeViewPluginParameters, DefaultTreeViewPluginSlotProps, DefaultTreeViewPluginSlots } from '../internals/plugins/defaultPlugins';
import { ConvertPluginsIntoSignatures } from '../internals/models';
export declare const SIMPLE_TREE_VIEW_PLUGINS: readonly [import("../internals/models").TreeViewPlugin<import("../internals").UseTreeViewIdSignature>, import("../internals/models").TreeViewPlugin<import("../internals").UseTreeViewItemsSignature>, import("../internals/models").TreeViewPlugin<import("../internals").UseTreeViewExpansionSignature>, import("../internals/models").TreeViewPlugin<import("../internals").UseTreeViewSelectionSignature>, import("../internals/models").TreeViewPlugin<import("../internals").UseTreeViewFocusSignature>, import("../internals/models").TreeViewPlugin<import("../internals").UseTreeViewKeyboardNavigationSignature>, import("../internals/models").TreeViewPlugin<import("../internals").UseTreeViewIconsSignature>, import("../internals/models").TreeViewPlugin<import("../internals/plugins/useTreeViewJSXItems").UseTreeViewJSXItemsSignature>];
export type SimpleTreeViewPlugins = ConvertPluginsIntoSignatures<typeof SIMPLE_TREE_VIEW_PLUGINS>;
export type SimpleTreeViewPluginSlots = DefaultTreeViewPluginSlots;
export type SimpleTreeViewPluginSlotProps = DefaultTreeViewPluginSlotProps;
export interface SimpleTreeViewPluginParameters<Multiple extends boolean | undefined> extends Omit<DefaultTreeViewPluginParameters<any, Multiple>, 'items' | 'isItemDisabled' | 'getItemLabel' | 'getItemId'> {
}
