import * as React from 'react';
import { RichTreeViewProps } from './RichTreeView.types';
export declare const RichTreeViewRoot: import("@emotion/styled").StyledComponent<import("@mui/system").MUIStyledCommonProps<import("@mui/material/styles").Theme> & {
    ownerState: RichTreeViewProps<any, any>;
}, Pick<React.DetailedHTMLProps<React.HTMLAttributes<HTMLUListElement>, HTMLUListElement>, keyof React.ClassAttributes<HTMLUListElement> | keyof React.HTMLAttributes<HTMLUListElement>>, {}>;
type RichTreeViewComponent = (<R extends {}, Multiple extends boolean | undefined = undefined>(props: RichTreeViewProps<R, Multiple> & React.RefAttributes<HTMLUListElement>) => React.JSX.Element) & {
    propTypes?: any;
};
/**
 *
 * Demos:
 *
 * - [Tree View](https://mui.com/x/react-tree-view/)
 *
 * API:
 *
 * - [RichTreeView API](https://mui.com/x/api/tree-view/rich-tree-view/)
 */
declare const RichTreeView: RichTreeViewComponent;
export { RichTreeView };
