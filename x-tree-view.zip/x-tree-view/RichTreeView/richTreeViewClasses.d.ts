export interface RichTreeViewClasses {
    /** Styles applied to the root element. */
    root: string;
}
export type RichTreeViewClassKey = keyof RichTreeViewClasses;
export declare function getRichTreeViewUtilityClass(slot: string): string;
export declare const richTreeViewClasses: RichTreeViewClasses;
