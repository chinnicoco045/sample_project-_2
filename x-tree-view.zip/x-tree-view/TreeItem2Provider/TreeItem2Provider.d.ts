/// <reference types="react" />
import { TreeItem2ProviderProps } from './TreeItem2Provider.types';
declare function TreeItem2Provider(props: TreeItem2ProviderProps): import("react").ReactNode;
declare namespace TreeItem2Provider {
    var propTypes: any;
}
export { TreeItem2Provider };
