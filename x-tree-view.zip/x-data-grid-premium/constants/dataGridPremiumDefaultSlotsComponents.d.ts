import type { GridPremiumSlotsComponent } from '../models';
export declare const DATA_GRID_PREMIUM_DEFAULT_SLOTS_COMPONENTS: GridPremiumSlotsComponent;
