import { GridStatePremium } from '../../../models/gridStatePremium';
export declare const gridCellSelectionStateSelector: (state: GridStatePremium) => import("./gridCellSelectionInterfaces").GridCellSelectionModel;
