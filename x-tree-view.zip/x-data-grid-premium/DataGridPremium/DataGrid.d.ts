export { SUBMIT_FILTER_STROKE_TIME, SUBMIT_FILTER_DATE_STROKE_TIME } from '@mui/x-data-grid';
/**
 * @deprecated Import DataGridPremium instead.
 */
export declare function DataGrid(): null;
/**
 * @deprecated Import DataGridPremium instead.
 */
export declare function DataGridPro(): null;
