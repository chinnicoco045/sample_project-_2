import * as React from 'react';
import { GridRenderCellParams } from '@mui/x-data-grid-pro';
declare function GridGroupingColumnLeafCell(props: GridRenderCellParams): React.JSX.Element;
export { GridGroupingColumnLeafCell };
