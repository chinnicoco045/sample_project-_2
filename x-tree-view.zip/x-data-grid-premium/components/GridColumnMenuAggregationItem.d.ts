import * as React from 'react';
import { GridColumnMenuItemProps } from '@mui/x-data-grid-pro';
declare function GridColumnMenuAggregationItem(props: GridColumnMenuItemProps): React.JSX.Element;
declare namespace GridColumnMenuAggregationItem {
    var propTypes: any;
}
export { GridColumnMenuAggregationItem };
