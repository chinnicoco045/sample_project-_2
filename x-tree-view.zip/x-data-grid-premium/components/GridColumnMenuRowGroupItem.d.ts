import * as React from 'react';
import { GridColumnMenuItemProps } from '@mui/x-data-grid-pro';
declare function GridColumnMenuRowGroupItem(props: GridColumnMenuItemProps): React.JSX.Element | null;
declare namespace GridColumnMenuRowGroupItem {
    var propTypes: any;
}
export { GridColumnMenuRowGroupItem };
