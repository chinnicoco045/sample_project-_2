import * as React from 'react';
import { GridColumnMenuItemProps } from '@mui/x-data-grid-pro';
declare function GridColumnMenuRowUngroupItem(props: GridColumnMenuItemProps): React.JSX.Element | null;
declare namespace GridColumnMenuRowUngroupItem {
    var propTypes: any;
}
export { GridColumnMenuRowUngroupItem };
