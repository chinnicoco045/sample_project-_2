import * as React from 'react';
import { GridRenderCellParams } from '@mui/x-data-grid-pro';
declare function GridGroupingColumnFooterCell(props: GridRenderCellParams): React.JSX.Element;
export { GridGroupingColumnFooterCell };
