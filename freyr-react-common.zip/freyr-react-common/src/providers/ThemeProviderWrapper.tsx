import React, { useMemo } from 'react';
import { ThemeProvider, createTheme, useTheme } from '@mui/material/styles';
import * as coreLocales from '@mui/material/locale';
// import * as gridLocales from "@mui/x-data-grid/locales";
import * as pickersLocales from '@mui/x-date-pickers/locales';
import { LANGUAGEMAP } from '../constants';
import { useFreyrLibraryContext } from '../context/FreyrLibraryContext';
type SupportedLocales = keyof typeof coreLocales;
// type GridLocales = keyof typeof gridLocales;
type PickersLocales = keyof typeof pickersLocales;

interface ComponentProps {
  children?: React.ReactNode;
}
const ThemeProviderWrapper: React.FC<ComponentProps> = ({ children }) => {
  const { language } = useFreyrLibraryContext();
  const theme = useTheme();
  const themeWithLocale = useMemo(() => {
    const locale: SupportedLocales = LANGUAGEMAP.mui[language];
    // const gridLocale: GridLocales = LANGUAGEMAP.mui[language];
    const pickersLocale: PickersLocales = LANGUAGEMAP.mui[language];
    return createTheme(
      {
        palette: {},
      },
      coreLocales[locale], //core translations
      //   gridLocales[gridLocale], // x-data-grid translations
      pickersLocales[pickersLocale] // x-date-pickers translations
    );
  }, [language, theme]);
  return <ThemeProvider theme={themeWithLocale}>{children}</ThemeProvider>;
};

export default ThemeProviderWrapper;
