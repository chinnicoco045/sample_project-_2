import Checkbox from '@mui/material/Checkbox';
import FormControlLabel from '@mui/material/FormControlLabel';
import {
  labelValue,
  FormContextType,
  RJSFSchema,
  StrictRJSFSchema,
  WidgetProps,
} from '@rjsf/utils';
import { FormControl } from '@mui/material';
import CustomizedFormLabel from './CustomizedFormLabel';
import React from 'react';

/** The `CheckBoxWidget` is a widget for rendering boolean properties.
 *  It is typically used to represent a boolean.
 *
 * @param props - The `WidgetProps` for this component
 */
export default function CheckboxWidget<
  T = any,
  S extends StrictRJSFSchema = RJSFSchema,
  F extends FormContextType = any
>(props: WidgetProps<T, S, F>) {
  const {
    schema,
    id,
    value,
    disabled,
    required,
    readonly,
    label = '',
    hideLabel,
    autofocus,
    onChange,
    registry,
    options,
    uiSchema,
  } = props;
  // Because an unchecked checkbox will cause html5 validation to fail, only add
  // the "required" attribute if the field value must be "true", due to the
  // "const" or "enum" keywords

  const _onChange = (_: any, checked: boolean) => onChange(checked);

  return (
    <FormControl>
      <CustomizedFormLabel
        label={
          (labelValue(label || undefined, hideLabel, false) as string) ?? ''
        }
        labelKey={uiSchema?.['ui:labelKey']}
        required={required}
        description={uiSchema?.['ui:description'] ?? schema['description']}
        icon={uiSchema?.['ui:icon']}
        readonly={uiSchema?.['ui:readonly'] ?? schema?.['readOnly']}
        disabled={uiSchema?.['ui:disabled']}
      ></CustomizedFormLabel>
      <FormControlLabel
        control={
          <Checkbox
            id={id}
            name={id}
            checked={typeof value === 'undefined' ? false : Boolean(value)}
            disabled={disabled || readonly}
            autoFocus={autofocus}
            onChange={_onChange}
          />
        }
        label={''}
      />
    </FormControl>
  );
}