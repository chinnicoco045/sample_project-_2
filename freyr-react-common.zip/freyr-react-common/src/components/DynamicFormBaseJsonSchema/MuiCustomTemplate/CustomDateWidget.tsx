import React from "react";
import {
  FormContextType,
  RJSFSchema,
  StrictRJSFSchema,
  WidgetProps,
  labelValue,
  // getUiOptions,
} from "@rjsf/utils";
import {
  FormControl,
  IconButton,
  InputAdornment,
  TextField,
} from "@mui/material";
import { DatePicker, LocalizationProvider } from "@mui/x-date-pickers";
import dayjs from "dayjs";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import HighlightOffOutlinedIcon from "@mui/icons-material/HighlightOffOutlined";
import CalendarMonthOutlinedIcon from "@mui/icons-material/CalendarMonthOutlined";
import CustomizedFormLabel from "./CustomizedFormLabel";

function CustomDateWidget<
  T = any,
  S extends StrictRJSFSchema = RJSFSchema,
  F extends FormContextType = any
>(props: WidgetProps<T, S, F>) {
  console.log("CustomDateWidget: ", props);
  const { uiSchema, schema, onChange, value } = props;
  const {
    label,
    hideLabel,
    required,
    disabled,
    readonly,
    placeholder,
    rawErrors = [],
  } = props;

  const [open, setOpen] = React.useState(false);
  const _onChange = (date: Date) => {
    onChange(date);
  };

  const handleOpen = (status: boolean) => {
    if (status && (readonly || disabled)) return;
    setOpen(status);
  };
  const dateFormat = "DD/MMM/YYYY";

    return (
    <FormControl>
      <CustomizedFormLabel
        label={
          (labelValue(label || undefined, hideLabel, false) as string) ?? ""
        }
        labelKey={uiSchema?.["ui:labelKey"]}
        required={required}
        description={uiSchema?.["ui:description"] ?? schema["description"]}
        icon={uiSchema?.["ui:icon"]}
        readonly={uiSchema?.["ui:readonly"] ?? schema?.["readOnly"]}
        disabled={uiSchema?.["ui:disabled"]}
      ></CustomizedFormLabel>
      <LocalizationProvider dateAdapter={AdapterDayjs}>
        <DatePicker
          className="custom-date-picker"
          inputFormat={dateFormat}
          value={value ?? ""}
          onChange={(newVal) => {
            onChange?.(dayjs(newVal).format(dateFormat) );
          }}
          open={open}
          onOpen={() => handleOpen(true)}
          onClose={() => handleOpen(false)}
          minDate={uiSchema?.minDate}
          maxDate={uiSchema?.maxDate}
          disabled={disabled}
          readOnly={readonly}
          renderInput={(params) => {
            return (
              <TextField
                {...params}
                inputProps={{
                  ...params.inputProps,
                  value: value ? dayjs(value).format(dateFormat) : "",
                  readOnly: true,
                  placeholder: placeholder ?? "Select Date",
                }}
                error={rawErrors.length > 0}
                size="small"
                onClick={() => handleOpen(true)}
                InputProps={{
                  endAdornment: (
                    <InputAdornment position="end">
                      {value && (
                        <HighlightOffOutlinedIcon
                          onClick={(ev) => {
                            ev.preventDefault();
                            ev.stopPropagation();
                                                        if (disabled) {
                              return
                            } else {
                              onChange(undefined);
                            }
                          }}
                          sx={{
                            marginX: "5px",
                            fontSize: "14px",
                            color: "GrayText",
                            "&:hover": disabled ? {} : {
                              color: "Highlight",
                              cursor: "pointer",
                            },
                          }}
                        ></HighlightOffOutlinedIcon>
                      )}
                      <IconButton
                        size="small"
                        sx={{
                          borderRadius: "50%",
                        }}
                        disabled={disabled}
                      >
                        <CalendarMonthOutlinedIcon
                          sx={{
                            fontSize: "16px",
                            color: "GrayText",
                            "&:hover": {
                              color: "Highlight",
                            },
                          }}
                        ></CalendarMonthOutlinedIcon>
                      </IconButton>
                    </InputAdornment>
                  ),
                }}
              />
            );
          }}
        />
      </LocalizationProvider>
    </FormControl>
  );
}

export default CustomDateWidget;
