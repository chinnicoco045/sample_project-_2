import {
  FormContextType,
  RJSFSchema,
  StrictRJSFSchema,
  BaseInputTemplateProps,
} from '@rjsf/utils';
import {
  Box,
  Tooltip,
  FormLabel,
  FormControlLabel,
  Checkbox,
} from '@mui/material';
import { useState, useEffect, useMemo } from "react";
import { useCustomSelect } from "../hooks/useCustomSelect";
import React from "react";

function CustomViewWidget<
  T = any,
  S extends StrictRJSFSchema = RJSFSchema,
  F extends FormContextType = any
>(props: BaseInputTemplateProps<T, S, F>) {
  const { label, value, uiSchema, name, formContext, options } = props;
  const [showValue, setShowValue] = useState<string>("");
  const { enumOptions, enumDisabled, emptyValue: optEmptyVal } = options;
  const uniqueKey = `${name}-unique-select`;
  const formState = formContext?.["formState"] as Record<string, unknown>;
  const extraState = formContext?.["extraState"] as Record<string, unknown>;
  const dynamicFormContextQueryKey =
    (formContext?.["dynamicFormContextQueryKey"] as string) ?? "";

  const shadowFormState = formContext?.["shadowFormState"] as Record<
    string,
    unknown
  >;

  const shadowValue = shadowFormState?.[name] as
    | string
    | number
    | Array<string | number>
    | undefined;
  const shadowOptionList = useMemo(() => {
    if (shadowValue === undefined) return undefined;
    if (Array.isArray(shadowValue)) return undefined;
    return [{ label: String(shadowValue), value }];
  }, [shadowValue, value]);

  const asyncConfig = uiSchema?.[
    "ui:asyncConfig"
  ] as TSelectInput["asyncConfig"];
  const type = uiSchema?.["ui:type"];
  const multiple = uiSchema?.["ui:multiple"] ?? false;
  const isNeedFetch = useMemo(() => {
    return ['select', 'radio', 'checkboxGroups'].includes(type);
  }, [type]);

  const enumOptionsFromDefinition = useMemo(() => {
    return (
      enumOptions?.map((el) => ({
        label: el?.label,
        value: el?.value?.value,
      })) ?? []
    );
  }, [enumOptions]);

  const { resOptionList } = useCustomSelect(
    asyncConfig,
    dynamicFormContextQueryKey
      ? [dynamicFormContextQueryKey, uniqueKey]
      : uniqueKey,
    { formState, extraState },
    isNeedFetch && shadowOptionList === undefined && !!asyncConfig?.url,
  );

  const optionList = useMemo(() => {
    return (
      shadowOptionList ??
      resOptionList ??
      (enumOptionsFromDefinition || [])
    );
  }, [enumOptionsFromDefinition, name, resOptionList, shadowOptionList]);

  const handleSingleInitValue = (
    optionList: (Omit<OptionItem, "label"> & {
      label: string;
    })[]
  ) => {
    const newValue = optionList?.find((el) => {
      if (Array.isArray(value)) {
        return value?.some((item) => `${item}` === `${el?.value}`);
      }
      if (typeof value !== "object") {
        return value && `${el?.value}` === `${value}`;
      }
      return value && `${el?.value}` === `${value?.value}`;
    });
    return newValue;
  };

  const handleMultiInitValue = (
    optionList: (Omit<OptionItem, "label"> & {
      label: string;
    })[]
  ) => {
    if (!value) return [];
    // show old format value.
    if (
      !Array?.isArray(value) &&
      (typeof value === "string" || typeof value === "number")
    ) {
      return optionList?.filter(
        (el) => `${el?.value}`?.toLowerCase() === `${value}`?.toLowerCase()
      );
    }
    if (!Array?.isArray(value) || value?.length === 0) {
      return [];
    }
    return value
      ?.map((item) => {
        const res = optionList?.find((el) => {
        if (typeof item !== "object") {
            return (
              item && `${el?.value}`?.toLowerCase() === `${item}`?.toLowerCase()
            );
          }
          const some =
            value &&
            `${el?.value}`?.toLowerCase() === `${item?.value}`?.toLowerCase();
          return some;
        });
        return res;
      })
      ?.filter((el) => !!el) as (Omit<OptionItem, "label"> & {
      label: string;
    })[];
  };

  useEffect(() => {
    if (
      !optionList ||
      optionList?.length === 0 ||
      !value ||
      (Array.isArray(value) && value?.length === 0)
    ) {
      return;
    }
    if (!multiple) {
      const newValue = handleSingleInitValue(optionList);
      setShowValue(newValue?.label ?? "");
      return;
    }
    const newValue = handleMultiInitValue(optionList);
    setShowValue(newValue.map((item) => item.label ?? "")?.join(",") ?? "");
  }, [optionList, value, multiple]);

  const labelValue = useMemo(() => {
    return isNeedFetch ? showValue : value;
  }, [showValue, value, type]);

  return (
    <Box>
      <FormLabel
        required={false}
        className="text-ellipsis"
        sx={{
          textAlign: "left",
          my: 1,
          display: "flex",
          alignItems: "center",
          color: "initial",
          position: "relative",
        }}
      >
        <Box flex={1} overflow={"hidden"} display={"flex"}>
          {" "}
          <Tooltip title={label}>
            <span className="text-ellipsis">{label}</span>
          </Tooltip>
        </Box>
      </FormLabel>
      {type !== 'checkbox' ? (
        <Tooltip placement="bottom-start" title={labelValue}>
          <Box marginTop={"10px"}>{labelValue || "-"}</Box>
        </Tooltip>
      ) : (
        <FormControlLabel
          control={
            <Checkbox
              disabled
              checked={
                typeof value === 'undefined' ? false : Boolean(labelValue)
              }
            />
          }
          label={''}
        />
      )}
    </Box>
  );
}

export default CustomViewWidget;
