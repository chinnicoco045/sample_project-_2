/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import { ChangeEvent, FocusEvent } from "react";
import {
  TextField,
  TextFieldProps,
  InputLabel,
  FormControl,
  FormLabel,
} from "@mui/material";
import {
  ariaDescribedByIds,
  BaseInputTemplateProps,
  examplesId,
  getInputProps,
  labelValue,
  FormContextType,
  RJSFSchema,
  StrictRJSFSchema,
  getUiOptions,
} from "@rjsf/utils";
import CustomizedFormLabel from "./CustomizedFormLabel";
import { MuiChipsInput } from "mui-chips-input";
import React from "react";
import ChipsInputWithOptionsList from "../../FormComps/ChipsInputWithOptionsList";

const TYPES_THAT_SHRINK_LABEL = ["date", "datetime-local", "file", "time"];

/** The `BaseInputTemplate` is the template to use to render the basic `<input>` component for the `core` theme.
 * It is used as the template for rendering many of the <input> based widgets that differ by `type` and callbacks only.
 * It can be customized/overridden for other themes or individual implementations as needed.
 *
 * @param props - The `WidgetProps` for this template
 */
export default function CustomChipsInput<
  T = any,
  S extends StrictRJSFSchema = RJSFSchema,
  F extends FormContextType = any
>(props: BaseInputTemplateProps<T, S, F>) {
  const {
    id,
    name, // remove this from textFieldProps
    placeholder,
    required,
    readonly,
    disabled,
    type,
    label,
    hideLabel,
    value,
    onChange,
    onChangeOverride,
    onBlur,
    onFocus,
    autofocus,
    options,
    schema,
    uiSchema,
    rawErrors = [],
    formContext,
    registry,
    InputLabelProps,
    ...textFieldProps
  } = props;
  // console.log("name: ", name, "uiSchema: ", uiSchema, "schema: ", schema);
  const inputProps = getInputProps<T, S, F>(schema, type, options);
  const uiOptions = getUiOptions<T, S, F>(uiSchema);
  // Now we need to pull out the step, min, max into an inner `inputProps` for material-ui
  const { step, min, max, ...rest } = inputProps;
  const otherProps = {
    inputProps: {
      step,
      min,
      max,
      ...(schema.examples ? { list: examplesId<T>(id) } : undefined),
    },
    ...rest,
  };
  const _onChange = (value: string[]) => {
    console.log("custom chips input _onchange: ", value);
    onChange(!value || value?.length === 0 ? options.emptyValue : value);
  };
  const _onBlur = (value: string[]) => onBlur(id, value);
  const _onFocus = (value: string[]) => onFocus(id, value);
  const DisplayInputLabelProps = TYPES_THAT_SHRINK_LABEL.includes(type)
    ? {
        ...InputLabelProps,
        shrink: true,
      }
    : InputLabelProps;

  // console.log(
  //   "custom chips input value: ====================",
  //   id,
  //   name,
  //   value,
  //   "inputProps, ",
  //   inputProps,
  //   "uiSchema options: ",
  //   uiOptions?.["customOptions"],
  //   "uiOptions: ", uiOptions
  // );

  return (
    <FormControl
      sx={{
        "& .MuiChip-root": {
          marginTop: "5px !important",
        },
      }}
    >
      <CustomizedFormLabel
        label={
          (labelValue(label || undefined, hideLabel, false) as string) ?? ""
        }
        labelKey={uiSchema?.["ui:labelKey"]}
        required={required}
        maxLen={uiSchema?.["ui:maxLen"] ?? undefined}
        existLen={value?.length ?? 0}
        description={uiSchema?.["ui:description"] ?? schema?.["description"]}
        icon={uiSchema?.["ui:icon"]}
        readonly={uiSchema?.["ui:readonly"] ?? schema?.["readOnly"]}
        disabled={uiSchema?.["ui:disabled"]}
      ></CustomizedFormLabel>
      <ChipsInputWithOptionsList
        id={id}
        // name={name}
        placeholder={placeholder ?? uiSchema?.["ui:placeholder"] ?? ""}
        // label={labelValue(label || undefined, hideLabel, false)}
        autoFocus={autofocus}
        // required={required}
        disabled={disabled || readonly}
        {...(otherProps as any)}
        value={value ?? []}
        options={uiOptions?.["customOptions"] ?? undefined}
        // error={rawErrors.length > 0}
        onChange={_onChange as any}
        // onBlur={_onBlur as any}
        // onFocus={_onFocus as any}
        size={uiSchema?.["ui:size"] || uiOptions?.["ui:size"] || "medium"}
        catchInputValAsChipOnBlur={
          uiSchema?.["ui:catchInputValAsChipOnBlur"] ||
          uiOptions?.["ui:catchInputValAsChipOnBlur"]
        }
        // InputLabelProps={{
        //   ...DisplayInputLabelProps,
        //   shrink: false,
        // }}
        // inputProps={{
        //   maxLength: uiSchema?.["ui:maxLen"] ?? null,
        //   min: schema?.["minimum"] ?? null,
        //   max: schema?.["maximum"] ?? null,
        // }}
        // {...(textFieldProps as TextFieldProps)}
        // aria-describedby={ariaDescribedByIds<T>(id, !!schema.examples)}
      />
    </FormControl>
  );
}
