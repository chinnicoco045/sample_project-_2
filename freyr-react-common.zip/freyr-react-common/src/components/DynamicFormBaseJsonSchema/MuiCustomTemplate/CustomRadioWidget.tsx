import { FocusEvent, useEffect, useMemo, useState } from "react";
import FormControlLabel from "@mui/material/FormControlLabel";
import FormLabel from "@mui/material/FormLabel";
import Radio from "@mui/material/Radio";
import RadioGroup from "@mui/material/RadioGroup";
import {
  ariaDescribedByIds,
  enumOptionsIndexForValue,
  enumOptionsValueForIndex,
  labelValue,
  optionId,
  FormContextType,
  RJSFSchema,
  StrictRJSFSchema,
  WidgetProps,
} from "@rjsf/utils";
import { useCustomSelect } from "../hooks/useCustomSelect";
import CustomizedFormLabel from "./CustomizedFormLabel";
import React from "react";

/** The `RadioWidget` is a widget for rendering a radio group.
 *  It is typically used with a string property constrained with enum options.
 *
 * @param props - The `WidgetProps` for this component
 */
export default function RadioWidget<
  T = any,
  S extends StrictRJSFSchema = RJSFSchema,
  F extends FormContextType = any
>({
  schema,
  id,
  name, // remove this from textFieldProps
  options,
  label,
  hideLabel,
  required,
  disabled,
  placeholder,
  readonly,
  value,
  autofocus,
  onChange,
  onBlur,
  onFocus,
  rawErrors = [],
  registry,
  uiSchema,
  hideError,
  formContext,
  ...otherProps
}: WidgetProps<T, S, F>) {
  const uniqueKey = `${name}-unique-select`;
  const formState = formContext?.["formState"] as Record<string, unknown>;
  const extraState = formContext?.["extraState"] as Record<string, unknown>;
  const dynamicFormContextQueryKey =
  (formContext?.["dynamicFormContextQueryKey"] as string) ?? "";
  const asyncConfig = uiSchema?.[
    "ui:asyncConfig"
  ] as TSelectInput["asyncConfig"];
  const { enumOptions, enumDisabled, emptyValue: optEmptyVal } = options;
  const [radioValue, setRadioValue] = useState<string | number | null>(null);

  const enumOptionsFromDefinition = useMemo(() => {
    return (
      enumOptions?.map((el) => ({
        label: el?.label,
        value: el?.value?.value,
      })) ?? []
    );
  }, [enumOptions]);

  const { resOptionList, fetchLoading } = useCustomSelect(
    asyncConfig,
    dynamicFormContextQueryKey
    ? [dynamicFormContextQueryKey, uniqueKey]
    : uniqueKey,
    { formState, extraState },
    !!asyncConfig?.url
  );

  const optionList = useMemo(() => {
    return resOptionList?.length > 0
      ? resOptionList
      : enumOptionsFromDefinition || [];
  }, [enumOptionsFromDefinition, name, resOptionList]);

  const handleValueChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    let newValue = (event.target as HTMLInputElement).value;
    onChange?.(newValue);
    if (!newValue) {
      setRadioValue(null);
    }
  };

  const handleSingleInitValue = (optionList: OptionItem[]) => {
    const newValue = optionList?.find((el) => {
      if (Array.isArray(value)) {
        return value?.some((item) => `${item}` === `${el?.value}`);
      }
      if (typeof value !== "object") {
        return value && `${el?.value}` === `${value}`;
      }
      return value && `${el?.value}` === `${value?.value}`;
    });
    return newValue;
  };

  useEffect(() => {
    if (!optionList || optionList?.length === 0 || !value) {
      return;
    }
    const newValue = handleSingleInitValue(optionList);
    setRadioValue(newValue?.value ?? null);
    return;
  }, [optionList, value]);

  return (
    <>
      <CustomizedFormLabel
        label={
          (labelValue(label || undefined, hideLabel, false) as string) ?? ""
        }
        labelKey={uiSchema?.["ui:labelKey"]}
        required={required}
        description={uiSchema?.["ui:description"] ?? schema["description"]}
        icon={uiSchema?.["ui:icon"]}
        readonly={uiSchema?.["ui:readonly"] ?? schema?.["readOnly"]}
        disabled={uiSchema?.["ui:disabled"]}
      ></CustomizedFormLabel>
      <RadioGroup value={radioValue} onChange={handleValueChange} row>
        {Array.isArray(optionList) &&
          optionList.map((option, index) => {
            const radio = (
              <FormControlLabel
                control={
                  <Radio name={id} id={optionId(id, index)} color="primary" />
                }
                label={option.label}
                value={option.value}
                key={index}
                disabled={disabled || readonly}
              />
            );
            return radio;
          })}
      </RadioGroup>
    </>
  );
}
