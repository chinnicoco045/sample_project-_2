import React, {
  useState,
  useEffect,
  useMemo,
  forwardRef,
  useImperativeHandle,
  useRef,
} from 'react';
import { Stack, Button } from '@mui/material';
import { RJSFSchema, RJSFValidationError, UiSchema } from '@rjsf/utils';
import validator from '@rjsf/validator-ajv8';
import { withTheme } from '@rjsf/core';
import { Theme } from '@rjsf/mui';
import CustomTemplate from './MuiCustomTemplate/ObjectFieldTemplate';
import CustomBaseInputTemplate from './MuiCustomTemplate/BaseInputTemplate';
import CustomSelectWidget from './MuiCustomTemplate/CustomSelectWidget';
import CustomChipsInput from './MuiCustomTemplate/CustomChipsInput';
import CustomDescriptionField from './MuiCustomTemplate/DescriptionField';
import CustomFieldErrorTemplate from './MuiCustomTemplate/FieldErrorTemplate';
import CustomTitleField from './MuiCustomTemplate/TitleField';
import CustomCheckboxesWidget from './MuiCustomTemplate/CheckboxesWidget';
import CustomCheckboxWidget from './MuiCustomTemplate/CheckboxWidget';
// import * as z from 'zod';
import CustomDateWidget from './MuiCustomTemplate/CustomDateWidget';
import { ConvertJsonSchemaFunc } from './hooks/convert';
import { isEqual } from 'lodash';
// import { t } from "i18next";
import { useTranslation } from 'react-i18next';
import CustomViewWidget from './MuiCustomTemplate/CustomViewWidget';
import CustomRadioWidget from './MuiCustomTemplate/CustomRadioWidget';
// import { CompProps } from './type';
import { transformStateByDefinitions as transformFunc } from './hooks/useCustomSelect';
import { useQueryClient } from '@tanstack/react-query';
import { produce } from 'immer';

const Form = withTheme(Theme);

export const DynamicFormCompBasicJsonSchema = forwardRef(
  (
    {
      uniqueKey,
      jsonData,
      onFormSubmit,
      initialFormData,
      okKey,
      okText = 'Submit',
      cancelKey,
      cancelText = 'Cancel',
      buttonPosition = 'right',
      onCancel,
      disabledFields = [],
      removeButtons = false,
      disabled = false,
      forbiddenSubmit = false,
      viewType = false,
      extraState,
      viewComponent,
      formContextQueryKey,
      shadowFormState = {},
      transformStateByDefinitions = transformFunc,
      transformDataMode = false,
    }: CompProps,
    ref
  ) => {
    // const [dynamicFields, setDynamicFields] = useState<DynamicFields>([]);
    const submitButtonHideRef = useRef<HTMLButtonElement | null>(null);
    const [formData, setFormData] = useState<Record<string, unknown>>(
      initialFormData ?? {}
    );
    const [formStateWithLabel, setFormStateWithLabel] = useState<
      Record<string, unknown>
    >(initialFormData ?? {});

    const [extraData, setExtraData] = useState<Record<string, unknown>>(
      extraState ?? {}
    );

    const { t } = useTranslation();
    const queryClient = useQueryClient();
    // const dynamicSchema = dynamicMap?.get(uniqueKey)?.schema;

    const dynamicSchema = useMemo(() => {
      if (jsonData && jsonData?.length > 0) {
        return ConvertJsonSchemaFunc(jsonData, disabledFields, viewType);
      }
      return ConvertJsonSchemaFunc([], disabledFields);
    }, [disabledFields, jsonData, uniqueKey, viewType]);

    const handleFormStateWithLabelChange = (field: string, data: unknown) => {
      setFormStateWithLabel(
        produce(draft => {
          if (!draft) return { [field]: data };
          draft[field] = data;
          return draft;
        })
      );
    };

    // console.log("uniqueKey", uniqueKey);
    // console.log("dynamicMap", dynamicMap);
    // console.log("info", info);
    // console.log("dynamicFields", dynamicFields);
    console.log(
      'DynamicFormCompBasicJsonSchema formData------------',
      formData
    );

    useEffect(() => {
      if (initialFormData && !isEqual(initialFormData, formData)) {
        setFormData(initialFormData);
      }
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [initialFormData]);

    useEffect(() => {
      if (extraState && !isEqual(extraState, extraData)) {
        setExtraData(extraState);
      }
    }, [extraState]);

    useImperativeHandle(
      ref,
      () => {
        return {
          submitForm: () => submitButtonHideRef?.current?.click(),
          clearFormState: () => setFormData({}),
          getFormState: () => formData,
        };
      },
      []
    );

    useEffect(() => {
      return () => {
        formContextQueryKey &&
          queryClient?.removeQueries([formContextQueryKey]);
      };
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    return (
      <Form
        // tagName="div"
        // noValidate
        noHtml5Validate
        schema={dynamicSchema?.jsonSchema as RJSFSchema}
        validator={validator}
        uiSchema={dynamicSchema?.uiSchema as UiSchema}
        formData={formData}
        formContext={{
          formState: formData,
          extraState: extraData,
          viewComponent,
          formStateWithLabel: formStateWithLabel,
          onFormStateWithLabelChange: handleFormStateWithLabelChange,
          dynamicFormContextQueryKey: formContextQueryKey,
          shadowFormState,
        }}
        omitExtraData // omit the extra; will cause remove some data auto, need clear handle.
        idPrefix={uniqueKey} // unique all fields in the page.
        disabled={disabled} // disable all form
        // readonly // readonly to all fields
        showErrorList={false} // top/bottom/false
        // just validate on submit.
        liveValidate={false}
        templates={{
          ObjectFieldTemplate: CustomTemplate,
          BaseInputTemplate: CustomBaseInputTemplate,
          DescriptionFieldTemplate: CustomDescriptionField,
          FieldErrorTemplate: CustomFieldErrorTemplate,
          TitleFieldTemplate: CustomTitleField,
        }}
        widgets={{
          CustomSelectWidget: CustomSelectWidget,
          CustomDateWidget: CustomDateWidget,
          CustomViewWidget: CustomViewWidget,
          CustomRadioWidget: CustomRadioWidget,
          CustomChipsInput: CustomChipsInput,
          CustomCheckboxesWidget: CustomCheckboxesWidget,
          CustomCheckboxWidget: CustomCheckboxWidget
        }}
        onSubmit={data => {
          console.log('on submit data: ', data, data?.formData);
          // console.log("exist data: ", formData);
          setFormData(data?.formData);
          if (forbiddenSubmit) return;
          if (transformDataMode) {
            const newFormState = transformStateByDefinitions(
              data?.formData,
              jsonData
            );
            onFormSubmit?.(newFormState);
            return;
          }
          onFormSubmit?.(data?.formData);
        }}
        onError={errors => {
          console.log('errors', errors);
        }}
        onChange={data => {
          // console.log("on change data: ", data?.formData);
          setFormData(prev => ({
            ...prev,
            ...data?.formData,
          }));
        }}
        customValidate={(formData, errors) => {
          console.log('formData: ', formData);
          const parseRes = dynamicSchema?.zodSchema?.safeParse(formData);
          console.log('parseRes: ', parseRes);
          if (!parseRes || parseRes?.success) {
            return errors;
          }
          console.log('parseRes.error: ', parseRes.error);
          const errorMsg = parseRes.error.flatten()?.fieldErrors as Record<
            string,
            string[]
          >;
          const fields = Object.keys(formData);
          // console.log("errorMsg", errorMsg);
          // console.log("fields", fields);
          for (const field of fields) {
            if (field in errorMsg && errorMsg?.[field]?.length > 0) {
              // console.log("field", field);
              errors[field]?.addError(errorMsg?.[field]?.[0] ?? '');
              // console.log("field errors: ", errors[field]?.__errors);
            }
          }
          console.log('formData: ', formData);
          return errors;
        }}
        // transformErrors exec before customValidate.
        transformErrors={errors => {
          const finalErrors: RJSFValidationError[] = [];
          for (const err of errors) {
            if (err?.name === 'required') {
              const labelName = err?.message
                ?.split('required property')?.[1]
                ?.slice(2, -1);
              finalErrors.push({
                ...err,
                message: `${labelName ?? err.property} ${t(
                  'validation.isRequired'
                )}`,
              });
            }
          }
          // console.log("errors", errors);
          console.log('finalErrors', finalErrors);
          return finalErrors;
        }}
      >
        {!removeButtons && (
          <Stack
            direction="row"
            alignItems="center"
            justifyContent={
              buttonPosition === 'left'
                ? 'flex-start'
                : buttonPosition === 'right'
                ? 'flex-end'
                : 'center'
            }
            gap={1}
            mt={4}
          >
            <Button
              variant="text"
              onClick={onCancel}
              data-testid="cancelBtn"
              size="small"
            >
              {cancelKey ? t(cancelKey) : cancelText}
            </Button>
            {!forbiddenSubmit && (
              <Button
                data-testid="okBtn"
                size="small"
                variant="contained"
                type="submit"
                ref={submitButtonHideRef}
              >
                {okKey ? t(okKey) : okText}
              </Button>
            )}
          </Stack>
        )}
        {removeButtons && (
          <Stack
            direction="row"
            alignItems="center"
            justifyContent={
              buttonPosition === 'left'
                ? 'flex-start'
                : buttonPosition === 'right'
                ? 'flex-end'
                : 'center'
            }
            gap={1}
            mt={4}
            display="none"
          >
            <Button
              data-testid="okBtn"
              size="small"
              variant="contained"
              type="submit"
              ref={submitButtonHideRef}
            >
              {okKey ? t(okKey) : okText}
            </Button>
          </Stack>
        )}
      </Form>
    );
  }
);

export interface CompProps {
  /**
   * unique key for the whole form component,
   * used to every form item.
   */
  uniqueKey?: string;
  /**
   * json form schema to render form.
   */
  jsonData?: PrettifiedTFormInput[];
  /**
   * submit event
   * @param data form data
   * @returns
   */
  onFormSubmit?: (data: Record<string, unknown>) => void;
  /**
   * default form data, will update whole form data when change.
   */
  initialFormData?: Record<string, unknown>;
  /**
   * text for submit button.
   */
  okText?: string;
  /**
   * text key (multi language) for submit button.
   */
  okKey?: string;
  /**
   * text for cancel button.
   */
  cancelText?: string;
  /**
   * text key (multi language) for cancel button.
   */
  cancelKey?: string;
  /**
   * buttons(submit/cancel) position of bottom.
   */
  buttonPosition?: 'center' | 'right' | 'left';
  /**
   * cancel event.
   */
  onCancel?: VoidFunction;
  /**
   * advanced disable fields; will force disable these form items by fields.
   */
  disabledFields?: string[];
  /**
   * remove submit/cancel buttons.
   */
  removeButtons?: boolean;
  /**
   * disable the whole form.
   */
  disabled?: boolean;
  /**
   * forbidden the submit event, will never trigger.
   */
  forbiddenSubmit?: boolean;
  /**
   * set the whole form as view mode,
   * will used special view component to render form items.
   */
  viewType?: boolean;
  extraState?: Record<string, unknown>;
  /**
   * Customize your own view component, will used default if undefined.
   */
  viewComponent?: React.ReactNode;
  /**
   * key will apply to the useQuery, and remove all cache when root form unmount.
   */
  formContextQueryKey?: string;
  /**
   * Can be used in viewComponent when no need query data, but used the shadowFormState instead.
   */
  shadowFormState?: Record<string, unknown>;
  /**
   * By default, will transform all select/multi-select value to array, and then submit.
   * @param formState submitted form data.
   * @param definition json form schema.
   * @returns
   */
  transformStateByDefinitions?: (
    formState?: Record<string, unknown>,
    definition?: PrettifiedTFormInput[]
  ) => Record<string, unknown>;
  /**
   * boolean for whether apply the transformStateByDefinitions function. False by default.
   */
  transformDataMode?: boolean;
}
