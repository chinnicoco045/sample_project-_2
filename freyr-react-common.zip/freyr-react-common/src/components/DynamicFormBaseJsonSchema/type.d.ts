export type TJsonSchemaData = {
  jsonSchema: RJSFSchema;
  uiSchema: UiSchema;
  zodSchema?: z.ZodObject<Record<string, any>>;
};

