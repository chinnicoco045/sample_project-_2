import { create } from "zustand";
import { immer } from "zustand/middleware/immer";
import { subscribeWithSelector, persist } from "zustand/middleware";
import { FilterIcons } from "../components/Filter/components/FilterSelectItem";
import { useEffect, useMemo } from "react";
import  cloneDeep from "lodash/cloneDeep";
import dayjs from "dayjs";
// import { useGetProductFormSetting } from "../hooks/formSetting";
import  mapValues from "lodash/mapValues";
// import { useGetActiveModule } from "../hooks/menu";
export type MenuItem = SYSLIB_API_TYPES["Modules"];

export interface FilterItemLinkedModules {
  [key: string]: {
    status: boolean;
    mappingModule: string;
  };
}

export interface DateFilterParams {
  type: string;
  less?: number;
  more?: number;
  between?: number;
  fromDate?: number;
  toDate?: number;
}
export interface FilterItem {
  label: string;
  value: string | number;
  disabled?: boolean;
  data: {
    field: string;
    label: string;
    totalLabel: string;
    searchPlaceholder: string;
    iconType: FilterIcons;
    itemType?: "select" | "date";
    fieldItemMode?: "plain" | "checkbox";
    linkedModules?: FilterItemLinkedModules;
    asyncConfig?: TSelectInput["asyncConfig"] | null;
    fieldId?: number | string;
  };
}

export type SelectFilterParams = {
  field: string;
  value: (string | number)[];
};

export type DateFilterFormatParams = {
  dateFlag: boolean;
  fieldId: number;
  le?: number;
  ge?: number;
};

export type FilterParamsItem = SelectFilterParams | DateFilterFormatParams;

const initialIdentifiers: FilterItem[] = [
  {
    label: "Product Name",
    value: 1,
    data: {
      field: "product",
      label: "Product Name",
      totalLabel: "Total products",
      searchPlaceholder: "Search products",
      iconType: 1,
      fieldItemMode: "checkbox",
      // linkedModules: ["Components"],
    },
  },
  {
    label: "Markets",
    value: 2,
    data: {
      field: "markets",
      label: "Markets",
      totalLabel: "Total markets",
      searchPlaceholder: "Search markets",
      iconType: 2,
      // fieldItemMode: "checkbox"
      // linkedModules: ["Components"],
    },
  },
  {
    label: "Countries",
    value: 3,
    data: {
      field: "country",
      label: "Countries",
      totalLabel: "Total countries",
      searchPlaceholder: "Search countries",
      iconType: 3,
      fieldItemMode: "checkbox",
      // linkedModules: ["Components"],
    },
  },
  {
    label: "Received Date",
    value: 13,
    data: {
      field: "rtq_date",
      label: "Date",
      totalLabel: "Total functions",
      searchPlaceholder: "Search functions",
      iconType: 4,
      itemType: "date",
      // linkedModules: ["Products", "Components"],
    },
  },
];

export type FilterStore = {
  // draft data.
  keyword?: string;
  filterItems: FilterItem[];
  fieldsState: Record<string, unknown>;
  updateFilterItems: (data: FilterItem[]) => void;
  updateFieldsState: (field: string, data: unknown) => void;
  removeSpareField: (data: {
    keepFields?: string[];
    removeFields?: string[];
    newFilterItems?: FilterItem[];
  }) => void;
  identifiers: FilterItem[];
  updateIdentifiers: (data: FilterItem[]) => void;
};

export const useFilterItemsStore = create<
  Omit<FilterStore, "identifiers" | "updateIdentifiers">
>()(
    subscribeWithSelector(
      immer((set, get) => ({
        // keyword: "",
        filterItems: [],
        fieldsState: {},
        updateFilterItems(data) {
          set((state) => {
            state.filterItems = data;
            return state;
          });
        },
        updateFieldsState(field, data) {
          set((state) => {
            if (field === "All") {
              state.fieldsState = data as Record<string, unknown>;
            } else {
              state.fieldsState[field] = data;
            }
            // state.fieldsState[field] = data;
            return state;
          });
        },
        removeSpareField(data) {
          console.log("data11", data);
          if ("keepFields" in data && data?.keepFields) {
            const newFieldsState = Object.fromEntries(
              Object.entries(get().fieldsState)?.filter(([field]) =>
                data?.keepFields?.includes(field)
              )
            );
            console.log("===================2", newFieldsState);
            let newFilterItems: FilterItem[];
            if (data?.newFilterItems) {
              newFilterItems = data?.newFilterItems ?? [];
            } else {
              newFilterItems = cloneDeep(get().filterItems)?.filter((el) =>
                data?.keepFields?.includes(el?.data?.field)
              );
              // console.log("newFilterItems", newFilterItems);
            }
            set((state) => {
              state.fieldsState = newFieldsState as Record<string, unknown>;
              state.filterItems = newFilterItems;
              // state.realFilterParams = newFieldsState;
              return state;
            });
          }
          if ("removeFields" in data && data?.removeFields) {
            const newFieldsState = Object.fromEntries(
              Object.entries(get().fieldsState)?.filter(
                ([field]) => !data?.removeFields?.includes(field)
              )
            );
            console.log("===================3", newFieldsState);
            let newFilterItems: FilterItem[];
            if (data?.newFilterItems) {
              newFilterItems = data?.newFilterItems ?? [];
            } else {
              newFilterItems =
                cloneDeep(get().filterItems)?.filter(
                  (el) => !data?.removeFields?.includes(el?.data?.field)
                ) ?? [];
            }
            set((state) => {
              state.fieldsState = newFieldsState as Record<string, unknown>;
              state.filterItems = newFilterItems;
              // state.realFilterParams = newFieldsState;
              return state;
            });
            // useViewModelStore?.getState()?.resetPagination?.();
          }
        },
      }))
    )
);

export const useNonPersistentFilterItemsStore = create(
  immer<Partial<FilterStore>>((set, get) => ({
    identifiers: [],
    updateIdentifiers(data) {
      set((state) => {
        state.identifiers = data;
        return state;
      });
    },
  }))
);

export const useGlobalFilterState = () => {
  const [fieldsState] = useFilterItemsStore((state) => [state?.fieldsState]);
  const [identifiers] = useNonPersistentFilterItemsStore((state) => [
    state?.identifiers,
  ]);
  const fieldsStateFormatted = useMemo(() => {
    let formattedData = mapValues(
      fieldsState,
      (items: FilterOptionItem[], key: string) => {
        const identifier = identifiers?.find(
          (identifier) => identifier.data?.field === key
        );
        const filterType = identifier
          ? identifier.data.itemType === "select"
          : false;
        if (filterType) {
          return items.map((item: FilterOptionItem) => {
            if (item.id_mapping) {
              const commonCode = Object.values(item.id_mapping)?.[0];
              return commonCode ?? item.value;
            } else if (item.value){
              return item.value
            }
          });
        }
      }
    );
    for (let key in formattedData) {
      const value = formattedData[key];
      if (value === undefined || (Array.isArray(value) && !value.length)) {
        delete formattedData[key];
      }
    }
    return formattedData;
  }, [fieldsState]);
  return {
    fieldsStateFormatted,
  };
};
