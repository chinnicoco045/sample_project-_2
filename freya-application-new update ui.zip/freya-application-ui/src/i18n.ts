import i18n from "i18next";
import { initReactI18next } from "react-i18next";
import en from "./locales/en-US";
import jp from './locales/ja-JP';

const resources = {
  en: {
    translation: en,
  },
  jp: {
    translation: jp,
  }
};

const globalConfigStore = JSON.parse(
  window.localStorage.getItem("global-config-store") ?? '{}'
);
i18n.use(initReactI18next).init({
  resources,
  lng: globalConfigStore?.state?.language || "en",
  fallbackLng: "en",
  interpolation: {
    escapeValue: false,
  },
});

export default i18n;
