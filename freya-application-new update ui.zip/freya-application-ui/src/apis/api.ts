declare type Prettify<T> = {
  [K in keyof T]: T[K];
} ;

declare interface InputOptionItem {
  label: string;
  value: string | number;
}

declare type StoreKey = "formState" | "EditItem" | "extraState";

interface ParamFromState {
  // param from the form context data or edit item data or global store.
  store: string | StoreKey;
  // "all" will get all formState.
  valuePath: string | "all";
  // use value path as the key when no fieldName.
  fieldName?: string;
  // value from definition json, will not get store value by value path;
  value?: unknown;
  format?: "array" | "arrayOfString"; // force change the current field's param format;
}

type Icon = "IDMPC" | "xEVMPDC" | "IDMPO" | "xEVMPDO" | "IDMPM" | "xEVMPDM";

type TInputCommon = {
  field: string;
  labelKey?: string;
  originlabel?: string; // For multilingual fields
  label?: string;
  required?: boolean;
  readonly?: boolean;
  disabled?: boolean;
  order?: number;
  description?: string;
  placeholder?: string;
  // hide the form item in the page.
  hide?: boolean;
  // cache the field value when hide and use it when save/update.
  keepValue?: boolean;
  icon?: Icon[];
  autoCreate?: boolean;
  default?: string | number | boolean | null;
  // size
  size?: string; // small | medium;
  // grid size number.
  field_xs?: number;
  field_xl?: number;
  field_md?: number;
  field_lg?: number;
};

type TTextInput = TInputCommon & {
  type: "text";
  minLen?: number;
  maxLen?: number;
  pattern?: string;
  textArea?: boolean;
  maxRows?: number;
};

type TNumberInput = TInputCommon & {
  type: "number";
  min?: number;
  max?: number;
};

type TSelectInput = TInputCommon & {
  type: "select";
  options?: Array<InputOptionItem>;
  multiple?: boolean;
  multipleChip?: boolean; // render one chip or multiple chips. false default.
  valuePrimitive?: boolean;
  // options from the api.
  asyncConfig?: {
    url: string; // api url.
    basicUrl?: string;
    prefixEnvName?: string;
    requestMethod?: string;
    //  ?: string;
    // query params in the query path. keys from the global data?
    params?: ParamFromState[];
    // query body data if post method. keys from the global data or form state.
    body?: ParamFromState[];
    dependencies?: string[]; // field keys from the form context data.
    // response data should be list.
    labelPath: string; // label of the response list item.
    valuePath: string; // value of the response list item.
    // path to the array list of useable data.
    listDataPath?: string;
    listFilters?: Array<
      [string, unknown, "equal" | "notEqual" | "include" | "exclude"]
    >; // [[path, value], ...]
    keepQueryCache?: boolean; // whether invoke remove func when unmount the custom hook. false/undefined by default, but should be true when view mode.
    cacheTime?: number;
  };
};

type TMultiSelectInput = TInputCommon & {
  type: "multi-select";
  options?: Array<InputOptionItem>;
  multiple?: boolean;
  multipleChip?: boolean; // render one chip or multiple chips. false default.
  valuePrimitive?: boolean;
  // options from the api.
  asyncConfig?: {
    url: string; // api url.
    basicUrl?: string;
    prefixEnvName?: string;
    requestMethod?: string;
    //  ?: string;
    // query params in the query path. keys from the global data?
    params?: ParamFromState[];
    // query body data if post method. keys from the global data or form state.
    body?: ParamFromState[];
    dependencies?: string[]; // field keys from the form context data.
    // response data should be list.
    labelPath: string; // label of the response list item.
    valuePath: string; // value of the response list item.
    // path to the array list of useable data.
    listDataPath?: string;
  };
};

type TDateInput = TInputCommon & {
  type: "date";
  minDate?: string | number;
  minDateDependency?: string; // limit from related fields of form state.
  maxDate?: string | number;
  maxDateDependency?: string; // limit from related fields of form state.
};

type TChipsInput = TInputCommon & {
  type: "chips";
  max?: number;
  options?: Array<InputOptionItem>; // recommend options.
  catchInputValAsChipOnBlur?: boolean; // functionality impl as ChipsInputWithOptionsList prop catchInputValAsChipOnBlur;
};

type TRadioInput = TInputCommon & {
  type: "radio";
  options?: Array<InputOptionItem>;
  inline?: boolean;
  // options from the api.
  asyncConfig?: {
    url: string; // api url.
    basicUrl?: string;
    prefixEnvName?: string;
    requestMethod?: string;
    //  ?: string;
    // query params in the query path. keys from the global data?
    params?: ParamFromState[];
    // query body data if post method. keys from the global data or form state.
    body?: ParamFromState[];
    dependencies?: string[]; // field keys from the form context data.
    // response data should be list.
    labelPath: string; // label of the response list item.
    valuePath: string; // value of the response list item.
    // path to the array list of useable data.
    listDataPath?: string;
  };
};

type TCheckboxesInput = TInputCommon & {
  type: "checkboxGroups";
  options?: Array<InputOptionItem>;
  inline?: boolean;
  multiple?: boolean;
  // unused
  valuePrimitive?: boolean;
  // options from the api.
  asyncConfig?: {
    url: string; // api url.
    basicUrl?: string;
    prefixEnvName?: string;
    requestMethod?: string;
    //  ?: string;
    // query params in the query path. keys from the global data?
    params?: ParamFromState[];
    // query body data if post method. keys from the global data or form state.
    body?: ParamFromState[];
    dependencies?: string[]; // field keys from the form context data.
    // response data should be list.
    labelPath: string; // label of the response list item.
    valuePath: string; // value of the response list item.
    // path to the array list of useable data.
    listDataPath?: string;
  };
};

type TCheckboxInput = TInputCommon & {
  type: "checkbox";
};

type TOmitType<T> = Omit<T, "type">;

type TView = (
  | TOmitType<TTextInput>
  | TOmitType<TChipsInput>
  | TOmitType<TNumberInput>
  | TOmitType<TDateInput>
  | TOmitType<TSelectInput>
  | TOmitType<TMultiSelectInput>
  | TOmitType<TRadioInput>
  | TOmitType<TCheckboxesInput>
  | TOmitType<TCheckboxInput>
) & { type: "view" };

declare type TFormInput =
  | TTextInput
  | TChipsInput
  | TNumberInput
  | TDateInput
  | TSelectInput
  | TView
  | TMultiSelectInput
  | TRadioInput
  | TCheckboxesInput
  | TCheckboxInput;

export declare type PrettifiedTFormInput = Prettify<TFormInput>;
export interface GridColCommon {
  id: string;
  [key: string]: any;
}

export interface GridManagerFieldItem {
  id: string;
  column: string;
  type: string;
  gridAvailability: boolean;
  visibility: boolean;
  fieldName: string;
  order: number;
}

export {};