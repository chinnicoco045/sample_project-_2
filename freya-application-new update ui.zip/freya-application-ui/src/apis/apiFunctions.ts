import axios from 'axios';
import service, { GET_API, languageformat } from '../Services/apiheader';
import { accessToken } from '../types';
import { PrettifiedTFormInput } from './api';
import Cookies from 'js-cookie';
import { useTranslation } from 'react-i18next';

// Define your API endpoint here

// Function to fetch region options
export const fetchRegionOptions = async (formatType: any) => {
  console.log("Format type:", formatType);

  try {
    const payload = {
      "tenant_id": "0",
      "node_name": "CountryGroup",
      "properties": [
        "id",
        "name",
        "code",
        "concept"
      ],
      "property_filters": {
    
      },
      "rel_filters": [
    
      ],
      "rel_name_tree": "applicable",
      "rel_name_tree_node_filters": {
    
      },
      "rel_name_tree_rel_filters": {
    
      },
      "rel_name_tree_concepts": [
      "Formattype"
      ],
      "max_level": 5,
      "page": 1,
      "page_size": 6000,
      "lang":languageformat
    };

    const response = await service.post(`${GET_API}km/api/v3/concepts`, payload);
    console.log("Region Options",response.data.data.data);

    const filteredRegions = response.data.data.data.filter((region: any) =>
      region.children?.some((child: any) => "Formattype_"+child.code === formatType.code)
    );
    const regionOptions = filteredRegions.length!=0 ? filteredRegions.map((item: any) => ({
      label: item.name,
      value: "CountryGroup_"+item.code
    })) : response.data.data.data.map((item: any) => ({
      label: item.name,
      value: "CountryGroup_"+item.code
    }));

    console.log("Region Options:", regionOptions);

    return regionOptions; // Return the mapped region options
  } catch (error) {
    console.error("Error fetching region options:", error);
    return []; // Return an empty array in case of an error
  }
};




export const fetchCountryOptions = async (regionName: any) => {
    try {
        const response = await service.get(`${GET_API}cm/dropdown-list`, {
            params: {
                domain: "MPR",
                module: "applications",
                label: "Country",
                groupLabel: "CountryGroup",
                filter: regionName
            },
            // headers: {
            //     Authorization: `Bearer ${accessToken}`,
            //     'Accept-Language': ""
            // }
        });

        console.log("CountryList", response);

        // Extract country options and sort by label (name)
        const countryOptions = response.data.data.map((item: any) => ({ label: item.name, value: item.id }));
        countryOptions.sort((a:any, b:any) => a.label.localeCompare(b.label)); // Sort by country name (label)
        console.log(countryOptions);
        return countryOptions;
    } catch (error) {
        console.error("Error fetching country options:", error);
        return [];
    }
};

export const fetchEditFormJson = async (regionCode: string,t:any) => {
    try {
        const response = await service.post(`${GET_API}cm/form-manager/forms/settings`, {
            module: "applications",
            formName: "Application",
            businessRule: { region: regionCode }
        // }, {
        //     headers: {
        //         Authorization: `Bearer ${accessToken}`,
        //         'Accept-Language': ''
        //     }
        });
 
        console.log(response.data.data);
        let json=JSON.parse(response.data.data.settingsJson);
        json= json.map((item: any) => {
          const translatedLabel = t(item.field, { defaultValue: item.label });
          const translatedOriginLabel = t(item.originlabel);
      
          // Replace originlabel substring in placeholder with its translated value
          let translatedPlaceholder = t(item.placeholder || '');
          if (item.placeholder.includes(item.originlabel)) {
            translatedPlaceholder = item.placeholder.replace(item.originlabel, translatedLabel);
          }
      
          return {
            ...item,
            label: translatedLabel,
            placeholder: translatedPlaceholder,
            originlabel: translatedOriginLabel,
          }}); // Return the fetched data if needed
          return JSON.stringify(json);
    } catch (error) {
        console.error('Error fetching edit form JSON:', error);
        throw error; // Optionally handle or rethrow the error
    }
};
export interface DataResponse<T> {
    code: number;
    message: string;
    data: T;
  }

  export interface FormSettings {
    id: string;
    tenantId: string;
    settingsJson: Array<PrettifiedTFormInput>;
  }

  const config = {
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Accept-Language': '', // Optionally set other headers like Accept-Language
    },
  };

export const apiGetFormSetting = (data: {
    module: string;
    formName: string;
    businessRule?: Record<string, unknown>;
  }): Promise<DataResponse<FormSettings>> =>
  service.post(
      `${GET_API}cm/form-manager/forms/settings`,
      data,config
    );


    const config_business = {
        headers: {
          Authorization: `Bearer ${accessToken}`,
          'Accept-Language': '', // Optionally set other headers like Accept-Language
        },
      };

    export const apiGetFormBusinessRule = (params: {
        module: string;
        formName: string;
      }): Promise<DataResponse<string>> => 
       
      
    service.get(`${GET_API}cm/form-manager/form/business-fields`, {
        params:params 
        ,
    }
    );
    
 
  
  // form businessrule
 



    export const customFetchApi = (
  
        completeUrl: string,
        method = "GET",
        params?: {
          params?: unknown;
          data?: unknown;
          responseConfig?: {
            labelPath: string;
            valuePath: string;
          };
        }
      ) => {
        return () => {
        
          if (completeUrl) {
            return axios({
              method,
              url: completeUrl,
              params: params?.["params"],
              data: params?.["data"],
              headers: {
                Authorization: accessToken ? `Bearer ${accessToken}` : "",
                "Accept-Language":  "",
              },
            });
          }
        };
      };


      export const fetchDataSource = async (url: string, region : string) => {
        const urlObj = new URL(url, GET_API);
        if (urlObj.searchParams.get('label') === 'Country') {
          urlObj.searchParams.append('groupLabel', 'CountryGroup');
          urlObj.searchParams.append('filter', region);
        }
        try {
            const response = await service.get(urlObj.toString(),  {
                headers: {
                    Authorization: `Bearer ${accessToken}`,
                    'Accept-Language': ''
                }
            });
     
            console.log(response.data.data);
            const options = response.data.data.map((item: any) => ({ label: item.name, value: item.id }));
            return options; // Return the fetched data if needed
        } catch (error) {
            console.error('Error fetching edit form JSON:', error);
            throw error; // Optionally handle or rethrow the error
        }
    };

    export const fetchApplicationTypeValues = async () =>{
      const payload = {
        "tenant_id": Cookies.get("USER_TENANT_ID"),
        "node_name": "ApplicationType",
        "properties": [
          "id",
          "name",
          "code",
          "concept"
        ],
        "property_filters": {
      
        },
        "rel_filters": [
      
        ],
        "rel_name_tree": "belongs",
        "rel_name_tree_node_filters": {
      
        },
        "rel_name_tree_rel_filters": {
      
        },
        "rel_name_tree_concepts": [
        ],
        "max_level": 5,
        "page": 1,
        "page_size": 6000,
        "lang":languageformat
      }
      const response = await service.post(
        `${GET_API}km/api/v1/concepts`,payload);
        return response;
    }

    export const fetchProcedureTypeValues = async () =>{
      const payload = {
        "tenant_id": "0",
        "node_name": "ProcedureType",
        "properties": [
          "id",
          "name",
          "code",
          "concept"
        ],
        "property_filters": {

        },
        "rel_filters": [
        ],
        "rel_name_tree": "applicable",
        "rel_name_tree_node_filters": {
      
        },
        "rel_name_tree_rel_filters": {
      
        },
        "rel_name_tree_concepts": [
        ""
        ],
        "max_level": 5,
        "page": 1,
        "page_size": 6000,
        "lang":languageformat
      };
      const response = await service.post(
        `${GET_API}km/api/v3/concepts`,payload);
        return response;
    }


    export const fetchReasons = async () => {
      const response = await service.get(
        `${GET_API}cm/dropdown-list?module=product&label=ReasonForDisable`,
        {
          // headers: {
          //   Authorization: `Bearer ${accessToken}`,
          //   "Accept-Language": "",
          // },
        }
      );
      return response.data.data;
    };


    export const fetchSectionProductTree = async (productId: any) => {
      try {
          const response = await service.get(`application/v1/section-tree?productId=${productId}`, {
              headers: {
                  Authorization: `Bearer ${accessToken}`,
                  "Accept-Language": "",
                  "X-TenantID":Cookies.get('USER_TENANT_ID')
              },
          });
  
          console.log("API Response:", response.data.data);
          return response;
      } catch (error) {
          console.error("Error fetching section product tree:", error);
          throw error; // Optionally rethrow the error if you want to handle it further up the call stack
      }
  };

  export const fetchRepeatUserwaves=async()=>{
    const payload= {
      "tenant_id": "0",
      "node_name": "RepeatUseWaves",
      "properties": [
        "id",
        "name",
        "code",
        "concept"
      ],
      "property_filters": {
    
      },
      "rel_filters": [
    
      ],
      "rel_name_tree": "applicable",
      "rel_name_tree_node_filters": {
    
      },
      "rel_name_tree_rel_filters": {
    
      },
      "rel_name_tree_concepts": [
      ""
      ],
      "max_level": 5,
      "page": 1,
      "page_size": 6000,
      "lang":languageformat
    }
    const response = await service.post(
      `${GET_API}km/api/v3/concepts`,payload);
      return response.data.data.data;

  }

  export const fetchFormatTypeOptions=async()=>{
    const payload= {
      "tenant_id": "0",
      "node_name": "Formattype",
      "properties": [
        "id",
        "name",
        "code",
        "concept"
      ],
      "property_filters": {
    
      },
      "rel_filters": [
    
      ],
      "rel_name_tree": "applicable",
      "rel_name_tree_node_filters": {
    
      },
      "rel_name_tree_rel_filters": {
    
      },
      "rel_name_tree_concepts": [
      ""
      ],
      "max_level": 5,
      "page": 1,
      "page_size": 6000,
      "lang":languageformat
    }
    const response = await service.post(
      `${GET_API}km/api/v3/concepts`,payload);
      console.log(response);
      return response.data.data.data;

  }

  export const fetchCookies = async() =>{ 
    const requestbody={
      "userId": Cookies.get('USER_ID'),
      "resourceType": "",
      "app": "",
      "module": "",
      "subModule": "",
      "parentId": null
    }
    const response=await service.post(`${GET_API}common-uam/resources/specified/related-list`, requestbody); 
    return response.data.data;
  }

  export const getProductPhaseId = async (productLabel: string): Promise<string> => {
    try {
      const response = await axios.get(
        `${GET_API}product/km/dropdown-list?domain=MPR&module=product&label=ProductPhase`,{
        headers: {
          Authorization: `Bearer ${accessToken}`,
          "Accept-Language": "",
        },
      }
      );
  
      const productPhases = response.data.data;
  
      // Find the product phase by name
      const productPhase = productPhases.find((item: any) => item.name === productLabel);
  
      // Return the code if found, otherwise return an empty string
      return "ProductPhase_"+productPhase?.code;
    } catch (error) {
      console.error("Error fetching product phase ID:", error);
      throw error;
    }
  };

  export const getProductCategoryId = async (productCategoryLabel: string): Promise<string> => {
    try {
      const response = await axios.get(
        `${GET_API}product/km/dropdown-list?domain=MPR&module=product&label=ProductCategory`,{
          headers: {
            Authorization: `Bearer ${accessToken}`,
            "Accept-Language": "",
          },
        }
      );
  
      const productCategories = response.data.data;
      const productCategory = productCategories.find((item: any) => item.name === productCategoryLabel);
      return "ProductCategory_" + (productCategory?.code || "");
    } catch (error) {
      console.error("Error fetching product category ID:", error);
      throw error;
    }
  };
  
  export const getProductTypeId = async (productTypeLabel: string): Promise<string> => {
    try {
      const response = await axios.get(
        `${GET_API}product/km/dropdown-list?domain=MPR&module=product&label=ProductType`,{
          headers: {
            Authorization: `Bearer ${accessToken}`,
            "Accept-Language": "",
          },
        }
      );
      const productTypes = response.data.data;
      const productType = productTypes.find((item: any) => item.name === productTypeLabel);
      return "ProductType_" + (productType?.code || "");
    } catch (error) {
      console.error("Error fetching product type ID:", error);
      throw error;
    }
  };

  type BusinessRule = {
    when: string;
    in?: string[];
    eq?: string;
};

type FieldObject = {
    field: string;
    dependencies?: {
        show?: BusinessRule[];
    };
    [key: string]: any; // Allow other dynamic properties
};

 export const applyBusinessRules = (field: FieldObject, data: Record<string, any>): boolean => {
  if (!field.dependencies?.show) return true; // Return true if no dependencies exist

  return field.dependencies.show.every(rule => {
    let field = rule.when;
    if (field === "regionName") {
      field = "region";
    }
    if(rule.when === "countryNames"){
      field = "country";
    }
      let fieldValue = data[field];

      if (rule.in) {
          return Array.isArray(fieldValue) ? fieldValue.some(val => rule.in!.includes(val)) : rule.in.includes(fieldValue);
      }

      if (rule.eq !== undefined) {
        if(field ==="rewardGranted"||field === "subjectToArbitration"){
          fieldValue === "Yes"?fieldValue = true:fieldValue = false;
        }
          return fieldValue === rule.eq;
      }

      return fieldValue !== undefined && fieldValue !== null && fieldValue !== "";
  });
};

export const getProductFamilyId = async (productFamilyLabel: string): Promise<string> => {
  try {
    const response = await axios.get(
      `${GET_API}product/km/dropdown-list?domain=MPR&module=product&label=ProductFamily`,{
        headers: {
          Authorization: `Bearer ${accessToken}`,
          "Accept-Language": "",
        },
      }
    );
    const productTypes = response.data.data;
    const productType = productTypes.find((item: any) => item.name === productFamilyLabel);
    return (productType?.id || "");
  } catch (error) {
    console.error("Error fetching product type ID:", error);
    throw error;
  }
};
  
  

  
  
