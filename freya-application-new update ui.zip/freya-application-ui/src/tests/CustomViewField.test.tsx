import { render } from "@testing-library/react";
import CustomViewField, { fieldItem } from "../Components/Applications/components/CustomViewField";

const fields: fieldItem[] = [
  { label: "Field 1", value: "Value 1", xs: 6 },
  { label: "Field 2", value: "Value 2" }, 
  { label: "Field 3", value: "Value 3", xs: 4 },
];

describe("CustomViewField Component", () => {
  it("renders without crashing", () => {
    render(<CustomViewField fields={fields} />);
  });
});