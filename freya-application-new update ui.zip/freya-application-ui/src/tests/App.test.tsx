
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';

import App from '../App';




describe('App Component', () => {
  test('renders without crashing', () => {
    const {container}  =render(
        <App />
    );

    const loadingIndicator=container.querySelector('.loading-spinner');
    expect(loadingIndicator).toBeInTheDocument();
    
    // expect(screen.getByText('Applications')).toBeInTheDocument();
  });


});

