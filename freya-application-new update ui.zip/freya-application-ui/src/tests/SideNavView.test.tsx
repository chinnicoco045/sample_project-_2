import { act, render, screen, waitFor } from '@testing-library/react';
import { MemoryRouter, useLocation } from 'react-router-dom';
import axios from 'axios';
import { useCookies } from 'react-cookie';
import SideNavView from '../Components/Applications/SideNavView';
import '@testing-library/jest-dom/extend-expect';
import MockAdapter from 'axios-mock-adapter';
import { GET_API } from '../Services/apiheader';

// Mock necessary modules and hooks
jest.mock('react-cookie', () => ({
  useCookies: jest.fn(),
}));
jest.mock('react-i18next', () => ({
  useTranslation: () => ({ t: (key: string) => key }),
}));
jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useLocation: () => ({
    state: {
      productId: '123',
      menuname: 'Test Menu',
      url: '/test-url/${productId}'
    },
  }),
}));
jest.mock('react-i18next', () => ({
  useTranslation: () => ({
    t: (key: string) => key,
  }),
}));

jest.mock('@mui/material', () => ({
  ...jest.requireActual('@mui/material'),
  Grid: ({ children }: any) => <div>{children}</div>,
  FormControl: ({ children }: any) => <div>{children}</div>,
  Checkbox: ({ checked }: any) => <input type="checkbox" checked={checked} readOnly />,
  Typography: ({ children }: any) => <div>{children}</div>,
}));

const location = useLocation();
const { url } = location.state || {};
const mockdata_api_header = GET_API.slice(0, -1);
const fullUrl = `${mockdata_api_header}${url.replace("${productId}", "123")}`;
jest.mock('../Components/Applications/components/Loading', () => () => <div data-testid="loading">Loading...</div>);
const mockAxios = new MockAdapter(axios);

describe('SideNavView', () => {

  beforeEach(() => {
    jest.mock('react-cookie', () => ({
      useCookies: jest.fn(),
    }));
    (useCookies as jest.Mock).mockReturnValue([{
      USER_TENANT_ID: 'tenant123',
      DOMAIN: 'example.com',
      USER_PRIVILEGES: 'admin',
      ACCESS_TOKEN: 'dummy-access-token',
    }, jest.fn()]);
    mockAxios.reset();
  });

  test('renders the breadcrumb, loading component, and labels', async () => {
    const menuname = 'Test Menu';
    const mockResponse1 = {
      data: {
        dynamicFieldJson: '{"description": "Age-appropriate oral liquid dosage form","field":"field"}'
      },
    };
    const parsedHeadData = [
      {
        field: 'testField1',
        label: 'Test Field 1',
        type: 'checkbox',
        field_xs: 6,
        hide: false,
        order: 1,
        asyncConfig: {
          url: '/cm/dropdown-list?domain=MPR&module=product&label=ProductFamily',
          labelPath: 'name',
          valuePath: 'id1'
        }
      },
      {
        field: 'testField2',
        label: 'Test Field 2',
        type: 'date',
        field_xs: 6,
        hide: false,
        order: 2,
        asyncConfig: {
          url: '/cm/dropdown-list?domain=MPR&module=product&label=ProductFamily',
          labelPath: 'name1',
          valuePath: 'id1'
        }
      },
      {
        field: 'testField3',
        label: 'Test Field 2',
        type: 'defa',
        field_xs: 6,
        hide: false,
        order: 2,
        asyncConfig: {
          url: '/cm/dropdown-list?domain=MPR&module=product&label=ProductFamily',
          labelPath: 'name1',
          valuePath: 'id1'
        }
      },
      {
        field: 'testField4',
        label: 'Test Field 2',
        type: 'defa',
        field_xs: 6,
        hide: true,
        order: 2,
        asyncConfig: {
          url: '/cm/dropdown-list?domain=MPR&module=product&label=ProductFamily',
          labelPath: 'name1',
          valuePath: 'id1'
        }
      }
    ];

    const mockResponse2 = {
      data: {
        settingsJson: JSON.stringify(parsedHeadData)
      },
    };

    const mockAsyncData = {

      data: [
        { id: 'field', name: 'checkbox' },
        { id: '2', name: 'date' },
      ],

    };

    mockAxios
      .onGet(fullUrl)
      .reply(200, mockResponse1)
      .onPost(mockdata_api_header + '/cm/form-manager/forms/settings'
      )
      .reply(200, mockResponse2)
      .onGet()
      .reply(200, mockAsyncData);

    await act(async () => {
       render(<MemoryRouter>
        <SideNavView />
      </MemoryRouter>)
    });
    await waitFor(() => {
      expect(screen.getByText('application')).toBeInTheDocument();
      expect(screen.getByText(menuname)).toBeInTheDocument();
    });
  });
});

