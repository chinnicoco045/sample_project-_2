import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';

import { useTranslation } from 'react-i18next';
import { fetchCountryOptions, fetchRepeatUserwaves } from '../apis/apiFunctions';
import AddMS from '../Components/Applications/AddMS';
import service from '../Services/apiheader';

jest.mock('../apis/apiFunctions',()=>({
    fetchCountryOptions:jest.fn(),
    fetchRepeatUserwaves:jest.fn()
}));
jest.mock('react-i18next', () => ({
  useTranslation: () => ({
    t: (key:any) => key
  })
}));
jest.mock('../Services/apiheader', () => ({
    put: jest.fn(() => Promise.resolve({}))
  }));

describe('AddMS Component', () => {
  const mockMS:any=[]
  const mockData:any = [];
  const mockApplicationDetails = { applicationdata: { waveInfo: [], memberStates: [], msCountryCode: [] } };
  const mockSetTrigger = jest.fn();
  const mockSetChecked = jest.fn();
  const productName = "Mock Product";
  const countryName = "Mock country";

  beforeEach(() => {
    (fetchCountryOptions as jest.Mock).mockResolvedValue([{ label: 'Country1', value: 'C1' }]);
    (fetchRepeatUserwaves as jest.Mock).mockResolvedValue([{ name: 'Wave1', code: 'W1', id: '1' }]);
  });

  it('renders AddMS component correctly', () => {
    render(<AddMS mode={"edit"} memberState={mockMS} data={mockData} applicationDetails={mockApplicationDetails} setTrigger={mockSetTrigger} checked={false} setChecked={mockSetChecked} productName={productName} countryName={countryName} />);
    expect(screen.getByText('Member States')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'actions' })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'add_ms' })).toBeInTheDocument();
  });

  it('opens and closes the dialog when Add Member State button is clicked', async () => {
    render(<AddMS mode={"edit"} memberState={mockMS}  data={mockData} applicationDetails={mockApplicationDetails} setTrigger={mockSetTrigger} checked={false} setChecked={mockSetChecked} productName={productName} countryName={countryName} />);
    
    const addButton = screen.getByRole('button', { name: 'add_ms' });
    fireEvent.click(addButton);
    
    // Check if dialog is open
    expect(screen.getByText('addMemberStates')).toBeInTheDocument();
    
    const cancelButton = screen.getByRole('button', { name: 'cancel' });
    fireEvent.click(cancelButton);
    
    // Check if dialog is closed
    await waitFor(() => {
      expect(screen.queryByText('addMemberStates')).not.toBeInTheDocument();
    });
  });

  it('displays validation errors if required fields are empty when saving', async () => {
    render(<AddMS mode={"edit"}  memberState={mockMS}  data={mockData} applicationDetails={mockApplicationDetails} setTrigger={mockSetTrigger} checked={false} setChecked={mockSetChecked} productName={productName} countryName={countryName} />);
    
    const addButton = screen.getByRole('button', { name: 'add_ms' });
    fireEvent.click(addButton);
    
    const saveButton = screen.getByRole('button', { name: 'save' });
    fireEvent.click(saveButton);
    
    expect(await screen.findByText('Please select at least one country.')).toBeInTheDocument();
    expect(screen.getByText('Please select a wave.')).toBeInTheDocument();
  });

test('sends correct data on save click when valid', async () => {
    (fetchCountryOptions as jest.Mock).mockResolvedValue([{ label: 'Country1', value: 'C1' }]);
    (fetchRepeatUserwaves as jest.Mock).mockResolvedValue([{ name: 'Wave1', code: 'W1' }]);
  
    const setTrigger = jest.fn();
  
    render(
      <AddMS mode={"edit"} 
      memberState={mockMS}
        data={[]}
        applicationDetails={{ applicationdata: { memberStates: [], msCountryCode: [], waveInfo: [] }, application_identifier: '123', groupid: '456' }}
        setTrigger={setTrigger}
        checked={false}
        setChecked={jest.fn()}
        productName={productName} countryName={countryName}
      />
    );
  
    fireEvent.click(screen.getByText('add_ms'));
    fireEvent.focus(screen.getByRole('combobox', { name: /country/i }));
    fireEvent.keyDown(screen.getByRole('combobox', { name: /country/i }), { key: 'ArrowDown' });
    await waitFor(() => screen.getByText('Country1'));
    fireEvent.click(screen.getByText('Country1'));
  
    fireEvent.focus(screen.getByRole('combobox',{name:/Wave/i}));
    fireEvent.keyDown(screen.getByRole('combobox', { name: /Wave/i }), { key: 'ArrowDown' });
    await waitFor(() => screen.getByText('Wave1'));
    fireEvent.click(screen.getByText('Wave1'));
  
    fireEvent.change(screen.getByLabelText('comments'), { target: { value: 'Test comment' } });
  
    fireEvent.click(screen.getByText('save'));
  
    await waitFor(() => expect(service.put).toHaveBeenCalledTimes(1));
  
    expect(setTrigger).toHaveBeenCalledWith(true);
  });
});
