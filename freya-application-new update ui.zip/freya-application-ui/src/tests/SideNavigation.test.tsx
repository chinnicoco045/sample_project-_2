import React, { useTransition } from 'react';
import { render, fireEvent, screen, act } from '@testing-library/react';
import SideNavigation from '../Components/Applications/SideNavigation';
import { useCookies } from 'react-cookie';
import { useNavigate, useLocation } from 'react-router-dom';
import axios from 'axios';
import MockAdapter from 'axios-mock-adapter';

import { GET_API } from "../Services/apiheader";
import { useTranslation } from 'react-i18next';

// Mock dependencies
jest.mock('react-cookie', () => ({
  useCookies: jest.fn(),
}));
jest.mock('react-router-dom', () => ({
  useNavigate: jest.fn(),
  useLocation: jest.fn(),
}));
jest.mock('react-i18next', () => ({
  useTranslation: () => ({
    t: (key:string) => key,
  }),
}));
jest.mock('../apis/apiFunctions', () => ({
  fetchSectionProductTree: jest.fn(() => Promise.resolve({data: {data: {}}}))
}))
const mockAxios = new MockAdapter(axios);

describe('SideNavigation Component', () => {
  const mockNavigate = jest.fn();
  const mockSetOpenDrawer = jest.fn(); // Mock setOpenDrawer
  const mockCellData = JSON.stringify({
    id: 'testid',
    productId: '12345',
    applicationData: {
      productCategory: 'Product Category',
      productPhase: 'Product Phase',
      productType: 'Product type',
      applicationType: '',
      applicationName: 'Demo_app',
      applicationNumber: '',
      application_id: 'testid',
      grid: "test"
    },
  });

  let mockDatanew = {
    data: [
      {
        id: '1818537109216903169',
        name: 'Application Information',
        displayName: 'Application Information',
        menuOrder: 1,
        children: [
          {
            businessRule:[{
              "source": "form",
              "name": "Product Information",
              "field": "productCategory",
              "rule": "equals",
              "value": "ProductCategory_PDCY00004"
          },{
            "source": "form",
            "name": "Product Information",
            "field": "productCategory",
            "rule": "in",
            "value": "ProductCategory_PDCY00004"
        },{
          "source": "form",
          "name": "Product Information",
          "field": "productCategory",
          "rule": "exists",
          "value": "ProductCategory_PDCY00004"
      }
    ],
            id: '1818904733960454145',
            name: 'Application',
            displayName: 'Application',
            module: 'applications',
            menuOrder: 1,
            children: null,
          },
        ],
      },
    ],
  };

  let mockData = {
    data: [
      {
        id: '28771703',
        name: 'General',
        displayName: 'General',
        formDataUrl: '/product/products/${productId}',
        menuOrder: 1,
        businessRule:null,
        children: [
          {
            businessRule:[{
              "source": "form",
              "name": "Product Information",
              "field": "productCategory",
              "rule": "equals",
              "value": "ProductCategory_PDCY00004"
          },{
            "source": "form",
            "name": "Product Information",
            "field": "productCategory",
            "rule": "in",
            "value": "ProductCategory_PDCY00004"
        },{
          "source": "form",
          "name": "Product Information",
          "field": "productCategory",
          "rule": "exists",
          "value": "ProductCategory_PDCY00004"
      }],
            id: '1800458049014112258',
            name: 'Product Information',
            displayName: 'Product Information',
            formDataUrl: '/product/products/${productId}',
            module: 'product',
            menuOrder: 1,
            children: null,
          },
        ],
      },
    ],
  };

  beforeEach(() => {
    jest.clearAllMocks();
    sessionStorage.clear();
    (useCookies as jest.Mock).mockReturnValue([{ ACCESS_TOKEN: 'mocked-token' }]);
    (useLocation as jest.Mock).mockReturnValue({ pathname: '/mock-path' });
    (useNavigate as jest.Mock).mockReturnValue(mockNavigate);
    mockAxios.reset(); // Reset any previous mock setups
    Storage.prototype.getItem = jest.fn((key) => {
      if (key === 'CellData') return mockCellData;
      return null;
    });
    mockAxios.onGet(`${GET_API}cm/form-manager/menus/module?module=product`).reply(200, mockData);
    mockAxios.onGet(`${GET_API}cm/form-manager/menus/module?module=applications`).reply(200, mockDatanew);
    mockAxios.onGet(GET_API + 'product/products/dropdown-list').reply(200, { data: [] });
    jest.spyOn(window.sessionStorage, "getItem").mockImplementation((key) => {
      if (key === "CellData") {
        return mockCellData; // Mocked productId
      }
      return null;
    });
  
    // Mock API call
    const dynamicFieldJson = JSON.stringify({ includeDevice: true }); // Mocked API response
    mockAxios
      .onGet(`${GET_API}product/products/12345`)
      .reply(200, {
          code: 200,
          message: null,
          data: {
            dynamicFieldJson: "{\"includeDevice\":false}"
          }
      });
  });

  const renderComponent = () =>
    render(
      <SideNavigation openDrawer={false} setOpenDrawer={mockSetOpenDrawer} /> // Pass mocked props here
    );

  it('handles search input correctly', () => {
    renderComponent();

    const searchInput = screen.getByPlaceholderText('search');
    fireEvent.change(searchInput, { target: { value: 'Demo_app' } });

    expect(searchInput).toHaveValue('Demo_app');
  });

  it('clears search input when close icon is clicked', () => {
    renderComponent();
 
    const searchInput = screen.getByPlaceholderText('search');
    fireEvent.change(searchInput, { target: { value: 'Demo_app' } });

    expect(searchInput).toHaveValue('Demo_app');

    const closeButton = screen.getByTestId('CloseIcon');
    fireEvent.click(closeButton);

    expect(searchInput).toHaveValue('');
  });

  it('fetches data on mount and sets state correctly', async () => {
    await act(async () => {
      renderComponent();
    });

    expect(mockAxios.history.get.length).toBe(4);
  });

  it('navigates to /sidenavView when "Product Information" is clicked', async () => {
    await act(async () => {
      renderComponent();
    });

    fireEvent.click(screen.getByText('General'));
    fireEvent.click(screen.getByText('Product Information'));

    expect(mockNavigate).toHaveBeenCalledWith('/sidenavView', {
      state: {
        productId: '12345',
        menuname: 'Product Information',
        url: "/product/products/${productId}",
      },
    });
  });

  it('navigates to /sidenavTable when an item with gridDataUrl is clicked', async () => {
    const mockData = {
      data: [
        {
          id: '28771703',
          name: 'General',
          displayName: 'General',
          formDataUrl: '/product/products/${productId}',
          menuOrder: 1,
          children: [
            {
              id: '1800458054462513153',
              name: 'Other Names',
              displayName: 'Other Names',
              gridDataUrl:
                '/product/other-names/page?pageNum=1&pageSize=1000000&productId=${productId}',
              formDataUrl: '/product/other-names/${id}',
              module: 'product',
              menuOrder: 3,
              children: null,
            },
          ],
        },
      ],
    };

    mockAxios.onGet(`${GET_API}cm/form-manager/menus/module?module=product`).reply(200, mockData);
    mockAxios.onGet(GET_API + 'product/products/dropdown-list').reply(200, { data: [] });

    await act(async () => {
      renderComponent();
    });

    fireEvent.click(screen.getByText('General'));
    fireEvent.click(screen.getByText('Other Names'));

    expect(mockNavigate).toHaveBeenCalledWith('/sidenavTable', {
      state: {
        productId: '12345',
        label: 'Other Names',
        menuname: 'Other Names',
        url: '/product/other-names/page?pageNum=1&pageSize=1000000&productId=${productId}',
        module:'product',
        jsonurl: '/product/other-names/${id}',
      },
    });
  });
  it('updates expanded items when tree view expansion changes', async () => {
    await act(async () => {
      renderComponent();
    });
    const searchInput = screen.getByPlaceholderText('search');
    fireEvent.change(searchInput, { target: { value: 'general' } });
    const generalItem = await screen.findByText('General');
    expect(generalItem.closest('[aria-expanded="true"]')).toBeTruthy();
  });
  it('does not render the application item when business rule fails', async () => {
    const failingCellData = JSON.stringify({
      id: 'testid',
      productId: '12345',
      applicationData: {
        productCategory: 'Mismatch',
        productPhase: 'Product Phase',
        productType: 'Product type',
        applicationType: '',
        applicationName: 'Demo_app',
        applicationNumber: '',
        application_id: 'testid',
      },
    });
    jest.spyOn(window.sessionStorage, "getItem").mockImplementation((key) => {
      if (key === "CellData") return failingCellData;
      return null;
    });
    await act(async () => {
      renderComponent();
    });
    expect(screen.queryByText('Application')).toBeNull();
  });
  
  
  it('renders the Application item when business rule passes', async () => {
    const passingCellData = JSON.stringify({
      id: 'testid',
      productId: '12345',
      applicationData: {
        productCategory: 'ProductCategory_PDCY00004', 
        productPhase: 'Product Phase',
        productType: 'Product type',
        applicationType: '',
        applicationName: 'Demo_app',
        applicationNumber: '',
        application_id: 'testid',
      },
    });
    jest.spyOn(window.sessionStorage, "getItem").mockImplementation((key) => {
      if (key === "CellData") return passingCellData;
      return null;
    });
    await act(async () => {
      renderComponent();
    });
  });

  it('renders side navigation with initial state', () => {
    mockAxios
      .onGet(`${GET_API}product/products/12345`)
      .reply(200, {
          code: 200,
          message: null,
          data: {
            dynamicFieldJson: "{\"includeDevice\":true}"
          }
      });
      mockAxios.onGet(GET_API + 'product/products/dropdown-list').reply(200, { data: [{id:"12345"}] });
      mockDatanew.data[0].children[0].businessRule = [{field: "regionName", rule: "exists", value: "test", source: "form", name: "test"},
        {field: "countryNames", rule: "default", value: "test", source: "form", name: "test"},
        {field: "countryNames", rule: "default", value: "test", source: "grid", name: "test"}]
mockAxios.onGet(`${GET_API}cm/form-manager/menus/module?module=applications`).reply(200, mockDatanew);
      (useLocation as jest.Mock).mockReturnValue({ pathname: '/editApplication' });

    act(() => {renderComponent();})

    expect(screen.getByPlaceholderText('search')).toBeInTheDocument();

    mockAxios.onGet(GET_API + 'product/products/dropdown-list').reply(200, { data: [ null] });
    mockData.data[0].children[0].id = "3"
    mockAxios.onGet(`${GET_API}cm/form-manager/menus/module?module=product`).reply(200, mockData);
    (useLocation as jest.Mock).mockReturnValue({ pathname: '/editApplication' });
    act(() => {renderComponent();})

    mockData.data[0].children[0].id = "4"
    mockAxios.onGet(`${GET_API}cm/form-manager/menus/module?module=product`).reply(200, mockData);
    (useLocation as jest.Mock).mockReturnValue({ pathname: '/viewApplication' });
    act(() => {renderComponent();})
  });

  it('renders side navigation with initial state with country names', () => {
     mockDatanew.data[0].children[0].businessRule = [{field: "countryNames", rule: "default", value: "test", source: "form", name: "test"}]
     mockAxios.onGet(`${GET_API}cm/form-manager/menus/module?module=applications`).reply(200, mockDatanew);

    act(() => {renderComponent();})
  });
});
