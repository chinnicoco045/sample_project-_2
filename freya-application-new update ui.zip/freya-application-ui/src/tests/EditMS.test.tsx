import React from 'react';
import { render, screen, fireEvent, waitFor, act } from '@testing-library/react';

import { enqueueSnackbar } from 'notistack';
import { fetchCountryOptions, fetchRepeatUserwaves } from '../apis/apiFunctions';
import EditMS from '../Components/Applications/EditMS';
import { t } from 'i18next';
import { json } from 'stream/consumers';
import { useTranslation } from 'react-i18next';
import userEvent from '@testing-library/user-event';

jest.mock('../apis/apiFunctions',()=>({
    fetchCountryOptions:jest.fn(),
    fetchRepeatUserwaves:jest.fn()
}));

jest.mock('notistack', () => ({
  enqueueSnackbar: jest.fn(),
  useSnackbar: () => ({
    enqueueSnackbar: jest.fn(),
  }),
}));

//jest.mock('react-i18next', () => ({
  //useTranslation: jest.fn(() => ({t: {'EditMSSuccessTip': 'abc', edit: 'edit', 'memberstate': 'memberstate', save:'save'}}))
//}))


const mockApplicationDetails = {
  applicationdata: {
    msCountryCode: ['US', 'IN'],
    waveInfo: [
      { countryCode: 'US', waveName: 'Wave 1', waveCode: 'W1', comments: 'Initial comment' },
    ],
    memberStates: ['United States', 'India'],
  },
};

const mockInfoData = [
  { field: 'comments', type: 'select', required: true, field_xs: 12, label: 'Comments' },
];

const mockMsName = { memberState: 'United States', waveName: '', comments: '' };

describe('EditMS Component', () => {
  const mockApplicationDetails = {
    applicationdata: {
      countryNames: 'CountryA',
      memberStates: ['CountryB', 'CountryC'],
      msCountryCode: ['CODEB', 'CODEC'],
      waveInfo: [{ countryCode: 'CODEB', waveName: 'Wave1', waveCode: 'WAVE1' }],
      region: 'EU',
    },
  };

 

  const defaultProps = {
    infoData: [
      { field: 'memberState', label: 'Member State', type: 'select', required: true, order: 1, hide: false },
      { field: 'waveName', label: 'Wave Name', type: 'select', required: true, order: 2, hide: false },
      { field: 'comments', label: 'Comments', type: 'text', required: false, order: 3, hide: false },
      { field: 'comments', label: 'Comments', type: 'select', required: false, order: 3, hide: false },
    ],
    applicationDetails: mockApplicationDetails,
    msName: { memberState: 'CountryB', waveName: 'Wave1', comments: 'Comments' },
    setApplicationsDetails: jest.fn(),
    handleCancelEdit: jest.fn(),
    setMsName: jest.fn(),
    id: '123',
    setTrigger: jest.fn(),
  };

  beforeEach(() => {
    jest.clearAllMocks();
    sessionStorage.setItem('CellData',JSON.stringify({
      applicationData: {
        countryNames: 'CountryA',
        memberStates: ['CountryB', 'CountryC'],
        msCountryCode: ['CODEB', 'CODEC'],
        waveInfo: [{ countryCode: 'CODEB', waveName: 'Wave1', waveCode: 'WAVE1' }],
        region: 'EU',
      },
    }));
    sessionStorage.setItem('memberStates',JSON.stringify(['CountryB','CountryC']));

    (fetchCountryOptions as jest.Mock).mockResolvedValue([
      { label: 'CountryB', value: 'CODEB' },
      { label: 'CountryD', value: 'CODED' },
    ]);
    (fetchRepeatUserwaves as jest.Mock).mockResolvedValue([
      { name: 'Wave1', code: 'WAVE1' },
      { name: 'Wave2', code: 'WAVE2' },
      { name: 'Comments', code: 'Comments' },
      { name: 'Comments2', code: 'Comments2' },
    ]);
    //(useTranslation as jest.Mock).mockReturnValue({t: {'EditMSSuccessTip': 'abc', edit: 'edit', 'memberstate': 'memberstate', save:'save'}})
  });

  test('renders form fields correctly', async () => {
    //jest.spyOn(EditMS, 'removeUndefined')
    act(() => {
      render(<EditMS {...defaultProps} />);
    })
    await waitFor(() => expect(screen.getByText(/edit memberstate/i)).toBeInTheDocument());
   // const selectText = screen.getByText('CountryB');
    //expect(selectText).toBeVisible();
    //selectText.click();
    const ms=screen.getAllByText(/memberState/i);
    expect(ms[0]).toBeInTheDocument();
  });


test('handles required fields validation on save', async () => {
  sessionStorage.getItem("CellData");
  sessionStorage.getItem("memberStates");
    // Set msName with an empty waveName to trigger error
    const propsWithEmptyWaveName = {
      ...defaultProps,
      msName: { ...defaultProps.msName, waveName: '' }
    };

    render(<EditMS {...propsWithEmptyWaveName} />);
    // Ensure the component is fully rendered and any async operations are complete

    //await waitFor(async () => {
      //const selectText = screen.getByText('CountryB');
     // expect(selectText).toBeVisible();
      //fireEvent.click(selectText);
      //await userEvent.click(selectText);
     // const option = screen.getByText('CountryD');
      //expect(option).toBeVisible();
   // })
   await waitFor(() => expect(screen.getByText(/edit memberstate/i)).toBeInTheDocument());
    fireEvent.click(screen.getByRole('button', { name: /save/i }));
  });

  test('handles required fields validation on select change', async () => {
    sessionStorage.getItem("CellData");
    sessionStorage.getItem("memberStates");
    (fetchRepeatUserwaves as jest.Mock).mockResolvedValue([
      { name: 'Comments', code: 'Comments' },
      { name: 'Comments2', code: 'Comments2' },
    ]);
    // Set msName with an empty waveName to trigger error
    const propsWithEmptyWaveName = {
      ...defaultProps,
      msName: { ...defaultProps.msName, waveName: '', comments: '' }
    };
    //const user = userEvent.setup();

    render(<EditMS {...defaultProps} />);
    // Ensure the component is fully rendered and any async operations are complete

    await waitFor(async () => {
      const selectText = screen.getByText('Comments');
      expect(selectText).toBeVisible();
      //fireEvent.click(selectText);
      await userEvent.click(selectText);
      //await waitFor(() => expect(screen.getByText('Comments2')).toBeInTheDocument());
      const option = screen.getByText('Comments2');
      expect(option).toBeVisible();
      await userEvent.click(option);
    })
    //await waitFor(() => expect(screen.getByText(/edit memberstate/i)).toBeInTheDocument());
    //fireEvent.click(screen.getByRole('button', { name: /save/i }));
  });
  

  test('handles cancel action correctly', () => {
    render(<EditMS {...defaultProps} />);

    fireEvent.click(screen.getByRole('button', { name: /cancel/i }));
    expect(defaultProps.handleCancelEdit).toHaveBeenCalled();
  });

  test('calls setApplicationsDetails with updated memberState', async () => {
    sessionStorage.getItem("CellData");
    sessionStorage.getItem("memberStates");
    render(<EditMS {...defaultProps} />);
  
    await waitFor(() => expect(fetchCountryOptions).toHaveBeenCalledWith('EU'));
  
    const memberStateSelect = screen.getAllByLabelText(/memberState/i);
  
    fireEvent.mouseDown(memberStateSelect[0]);
    const countryOption = await screen.findByText('CountryD');
    fireEvent.click(countryOption);
  
    await waitFor(() => {
      expect(defaultProps.setApplicationsDetails).toHaveBeenCalledWith({
        applicationdata: {
          countryNames: "CountryA",
          memberStates: ["CODED", "CODEC"],
          msCountryCode: ["CODED", "CODEC"],
          region: "EU",
          waveInfo: [
            {
              countryCode: "CODED",
              countryName: "CountryD",
              waveCode: "WAVE1",
              waveName: "Wave1"
            }
          ]
        }
      });
    });
  });  

  test('handles wave name selection change', async () => {
    sessionStorage.getItem("CellData");
    sessionStorage.getItem("memberStates");
    const mockProps = {
        infoData: [{ field: 'waveName', type: 'select', required: true, label: 'Wave Name', field_xs: 6 }],
        applicationDetails: {
            applicationdata: {
                countryNames: 'Country A',
                region: 'Region 1',
                memberStates: ['Country B'],
                msCountryCode: ['B'],
                waveInfo: []
            }
        },
        msName: { waveName: 'Wave A' },
        setApplicationsDetails: jest.fn(),
        handleCancelEdit: jest.fn(),
        setMsName: jest.fn(),
        id: '123',
        setTrigger: jest.fn()
    };

    render(<EditMS {...mockProps} />);
    await waitFor(() => expect(screen.getByText('edit memberstate')).toBeInTheDocument());
    const waveNameSelect = await screen.findByRole('combobox', { name: 'waveName' });

    fireEvent.mouseDown(waveNameSelect);
    const waveNameOption = await screen.findByRole('option', { name: 'Wave2' });
    fireEvent.click(waveNameOption);


    expect(mockProps.setMsName).toHaveBeenCalled();
});

test('handleEditWaveForm updates waveInfo correctly', async () => {
 JSON.parse(sessionStorage.getItem('CellData') || '{}');
  JSON.parse(sessionStorage.getItem("memberStates")||'[]');
  render(<EditMS {...defaultProps} />);

  // Open the waveName dropdown
  const waveNameSelect = screen.getAllByRole('combobox')[1]; // Assuming waveName is the second combobox
  fireEvent.mouseDown(waveNameSelect);

  // Wait for the options to be rendered
  const waveNameOption = await screen.findByText('Wave2');
  fireEvent.click(waveNameOption);

});

it.skip('should update wave comments correctly', () => {
  const setApplicationsDetails = jest.fn();
  const setMsName = jest.fn();
  const handleCancelEdit = jest.fn();
  const setTrigger = jest.fn();

  render(
    <EditMS
      infoData={mockInfoData}
      applicationDetails={mockApplicationDetails}
      msName={mockMsName}
      setApplicationsDetails={setApplicationsDetails}
      handleCancelEdit={handleCancelEdit}
      setMsName={setMsName}
      id="1"
      setTrigger={setTrigger}
    />
  );

  const commentsInput = screen.getByLabelText(/comments/i);
  fireEvent.click(commentsInput);
  const ddValue = screen.getByText("Updated comment");
  expect(ddValue).toBeVisible();
  //fireEvent.change(commentsInput, { target: { value: 'Updated comment' } });

  expect(setApplicationsDetails).toHaveBeenCalledWith(expect.objectContaining({
    applicationdata: expect.objectContaining({
      waveInfo: expect.arrayContaining([
        expect.objectContaining({
          comments: 'Updated comment',
        }),
      ]),
    }),
  }));
});

});
