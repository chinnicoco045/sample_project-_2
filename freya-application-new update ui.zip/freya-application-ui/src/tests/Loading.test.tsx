import React from 'react';
import { render, screen, waitFor} from '@testing-library/react';
import Loading from "../Components/Applications/components/Loading";
import '@testing-library/jest-dom/extend-expect';

describe('Loading Component', () => {
  test('renders CircularProgress when open is true', async () => {
    render(<Loading open={true} />);

    // Wait for CircularProgress to be in the document
    await waitFor(() => {
      const circularProgress = screen.getByRole('progressbar', { hidden: true });
      expect(circularProgress).toBeInTheDocument();
    });
  });

  test('does not render CircularProgress when open is false', () => {
    render(<Loading open={false} />);
    const circularProgress = screen.queryByRole('progressbar');
    expect(circularProgress).not.toBeInTheDocument();
  });

  test('displays wording when provided', () => {
    const wording = 'Loading...';
    render(<Loading open={true} wording={wording} />);
    const typographyElement = screen.getByText(wording);
    expect(typographyElement).toBeInTheDocument();
  });

  test('displays children when provided', () => {
    const childText = 'Please wait...';
    render(<Loading open={true}><span>{childText}</span></Loading>);
    const childElement = screen.getByText(childText);
    expect(childElement).toBeInTheDocument();
  });

  test('displays children when both wording and children are provided', () => {
    const wording = 'Loading...';
    const childText = 'Please wait...';
    render(<Loading open={true} wording={wording}><span>{childText}</span></Loading>);
    const childElement = screen.getByText(childText);
    expect(childElement).toBeInTheDocument();
    const wordingElement = screen.queryByText(wording);
    expect(wordingElement).not.toBeInTheDocument();
  });

  test('applies correct styles to Backdrop', () => {
    render(<Loading open={true} />);
    const backdropElement = document.querySelector('.MuiBackdrop-root');
    expect(backdropElement).toHaveStyle('color: #fff');
    expect(backdropElement).toHaveStyle('z-index: 9999');
  });

  test('applies correct styles to Typography', () => {
    const wording = 'Loading...';
    render(<Loading open={true} wording={wording} />);
    const typographyElement = screen.getByText(wording);
    expect(typographyElement).toHaveStyle('margin-top: 16px'); // Adjust to actual applied margin-top
    expect(typographyElement).toHaveStyle('margin-bottom: 16px'); // Adjust to actual applied margin-bottom
    expect(typographyElement).toHaveStyle('color: white');
  });
});
