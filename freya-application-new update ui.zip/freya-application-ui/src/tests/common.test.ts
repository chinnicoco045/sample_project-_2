export const mockRowContextValues: any = {
    rows: [],
    setRows: jest.fn(),
    disabledRows: [],
    setDisabledRows: jest.fn(),
    allRows: [],
    setAllRows: jest.fn(),
    isEdited: false,
    setIsEdited: jest.fn(),
    isDisabled: false,
    setIsDisabled: jest.fn(),
    isAddPrivileged: true,
    setIsAddPrivileged: jest.fn(),
    showDisabled: false,
    setShowDisabled: jest.fn(),
     isAdded:false,
    setIsAdded:jest.fn(),
    selectedRow:{},
    setSelectedRow:jest.fn(),
    checked:{ section1: ['section1_child1_1'] },
    setChecked:jest.fn(),
    applicationIdentifier:{label:"",value:""},
    setApplicationIdentifier:jest.fn(),
    error:false,
    setError:jest.fn(),
    regionOptions:[],
    setRegionOptions:jest.fn(),
    countryOptions:[],
    setCountryOptions:jest.fn(),
    selectedCountry:[],
    setSelectedCountry:jest.fn(),
    setinactiveRows: jest.fn(),
    activeRows:[],
    isEditPrivilege:true,
    setIsEditPrivilege:jest.fn(),
    paginationobject: { page: 0, pageSize: 0 },
    setPaginationobject:jest.fn(),
    paginationTotalRecord:0,
    setPaginationTotalRecord:jest.fn(),
    gridstatus:{active:true,inactive:false,disable:false},
    setGridStatus:jest.fn()
  };

  describe('SomeComponent', () => {
    it('should use mockRowContextValues correctly', () => {
      // Your test code here
      expect(mockRowContextValues.isEdited).toBe(false);
    });
  });