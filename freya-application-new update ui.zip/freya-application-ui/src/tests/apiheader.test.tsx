import { AxiosError } from 'axios';
import MockAdapter from 'axios-mock-adapter';
import service from '../Services/apiheader';
import Cookies from 'js-cookie';

describe('API Header', () => {
  let mock: MockAdapter;

  beforeEach(() => {
    mock = new MockAdapter(service); 
    Cookies.set('ACCESS_TOKEN', 'test_token');
  });

  afterEach(() => {
    mock.restore();
    Cookies.remove('ACCESS_TOKEN');
  });

  it('should set the correct headers when a token is present', async () => {
    // Mocking the API call
    mock.onGet('/test').reply(200, {});

    try {
      // Making the service call
      const response = await service.get('/test');

      // Assertions
      expect(response.config.headers['Content-Type']).toEqual('application/json;charset=utf-8');
      expect(response.config.headers['Authorization']).toEqual('Bearer test_token');
      expect(response.config.headers['Accept-Language']).toEqual('');
    } catch (error) {
      console.log(error);
      throw error;
    }
  });

  it('should set Content-Type to application/octet-stream when responseType is arraybuffer', async () => {
    // Mocking the API call
    mock.onGet('/test').reply(200, {}, { responseType: 'arraybuffer' });

    try {
      // Making the service call
      const response = await service.get('/test', {
        responseType: 'arraybuffer',
        data: {},
      });

      // Assertions
      expect(response.config.headers['Content-Type']).toEqual('application/octet-stream;charset=utf-8');
    } catch (error) {
      console.log(error);
      throw error;
    }
  });

  it('should handle a 401 response and log a message', async () => {
    // Mocking the API call
    mock.onGet('/test').reply(401, {});

    // Spy on console.log
    const consoleSpy = jest.spyOn(console, 'log');

    try {
      // Making the service call
      await service.get('/test');
    } catch (error) {
      // Handling the error
      const axiosError = error as AxiosError;
      if (axiosError.response) {
        // Assertion for 401 error
        expect(axiosError.response.status).toEqual(401);
        // Check that console.log was called with the correct message
        expect(consoleSpy).toHaveBeenCalledWith("call the refresh token api here");
      }
    } finally {
      consoleSpy.mockRestore();
    }
  });

  it('should not set headers if token is not present', async () => {
    // Remove the token
    Cookies.remove('ACCESS_TOKEN');

    // Mocking the API call
    mock.onGet('/test').reply(200, {});

    try {
      // Making the service call
      const response = await service.get('/test');

      // Assertions
      expect(response.config.headers['Authorization']).toBeUndefined();
      expect(response.config.headers['Content-Type']).toBeUndefined();
      expect(response.config.headers['Accept-Language']).toBeUndefined();
    } catch (error) {
      console.log(error);
      throw error;
    }
  });

  it('should reject the request if an error occurs in the request interceptor', async () => {
    // Spy on console.error
    const errorSpy = jest.spyOn(console, 'error').mockImplementation(() => {});

    // Mock the interceptor to throw an error
    const error = new Error('Request Interceptor Error');
    service.interceptors.request.use(() => {
      throw error;
    });

    try {
      // Making the service call
      await service.get('/test');
    } catch (err) {
      // Assertions
      expect(err).toEqual(error);
    } finally {
      errorSpy.mockRestore();
    }
  });
});