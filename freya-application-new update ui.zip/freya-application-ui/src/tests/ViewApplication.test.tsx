import React, { useTransition } from 'react';
import { act, render, screen, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import ViewApplication from '../Components/Applications/ViewApplication';
import service from '../../src/Services/apiheader';
import { RowContext } from '../App';
import { BrowserRouter, useLocation } from 'react-router-dom';
import { mockRowContextValues } from './common.test';
import { fetchEditFormJson,fetchReasons, applyBusinessRules } from '../../src/apis/apiFunctions';
import Cookies from 'js-cookie';
import { useTranslation } from 'react-i18next';
import MockAdapter from 'axios-mock-adapter';

const mockGetResponse = {
  data: {
    applicationdata: {
      "region": "CountryGroup_CGCD0029",
      "status": "Active",
      "country": "Country_COCO0173",
      "waveInfo": [],
      "productId": "20001051",
      "disabledMS": [],
      "formatType": "Formattype_FORY000001",
      "regionName": "CountryGroup_CGCD0029",
      "eIdentifier": "",
      "productName": "the newly approved drug product, known scientifically as \"Xylomax Forte",
      "productType": "ProductType_PRTY000111",
      "countryNames": "Country_COCO0173",
      "memberStates": [],
      "producerType": "",
      "productPhase": "ProductPhase_PDPS00001",
      "applicationId": "",
      "msCountryCode": [],
      "productFamily": "ProductFamily_PTFY000001",
      "eSubIdentifier": "",
      "registrationId": "",
      "applicationName": "",
      "applicationType": "",
      "procedureNumber": "",
      "productCategory": "ProductCategory_PDCY00004",
      "applicationNumber": "",
      "countryIdentifier": "",
      "dossierIdentifier": "",
      "eCTDReceptionNumber": "",
      "recordID": "APP-2943",
      "sectionTree": {}
  },
    application_identifier: "null",
    accessidentifier: "access identifier",
    data:{applicationdata:{sectionTree:{
      section1: ["id1", "id2"],
      section2: {
        subsection1: ["id3", "id4"],
        subsection2: {
          subsubsection1: ["id5"]
        }
      },
      section3: ["id6"]
    }}}
  },
};
// Mocking dependencies
jest.mock('../Services/apiheader');
jest.mock('../../src/apis/apiFunctions', () => ({
  fetchReasons: () => ([{id: "123", name: "test"}]),
  fetchEditFormJson: jest.fn(),
  applyBusinessRules: jest.fn()
}));
// jest.mock('../Services/apiheader',()=>({get:()=>mockGetResponse}))
jest.mock('react-i18next', () => ({
  useTranslation: () => ({ t: (key: any) => key }),
}));
const mockService = new MockAdapter(service);


jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useNavigate: jest.fn(),
  useLocation:jest.fn()
}));

describe('ViewApplication Component', () => {

  beforeEach(() => {
    // (service.get as jest.Mock).mockResolvedValue(mockGetResponse)
    (service.get as jest.Mock).mockResolvedValue({
      data: {
        data: {
          groupid: 'testGroupId',
          producerType: 'Producer Type',
          procedureNumber: 123,
          applicationdata: {
            "region": "CountryGroup_CGCD0029",
            "status": "Active",
            "country": "Country_COCO0173",
            "waveInfo": [],
            "productId": "20001051",
            "disabledMS": [],
            "formatType": "Formattype_FORY000001",
            "regionName": "CountryGroup_CGCD0029",
            "eIdentifier": "",
            "productName": "the newly approved drug product, known scientifically as \"Xylomax Forte",
            "productType": "ProductType_PRTY000111",
            "countryNames": "Country_COCO0173",
            "memberStates": [],
            "producerType": "",
            "productPhase": "ProductPhase_PDPS00001",
            "applicationId": "",
            "msCountryCode": [],
            "productFamily": "ProductFamily_PTFY000001",
            "eSubIdentifier": "",
            "registrationId": "",
            "applicationName": "",
            "applicationType": "",
            "procedureNumber": "",
            "productCategory": "ProductCategory_PDCY00004",
            "applicationNumber": "",
            "countryIdentifier": "",
            "dossierIdentifier": "",
            "eCTDReceptionNumber": "",
            "recordID": "APP-2943",
            "sectionTree": {
              section1: ["id1", "id2"],
              section2: {
                subsection1: ["id3", "id4"],
                subsection2: {
                  subsubsection1: ["id5"]
                }
              },
              section3: ["id6"]
            }
        },
        },
      },
    });
    (useLocation as jest.Mock).mockResolvedValue({
      state: { editprivilege:true }, 
    });

    (fetchEditFormJson as jest.Mock).mockResolvedValue(JSON.stringify([
      { field: 'groupid', label: 'Group ID', type: 'text', order: 1, field_xs: 12 },
      { field: 'procedureNumber', label: 'Procedure Number', type: 'text', order: 2, field_xs: 12 },
      { field: 'reasonToDisable', label: 'reasonToDisable', type: 'text', order: 2, field_xs: 12 },
    ]));
    (applyBusinessRules as jest.Mock).mockReturnValue(true);

    sessionStorage.setItem('id', 'testId');
    sessionStorage.setItem(
      "CellData",
      JSON.stringify({
        applicationData: {
          procedureNumber: 1,
          groupid: "23",
          reasonToDisable: "123"
        },
      })
    );
    const id = sessionStorage.getItem('id');
    mockService
    .onGet(`application/v1/display/refresh-products/${id}`)
    .reply(200, mockGetResponse);
    
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  test('renders without crashing', async () => {
     await act(async () => {
    render(
      <BrowserRouter>
        <RowContext.Provider value={mockRowContextValues}>
          <ViewApplication />
        </RowContext.Provider>
      </BrowserRouter>
    );
  });

  
    const pageTitle = screen.getByRole('heading', { name: /view_application/i });
    const breadcrumb = screen.getByRole('navigation', { name: /breadcrumb/i });
    const editButton = screen.getByRole('button', { name: /Edit/i });

    expect(pageTitle).toBeInTheDocument();
    expect(breadcrumb).toBeInTheDocument();
    expect(editButton).toBeInTheDocument();

    await waitFor(() => expect(service.get).toHaveBeenCalledWith('application/v1/display/refresh-products/testId',{
      headers:{
        "X-TenantID":Cookies.get('USER_TENANT_ID')
      }
    }));
  });

  test('fetches and displays data correctly', async () => {
    const {t}=useTranslation();
    await act(async () => {
    render(
      <BrowserRouter>
        <RowContext.Provider value={mockRowContextValues}>
          <ViewApplication />
        </RowContext.Provider>
      </BrowserRouter>
    );
  });
    await waitFor(() => {
      // expect(screen.getByText('d').toBeInTheDocument();
     // expect(screen.getByText(t('procedureNumber'))).toBeInTheDocument();
      // expect(screen.getByText('groupId')).toBeInTheDocument();
      // expect(screen.getByText('-')).toBeInTheDocument();
    });
  });

  test('handles Edit button click', () => {
    mockRowContextValues.isEditPrivilege=false
    render(
      <RowContext.Provider value={mockRowContextValues}>
        <BrowserRouter>
          <ViewApplication />
        </BrowserRouter>
      </RowContext.Provider>
    );
     expect(screen.queryByRole(/edit/i)).not.toBeInTheDocument()
    // const editButton = screen.getByText(/edit/i);
    // expect(editButton).toBeFalsy();
  });

  test('renders checkboxes correctly', async () => {
     const mockFieldsData = [
      {
        "dependencies": {
          "show":{}
        },
          "field": "recordID",
          "label": "Record ID",
          "required": true,
          "readonly": false,
          "disabled": false,
          "description": "",
          "hide": false,
          "icon": [],
          "field_xs": 4,
          "field_xl": 4,
          "field_md": 4,
          "field_lg": 4,
          "originlabel": "Record ID",
          "id": 1904130887183696000,
          "systemDefault": true,
          "type": "checkbox",
          "maxLen": "",
          "textArea": false,
          "maxRows": 1,
          "order": 1,
          "asyncConfig": {
            "dependencies": {
              "show": [
                {
                  "when": "region",
                  "in": [
                    "region",
                  ]
                }
              ]
            }
          },
          "placeholder": "Input the Record ID"
      },
      {
          "field": "productType",
          "label": "Product Type",
          "required": true,
          "readonly": true,
          "disabled": true,
          "order": 2,
          "description": "",
          "hide": false,
          "icon": [],
          "field_xs": 4,
          "field_xl": 4,
          "field_md": 4,
          "field_lg": 4,
          "originlabel": "Product Type",
          "systemDefault": true,
          "type": "select",
          "options": [],
          "multiple": false,
          "dependencies": {
                "show": true
              },
          "asyncConfig": {
              "url": "/cm/dropdown-list?domain=MPR&module=product&label=ProductType",
              "labelPath": "name",
              "valuePath": "id",
          },
          "businessFlg": false,
          "id": 1853700770607595500,
          "placeholder": "Select the Product Type"
      },
      {
        "dependencies": {
          "show": true
        },
          "type": "checkbox",
          "field": "productName",
          "businessField": false,
          "required": true,
          "readonly": true,
          "disabled": true,
          "hide": false,
          "systemDefault": true,
          "originlabel": "Product Name",
          "label": "Product Name",
          "multiple": false,
          "options": [],
          "asyncConfig": {
              "url": "/product/products/dropdown-list",
              "labelPath": "name",
              "valuePath": "id",
              "dependencies": {
                "show": [
                  {
                    "when": "region",
                    "in": [
                      "region",
                    ]
                  }
                ]
              }
          },
          "icon": [],
          "description": "",
          "textArea": false,
          "maxRows": 1,
          "field_xs": 4,
          "field_xl": 4,
          "field_md": 4,
          "field_lg": 4,
          "gridDefault": true,
          "Visibility": true,
          "tenantId": 0,
          "order": 3,
          "businessFlg": false,
          "id": 1853700770636955600,
          "placeholder": "Input the Product Name"
      },
      {
        "dependencies": {
          "show": true
        },
          "field": "productCategory",
          "label": "Product Category",
          "required": true,
          "readonly": true,
          "disabled": true,
          "order": 4,
          "description": "",
          "hide": false,
          "icon": [],
          "field_xs": 4,
          "field_xl": 4,
          "field_md": 4,
          "field_lg": 4,
          "originlabel": "Product Category",
          "systemDefault": true,
          "type": "select",
          "options": [],
          "multiple": false,
          "asyncConfig": {
              "url": "/cm/dropdown-list?domain=MPR&module=product&label=ProductCategory",
              "labelPath": "name",
              "valuePath": "id",
              "dependencies": {
                "show": [
                  {
                    "when": "region",
                    "in": [
                      "region",
                    ]
                  }
                ]
              }
          },
          "businessFlg": false,
          "id": 1853700770662121500,
          "placeholder": "Select the Product Category"
      },
      {
        "dependencies": {
          "show": false
        },
          "field": "reasonToDisable",
          "label": "reasonToDisable",
          "required": true,
          "readonly": false,
          "disabled": false,
          "description": "",
          "hide": false,
          "icon": [],
          "field_xs": 4,
          "field_xl": 4,
          "field_md": 4,
          "field_lg": 4,
          "originlabel": "Product Family",
          "id": 1904132371807928300,
          "systemDefault": true,
          "type": "select",
          "maxLen": "",
          "textArea": false,
          "maxRows": 1,
          "order": 5,
          "asyncConfig": {
            "dependencies": {
              "show": [
                {
                  "when": "region",
                  "in": [
                    "region",
                  ]
                }
              ]
            }
          },
          "placeholder": "Select the Product Family"
      },
      {
        "dependencies": {
          "show": true
        },
          "field": "productPhase",
          "label": "Product Phase",
          "required": true,
          "readonly": true,
          "disabled": true,
          "order": 6,
          "description": "",
          "hide": false,
          "icon": [],
          "field_xs": 4,
          "field_xl": 4,
          "field_md": 4,
          "field_lg": 4,
          "originlabel": "Product Phase",
          "systemDefault": true,
          "type": "select",
          "options": [],
          "multiple": false,
          "asyncConfig": {
              "url": "/cm/dropdown-list?domain=MPR&module=product&label=ProductPhase",
              "labelPath": "name",
              "valuePath": "id",
              "dependencies": {
                "show": [
                  {
                    "when": "region",
                    "in": [
                      "region",
                    ]
                  }
                ]
              }
          },
          "businessFlg": false,
          "id": 1853700770687287300,
          "code": "productPhaseId",
          "placeholder": "Select the Product Phase"
      },
      {
        "dependencies": {
          "show": true
        },
          "type": "select",
          "field": "regionName",
          "businessField": true,
          "required": true,
          "readonly": true,
          "disabled": true,
          "hide": false,
          "systemDefault": true,
          "originlabel": "Region",
          "label": "Region",
          "multiple": false,
          "options": [],
          "asyncConfig": {
              "url": "/cm/dropdown-list?domain=MPR&module=product&label=CountryGroup",
              "labelPath": "name",
              "valuePath": "id",
              "dependencies": {
                "show": [
                  {
                    "when": "region",
                    "in": [
                      "region",
                    ]
                  }
                ]
              }
          },
          "icon": [],
          "description": "",
          "textArea": false,
          "maxRows": 1,
          "field_xs": 4,
          "field_xl": 4,
          "field_md": 4,
          "field_lg": 4,
          "gridDefault": true,
          "Visibility": true,
          "tenantId": 0,
          "order": 7,
          "businessFlg": true,
          "id": 1853700770712453000,
          "placeholder": "Select the Region"
      },
      {
        "dependencies": {
          "show": true
        },
          "type": "select",
          "field": "producerType",
          "businessField": false,
          "required": true,
          "readonly": true,
          "disabled": true,
          "hide": false,
          "systemDefault": true,
          "originlabel": "Procedure Type",
          "label": "Procedure Type",
          "multiple": false,
          "options": [],
          "asyncConfig": {
            "dependencies": {
              "show": [
                {
                  "when": "region",
                  "in": [
                    "region",
                  ]
                }
              ]
            }
          },
          "icon": [],
          "description": "",
          "textArea": false,
          "maxRows": 1,
          "field_xs": 4,
          "field_xl": 4,
          "field_md": 4,
          "field_lg": 4,
          "gridDefault": true,
          "Visibility": true,
          "tenantId": 0,
          "order": 8,
          "businessFlg": false,
          "id": 1853700770737619000,
          "placeholder": "Select the Procedure Type"
      },
      {
        "dependencies": {
          "show": true
        },
          "field": "countryNames",
          "label": "Lead Country",
          "required": true,
          "readonly": true,
          "disabled": true,
          "order": 9,
          "description": "",
          "hide": false,
          "icon": [],
          "field_xs": 4,
          "field_xl": 4,
          "field_md": 4,
          "field_lg": 4,
          "originlabel": "Lead Country",
          "systemDefault": true,
          "type": "select",
          "options": [],
          "multiple": false,
          "asyncConfig": {
              "url": "/cm/dropdown-list?domain=MPR&module=rtq&label=Country",
              "labelPath": "name",
              "valuePath": "id",
              "params": [
                  {
                      "fieldName": "groupLabel",
                      "value": "CountryGroup"
                  },
                  {
                      "store": "formState",
                      "fieldName": "filter",
                      "valuePath": "region"
                  }
              ],
              "dependencies": {
                "show": [
                  {
                    "when": "region",
                    "in": [
                      "region",
                    ]
                  }
                ]
              }
          },
          "businessFlg": false,
          "id": 1853700770771173400,
          "placeholder": "Select the Lead Country"
      },
      {
        "dependencies": {
          "show": true
        },
          "type": "select",
          "field": "memberStates",
          "businessField": false,
          "required": true,
          "readonly": true,
          "disabled": true,
          "hide": false,
          "systemDefault": true,
          "originlabel": "MS",
          "label": "MS",
          "multiple": false,
          "options": [],
          "asyncConfig": {
              "url": "/cm/dropdown-list?domain=MPR&module=rtq&label=Country",
              "labelPath": "name",
              "valuePath": "id",
              "params": [
                  {
                      "fieldName": "groupLabel",
                      "value": "CountryGroup"
                  },
                  {
                      "store": "formState",
                      "fieldName": "filter",
                      "valuePath": "region"
                  }
              ],
              "dependencies": {
                "show": [
                  {
                    "when": "region",
                    "in": [
                      "region",
                    ]
                  }
                ]
              }
          },
          "icon": [],
          "description": "",
          "textArea": false,
          "maxRows": 1,
          "field_xs": 4,
          "field_xl": 4,
          "field_md": 4,
          "field_lg": 4,
          "gridDefault": true,
          "Visibility": true,
          "tenantId": 0,
          "order": 10,
          "businessFlg": false,
          "id": 1853700770817310700,
          "placeholder": "Select the MS"
      }
      ];

    //(fetchEditFormJson as jest.Mock).mockResolvedValue(JSON.stringify(mockFieldsData));
    await act(async () => {
    render(
      <BrowserRouter>
        <RowContext.Provider value={mockRowContextValues}>
          <ViewApplication />
        </RowContext.Provider>
      </BrowserRouter>
    );
  });

    await waitFor(() => {
      // Use getByLabelText to find the checkbox by its label
      //const checkbox = screen.getByLabelText(/inactiveFlg/i);
      //expect(checkbox).toBeInTheDocument();
      // expect(checkbox).toBeDisabled();
    });
  });

  test('renders checkboxes correctly11', async () => {
    const mockFieldsData =  [{
      "field": ["recordID"],
      "label": "Record ID",
      "required": true,
      "readonly": false,
      "disabled": false,
      "description": "",
      "hide": false,
      "icon": [],
      "field_xs": 4,
      "field_xl": 4,
      "field_md": 4,
      "field_lg": 4,
      "originlabel": "Record ID",
      "id": 1904130887183696000,
      "systemDefault": true,
      "type": "checkbox",
      "maxLen": "",
      "textArea": false,
      "maxRows": 1,
      "order": 1,
      "asyncConfig": {},
      "placeholder": "Input the Record ID"
    }
    ];

   //(fetchEditFormJson as jest.Mock).mockResolvedValue(JSON.stringify(mockFieldsData));
   await act(async () => {
   render(
     <BrowserRouter>
       <RowContext.Provider value={mockRowContextValues}>
         <ViewApplication />
       </RowContext.Provider>
     </BrowserRouter>
   );
 });

   await waitFor(() => {
     // Use getByLabelText to find the checkbox by its label
     //const checkbox = screen.getByLabelText(/inactiveFlg/i);
     //expect(checkbox).toBeInTheDocument();
     // expect(checkbox).toBeDisabled();
   });
 });

 test('getAllIds function extracts all IDs from sectionTree', () => {
  const sectionTree = {
    section1: ["id1", "id2"],
    section2: {
      subsection1: ["id3", "id4"],
      subsection2: {
        subsubsection1: ["id5"]
      }
    },
    section3: ["id6"]
  };

  const expectedIds = ["id1", "id2", "id3", "id4", "id5", "id6"];

  const mockFunctions = jest.fn();
  // const mockComponent = ReactTest

  // expect(getAllIds(sectionTree)).toEqual(expectedIds);
});
});
