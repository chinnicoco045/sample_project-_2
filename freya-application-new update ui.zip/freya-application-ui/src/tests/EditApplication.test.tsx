import { render, screen, waitFor, act, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom';
import EditApplication from "../Components/Applications/EditApplication";
import { MemoryRouter, useNavigate } from 'react-router-dom';
import { RowContext } from '../App';
import service from '../Services/apiheader';
import MockAdapter from 'axios-mock-adapter';
import { fetchEditFormJson,applyBusinessRules } from '../apis/apiFunctions';
import { GET_API } from '../Services/apiheader';
import userEvent from '@testing-library/user-event';
import { BrowserRouter as Router } from 'react-router-dom';
import { fetchApplicationTypeValues } from '../apis/apiFunctions';
// Mock modules
jest.mock('react-i18next', () => ({
  useTranslation: () => ({ t: (key: string) => key }),
}));
jest.mock('../apis/apiFunctions');
jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useNavigate: jest.fn(),
}));

// Mock RowContext
const mockSetIsEdited = jest.fn();
const mockSetRows = jest.fn();
const mockRows: any = [
  { id: 'row1', data: 'Row 1' },
  { id: 'row2', data: 'Row 2' }
];
const mockContextValue: any = {
  isEdited: false,
  setIsEdited: mockSetIsEdited,
  rows: mockRows,
  setRows: mockSetRows,
};

// Mock responses
const mockGetResponse = {
  data: {
    applicationdata: {
      sectionTree: {
        section1: ['id1', 'id2'],
        section2: { subsection1: ['id3', 'id4'] },
      },
      productType: ['1', '2'],
      applicationId: "testid",
      applicationName: "Demo_app",
      applicationNumber: "",
      applicationType: "",
      productCategory: "Product category",
      country: "country",
      Productid: "productid",
      region: "region",
      regionName: "regionname",
    },
    application_identifier: "null",
    accessidentifier: "access identifier",
  },
};

const mockGetResponsei = {
  data: {
    applicationdata: {
      sectionTree: {
        section1: ['id1', 'id2'],
        section2: { subsection1: ['id3', 'id4'] },
      },
      productType: ['1', '2'],
      applicationId: "testid",
      applicationName: "Demo_app",
      applicationNumber: "",
      applicationType: "",
      productCategory: "Product category",
      country: "country",
      Productid: "productid",
      region: "region",
      regionName: "regionname",
      inactiveFlg: true
    },
    application_identifier: "null",
    accessidentifier: "access identifier",
  },
};

const parsedHeadData = [
  {
    type: "select",
    field: "productType",
    label: "Product Type1",
    required: true,
    readonly: true,
    disabled: false,
    order: 1,
    hide: false,
    icon: ["IDMPC","xEVMPDC","IDMPO","xEVMPDO","IDMPM","xEVMPDM","abc"],
    field_xs: 1,
    field_xl: 1,
    fiels_md: 1,
    field_lg: 1,
    originlabel: "Product Type1",
    systemDefault: true,
    Placeholder: "Select the Product Type1",
    asyncConfig : {url:"url1"},
    options: [{ value: 'option11', label: 'Option 11' }],
    conditional:{show:true},
    multiple:false,
    "dependencies": {
    "show": [
      {
        "when": "region",
        "in": [
          "region",
        ]
      }
    ]
  }
  },
  {
    "type": "select",
    "field": "applicationType",
    "businessField": false,
    "required": false,
    "readonly": false,
    "disabled": false,
    "hide": false,
    "systemDefault": true,
    "originlabel": "Application Type",
    "label": "Application Type",
    "multiple": false,
    "options": [
        {
            "label": "Orphan Drug Application",
            "value": "Orphan Drug Application"
        },
        {
            "label": "Master-file",
            "value": "Master-file"
        },
        {
            "label": "New Drug Application (NDA)",
            "value": "New Drug Application (NDA)"
        },
        {
            "label": "Abbreviated New Drug Application (ANDA)",
            "value": "Abbreviated New Drug Application (ANDA)"
        },
        {
            "label": "Biologic License Application (BLA)",
            "value": "Biologic License Application (BLA)"
        },
        {
            "label": "Investigational New Drug (IND)",
            "value": "Investigational New Drug (IND)"
        },
        {
            "label": "Drug Master File (DMF)",
            "value": "Drug Master File (DMF)"
        },
        {
            "label": "Emergency Use Authorization (EUA)",
            "value": "Emergency Use Authorization (EUA)"
        },
        {
            "label": "Investigational Device Exemption (IDE)",
            "value": "Investigational Device Exemption (IDE)"
        },
        {
            "label": "Safety Issue (FDA Use Only)",
            "value": "Safety Issue (FDA Use Only)"
        },
        {
            "label": "Premarket Approval Application (PMA)",
            "value": "Premarket Approval Application (PMA)"
        },
        {
            "label": "Premarket Notification 510k (510K)",
            "value": "Premarket Notification 510k (510K)"
        }
    ],
    "asyncConfig": {
        "url": "",
        "labelPath": "name",
        "valuePath": "id"
    },
    "icon": [],
    "description": "",
    "textArea": false,
    "maxRows": 1,
    "field_xs": 4,
    "field_xl": 4,
    "field_md": 4,
    "field_lg": 4,
    "gridDefault": false,
    "Visibility": true,
    "tenantId": 0,
    "order": 15,
    "businessFlg": false,
    "id": 1816379804354429000,
    "placeholder": "Select the Application Type",
    "dependencies": {
    "show": [
      {
        "when": "region",
        "in": [
          "region",
        ]
      }
    ]
  }
},
  {
    type: "text",
    field: "productType",
    label: "Product Type1",
    required: true,
    readonly: true,
    disabled: false,
    order: 1,
    hide: false,
    icon: [],
    field_xs: 1,
    field_xl: 1,
    fiels_md: 1,
    field_lg: 1,
    originlabel: "Product Type1",
    systemDefault: true,
    Placeholder: "Select the Product Type1 ",
    asyncConfig : {url:"url2"},
    options: [{ value: 'option11', label: 'Option 11' }],
    conditional:{show:true},
    show:false,
    "dependencies": {
    "show": [
      {
        "when": "region",
        "in": [
          "region",
        ]
      }
    ]
  }
  },
  {
    type: "checkbox",
    field: "applicationId",
    label: "Product Type1",
    required: true,
    readonly: true,
    disabled: true,
    order: 1,
    hide: false,
    icon: ["xEVMPDC","IDMPO","xEVMPDO","IDMPM","xEVMPDM"],
    field_xs: 1,
    field_xl: 1,
    fiels_md: 1,
    field_lg: 1,
    originlabel: "Product Type1",
    systemDefault: true,
    Placeholder: "Select the Product Type1 ",
    asyncConfig : {url:"url3"},
    options: [{ value: 'option11', label: 'Option 11' }],
    conditional:{show:true},
    "dependencies": {
    "show": [
      {
        "when": "region",
        "in": [
          "region",
        ]
      }
    ]
  }
  },
  {
    type: "radio",
    field: "productType",
    label: "Product Phase4",
    required: true,
    readonly: true,
    disabled: true,
    order: 4,
    hide: false,
    icon: ["xEVMPDC","IDMPO","xEVMPDO","IDMPM","xEVMPDM"],
    field_xs: 4,
    field_xl: 4,
    fiels_md: 4,
    field_lg: 4,
    originlabel: "Product Phase4",
    systemDefault: true,
    Placeholder: "Select the Product Phase 4",
    options: [{ value: 'option4', label: 'Option 14' }],
    asyncConfig : {url:"url4"},
    show:false,
    "dependencies": {
    "show": [
      {
        "when": "region",
        "in": [
          "region",
        ]
      }
    ]
  }
  },
  {
    type: "date",
    field: "productType",
    label: "Product Phase4",
    required: true,
    readonly: true,
    disabled: true,
    order: 4,
    hide: false,
    icon: ["xEVMPDC","IDMPO","xEVMPDO","IDMPM","xEVMPDM"],
    field_xs: 4,
    field_xl: 4,
    fiels_md: 4,
    field_lg: 4,
    originlabel: "Product Phase4",
    systemDefault: true,
    Placeholder: "Select the Product Phase 4",
    options: [{ value: 'option4', label: 'Option 14' }],
    asyncConfig : {url:"url4"},
    show:false,
    "dependencies": {
    "show": [
      {
        "when": "region",
        "in": [
          "region",
        ]
      }
    ]
  }
  },
  {
    type: "default",
    field: "productType",
    label: "Product Phase4",
    required: true,
    readonly: true,
    disabled: true,
    order: 4,
    hide: false,
    icon: ["xEVMPDC","IDMPO","xEVMPDO","IDMPM","xEVMPDM"],
    field_xs: 4,
    field_xl: 4,
    fiels_md: 4,
    field_lg: 4,
    originlabel: "Product Phase4",
    systemDefault: true,
    Placeholder: "Select the Product Phase 4",
    options: [{ value: 'option4', label: 'Option 14' }],
    asyncConfig : {url:"url4"},
    "dependencies": {
    "show": [
      {
        "when": "region",
        "in": [
          "region",
        ]
      }
    ]
  }
  }
];

const mockPostResponse = {
  data: {
    id: "fakeid",
    tenantId: 0,
    settingsJson: JSON.stringify(parsedHeadData)
  },
};

const mockPutResponse = {
  applicationdata:{
    application_identifier: "_kuwait",
    id: "84",
    application_id: "appid",
    productName: "test",
    regionCode: "CountryGroup_CGCD0009",
    procedureType: "National",
  }
}

// Set up axios mock adapter
const mockService = new MockAdapter(service);
const mockdata_api_header = 'https://mockapi';

const renderComponent = () => {
  render(
    <MemoryRouter>
      <RowContext.Provider value={mockContextValue}>
        <EditApplication />
      </RowContext.Provider>
    </MemoryRouter>
  );
};

describe('EditApplication Component', () => {
  let navigate: jest.Mock;

  beforeEach(() => {
    jest.clearAllMocks();

    // Set up sessionStorage
    sessionStorage.setItem('id', 'testid');
    sessionStorage.setItem('CellData', JSON.stringify({
      id: 'testid',
      applicationData: {
        productCategory: 'Product Category',
        productPhase: 'Product Phase',
        productType: 'Product type',
        applicationType: '',
        applicationName: 'Demo_app',
        applicationNumber: '',
        application_id: 'testid'
      }
    }));

    const maockdatakm = {
      data:{data:[{
        "name": "New Chemical Entity",
        "id": 894817,
        "code": "ALTP00001",
        "status": 0,
        "children": [
            {
                "name": "Australia",
                "id": 895581,
                "code": "COCO0014",
                "status": 0
            }
        ]
    }]
    }}

    // Mocking API responses
    mockService.resetHandlers();
    const id = sessionStorage.getItem('id'); // Retrieve id from sessionStorage
    mockService
      .onGet(`application/v1/display/refresh-products/${id}`)
      .reply(200, mockGetResponse);
    mockService
      .onPost(`${mockdata_api_header}/syslib/form-manager/forms/settings`)
      .reply(200, mockPostResponse);
      mockService
      .onPost(`${GET_API}km/api/v1/concepts`)
      .reply(200, maockdatakm);
    mockService
      .onPut(`application/v1/modification/${id}`)
      .reply(200, mockPutResponse);

    // Mock the fetchEditFormJson function
    (fetchEditFormJson as jest.Mock).mockResolvedValue(JSON.stringify(parsedHeadData));
    jest.mock("../apis/apiFunctions", () => ({
        applyBusinessRules: jest.fn(),
      }));
    (applyBusinessRules as jest.Mock).mockReturnValue(true);

    // Mock navigate
    navigate = jest.fn();
    (useNavigate as jest.Mock).mockImplementation(() => navigate);
  });

  test('renders the component and form fields', async () => {
    await act(async () => {
      renderComponent();
    });

    await waitFor(() => {
      expect(screen.getByTestId('breadcrumb-edit-app')).toBeInTheDocument();
    });

    fireEvent.click(screen.getByText('save'));
    expect(screen.getByText('noDataUpdatedMessage')).toBeInTheDocument();

    
  });
 
  test('handles form submission', async () => {
    renderComponent();
    await waitFor(() => {
      expect(screen.getByTestId('breadcrumb-edit-app')).toBeInTheDocument();
    });
        const saveButton = await screen.findByText(/save/i);
        fireEvent.click(saveButton);
        await waitFor(() => expect(mockSetIsEdited).toHaveBeenCalledWith(true));
        await waitFor(() => expect(navigate).toHaveBeenCalledWith(-1));

  });

  test('tests inactive', async () => {
    const id = sessionStorage.getItem('id');
    mockService
    .onGet(`application/v1/display/refresh-products/${id}`)
    .reply(200, mockGetResponsei);
    await act(async () => {
      renderComponent();
    });
  
    await waitFor(() => {
      expect(screen.getByTestId('breadcrumb-edit-app')).toBeInTheDocument();
    });

    fireEvent.click(screen.getByText('save'));
  });
  test('cancel button',async () => {
      await act(async () => {
      render(
        <Router>
          <RowContext.Provider value={mockContextValue}>
            <EditApplication />
          </RowContext.Provider>
        </Router>
      );
    });
      fireEvent.click(screen.getByText('cancel'));

    });
  //Test handle Field Change
  test('updates text field value when changed using fireEvent.change with data-testid', async () => {
    const testData = JSON.parse(JSON.stringify(parsedHeadData));
    testData[2].readonly = false;
    (fetchEditFormJson as jest.Mock).mockResolvedValue(JSON.stringify(testData));
    await act(async () => {
      render(
        <MemoryRouter>
          <RowContext.Provider value={mockContextValue}>
            <EditApplication />
          </RowContext.Provider>
        </MemoryRouter>
      );
    });

    const textField = await screen.findByTestId("content-input") as HTMLInputElement;

    fireEvent.change(textField, { target: { value: 'New' } });

    expect(textField.value).toBe('New');
  });
  test('up1dates checkbox value when changed using fireEvent.change with data-testid', async () => {
    const testData = JSON.parse(JSON.stringify(parsedHeadData));
    testData[3].readonly = false;

    (fetchEditFormJson as jest.Mock).mockResolvedValue(JSON.stringify(testData));

    await act(async () => {
      render(
        <MemoryRouter>
          <RowContext.Provider value={mockContextValue}>
            <EditApplication />
          </RowContext.Provider>
        </MemoryRouter>
      );
    });

    const checkbox = await screen.findByTestId("checkbox-input") as HTMLInputElement;

    fireEvent.click(checkbox);
    expect(checkbox.checked).toBe(true);
  });
  test('Click radio button', async () => {
    const testData = JSON.parse(JSON.stringify(parsedHeadData));
    testData[4].readonly = false;
    (fetchEditFormJson as jest.Mock).mockResolvedValue(JSON.stringify(testData));
    await act(async () => {
        render(
            <MemoryRouter>
                <RowContext.Provider value={mockContextValue}>
                    <EditApplication />
                </RowContext.Provider>
            </MemoryRouter>
        );
    });
    const radioButton = await screen.findByTestId("radio-input") as HTMLInputElement;
    fireEvent.click(radioButton);
});
test('submits form with inactiveFlg true sets status to "Inactive"', async () => {
  const cellData = {
    id: 'testid',
    applicationData: {
      productCategory: "Category",
      productPhase: "Phase",
      productType: "Type",
      applicationType: "AppType",
      applicationName: "Demo_app",
      applicationNumber: "123",
      inactiveFlg: true,
      reasonForInactive: "Some reason"
    },
    application_identifier: "app123",
    created_by: "creator@example.com"
  };
  sessionStorage.setItem('CellData', JSON.stringify(cellData));

  const mockPut = jest.spyOn(service, 'put').mockResolvedValue({ data: { id: '123' } });

  (fetchEditFormJson as jest.Mock).mockResolvedValue(JSON.stringify(parsedHeadData));

  await act(async () => {
    render(
      <MemoryRouter>
        <RowContext.Provider value={mockContextValue}>
          <EditApplication />
        </RowContext.Provider>
      </MemoryRouter>
    );
  });

  const textField = await screen.findByTestId("content-input") as HTMLInputElement;
  fireEvent.change(textField, { target: { value: "New Value" } });

  const saveButton = await screen.findByText(/save/i);
  fireEvent.click(saveButton);

  await waitFor(() => expect(mockPut).toHaveBeenCalled());

  mockPut.mockRestore();
});
test('covers branch when applicationType matches country code in ApptypeOptions', async () => {
  const testData = JSON.parse(JSON.stringify(parsedHeadData));
  testData[1].readonly = false; 
  const updatedRecordDetails = {
    ...mockContextValue.recordDetails,
    country: "Country_ABC"
  };
  const mockAppTypeOptions = [
    {
      name: "Test AppType",
      code: "X",
      children: [{ code: "ABC" }] 
    }
  ];
  (fetchApplicationTypeValues as jest.Mock).mockResolvedValue({
    data: { data: mockAppTypeOptions }
  });
  const updatedMockContext = { ...mockContextValue, recordDetails: updatedRecordDetails };
  (fetchEditFormJson as jest.Mock).mockResolvedValue(JSON.stringify(testData));
  await act(async () => {
    render(
      <MemoryRouter>
        <RowContext.Provider value={updatedMockContext}>
          <EditApplication />
        </RowContext.Provider>
      </MemoryRouter>
    );
  });
  const selectField = await screen.findByLabelText(/Application Type/i);
  expect(selectField).toBeInTheDocument();
  fireEvent.mouseDown(selectField);

});
  
});