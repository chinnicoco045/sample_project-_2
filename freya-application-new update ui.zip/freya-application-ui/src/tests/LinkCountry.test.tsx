import React, { useEffect } from 'react';
import { render, waitFor, screen, fireEvent, renderHook } from '@testing-library/react';

import { Controller } from 'react-hook-form';
import { act } from 'react-dom/test-utils';
import '@testing-library/jest-dom/extend-expect';
import { RowContext } from '../../src/App';
import LinkCountry from '../Components/Applications/wizard/LinkCountry';
import axios from 'axios';
import MockAdapter from 'axios-mock-adapter';
import { GET_API } from '../Services/apiheader';
import { mockRowContextValues } from './common.test';
import service from '../Services/apiheader';
import { fetchApplicationTypeValues, fetchCountryOptions, fetchFormatTypeOptions, fetchProcedureTypeValues, fetchRegionOptions } from '../apis/apiFunctions';

mockRowContextValues.checked = { section1: ['section1_child1_1'] };
mockRowContextValues.selectedCountry = ["Switzerland", "United States of America", "South Africa", "China"];
jest.mock('react-i18next', () => ({
    useTranslation: () => ({ t: (key: string) => key }),
}));
jest.mock("../apis/apiFunctions", () => ({
  fetchFormatTypeOptions: jest.fn(),
  fetchApplicationTypeValues: jest.fn(),
  fetchProcedureTypeValues: jest.fn(),
  fetchCountryOptions: jest.fn(),
  fetchRegionOptions: jest.fn(),
}));

jest.mock('@mui/material', () => ({
    ...jest.requireActual('@mui/material'),
    Grid: ({ children }: any) => <div>{children}</div>,
    FormControl: ({ children }: any) => <div>{children}</div>,
    Checkbox: ({ checked }: any) => <input type="checkbox" checked={checked} readOnly />,
    Typography: ({ children }: any) => <div>{children}</div>,
}));
const FormTypes:any ={
    formState: {
        errors: {
          name: { message: 'Name is required' },
          email: { message: 'Email is required' }
        }
      },
      watch: (field:any) => {
        if (field === 'region') return {label:"viji",value:"CountryGroup_CGCD0006"};
      },
      setValue:jest.fn(),
      clearErrors:jest.fn()
  }

const mockAxios = new MockAdapter(axios);

const mockResponse = {
    data: [
        {
            id: "20000092",
            name: "SINGULAIR 10-mg Film-Coated Tablets"
        },
        {
            id: "200000926",
            name: "SINGULAIR 10-mg Film-Coated Tssadasdablets"
        }
    ]
};
const mockresponse2 = 
       [ {
            id: "20000092",
            name: "ASEAN"
        },
        {
            id: "200000926",
            name: "Caribbean"
        }]
;
const maockdatakm = {
    data:[{
      "name": "New Chemical Entity",
      "id": 894817,
      "code": "ALTP00001",
      "status": 0,
      "children": [
          {
              "name": "Australia",
              "id": 895581,
              "code": "COCO0014",
              "status": 0
          }
      ]
  }]
  }

  const mockproceduretypedata = {
    data:[
        {
            "name": "Centralised Procedure",
            "id": 3585,
            "code": "PCT00003",
            "status": 0
        },
        {
            "name": "Decentralised Procedure",
            "id": 3586,
            "code": "PCT00004",
            "status": 0
        },
        {
            "name": "Mutual Recognition Procedure",
            "id": 3587,
            "code": "PCT00005",
            "status": 0
        },
        {
            "name": "National Procedure",
            "id": 3588,
            "code": "PCT00006",
            "status": 0
        },
        {
            "name": "GCC procedure",
            "id": 3589,
            "code": "PCT00013",
            "status": 0
        },
        {
            "name": "Jordan Procedure",
            "id": 3590,
            "code": "PCT00014",
            "status": 0
        },
        {
            "name": "Company Registration / Tender",
            "id": 3591,
            "code": "PCT00015",
            "status": 0
        }
    ]
  }
const mockService = new MockAdapter(service);

jest.mock('react-hook-form', () => ({
    useForm: jest.fn(),
    Controller: jest.fn(),
  }));

describe('LinkCountry', () => {
  let setprocedureTypeoptions: jest.Mock;
  let kmprocedureTypeoptions: any[];

    beforeEach(async() => {
      setprocedureTypeoptions = jest.fn();
    kmprocedureTypeoptions = [
      { code: 'ProcedureType_PCT00003', label: 'Centralised Procedure' },
      { code: 'ProcedureType_PCT00004', label: 'Decentralised Procedure' },
      { code: 'ProcedureType_PCT00005', label: 'Mutual Recognition Procedure' },
      { code: 'ProcedureType_PCT00006', label: 'National Procedure' },
      { code: 'ProcedureType_PCT00013', label: 'GCC Procedure' },
      { code: 'ProcedureType_PCT00014', label: 'Jordan Procedure' },
      { code: 'ProcedureType_PCT00015', label: 'Company Registration / Tender' },
    ];
        (Controller as jest.Mock).mockImplementation(({ control, rules, render }) => {
            const field = {
              onChange: jest.fn(),
              onBlur: jest.fn(),
              name: 'msCountry', // Mock name for the field
              ref: null,
              label:"test",value:[{label:'label1',value:'value1'},{label:'label2',value:'value2'}],
              getOptionLabel:jest.fn(),
              getOptionDisabled:jest.fn(),
              isOptionEqualToValue:jest.fn(),
              renderInput:jest.fn(),
            };
            return render({ field });
          });
          
          mockAxios.onGet(`${GET_API}product/products/dropdown-list`)
                   .reply(200, mockResponse).onGet().reply(200, mockresponse2);
                   mockService
                   .onPost(`${GET_API}km/api/v1/concepts`)
                   .reply(200, {data:{data:maockdatakm}});
                   mockService.onPost(`${GET_API}km/api/v1/concepts`)
                   .reply(200, {mockproceduretypedata});

                   jest.mock("../apis/apiFunctions", () => ({
                    fetchApplicationTypeValues: jest.fn(() =>
                      Promise.resolve({
                        data: {
                          data: [
                            { label: "Type 1", value: "type1" },
                            { label: "Type 2", value: "type2" },
                          ],
                        },
                      })
                    ),
                  }));
                  
                  (fetchApplicationTypeValues as jest.Mock).mockResolvedValueOnce({
                    data: {
                      data: [
                        {
                          name: "Plasma Master File",
                          id: 536,
                          code: "ALTP00043",
                          children: [
                            { name: "Afghanistan", id: 1245, code: "COCO0001" },
                            { name: "Åland Islands", id: 1246, code: "COCO0002" },
                          ],
                        },
                        {
                          name: "Investigational New Drug (IND)",
                          id: 106072,
                          code: "ALTP00090",
                          children: [
                            { name: "United States of America", id: 1475, code: "COCO0232" },
                          ],
                        },
                      ],    
                    },
                  });
             await act(async()=>{
                (fetchRegionOptions as jest.Mock).mockResolvedValueOnce(mockresponse2);
                (fetchProcedureTypeValues as jest.Mock).mockResolvedValueOnce({
                    data: {
                      data: {
                        data: [ // Ensure this is an array
                          { name: "Centralised Procedure", id: 3585, code: "PCT00003" },
                          { name: "National Procedure", id: 3588, code: "PCT00006" },
                        ],
                      },
                    },
                  });
                  
                (fetchFormatTypeOptions as jest.Mock).mockResolvedValueOnce( [
                   {
                       "name": "ACTD",
                       "id": 1613,
                       "code": "FORY000001"
                   },
                   {
                       "name": "NeES",
                       "id": 1614,
                       "code": "FORY000002"
                   }])
           });
           (fetchApplicationTypeValues as jest.Mock).mockResolvedValueOnce({data:{data:[ {
               "name": "Plasma Master File",
               "id": 536,
               "code": "ALTP00043",
               "children": [
                   {
                       "name": "Afghanistan",
                       "id": 1245,
                       "code": "COCO0001"
                   },
                   {
                       "name": "Åland Islands",
                       "id": 1246,
                       "code": "COCO0002"
                   }]},{
                       "name": "Investigational New Drug (IND)",
                       "id": 106072,
                       "code": "ALTP00090",
                       "children": [
                           {
                               "name": "United States of America",
                               "id": 1475,
                               "code": "COCO0232"
                           }
                       ]
                   }]}})
             }) 
             
 
    const renderfunction =async () =>{
        try{
        await act(async () => {
            render(
                <RowContext.Provider value={mockRowContextValues}>
                    <LinkCountry productId="product id=100" multiProduct={false} productNames={[]} formMethods={FormTypes} />
                </RowContext.Provider>
            );
        });
    }
    catch(e){
      console.error(e);
    }
    }
    
    it('isShowLmsAndMs',  async() => {
       
        FormTypes.watch = (field:any) => {
            if(field=='formatType') return {label:"eCTD", value:'Formattype_FORY000003'};
            if (field === 'region') return {label:"Gulf Cooperation Council (GCC)",value:"CountryGroup_CGCD0009"};
            if(field == 'procedureType') return {label:"GCC procedure",code:"ProcedureType_PCT00013"};
          };
          renderfunction();
    });
    it('isRegistrationId',  async() => {
       
        
        FormTypes.watch = (field:any) => {
            if(field=='formatType') return {label:"eCTD", value:'Formattype_FORY000003'};
            if (field === 'region') return {label:"Eurasian Economic Union (EAEU)",value:"CountryGroup_CGCD0016"};
          };
          renderfunction();
          await waitFor(() => {
            const input = screen.getByPlaceholderText('registrationId'); 
            fireEvent.blur(input, { target: { value: 'newValue' } }); 
            fireEvent.change(input);
        });
    });
    it('isShowApplicationId', async () => {
       
        FormTypes.watch = (field:any) => {
            if(field=='formatType') return {label:"eCTD", value:'Formattype_FORY000003'};
            if (field === 'region') return {label:"China",value:"CountryGroup_CGCD0006"};
          };
          renderfunction();
    });
    it('!(isShowLmsAndMs || isShowRmsAndCms) && !isCountrySameWithRegion',async  () => {
       
        FormTypes.watch = (field:any) => {
            if(field=='formatType') return {label:"eCTD", value:'Formattype_FORY000003'};
            if (field === 'region') return {label:"EU / EEA",value:"CountryGroup_CGCD0006"};
            if(field == 'procedureType') return {label:"Decentralised Procedure",code:"ProcedureType_PCT00004"};
          };
          renderfunction();
    });
    it('isShowRmsAndCms',async  () => {
       
        FormTypes.watch = (field:any) => {
            if(field=='formatType') return {label:"eCTD", value:'Formattype_FORY000003'};
            if (field === 'region') return {label:"EU / EEA",value:"CountryGroup_CGCD0001"};
            if(field == 'procedureType') return {label:"Mutual Recognition Procedure",code:"ProcedureType_PCT00005"};
          };
          renderfunction();
    });
    it('isApplicationType', async () => {
      
        (fetchCountryOptions as jest.Mock).mockResolvedValueOnce([{"label":"United States of America","value":"Country_COCO0232"},{"label":"China","value":"Country_COCO0046"}])
        mockRowContextValues.selectedCountry = ["United States of America","China","Switzerland"];
       
        FormTypes.watch = (field:any) => {
            if(field=='formatType') return {label:"eCTD", value:'Formattype_FORY000003'};
            if (field === 'region') return {label:"EU / EEA",value:"CountryGroup_CGCD0006"};
            if(field == 'procedureType') return {label:"Mutual Recognition Procedure",code:"ProcedureType_PCT00005"};
          };
          renderfunction();
    });
    it('isShowRmsAndMsc', async () => {
        
        mockRowContextValues.selectedCountry = ["United States of America","China","Switzerland"];
        mockRowContextValues.selectedRow.productPhase = "Investigational";
        FormTypes.watch = (field:any) => {
            if(field=='formatType') return {label:"eCTD", value:'Formattype_FORY000003'};
            if (field === 'region') return {label:"EU / EEA",value:"CountryGroup_CGCD0001"};
            if(field == 'procedureType') return {label:"Mutual Recognition Procedure",code:"ProcedureType_PCT00005"};
          };
          renderfunction();
    });
    it('isApplicationType', async () => {
        mockRowContextValues.selectedCountry = ["Jordan"];
       
        FormTypes.watch = (field:any) => {
            if(field=='formatType') return {label:"eCTD", value:'Formattype_FORY000003'};
            if (field === 'region') return {label:"EU / EEA",value:"CountryGroup_CGCD0006"};
            if(field == 'procedureType') return {label:"Mutual Recognition Procedure",code:"ProcedureType_PCT00005"};
          };
          renderfunction();
    });
    it('isESubIdentifier', async () => {
        mockRowContextValues.selectedCountry = ["Country_COCO0215"];
       
        FormTypes.watch = (field:any) => {
            if(field=='formatType') return {label:"eCTD", value:'Formattype_FORY000003'};
            if (field === 'region') return {label:"Eurasian Economic Union",value:"CountryGroup_CGCD0006"};
            if(field == 'procedureType') return {label:"Mutual Recognition Procedure",code:"ProcedureType_PCT00005"};
          };
          renderfunction();
        await waitFor(() => {
            const input = screen.getByPlaceholderText('e_submission_identifier'); 
            fireEvent.change(input, { target: { value: 'newValue' } }); 
            fireEvent.blur(input, { target: { value: 'newValue' } });
        });
    });
    it('isEidentifier',async  () => {
        mockRowContextValues.selectedCountry = "Country_COCO0014";
       
        FormTypes.watch = (field:any) => {
            if(field=='formatType') return {label:"eCTD", value:'Formattype_FORY000003'};
            if (field === 'region') return {label:"TGA",value:"CountryGroup_CGCD0006"};
            if(field == 'procedureType') return {label:"Mutual Recognition Procedure",code:"ProcedureType_PCT00005"};
          };
          renderfunction();
          await waitFor(() => {
            const input = screen.getByPlaceholderText('e_Identifier'); 
            fireEvent.blur(input, { target: { value: 'newValue' } }); 
            fireEvent.change(input);
        });
    });
    it('isApplicationNumber',async  () => {
        mockRowContextValues.selectedCountry = ["Switzerland","United States of America","South Africa","China"];
       
        FormTypes.watch = (field:any) => {
            if(field=='formatType') return {label:"eCTD", value:'Formattype_FORY000003'};
            if (field === 'region') return {label:"USFDA",value:"CountryGroup_CGCD0006"};
            if(field == 'procedureType') return {label:"Mutual Recognition Procedure",value:"ProcedureType_PCT00005"};
          };
          renderfunction();
          await waitFor(() => {
            const input = screen.getByPlaceholderText('applicationNumber'); 
            fireEvent.blur(input, { target: { value: 'newValue' } }); 
            fireEvent.change(input);
        });
    });
    it('isDossIdentifier',async  () => {
        mockRowContextValues.selectedCountry = ["Country_COCO0040"];
       
        FormTypes.watch = (field:any) => {
            if(field=='formatType') return {label:"eCTD", value:'Formattype_FORY000003'};
            if (field === 'region') return {label:"Oceania and Australia",value:"CountryGroup_CGCD0006"};
            if(field == 'procedureType') return {label:"Mutual Recognition Procedure",value:"ProcedureType_PCT00005"};
          };
          renderfunction();
          await waitFor(() => {
            const input = screen.getByPlaceholderText('dossier_identifier'); 
            fireEvent.blur(input, { target: { value: 'newValue' } }); 
            fireEvent.change(input);
        });
    });
    it('isShowApplicationName',async  () => {
        mockRowContextValues.selectedCountry = [ "CountryGroup_CGCD0001", // European Union / European Economic Area
        "CountryGroup_CGCD0009", // GCC
        // "Country_COCO0269", // JFDA
        "Country_COCO0133", // Malaysia
        "Country_COCO0202", // South Africa
        "Country_COCO0113", // Jordan
        "Country_COCO0232", // United States of America
        "Country_COCO0211", // Switzerland
    ];
       
        FormTypes.watch = (field:any) => {
            if(field=='formatType') return {label:"eCTD", value:'Formattype_FORY000003'};
            if (field === 'region') return {label:"Oceania and Australia",value:"CountryGroup_CGCD0006"};
            if(field == 'procedureType') return {label:"Mutual Recognition Procedure",value:"ProcedureType_PCT00005"};
          };
          renderfunction();
          await waitFor(() => {
            const input = screen.getByPlaceholderText('applicationName'); 
            fireEvent.blur(input, { target: { value: 'newValue' } }); 
            fireEvent.change(input);
        });
    });
    it('isProcedureNumber', async () => {
        mockRowContextValues.selectedCountry = ["Country_COCO0113"];
       
        FormTypes.watch = (field:any) => {
            if(field=='formatType') return {label:"eCTD", value:'Formattype_FORY000003'};
            if (field === 'region') return {label:"EU / EEA",value:"CountryGroup_CGCD0009"};
            if(field == 'procedureType') return {label:"Mutual Recognition Procedure",value:"ProcedureType_PCT00005"};
          };
          renderfunction();
        await waitFor(() => {
            const input = screen.getByPlaceholderText('procedure_number'); 
            fireEvent.blur(input, { target: { value: 'newValue' } }); 
            fireEvent.change(input);
        });
    });
    it('isEctdReceptionNumber', async () => {
      mockRowContextValues.selectedCountry = ["Country_COCO0111"];
      mockRowContextValues.selectedFormatType={label:"jp_ectd",code:"Formattype_FORY000008"}
     
      FormTypes.watch = (field:any) => {
          if(field=='formatType') return {label:"jp_ctd", code:'Formattype_FORY000008'};
          if (field === 'region') return {label:"Asia",value:"CountryGroup_CGCD0002"};
        };
        renderfunction();
  });

  it('isShowRmsAndMsc',async  () => {
       mockRowContextValues.selectedRow=[{productPhaseId:"ProductPhase_PDPS00002"}]
    FormTypes.watch = (field:any) => {
        if(field=='formatType') return {label:"eCTD", value:'Formattype_FORY000003'};
        if (field === 'region') return {label:"EU / EEA",value:"CountryGroup_CGCD0001"};
        if(field == 'procedureType') return {label:"Mutual Recognition Procedure",code:"ProcedureType_PCT00003"};
      };
      renderfunction();
});

});


