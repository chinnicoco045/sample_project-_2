import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import { BrowserRouter } from 'react-router-dom';
import AddApplication from '../Components/Applications/AddApplication';
import { RowContext } from '../App';

jest.mock('react-i18next', () => ({
  useTranslation: () => ({
    t: (key:string) => key,
  }),
}));

describe('AddApplication', () => {
  const mockContextValue : any = {
    disabledRows: [{ id: 1, status: 'disabled' }],
    rows: [],
    allRows: [{ id: 1, status: 'disabled' }, { id: 2, status: 'active' }, { id: 3, status: 'inactive' }],
    activeRows: [{ id: 2, status: 'active' }],
    inactiveRows: [{ id: 3, status: 'inactive' }],
    setRows: jest.fn(),
    isAddPrivileged: true,
    setShowDisabled: jest.fn(),
    setisActiveEnabled: jest.fn(),
    setisInactiveEnabled: jest.fn(),
    ShowDisabled:true,
    gridstatus:{active:true,inactive:false,disable:false},
    setGridStatus:jest.fn(),
    setPaginationobject:jest.fn()
  };

  test('opens and closes the actions menu correctly', async () => {
      render(
        <BrowserRouter>
        <RowContext.Provider value={mockContextValue}>
          <AddApplication />
        </RowContext.Provider>
      </BrowserRouter>

      );
      const actionButton1 = screen.getByRole('button', { name: /actions/i });
      fireEvent.click(actionButton1);

      await waitFor(() => {
        const aroowbtn = screen.getAllByRole("checkbox");
      fireEvent.click(aroowbtn[0]);
      });
      const actionButton2 = screen.getByRole('button', { name: /actions/i });
      fireEvent.click(actionButton2);

      await waitFor(() => {
        const aroowbtn = screen.getAllByRole("checkbox");
      fireEvent.click(aroowbtn[1]);
      });
      const actionButton3 = screen.getByRole('button', { name: /actions/i });
      fireEvent.click(actionButton3);

      await waitFor(() => {
        const aroowbtn = screen.getAllByRole("checkbox");
      fireEvent.click(aroowbtn[2]);
      });
    });

    test('onlyactive', async () => {
      render(
        <BrowserRouter>
        <RowContext.Provider value={mockContextValue}>
          <AddApplication />
        </RowContext.Provider>
      </BrowserRouter>

      );
      const actionButton1 = screen.getByRole('button', { name: /actions/i });
      fireEvent.click(actionButton1);

      await waitFor(() => {
        const aroowbtn = screen.getAllByRole("checkbox");
      fireEvent.click(aroowbtn[1]);
      });
    });
    test('onlyinactive', async () => {
      render(
        <BrowserRouter>
        <RowContext.Provider value={mockContextValue}>
          <AddApplication />
        </RowContext.Provider>
      </BrowserRouter>

      );
      const actionButton1 = screen.getByRole('button', { name: /actions/i });
      fireEvent.click(actionButton1);

      await waitFor(() => {
        const aroowbtn = screen.getAllByRole("checkbox");
      fireEvent.click(aroowbtn[2]);
      });
    });
    test('onlydisable', async () => {
      render(
        <BrowserRouter>
        <RowContext.Provider value={mockContextValue}>
          <AddApplication />
        </RowContext.Provider>
      </BrowserRouter>

      );
      const actionButton1 = screen.getByRole('button', { name: /actions/i });
      fireEvent.click(actionButton1);

      await waitFor(() => {
        const aroowbtn = screen.getAllByRole("checkbox");
      fireEvent.click(aroowbtn[0]);
      });
    });
});