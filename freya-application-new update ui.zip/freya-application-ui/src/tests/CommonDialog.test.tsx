import { render, screen } from '@testing-library/react';
import CommonDialog from '../Components/Applications/components/CommonDialog';
import { DialogProps } from '@mui/material/Dialog';
import userEvent from '@testing-library/user-event';

jest.mock('react-i18next', () => ({
    useTranslation: () => ({
        t: (key: any) => key,
        i18n: { changeLanguage: jest.fn() }
    })
}));

describe('CommonDialog', () => {
    const handlePrimaryBtnMock = jest.fn();
    const handleSecondaryBtnMock = jest.fn();
    const handleCloseBtnMock = jest.fn();

    test('renders without crashing', () => {
        render(
            <CommonDialog
                openDialog={true}
                title="Test Dialog"
                content="This is a test content."
                isDeleteDialog={false}
                handlePrimaryBtn={handlePrimaryBtnMock}
                primaryBtnName="Primary Button"
                handleSecondaryBtn={handleSecondaryBtnMock}
                secondaryBtnName="Secondary Button"
                handleCloseBtn={handleCloseBtnMock}
            />
        );

        expect(screen.getByText('Test Dialog')).toBeInTheDocument();
        expect(screen.getByText('This is a test content.')).toBeInTheDocument();
        expect(screen.getByText('Primary Button')).toBeInTheDocument();
        expect(screen.getByText('Secondary Button')).toBeInTheDocument();
    });

    test('displays dialog', () => {
        render(
            <CommonDialog
                openDialog={true}
                title="Test Dialog"
                content="This is a test content."
                isDeleteDialog={false}
                handlePrimaryBtn={handlePrimaryBtnMock}
                primaryBtnName="Primary Button"
                handleSecondaryBtn={handleSecondaryBtnMock}
                secondaryBtnName="Secondary Button"
                handleCloseBtn={handleCloseBtnMock}
            />
        );

        expect(screen.getByRole('dialog')).toBeInTheDocument();
    });

    const props = {
        openDialog: true,
        title: 'Test Dialog',
        content: 'Test Content',
        isDeleteDialog: false,
        handleSecondaryBtn: jest.fn(),
        secondaryBtnName: 'Secondary Button',
        handlePrimaryBtn: jest.fn(),
        primaryBtnName: 'Primary Button',
        handleCloseBtn: jest.fn(),
        maxWidth: 'xs' as DialogProps['maxWidth'], // 修正此处
        disabledPrimaryBtn: false,
        containerStyle: 'test-container',
        formControl: true,
        dialogPaperWidth: 'md',
    };


    it('should render form elements when formControl is true', () => {
        render(<CommonDialog {...props} />);
        const form = screen.getByText('Test Content');
        expect(form).toBeInTheDocument();

        const submitButton = screen.getByRole('button', { name: 'Primary Button' });
        userEvent.click(submitButton);
        expect(props.handlePrimaryBtn).toHaveBeenCalled();
    });
});