import React from 'react';
import { render, waitFor, screen, act, fireEvent } from '@testing-library/react';
import axios from 'axios';
import MockAdapter from 'axios-mock-adapter';
import { RowContext } from '../App';
import LinkProduct from '../Components/Applications/wizard/LinkSection';
import service, { basicUrl, GET_API } from '../Services/apiheader';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { FreyrLibraryProvider } from '@freyr/freyr-react-common';
import { accessToken } from '../types';
import { mockRowContextValues } from './common.test';
import { fetchSectionProductTree } from '../apis/apiFunctions';

interface LinkProductRef {
  getFormatCheckedValues: (productId: any) => any;
  filterAndBuildTree: (treeList: any[], selectedNodeValues: string[]) => any;
  transformData: (data: any[]) => any[];
}

jest.mock("../apis/apiFunctions",()=>({
 fetchSectionProductTree:jest.fn()
}));
// Mock Axios
const queryClient = new QueryClient();
const mock = new MockAdapter(service);
const mockaxios = new MockAdapter(axios);

const mockContext = {
  setChecked: jest.fn(),
};

const mockBasicInfo = {
  productName: 'Product 1',
  region: 'Region 1',
  procedureType: 'Type 1',
  country: 'Country 1',
};
mockRowContextValues.checked = {
  section1: {
    'Child 1': ['section1_child1_1'],
  },
};

describe('LinkProduct Component', () => {
  const ref = React.createRef<LinkProductRef>();
  const renderComponent = (props = {}) => {
    return render(
      <FreyrLibraryProvider token={accessToken}>
        <QueryClientProvider client={queryClient}>
          <RowContext.Provider value={mockRowContextValues}>
            <LinkProduct ref={ref} multiProduct={true} // or false, depending on the expected behavior
              products={[{ id: '123', name: 'Test Product' }]} {...props} />
          </RowContext.Provider>
        </QueryClientProvider>
      </FreyrLibraryProvider>
    );
  };

  const sectionTreeMock = [
    {
      "id": "255",
      "name": "Documents",
      "displayName": "Documents",
      "gridDataUrl": "/product/document/product/${id}",
      "menuOrder": 28,
      "children": [
        {
          "id": "1800458049857167361",
          "name": "Documents",
          "displayName": "Documents",
          "gridDataUrl": "/product/document/product/${id}",
          "data": [],
          "labelPath": "responseDocumentName",
          "module": "product",
          "menuOrder": 28,
          "children": null
        }
      ]
    },
    {
      "id": "211",
      "name": "Organizations",
      "displayName": "Organizations",
      "gridDataUrl": "/product/organization/page?pageNum=1&pageSize=1000000&productId=${id}",
      "formDataUrl": "/product/organization/${id}",
      "menuOrder": 25,
      "children": [
        {
          "id": "1800458052688322562",
          "name": "Organizations",
          "displayName": "Organizations",
          "gridDataUrl": "/product/organization/page?pageNum=1&pageSize=1000000&productId=${id}",
          "formDataUrl": "/product/organization/${id}",
          "data": [],
          "labelPath": "organisationName",
          "module": "product",
          "menuOrder": 25,
          "children": null
        },
        {
          "id": "1800458052948369409",
          "name": "Business Operations",
          "displayName": "Business Operations",
          "gridDataUrl": "/product/business-operation/page?pageNum=1&pageSize=1000000&productId=${id}",
          "formDataUrl": "/product/business-operation/${id}",
          "data": [],
          "labelPath": "manufacturedItem",
          "module": "product",
          "menuOrder": 26,
          "children": null
        }
      ]
    },
  ];

  test('should fetch and display section tree', async () => {
  (fetchSectionProductTree as jest.Mock).mockResolvedValueOnce({data:{data:sectionTreeMock}});
    await act(async () => {
      renderComponent({ productId: '123', basicInfo: sectionTreeMock, multiProduct: false, products: {} });
    });
  
    await waitFor(() => {
      expect(screen.getByTestId('checkbox-tree')).toBeInTheDocument();
    });
  
      // Debug the DOM to see what is rendered
    console.log('--- Start of DOM Debug ---');
    screen.debug();
    console.log('--- End of DOM Debug ---');

     // Find all checkboxes
      const checkboxes = screen.queryAllByRole("checkbox");
      console.log('Checkboxes found:', checkboxes.length); // Log the number of checkboxes found
      // expect(checkboxes.length).toBeGreaterThan(0); // Ensure there are checkboxes

      // Interact with the first checkbox
      if (checkboxes.length > 0) {
        fireEvent.click(checkboxes[0]);
        expect(checkboxes[0]).toBeChecked();
      }
  });
  

  test('should update state on currentApplication change', async () => {
    const newApplication = {
      productId: '456',
      sectionTree: sectionTreeMock,
    };

    await act(async () => {
      renderComponent({
        productId: '123',
        currentApplication: newApplication,
        multiProduct: false,
        products: [],
      });
    });

    await waitFor(() => {
      expect(ref.current?.getFormatCheckedValues('456')).toEqual(expect.any(Object));
    });
  });




  test('should handle product selection', async () => {
    const { getByTestId } = renderComponent({
      productId: '123',
      multiProduct: true,
      products: [{ id: '123', name: 'Product 1' }, { id: '456', name: 'Product 2' }]
    });
  
    const productList = getByTestId('selected-products');
    const productItems = productList.querySelectorAll('[role="button"]');
  
    // Ensure there are enough buttons
    expect(productItems.length).toBeGreaterThan(1);
  
    fireEvent.click(productItems[1]); // Select the second product
  
    await waitFor(() => {
      expect(ref.current?.getFormatCheckedValues('456')).toEqual(expect.any(Object));
    });
  });



  describe('getFormConfig', () => {
    const formName = 'TestForm';
    const formConfigUrl = `${GET_API}cm/form-manager/forms/settings`;

    beforeEach(() => {
      mock.reset();
      jest.spyOn(console, 'error').mockImplementation(() => {});
    });

    afterEach(() => {
      jest.restoreAllMocks();
    });

    test('should handle error when fetching form configuration', async () => {
      mock.onPost(formConfigUrl).reply(500);

      await act(async () => {
        renderComponent({
          currentApplication: { formName },
          detailRecord: { formName }, multiProduct: false, products: {}
        });
      });

      await waitFor(() => {
        expect.any(Error)
      });
    });
  });
});




























// import React from 'react';
// import { render, waitFor, screen, act, fireEvent } from '@testing-library/react';
// import axios from 'axios';
// import MockAdapter from 'axios-mock-adapter';
// import { RowContext } from '../App';
// import LinkProduct from '../Components/Applications/wizard/LinkSection';
// import service,{ basicUrl, GET_API } from '../Services/apiheader';
// import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
// import { FreyrLibraryProvider } from '@freyr/freyr-react-common';
// import { accessToken } from '../types';
// import { mockRowContextValues } from './common.test';


// interface LinkProductRef {
//   getFormatCheckedValues: () => any;
// }

// // Mock Axios
// const queryClient = new QueryClient();
// const mock = new MockAdapter(service);
// const mockaxios = new MockAdapter(axios);

// const mockContext = {
//   setChecked: jest.fn(),
// };

// const mockBasicInfo = {
//   productName: 'Product 1',
//   region: 'Region 1',
//   procedureType: 'Type 1',
//   country: 'Country 1',
// };
// mockRowContextValues.checked = {
//           section1: {
//             'Child 1': ['section1_child1_1'],
//           },
//         };

// describe('LinkProduct Component', () => {
//  const ref = React.createRef<LinkProductRef>();
//   const renderComponent = (props = {}) => {
//     return render(
//       <FreyrLibraryProvider token={accessToken}>
//         <QueryClientProvider client={queryClient}>
//         <RowContext.Provider value={mockRowContextValues}>
//             <LinkProduct ref={ref}  multiProduct={true} // or false, depending on the expected behavior
//               products={[{ id: '123', name: 'Test Product' }]} {...props} />
//           </RowContext.Provider>
//         </QueryClientProvider>
//       </FreyrLibraryProvider>
//     );
//   };

//     const sectionTreeMock = [
//       {
//         "id": "255",
//         "name": "Documents",
//         "displayName": "Documents",
//         "gridDataUrl": "/product/document/product/${id}",
//         "menuOrder": 28,
//         "children": [
//             {
//                 "id": "1800458049857167361",
//                 "name": "Documents",
//                 "displayName": "Documents",
//                 "gridDataUrl": "/product/document/product/${id}",
//                 "data": [],
//                 "labelPath": "responseDocumentName",
//                 "module": "product",
//                 "menuOrder": 28,
//                 "children": null
//             }
//         ]
//     },
//     {
//       "id": "211",
//       "name": "Organizations",
//       "displayName": "Organizations",
//       "gridDataUrl": "/product/organization/page?pageNum=1&pageSize=1000000&productId=${id}",
//       "formDataUrl": "/product/organization/${id}",
//       "menuOrder": 25,
//       "children": [
//           {
//               "id": "1800458052688322562",
//               "name": "Organizations",
//               "displayName": "Organizations",
//               "gridDataUrl": "/product/organization/page?pageNum=1&pageSize=1000000&productId=${id}",
//               "formDataUrl": "/product/organization/${id}",
//               "data": [],
//               "labelPath": "organisationName",
//               "module": "product",
//               "menuOrder": 25,
//               "children": null
//           },
//           {
//               "id": "1800458052948369409",
//               "name": "Business Operations",
//               "displayName": "Business Operations",
//               "gridDataUrl": "/product/business-operation/page?pageNum=1&pageSize=1000000&productId=${id}",
//               "formDataUrl": "/product/business-operation/${id}",
//               "data": [],
//               "labelPath": "manufacturedItem",
//               "module": "product",
//               "menuOrder": 26,
//               "children": null
//           }
//       ]
//   },
  
//     ];
//     test('should fetch and display section tree', async () => {

//     mock.onGet(`${basicUrl}application/v1/section-tree?productId=123`).reply(200, {
//       data: sectionTreeMock,
//     });
//     await act(async () => {
//     renderComponent({ productId: '123', basicInfo: sectionTreeMock,multiProduct:false, products:{} });
//     });

//     await waitFor(() => expect(screen.getByTestId('loading-text')).toBeInTheDocument());

//     const sectionName= screen.getByTestId("test1");
//     expect(sectionName).toBeInTheDocument();
//     fireEvent.change(sectionName);
//     ref.current?.getFormatCheckedValues();
  
//       const aroowbtn =await screen.getAllByRole("checkbox");
//     fireEvent.click(aroowbtn[1]);
   
//   });  

  // test('events', async () => {
  //   await act(async () => {
  //     renderComponent({ productId: '123', basicInfo: mockBasicInfo,currentApplication:{productId:"123",productname:"test",sectionTree:sectionTreeMock,multiProduct:false, products:{}} });
  //     });
  //     await waitFor(() => {
  //       const aroowbtn = screen.getAllByRole("checkbox");
  //     fireEvent.click(aroowbtn[1]);
  //     });
  // });

  // test('should handle checkbox interactions', async () => {
  //   mock.onGet(`${basicUrl}application/v1/section-tree?productId=123`).reply(200, {
  //     data: sectionTreeMock,
  //   });

  //   await act(async () => {
  //     renderComponent({
  //       productId: '123',
  //       currentApplication: {
  //         sectionTree: sectionTreeMock,
  //       },
  //       multiProduct: false,
  //       products: [],
  //     });
  //   });

  //   await waitFor(() => {
  //     const checkboxTree = screen.getByTestId('checkbox-tree');
  //     expect(checkboxTree).toBeInTheDocument();
  //   });

  //   const checkboxes = screen.queryAllByRole('checkbox');
  //   if (checkboxes.length > 0) {
  //     fireEvent.click(checkboxes[0]);
  //     expect(checkboxes[0]).toBeChecked();
  //   } else {
  //     console.error('No checkboxes found');
  //   }
  // });

//   describe('getFormConfig', () => {
//     const formName = 'TestForm';
//     const formConfigUrl = `${GET_API}cm/form-manager/forms/settings`;

//     beforeEach(() => {
//       mock.reset();
//       jest.spyOn(console, 'error').mockImplementation(() => {});
//     });

//     afterEach(() => {
//       jest.restoreAllMocks();
//     });

//     test('should handle error when fetching form configuration', async () => {
//       mock.onPost(formConfigUrl).reply(500);

//       await act(async () => {
//         renderComponent({
//           currentApplication: { formName },
//           detailRecord: { formName },multiProduct:false, products:{}
//         });
//       });

//       await waitFor(() => {
//           expect.any(Error)
//       });
//     });
//   });
// });