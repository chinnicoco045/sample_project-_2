import { render, screen, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import CustomAutoComplete from  "../Components/Applications/components/CustomAutoComplete";
import { TextField } from '@mui/material';
import { AutocompleteRenderInputParams } from '@mui/material/Autocomplete';

const mockOptions = [
  { id: 1, label: 'Option 1', value: 'opt1' },
  { id: 2, label: 'Option 2', value: 'opt2' },
];

const mockProps = {
  options: mockOptions,
  multiple: true,
  labelField: 'label',
  valueField: 'value',
  valuePrimitive: true,
  value: [],
  onChange: jest.fn(),
  renderInput: (params: AutocompleteRenderInputParams) => <TextField {...params} label="Autocomplete" variant="outlined" />
};

describe('CustomAutoComplete Component', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('renders without crashing', () => {
    render(<CustomAutoComplete {...mockProps} />);
    expect(screen.getByRole('combobox')).toBeInTheDocument();
  });

  it('handles value change correctly for multiple selections with primitive values', () => {
    render(<CustomAutoComplete {...mockProps} />);
    
    const autocompleteInput = screen.getByRole('combobox');

    fireEvent.change(autocompleteInput, { target: { value: 'Option 1' } });
    fireEvent.click(screen.getByText('Option 1'));

    expect(mockProps.onChange).toHaveBeenCalledWith(
      expect.anything(),
      ['opt1'],
      'selectOption',
      expect.anything()
    );
  });

  it('handles value change correctly for single selection with primitive value', () => {
    render(<CustomAutoComplete {...mockProps} multiple={false} />);
    
    const autocompleteInput = screen.getByRole('combobox');
    
    fireEvent.change(autocompleteInput, { target: { value: 'Option 1' } });
    fireEvent.click(screen.getByText('Option 1'));

    expect(mockProps.onChange).toHaveBeenCalledWith(
      expect.anything(),
      'opt1',
      'selectOption',
      expect.anything()
    );
  });

  it('renders options correctly with custom renderOption', () => {
    render(<CustomAutoComplete {...mockProps} />);
    
    fireEvent.mouseDown(screen.getByRole('combobox'));
    
    const option1 = screen.getByText('Option 1');
    const option2 = screen.getByText('Option 2');

    expect(option1).toBeInTheDocument();
    expect(option2).toBeInTheDocument();
  });

  it('handles rendering tags correctly when multipleChip is false', () => {
    render(<CustomAutoComplete {...mockProps} multipleChip={false} value={['opt1', 'opt2']} />);
    
    expect(screen.getByText('2 selected')).toBeInTheDocument();
  });

});