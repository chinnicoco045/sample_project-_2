import React, { useContext, useEffect, useState } from "react";
import { UseFormReturn, Controller } from "react-hook-form";
import {
  TextField,
  Grid,
  Box,
  FormLabel,
  FormControl,
  InputLabel,
  
  Chip,
  Tooltip,
} from "@mui/material";
import CustomAutoComplete from "../components/CustomAutoComplete";
import axios from "axios";
import { accessToken } from "../../../types";
import { RowContext } from "../../../App";
import service, { GET_API } from "../../../Services/apiheader";
import { useTranslation } from "react-i18next";
import {
  fetchApplicationTypeValues,
  fetchCountryOptions,
  fetchRegionOptions,
  fetchProcedureTypeValues,
  fetchFormatTypeOptions
} from "../../../apis/apiFunctions";
import Cookies from "js-cookie";
import TagIcon from '@mui/icons-material/LocalOfferOutlined';

export interface FormTypes {
  productName: { label: string; value: string } | undefined;
  region: { label: string; value: string } | undefined;
  country: { label: string; value: string } []|{ label: string; value: string }| undefined;
  procedureType: { label: string; value: string ; code : string} | undefined;
  lmsCountry: { label: string; value: string } | undefined;
  msCountry: { label: string; value: string }[] | undefined;
  rmsCountry?: { label: string; value: string } | undefined;
  cmsCountry?: { label: string; value: string }[] | undefined;
  mscCountry?: { label: string; value: string }[] | undefined;
  applicationIdentifier?: { label: string; value: string } | undefined;
  formatType?: { label: string; value: string } | undefined;
  applicationType?: { label: string; value: string; code:string } | undefined;
  procedureNumber: string | undefined;
  registrationId: string | undefined;
  applicationNumber: string | undefined;
  countryIdentifier: string[];
  applicationId: string | undefined;
  eCTDReceptionNumber:string | undefined;
  applicationName: string | "";
  eSubIdentifier: string | undefined;
  eIdentifier: string | undefined;
  dossierIdentifier: string | undefined;
}

interface procedureType{
  label: string; value: string; code: string 
}


interface ComponentsProps {
  productId: string;
  formMethods: UseFormReturn<FormTypes>;
  multiProduct: Boolean;
  productNames: string[];
}
export interface Option {
  value: string;
  label: string;
}


const LinkCountry: React.FC<ComponentsProps> = ({ productId, formMethods,multiProduct,productNames }) => {
  const {
    watch,
    control,
    formState: { errors },
    setValue,
    clearErrors,
  } = formMethods;
  const {
    applicationIdentifier,
    setApplicationIdentifier,
    error,
    setError,
    regionOptions,
    setRegionOptions,
    countryOptions,
    setCountryOptions,
    selectedCountry,
    setSelectedCountry,
    selectedRow,
  } = useContext(RowContext);
  const [productOptions, setProductOptions] = useState([]);
  const [procedureNumber, setProcedureNumber] = useState("");
  const [registrationId, setRegistrationId] = useState("");
  const [applicationName, setApplicationName] = useState("");
  const [applicationId, setApplicationId] = useState("");
  const [dossierIdentifier, setDossierIdentifier] = useState("");
  const [eIdentifier, setEIdentifier] = useState("");
  const [eSubmissionIdentifier, setESubmissionIdentifier] = useState("");
  const [isNameMandatory, setIsNameMandatory] = useState(false);
  const [isNumberMandatory, setIsNumberMandatory] = useState(false);
  const [isTypeMandatory, setIsTypeMandatory] = useState(false);
  const [applicationTypeOptions, setApplicationTypeOptions] = useState<any>([]);
  const [procedureTypeoptions, setprocedureTypeoptions] = useState<procedureType[]>([]);
  const [kmprocedureTypeoptions, setkmprocedureTypeoptions] = useState<procedureType[]>([]);
  const [formatTypeOptions,setFormatTypeOptions]=useState<any[]>([]);
  const [defaultMSCountries, setdefaultMSCountries] = useState<any>([]);
  const [selectedFormatType,setSelectedFormatType]=useState<any>();
  // const [selectedCountry, setSelectedCountry] = useState<string[]>([]);

  const region = watch("region");
  const procedureType = watch("procedureType");
  const rmsCountry = watch("rmsCountry");
  const cmsCountry = watch("cmsCountry");
  const lmsCountry = watch("lmsCountry");
  const msCountry = watch("msCountry");
  const mscCountry = watch("mscCountry");
  const formatType = watch("formatType");
  const regionName = region?.value;
  const region_name = region?.label;

  const isShowEctdReceptionNumber =
  (Array.isArray(selectedCountry)
    ? selectedCountry.includes("Country_COCO0111")
    : selectedCountry === "Country_COCO0111") &&  // Japan
  (selectedFormatType?.code === "Formattype_FORY000009" || selectedFormatType?.code === "Formattype_FORY000008");

const isShowProcedureType =
(region_name && ["Middle East"].includes(region_name)) ||
(regionName &&
  [
    "CountryGroup_CGCD0001", // European Union / European Economic Area
    "CountryGroup_CGCD0016", // Eurasian Economic Union (EAEU)
    "CountryGroup_CGCD0009", // Gulf Cooperation Council (GCC)
  ].includes(regionName));

const isShowLmsAndMs =
regionName === "CountryGroup_CGCD0009" && // GCC
procedureType?.code === "ProcedureType_PCT00013";

const isShowRmsAndCms =
regionName &&
["CountryGroup_CGCD0001", "CountryGroup_CGCD0016"].includes(regionName) && // EU/EEA, EAEU
procedureType?.code &&
["ProcedureType_PCT00005", "ProcedureType_PCT00004"].includes(procedureType.code);

const productPhaseId=selectedRow?.[0]?.productPhaseId;

const isShowRmsAndMsc =
regionName &&
["CountryGroup_CGCD0001", "CountryGroup_CGCD0016"].includes(regionName) && // EU/EEA, EAEU
procedureType?.code === "ProcedureType_PCT00003" &&
productPhaseId === "ProductPhase_PDPS00002";

const noRequirement =
regionName === "CountryGroup_CGCD0009" && // GCC
productPhaseId === "ProductPhase_PDPS00002";

const isCountrySameWithRegion =
regionName === "CountryGroup_CGCD0001" && // EU/EEA
procedureType?.code === "ProcedureType_PCT00003" &&
!isShowRmsAndMsc;

const isProcedureTypeMandatory =
(productPhaseId === "ProductPhase_PDPS00001" &&
  Array.isArray(selectedCountry) &&
  selectedCountry.some((country) => country === "Country_COCO0113")) || // Jordan
(!Array.isArray(selectedCountry) && selectedCountry === "Country_COCO0113");

  useEffect(() => {
    setValue("rmsCountry", undefined);
    setValue("cmsCountry", []);
    setValue("lmsCountry", undefined);
    setValue("msCountry", []);
    // setValue("formatType", undefined);
    setValue("applicationName", "");
    setValue("applicationId", undefined); // Reset applicationId
    setValue("applicationNumber", undefined);
    setValue("countryIdentifier",[]); // Reset applicationNumber
    setApplicationId(""); // Clear local state
    setProcedureNumber("");
    setEIdentifier("");
    setDossierIdentifier("");
    setESubmissionIdentifier("");
    setValue("registrationId", undefined);
    setRegistrationId("");
    if (isCountrySameWithRegion === true)
      setValue("country", [
        { label: "European Union", value: "Country_COCO0072" },
      ]);
    else setValue("country", []);
  }, [isCountrySameWithRegion, procedureType]);

  useEffect(() => {
    // Reset procedureType if productId changes
    setValue("formatType",undefined);
setValue("region",undefined);
    setValue("procedureType", undefined);
setValue("applicationType",undefined);
  }, [productId, setValue]);
  
  useEffect(() => {
    // Set default procedureType to "National" and disable autofill
    // setValue("formatType", undefined);
    setValue("country", undefined);
    setSelectedCountry([]);
  }, []);

  const isApplicationType =
  (regionName &&
    ["CountryGroup_CGCD0009", "CountryGroup_CGCD0016"].includes(
      // GCC, EAEU
      regionName
    )) ||
  (Array.isArray(selectedCountry) &&
    selectedCountry.some((country) =>
      [
        "Country_COCO0232", // United States of America
        "Country_COCO0046", // China
        "Country_COCO0211", // Switzerland
        "CountryGroup_CGCD0016", // Eurasian Economic Union (EAEU)
        "Country_COCO0113", // Jordan
      ].includes(country)
    )) ||
  (!Array.isArray(selectedCountry) &&
    [
      "Country_COCO0150", // United States of America
      "Country_COCO0046", // China
      "Country_COCO0211", // Switzerland
      "Country_COCO0113", // Jordan
    ].includes(selectedCountry));

const isShowApplicationName =
  (regionName && ["CountryGroup_CGCD0009", "CountryGroup_CGCD0016"]?.includes(regionName)) || // GCC, EAEU
  (regionName &&
    [
      "CountryGroup_CGCD0001", // European Union / European Economic Area
      "CountryGroup_CGCD0009", // Gulf Cooperation Council (GCC)
      "Country_COCO0269", // JFDA (No code found, replaced with European Union/EEA for clarity)
      "Country_COCO0133", // Malaysia
      "Country_COCO0197", // Singapore
      "Country_COCO0202", // South Africa
      // "Country_COCO0077", // Swiss Medic (Switzerland)
      "CountryGroup_CGCD0016", // Eurasian Economic Union (EAEU)
    ].includes(regionName)) ||
  (Array.isArray(selectedCountry) &&
    selectedCountry.some((country) =>
      [
        "CountryGroup_CGCD0001", // European Union / European Economic Area
        "CountryGroup_CGCD0009", // GCC
        // "Country_COCO0269", // JFDA
        "Country_COCO0133", // Malaysia
        "Country_COCO0202", // South Africa
        "Country_COCO0113", // Jordan
        "Country_COCO0232", // United States of America
        "Country_COCO0211", // Switzerland
      ].includes(country)
    )) ||
  (!Array.isArray(selectedCountry) &&
    [
      "CountryGroup_CGCD0001", // European Union / European Economic Area
      "CountryGroup_CGCD0009", // GCC
      // "Country_COCO0269", // JFDA
      "Country_COCO0133", // Malaysia
      "Country_COCO0202", // South Africa
      "Country_COCO0211", // Switzerland
      "Country_COCO0113", // Jordan
      "Country_COCO0232", // United States of America
    ].includes(selectedCountry));


const isShowApplicationId =
  (regionName &&
    ["Country_COCO0046", "CountryGroup_CGCD0016"].includes(regionName)) || // China, EAEU
  (Array.isArray(selectedCountry) &&
    selectedCountry.some((country) =>
      ["Country_COCO0046", "CountryGroup_CGCD0016"].includes(country)
    )) ||
  (!Array.isArray(selectedCountry) &&
    ["Country_COCO0046", "CountryGroup_CGCD0016"].includes(selectedCountry));

const isEidentifier =
  (Array.isArray(selectedCountry) &&
    selectedCountry.some((country) => ["Country_COCO0014"].includes(country))) || // Australia
  (!Array.isArray(selectedCountry) && ["Country_COCO0014"].includes(selectedCountry));

const isApplicationNumber =
  (Array.isArray(selectedCountry) &&
    selectedCountry.some((country) =>
      [
        "Country_COCO0211", // Switzerland
        "Country_COCO0232", // United States of America
        "Country_COCO0202", // South Africa
        "Country_COCO0046", // China
      ].includes(country)
    )) ||
  (!Array.isArray(selectedCountry) &&
    [
       "Country_COCO0211", // Switzerland
        "Country_COCO0232", // United States of America
        "Country_COCO0202", // South Africa
        "Country_COCO0046", // China 
    ].includes(selectedCountry));

const isDossIdentifier =
  (Array.isArray(selectedCountry) &&
    selectedCountry.some((country) => ["Country_COCO0040"].includes(country))) || // Canada
  (!Array.isArray(selectedCountry) && ["Country_COCO0040"].includes(selectedCountry));

const isProcedureNumber =
  (regionName &&
    ["CountryGroup_CGCD0001", "CountryGroup_CGCD0009", "CountryGroup_CGCD0016"].includes(regionName)) || // EU/EEA, GCC, EAEU
  (Array.isArray(selectedCountry) &&
    selectedCountry.some((country) => ["Country_COCO0113"].includes(country))) || // Jordan
  (!Array.isArray(selectedCountry) && ["Country_COCO0113"].includes(selectedCountry));

const isESubIdentifier =
  (Array.isArray(selectedCountry) &&
    selectedCountry.some((country) => ["Country_COCO0215"].includes(country))) || // Thailand
  (!Array.isArray(selectedCountry) && ["Country_COCO0215"].includes(selectedCountry));

const isRegistrationId =
regionName && ["CountryGroup_CGCD0016"].includes(regionName); // EAEU

  const { t } = useTranslation();
  useEffect(() => {
    getProductOptions();
    loadRegionOptions(selectedFormatType);
    getCountryAppTypeCombination();
  }, [selectedFormatType]);
  
 


useEffect(() => {
  const fetchData = async () => {
    const formatTypeResponse= await fetchFormatTypeOptions();
    const formatData=formatTypeResponse;
    const finalFormatData = formatData.map((proctype: any) => {
      return { label: proctype.name, value: "Formattype_"+proctype.code, code: "Formattype_"+proctype.code };
    });

    setFormatTypeOptions(finalFormatData);
    const responsedata = await fetchProcedureTypeValues();
    const proceduredata = responsedata.data.data.data;
    const finaldata = proceduredata.map((proctype: any) => {
      return { label: proctype.name, value: proctype.name, code: "ProcedureType_"+proctype.code };
    });
    setprocedureTypeoptions(finaldata);
    setkmprocedureTypeoptions(finaldata);
  };

  fetchData();
}, []);



  const getCountryAppTypeCombination = async () =>{
    const adddatatoapptype = (AppTypeOptions:any,countrycode:any) =>{
      for (const apptype of AppTypeOptions || [])
        {
          for (const apptypechild of apptype.children || [])
          {
            if(countrycode === apptypechild.code){
              finaldata.push({label:apptype.name,value:apptype.name})
            }
          }
        }
    }
    const response =await fetchApplicationTypeValues();
    let countryselected = watch("country");
    let AppTypeOptions = response.data.data;
    let finaldata: { label: any; value: any; }[] = [];
    if(Array.isArray(countryselected)){
    for (const countryName of countryselected || [])
    {
      let countrycode = countryName.value.replace("Country_","");
      adddatatoapptype(AppTypeOptions,countrycode);
    }
  }else{
    let countrycode = countryselected?.value.replace("Country_","");
    adddatatoapptype(AppTypeOptions,countrycode);
  }
  if(finaldata.length === 0)
  {
    finaldata = AppTypeOptions.map((apptype:any)=>{
       return {label:apptype.name,value:"ApplicationType_"+apptype.code,code:"ApplicationType_"+apptype.code}
    })
  }
    setApplicationTypeOptions(finaldata);
  };

  const getProductOptions = async () => {
    const response = await axios.get(
      GET_API + `product/products/dropdown-list`,
      {
        headers: {
          Authorization: `Bearer ${accessToken}`,
          "Accept-Language": "",
        },
      }
    );
    const data = response.data.data.map((item: any) => ({
      label: item.name,
      value: item.id,
    }));
    setProductOptions(data);
  };

  const loadRegionOptions = async (formatType:any) => {

    const regionOptions = await fetchRegionOptions(formatType);
    setRegionOptions(regionOptions);
  };

  const loadCountryOptions = async (regionName: any) => {
    setValue("country", []);
    setSelectedCountry([]);
    
    const countryOptions = await fetchCountryOptions(regionName);
    setCountryOptions(countryOptions);
  };

  useEffect(() => {
    setValue("procedureType", undefined);
    if (!regionName || !procedureType) {
      setValue("country", []);
      setSelectedCountry([]);
    }
  }, [regionName, setValue]);

  useEffect(() => {
    setIsNumberMandatory(isApplicationNumber);
    setIsTypeMandatory(isApplicationType);
    setIsNameMandatory(isShowApplicationName);
  }, [region_name, selectedCountry]);

  useEffect(() => {
    getCountryAppTypeCombination();
  }, [selectedCountry]);

  useEffect(() => {
    if (regionName !== "") {
      loadCountryOptions(regionName);
  
      const filteredprocedure = kmprocedureTypeoptions.filter((option) => {
        if (
          (option.code === "ProcedureType_PCT00003" || // Centralised Procedure
            option.code === "ProcedureType_PCT00004" || // Decentralised Procedure
            option.code === "ProcedureType_PCT00005" || // Mutual Recognition Procedure
            option.code === "ProcedureType_PCT00006") && // National Procedure
          regionName === "CountryGroup_CGCD0001" && // European Union / European Economic Area
          productPhaseId === "ProductPhase_PDPS00001"
        )
          return option;
  
        if (
          (option.code === "ProcedureType_PCT00003" || // Centralised Procedure
            option.code === "ProcedureType_PCT00006") && // National Procedure
          regionName === "CountryGroup_CGCD0001" && // European Union / European Economic Area
          productPhaseId === "ProductPhase_PDPS00002"
        )
          return option;
  
        if (
          (option.code === "ProcedureType_PCT00013" || // GCC Procedure
            option.code === "ProcedureType_PCT00006") && // National Procedure
          regionName === "CountryGroup_CGCD0009" // Gulf Cooperation Council (GCC)
        )
          return option;
  
        if (
          (option.code === "ProcedureType_PCT00014" || // Jordan Procedure
            option.code === "ProcedureType_PCT00006") && // National Procedure
          regionName === "CountryGroup_CGCD0002" // Asia
        )
          return option;
  
        if (
          (option.code === "ProcedureType_PCT00004" || // Decentralised Procedure
            option.code === "ProcedureType_PCT00005" || // Mutual Recognition Procedure
            option.code === "ProcedureType_PCT00006") && // National Procedure
          regionName === "CountryGroup_CGCD0016" && // Eurasian Economic Union (EAEU)
          productPhaseId === "ProductPhase_PDPS00001"
        )
          return option;
  
        if (
          (option.code === "ProcedureType_PCT00003" || // Centralised Procedure
            option.code === "ProcedureType_PCT00006") && // National Procedure
          regionName === "CountryGroup_CGCD0016" && // Eurasian Economic Union (EAEU)
          productPhaseId === "ProductPhase_PDPS00002"
        )
          return option;
  
        if (
          (option.code === "ProcedureType_PCT00015" || // Company Registration / Tender
            option.code === "ProcedureType_PCT00006") && // National Procedure
          regionName === "CountryGroup_CGCD0013" // Global
        )
          return option;
  
        if (
          option.code === "ProcedureType_PCT00006" && // National Procedure
          regionName !== "CountryGroup_CGCD0001" && // European Union / European Economic Area
          regionName !== "CountryGroup_CGCD0009" && // Gulf Cooperation Council (GCC)
          regionName !== "CountryGroup_CGCD0002" && // Asia
          regionName !== "CountryGroup_CGCD0016" && // Eurasian Economic Union (EAEU)
          regionName !== "CountryGroup_CGCD0013" // Global
        )
          return option;
  
        return false;
      });
  
      setprocedureTypeoptions(filteredprocedure);
    }
  }, [regionName]);
  
  useEffect(() => {
    formMethods.setValue("rmsCountry", undefined);
    formMethods.setValue("cmsCountry", []);
    formMethods.setValue("lmsCountry", undefined);
    formMethods.setValue("msCountry", []);
    formMethods.setValue("mscCountry", undefined);
    formMethods.setValue("applicationName", "");
    formMethods.setValue("applicationId", undefined);
    formMethods.setValue("eSubIdentifier", undefined);
    formMethods.setValue("eIdentifier", undefined);
    formMethods.setValue("dossierIdentifier", undefined);
    formMethods.setValue("registrationId", undefined);
    formMethods.setValue("procedureNumber", undefined);
    formMethods.setValue("countryIdentifier", []);
    formMethods.setValue("applicationType", undefined);
  }, [regionName, region_name, formMethods,formatType]);

  useEffect(()=>{
    formMethods.setValue("region",undefined)
  },[formatType])
  const realCountryOptions = region ? countryOptions || [] : [];

  useEffect(() => {
    if (productId && productOptions.length) {
      const productObj = productOptions.find(
        (item: { value: string }) => item.value === productId
      );
      setValue("productName", productObj);
    }
  }, [productId, productOptions]);

  useEffect(() => {
    if (!isShowProcedureType) {
      // formMethods.setValue("procedureType", {
      //   label: "National",
      //   value: "National",
      // });
      clearErrors("procedureType");
    }
  }, [isShowProcedureType, formMethods]);


  useEffect(() => {
    if (applicationName) {
      setApplicationIdentifier({
        label: "applicationName",
        value: applicationName,
      });
    } else if (applicationId) {
      setApplicationIdentifier({
        label: "applicationId",
        value: applicationId,
      });
    } else if (dossierIdentifier) {
      setApplicationIdentifier({
        label: "dossierIdentifier",
        value: dossierIdentifier,
      });
    } else if (eIdentifier) {
      setApplicationIdentifier({
        label: "eIdentifier",
        value: eIdentifier,
      });
    } else if (eSubmissionIdentifier) {
      setApplicationIdentifier({
        label: "eSubmissionIdentifier",
        value: eSubmissionIdentifier,
      });
    } else {
      setApplicationIdentifier({
        label: "",
        value: "",
      });
    }
    
  }, [
    applicationName,
    applicationId,
    dossierIdentifier,
    eIdentifier,
    eSubmissionIdentifier,
  ]);

  if (isShowRmsAndCms) {
    formMethods.setValue("countryIdentifier", ["RMS", "CMS"]);
    // formMethods.setValue('countryIdentifier', 'CMS');
  } else if (isShowLmsAndMs) {
    formMethods.setValue("countryIdentifier", ["MS", "LMS"]);
  } else if (isShowRmsAndMsc) {
    formMethods.setValue("countryIdentifier", ["RMS", "MSC"]);
  }

  useEffect(()=>{
    if (regionName === "CountryGroup_CGCD0009" && procedureType?.code === "ProcedureType_PCT00013") {
      const defaultMScountries = realCountryOptions.filter((option) => option.value !== "Country_COCO0272" && option.value !== lmsCountry?.value);
      formMethods.setValue("msCountry", defaultMScountries);
      setdefaultMSCountries(defaultMScountries);
    } else {
      setdefaultMSCountries([]);
    }
  },[lmsCountry?.value])

  return (
    <Box className="link-country">
      <form className="form-group">
        <Grid container>
         {multiProduct? <>
          <Grid item xs={12}>
          <FormLabel>
              <Box display="flex">
                <span>{t('Selected Products')}</span>
              </Box>
            </FormLabel> 
            {productNames.map((name) => (
  <Tooltip key={name} title={name} placement="bottom-start">
    <Chip
      label={name}
      style={{
        marginRight: '10px',
      }}
    />
  </Tooltip>
))}
</Grid>
</> : <Grid item xs={4}>
            <FormLabel>
              <Box display="flex">
                <span>{t('productName')}</span>
                <span style={{ color: "red" }}> * </span>
              </Box>
            </FormLabel>
            <Controller
              name="productName"
              control={control}
              rules={{ required: t("fieldRequired", { field: t("productName") }) }}
              render={({ field }) => (
                <CustomAutoComplete
                  {...field}
                  disabled
                  options={productOptions}
                  getOptionLabel={(option) => option.label || ""}
                  isOptionEqualToValue={(option, value) =>
                    option.value === value.value
                  }
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      error={!!errors.productName}
                      helperText={errors.productName?.message}
                    />
                  )}
                  onChange={(_, value) => field.onChange(value)}
                />
              )}
            />
          </Grid>}
          <Grid item xs={4}>
            <FormLabel>
              <Box display={"flex"}>
                <span>{t('formatType')}</span>
                <span style={{ color: "red" }}> * </span>
              </Box>
            </FormLabel>
            <Controller
              name="formatType"
              control={control}
              rules={{ required: t("fieldRequired", { field: t("formatType") }) }}
              render={({ field }) => (
                <CustomAutoComplete
                  {...field}
                  // valuePrimitive={true}
                  // valueField={"value"}
                  options={formatTypeOptions}
                  getOptionLabel={(option) => option.label || ""}
                  isOptionEqualToValue={(option, value) =>
                    option.value === value.value
                  }
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      error={!!errors.formatType?.message}
                      inputProps={{
                        ...params.inputProps,
                      }}
                      helperText={errors.formatType?.message ?? ""}
                    />
                  )}
                  onChange={(_, value) => {
                    field.onChange(value);
                    setSelectedFormatType(value);
                    clearErrors("formatType"); // Clear validation error on change
                  }}
                />
              )}
            />
          </Grid>
          <Grid item xs={4}>
            <FormLabel>
              <Box display="flex">
                <span>{t('region')}</span>
                <span style={{ color: "red" }}> * </span>
              </Box>
            </FormLabel>
            <Controller
              name="region"
              control={control}
              rules={{ required: t("fieldRequired", { field: t("region") })}}
              render={({ field }) => (
                <CustomAutoComplete
                  {...field}
                  options={regionOptions}
                  getOptionLabel={(option) => option.label || ""}
                  isOptionEqualToValue={(option, value) =>
                    option.value === value.value
                  }
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      error={!!errors.region}
                      helperText={errors.region?.message}
                    />
                  )}
                  onChange={(_, value) => {
                    field.onChange(value);
                    clearErrors("region");
                  }}
                />
              )}
            />
          </Grid>
          <Grid item xs={4}>
            <FormLabel>
              <Box display={"flex"}>
                <span>{t('procedureType')}</span>
                {(isShowProcedureType || isProcedureTypeMandatory) &&
                  !noRequirement && <span style={{ color: "red" }}> * </span>}
              </Box>
            </FormLabel>
            <Controller
              name="procedureType"
              control={control}
              rules={{
                required:
                  (isShowProcedureType || isProcedureTypeMandatory) &&
                  !noRequirement
                    ?t("fieldRequired", { field: t("procedureType") })
                    : false,
              }}
              render={({ field }) => (
                <CustomAutoComplete
                  {...field}
                  options={procedureTypeoptions}
                  getOptionLabel={(option) => option.label || ""}
                  isOptionEqualToValue={(option, value) =>
                    option.value === value.value
                  }
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      error={!!errors.procedureType?.message}
                      inputProps={{
                        ...params.inputProps,
                      }}
                      helperText={errors.procedureType?.message ?? ""}
                    />
                  )}
                  onChange={(_, value) => {
                    field.onChange(value);
                    clearErrors("procedureType");
                  }}
                  // disabled={!isShowProcedureType}
                  // value={
                  //   !isShowProcedureType
                  //     ? { label: "National", value: "National" }
                  //     : field.value
                  // }
                />
              )}
            />
          </Grid>
          {!(isShowLmsAndMs || isShowRmsAndCms || isShowRmsAndMsc) && (
            <Grid item xs={4}>
              <FormLabel>
                <Box display="flex">
                  <span>{t('countries')}</span>
                  <span style={{ color: "red" }}> * </span>
                </Box>
              </FormLabel>
              <Controller
                name="country"
                control={control}
                rules={{ required: t("fieldRequired", { field: t("countries") }) }}
                render={({ field }) => (
                  <CustomAutoComplete
                    {...field}
                    options={countryOptions}
                    getOptionLabel={(option) => option.label || ""}
                    isOptionEqualToValue={(option, value) =>
                      option.value === value.value
                    }
                    renderTags={(selectedOptions: any) => {
                      const selectedLabels = selectedOptions
                        .map((option: any) => option.label)
                        .join(", ");
                      return (
                        <Tooltip title={selectedLabels}>
                          <Chip label={selectedOptions.length + " selected"} />
                        </Tooltip>
                      );
                    }}
                    disableCloseOnSelect
                    renderInput={(params) => (
                      <TextField
                        {...params}
                        inputProps={{
                          ...params.inputProps,
                        }}
                        error={!!errors.country}
                        helperText={errors.country?.message}
                      />
                    )}
                    onChange={(_, value) => {
                      field.onChange(value);
                      if (Array.isArray(value)) {
                        setSelectedCountry(value.map((item) => item.value));
                      } else {
                        setSelectedCountry(value?.value || "");
                      }
                      clearErrors("country");
                    }}
                    disabled={isCountrySameWithRegion} // Disable if isCountrySameWithRegion is true
                    multiple={
                      !isShowProcedureType ||
                      (isShowProcedureType &&
                        procedureType?.code === "ProcedureType_PCT00006") ||
                      isCountrySameWithRegion
                    }
                  />
                )}
              />
            </Grid>
          )}
          {isShowLmsAndMs && (
            <>
              <Grid item xs={4} marginBottom={2}>
                <FormLabel>
                  <Box display={"flex"}>
                    <span>{t('lms')+' '+t('country')}</span>
                    <span style={{ color: "red" }}> * </span>
                  </Box>
                </FormLabel>
                <Controller
                  name="lmsCountry"
                  control={control}
                  rules={{ required: t("fieldRequired", { field: t('lms')+' '+t('country') }) }}
                  render={({ field }) => (
                    <CustomAutoComplete
                      {...field}
                      // valuePrimitive={true}
                      // valueField={"value"}
                      options={realCountryOptions}
                      getOptionLabel={(option) => option.label || ""}
                      getOptionDisabled={(option) =>
                        !!msCountry?.find((item) => item.value === option.value)
                      }
                      isOptionEqualToValue={(option, value) =>
                        option.value === value.value
                      }
                      renderInput={(params) => (
                        <TextField
                          {...params}
                          // label="LMS Country"
                          inputProps={{
                            ...params.inputProps,
                          }}
                          error={!!errors.lmsCountry?.message}
                          helperText={errors.lmsCountry?.message ?? ""}
                        />
                      )}
                      onChange={(_, value) => {
                        field.onChange(value);
                        clearErrors("lmsCountry");
                      }}
                    />
                  )}
                />
              </Grid>
              <Grid item xs={4} marginBottom={2}>
                <FormLabel>
                  <Box display={"flex"}>
                    <span>{t('ms')+' '+t('country')}(s)</span>
                    <span style={{ color: "red" }}> * </span>
                  </Box>
                </FormLabel>
                <Controller
                  name="msCountry"
                  control={control}
                  rules={{ required: t("fieldRequired", { field: t('ms')+' '+t('country')}) }}
                  render={({ field }) => (
                    <CustomAutoComplete
                      {...field}
                      // valuePrimitive={true}
                      // valueField={"value"}

                      multiple={true}
                      renderTags={(selectedOptions: any) => {
                        const selectedLabels = selectedOptions
                          .map((option: any) => option.label)
                          .join(", ");
                        return (
                          <Tooltip title={selectedLabels}>
                            <Chip
                              label={selectedOptions.length + " selected"}
                            />
                          </Tooltip>
                        );
                      }}
                      disableCloseOnSelect
                      options={realCountryOptions}
                      getOptionLabel={(option) => option.label || ""}
                      getOptionDisabled={(option) =>
                        lmsCountry?.value === option.value
                      }
                      isOptionEqualToValue={(option, value) =>
                        option.value === value.value
                      }
                      renderInput={(params) => (
                        <TextField
                          {...params}
                          // label="MS Country(s)"
                          inputProps={{
                            ...params.inputProps,
                          }}
                          error={!!errors.msCountry?.message}
                          helperText={errors.msCountry?.message ?? ""}
                        />
                      )}
                      onChange={(_, value) => {
                        field.onChange(value);
                        clearErrors("msCountry");
                      }}
                    />
                  )}
                />
              </Grid>
            </>
          )}
          {isShowRmsAndCms && (
            <>
              <Grid item xs={4} marginBottom={2}>
                <FormLabel>
                  <Box display={"flex"}>
                    <span>{t('rms')+' '+t('country')}</span>
                    <span style={{ color: "red" }}> * </span>
                  </Box>
                </FormLabel>
                <Controller
                  name="rmsCountry"
                  control={control}
                  rules={{ required: t("fieldRequired", { field: t('rms')+' '+t('country') }) }}
                  render={({ field }) => (
                    <CustomAutoComplete
                      {...field}
                      // valuePrimitive={true}
                      // valueField={"value"}
                      options={realCountryOptions}
                      getOptionLabel={(option) => option.label || ""}
                      getOptionDisabled={(option) =>
                        !!cmsCountry?.find(
                          (item) => item.value === option.value
                        )
                      }
                      isOptionEqualToValue={(option, value) =>
                        option.value === value.value
                      }
                      renderInput={(params) => (
                        <TextField
                          {...params}
                          // label="RMS Country"
                          inputProps={{
                            ...params.inputProps,
                          }}
                          error={!!errors.rmsCountry?.message}
                          helperText={errors.rmsCountry?.message ?? ""}
                        />
                      )}
                      onChange={(_, value) => {
                        field.onChange(value);
                        clearErrors("rmsCountry");
                      }}
                    />
                  )}
                />
              </Grid>
              <Grid item xs={4} marginBottom={2}>
                <FormLabel>
                  <Box display={"flex"}>
                    <span>{t('cms')+' '+t('country')}(s)</span>
                    <span style={{ color: "red" }}> * </span>
                  </Box>
                </FormLabel>
                <Controller
                  name="cmsCountry"
                  control={control}
                  rules={{ required: t("fieldRequired", { field: t('cms')+' '+t('country') }) }}
                  render={({ field }) => (
                    <CustomAutoComplete
                      {...field}
                      renderTags={(selectedOptions: any) => {
                        const selectedLabels = selectedOptions
                          .map((option: any) => option.label)
                          .join(", ");
                        return (
                          <Tooltip title={selectedLabels}>
                            <Chip
                              label={selectedOptions.length + " selected"}
                            />
                          </Tooltip>
                        );
                      }}
                      disableCloseOnSelect
                      // valuePrimitive={true}
                      // valueField={"value"}
                      multiple={true}
                      // labelField="label"
                      options={realCountryOptions}
                      getOptionLabel={(option) => option.label || ""}
                      getOptionDisabled={(option) =>
                        rmsCountry?.value === option.value
                      }
                      isOptionEqualToValue={(option, value) =>
                        option.value === value.value
                      }
                      renderInput={(params) => (
                        <TextField
                          {...params}
                          // label="CMS Country(s)"
                          inputProps={{
                            ...params.inputProps,
                          }}
                          error={!!errors.cmsCountry?.message}
                          helperText={errors.cmsCountry?.message ?? ""}
                        />
                      )}
                      onChange={(_, value) => {
                        field.onChange(value);
                        clearErrors("cmsCountry");
                      }}
                    />
                  )}
                />
              </Grid>
            </>
          )}
          {isShowRmsAndMsc && (
            <>
              <Grid item xs={4} marginBottom={2}>
                <FormLabel>
                  <Box display={"flex"}>
                    <span>{t('rms')+' '+t('country')}</span>
                    <span style={{ color: "red" }}> * </span>
                  </Box>
                </FormLabel>
                <Controller
                  name="rmsCountry"
                  control={control}
                  rules={{ required: t("fieldRequired", { field: t('rms')+' '+t('country') }) }}
                  render={({ field }) => (
                    <CustomAutoComplete
                      {...field}
                      options={realCountryOptions}
                      getOptionLabel={(option) => option.label || ""}
                      getOptionDisabled={(option) =>
                        !!mscCountry?.find(
                          (item) => item.value === option.value
                        )
                      }
                      isOptionEqualToValue={(option, value) =>
                        option.value === value.value
                      }
                      renderInput={(params) => (
                        <TextField
                          {...params}
                          inputProps={{
                            ...params.inputProps,
                          }}
                          error={!!errors.rmsCountry?.message}
                          helperText={errors.rmsCountry?.message ?? ""}
                        />
                      )}
                      onChange={(_, value) => {
                        field.onChange(value);
                        clearErrors("rmsCountry");
                      }}
                    />
                  )}
                />
              </Grid>
              <Grid item xs={4} marginBottom={2}>
                <FormLabel>
                  <Box display={"flex"}>
                    <span>{t('msc')+' '+t('country')}(s)</span>
                    {/* <span style={{ color: "red" }}> * </span> */}
                  </Box>
                </FormLabel>
                <Controller
                  name="mscCountry"
                  control={control}
                  // rules={{ required: "MSC Country(s) is required" }}
                  render={({ field }) => (
                    <CustomAutoComplete
                      {...field}
                      multiple
                      renderTags={(selectedOptions) => {
                        const selectedLabels = selectedOptions
                          .map((option) => option.label)
                          .join(", ");
                        return (
                          <Tooltip title={selectedLabels}>
                            <Chip
                              label={`${selectedOptions.length} selected`}
                            />
                          </Tooltip>
                        );
                      }}
                      disableCloseOnSelect
                      options={realCountryOptions}
                      getOptionLabel={(option) => option.label || ""}
                      getOptionDisabled={(option) =>
                        rmsCountry?.value === option.value
                      }
                      isOptionEqualToValue={(option, value) =>
                        option.value === value.value
                      }
                      renderInput={(params) => (
                        <TextField
                          {...params}
                          inputProps={{
                            ...params.inputProps,
                          }}
                          error={!!errors.mscCountry?.message}
                          helperText={errors.mscCountry?.message ?? ""}
                        />
                      )}
                      onChange={(_, value) => {
                        field.onChange(value);
                        clearErrors("mscCountry");
                      }}
                    />
                  )}
                />
              </Grid>
            </>
          )}
           {isShowEctdReceptionNumber && (
            <Grid item xs={4}>
              <FormControl fullWidth>
                <InputLabel id="application-id-label">
                  {t("eCTDReceptionNumber")}
                </InputLabel>
                <Controller
                  name="eCTDReceptionNumber"
                  control={control}
                  defaultValue=""
                  render={({ field }) => (
                    <TextField
                      size="small"
                      placeholder={t("eCTDReceptionNumber")}
                      // value={eCTDReceptionNumber}
                      onChange={(event) => {
                        const inputValue = event.target.value;
                        field.onChange(inputValue)
                        clearErrors("eCTDReceptionNumber");
                      }}
                      error={error}
                      InputProps={{
                        style: {
                          borderColor: error ? "red" : "inherit",
                        },
                        inputProps: { maxLength: 11 },
                        autoComplete: "off",
                      }}
                    />
                  )}
                />
              </FormControl>
            </Grid>
          )}
          <Grid item xs={4}>
            <FormControl fullWidth>
              <FormLabel>
                <Box display="flex">
                  <span>{t('applicationName')}</span>
                  {isNameMandatory && <span style={{ color: "red" }}> * </span>}
                </Box>
              </FormLabel>
              <Controller
                name="applicationName"
                control={control}
                defaultValue="" // Ensure the initial value is empty
                rules={{
                  required: isNameMandatory
                    ? t("fieldRequired", { field: t("applicationName") })
                    : false,
                }}
                render={({ field }) => (
                  <TextField
                    {...field}
                    size="small"
                    placeholder={t('applicationName')}
                    error={!!errors.applicationName}
                    helperText={
                      errors.applicationName
                        ? errors.applicationName.message
                        : ""
                    }
                    InputProps={{
                      style: {
                        borderColor: errors.applicationName ? "red" : "inherit",
                      },
                      inputProps: { maxLength: 1000 },
                      autoComplete: "off",
                    }}
                    onBlur={(event) => {
                      field.onBlur();
                      clearErrors("applicationName");
                    }}
                    onChange={(event) => {
                      field.onChange(event);
                      clearErrors("applicationName");
                    }}
                  />
                )}
              />
            </FormControl>
          </Grid>
          {isShowApplicationId && (
            <Grid item xs={4}>
              <FormControl fullWidth>
                <InputLabel id="application-id-label">
                  {t("application_id")}
                </InputLabel>
                <Controller
                  name="applicationId"
                  control={control}
                  defaultValue=""
                  render={({ field }) => (
                    <TextField
                      size="small"
                      placeholder={t("application_id")}
                      value={applicationId}
                      onChange={(event) => {
                        const inputValue = event.target.value;
                        field.onChange(inputValue)
                        setApplicationId(inputValue);
                        clearErrors("applicationId");
                      }}
                      error={error}
                      InputProps={{
                        style: {
                          borderColor: error ? "red" : "inherit",
                        },
                        inputProps: { maxLength: 20 },
                        autoComplete: "off",
                      }}
                    />
                  )}
                />
              </FormControl>
            </Grid>
          )}
          {isDossIdentifier && (
            <>
              <Grid item xs={4}>
                <FormControl fullWidth>
                  <InputLabel id="demo-simple-select-label">
                    {t("dossier_identifier")}
                  </InputLabel>
                  <Controller
                    name="dossierIdentifier"
                    control={control}
                    render={({ field }) => (
                      <TextField
                        size="small"
                        placeholder={t("dossier_identifier")}
                        onChange={(event) => {
                          field.onChange(event.target.value);
                          setDossierIdentifier(event.target.value);
                          clearErrors("dossierIdentifier");
                        }}
                        style={{ borderColor: error ? "red" : "inherit" }}
                        InputProps={{
                          style: {
                            borderColor: error ? "1px red solid" : "inherit",
                          },
                          inputProps: { maxLength: 20 },
                          autoComplete: "off",
                        }}
                      />
                    )}
                  />
                </FormControl>
              </Grid>
            </>
          )}
          <Grid item xs={4}>
            <FormControl fullWidth>
              <FormLabel>
                <Box display="flex">
                  <span>{t('applicationNumber')}</span>
                  {isNumberMandatory && (
                    <span style={{ color: "red" }}> * </span>
                  )}
                </Box>
              </FormLabel>
              <Controller
                name="applicationNumber"
                control={control}
                defaultValue=""
                rules={{
                  required: isNumberMandatory
                    ? t("fieldRequired", { field: t("applicationNumber") })
                    : false,
                }}
                render={({ field }) => (
                  <TextField
                    {...field}
                    size="small"
                    placeholder={t('applicationNumber')}
                    error={!!errors.applicationNumber}
                    helperText={
                      errors.applicationNumber
                        ? errors.applicationNumber.message
                        : ""
                    }
                    InputProps={{
                      style: {
                        borderColor: errors.applicationNumber
                          ? "red"
                          : "inherit",
                      },
                      inputProps: { maxLength: 20 },
                      autoComplete: "off",
                    }}
                    onBlur={(event) => {
                      field.onBlur();
                      clearErrors("applicationNumber");
                    }}
                  />
                )}
              />
            </FormControl>
          </Grid>
          {isEidentifier && (
            <Grid item xs={4}>
              <FormControl fullWidth>
                <InputLabel id="demo-simple-select-label">
                  {t("e_Identifier")}
                </InputLabel>

                <Controller
                  name="eIdentifier"
                  control={control}
                  render={({ field }) => (
                    <TextField
                      {...field}
                      size="small"
                      placeholder={t("e_Identifier")}
                      onChange={(event) => {
                        field.onChange(event.target.value);

                        setEIdentifier(event.target.value);

                        clearErrors("eIdentifier");
                      }}
                      style={{ borderColor: error ? "red" : "inherit" }}
                      InputProps={{
                        style: {
                          borderColor: error ? "1px red solid" : "inherit",
                        },
                        inputProps: { maxLength: 20 },
                        autoComplete: "off",
                      }}
                    />
                  )}
                />
              </FormControl>
            </Grid>
          )}
          {isESubIdentifier && (
            <Grid item xs={4}>
              <FormControl fullWidth>
                <InputLabel id="demo-simple-select-label">
                  {t("e_submission_identifier")}
                </InputLabel>
                <Controller
                  name="eSubIdentifier"
                  control={control}
                  render={({ field }) => (
                    <TextField
                      {...field}
                      size="small"
                      placeholder={t("e_submission_identifier")}
                      onChange={(event) => {
                        field.onChange(event.target.value);

                        setESubmissionIdentifier(event.target.value);

                        clearErrors("eSubIdentifier");
                      }}
                      style={{ borderColor: error ? "red" : "inherit" }}
                      InputProps={{
                        style: {
                          borderColor: error ? "1px red solid" : "inherit",
                        },
                        inputProps: { maxLength: 20 },
                        autoComplete: "off",
                      }}
                    />
                  )}
                />
              </FormControl>
            </Grid>
          )}
          <Grid item xs={4}>
            <FormLabel>
              <Box display={"flex"}>
                <span>{t('applicationType')}</span>
                {isTypeMandatory && <span style={{ color: "red" }}> * </span>}
              </Box>
            </FormLabel>
            <Controller
              name="applicationType"
              control={control}
              rules={{
                required: isTypeMandatory
                  ? t("fieldRequired", { field: t("applicationType") })
                  : false,
              }}
              render={({ field }) => (
                <CustomAutoComplete
                  {...field}
                  // valuePrimitive={true}
                  // valueField={"value"}
                  options={Array.from(
                    new Set(applicationTypeOptions.map((item:any) => JSON.stringify(item)))
                  ).map((item:any) => JSON.parse(item))}
                  getOptionLabel={(option) => option.label || ""}
                  isOptionEqualToValue={(option, value) =>
                    option.value === value.value
                  }
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      error={!!errors.applicationType?.message}
                      inputProps={{
                        ...params.inputProps,
                      }}
                      helperText={errors.applicationType?.message ?? ""}
                    />
                  )}
                  onChange={(_, value) => {
                    field.onChange(value);
                    clearErrors("applicationType");
                  }}
                />
              )}
            />
          </Grid>
          {isProcedureNumber && (
            <Grid item xs={4}>
              <FormControl fullWidth>
                <InputLabel id="procedure-number-label">
                  {t("procedure_number")}
                </InputLabel>
                <Controller
                  name="procedureNumber"
                  control={control}
                  defaultValue=""
                  render={({ field }) => (
                    <TextField
                      {...field}
                      size="small"
                      placeholder={t("procedure_number")}
                      value={procedureNumber}
                      onChange={(event) => {
                        setProcedureNumber(event.target.value);
                        field.onChange(event);
                        clearErrors("procedureNumber");
                      }}
                      InputProps={{
                        inputProps: { maxLength: 20 },
                        autoComplete: "off",
                      }}
                    />
                  )}
                />
              </FormControl>
            </Grid>
          )}
          {isRegistrationId && (
            <Grid item xs={4}>
              <FormControl fullWidth>
                <InputLabel id="registration-id-label">
                  {t("registrationId")}
                </InputLabel>
                <Controller
                  name="registrationId"
                  control={control}
                  defaultValue={registrationId}
                  render={({ field }) => (
                    <TextField
                      {...field}
                      size="small"
                      placeholder={t("registrationId")}
                      value={registrationId}
                      onChange={(event) => {
                        setRegistrationId(event.target.value);
                        field.onChange(event);
                        clearErrors("registrationId");
                      }}
                      InputProps={{
                        inputProps: { maxLength: 20 },
                        autoComplete: "off",
                      }}
                    />
                  )}
                />
              </FormControl>
            </Grid>
          )}{" "}
        </Grid>
      </form>
    </Box>
  );
};

export default LinkCountry;
