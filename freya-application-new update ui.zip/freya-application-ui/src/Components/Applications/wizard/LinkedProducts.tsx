import { Box, Button, Dialog, DialogActions, DialogContent, DialogTitle, FormControl, FormLabel, Grid, IconButton, InputLabel, MenuItem, Select, TextField, Typography } from "@mui/material";
import {
  DataGridPremium,
  GridRowParams,
  GridRowSelectionModel,
  GridToolbar,
} from "@mui/x-data-grid-premium";
import React, { forwardRef, useImperativeHandle, useContext, useEffect,  useState } from "react";


import Loading from "../components/Loading";
import NoDataAvailable from "../components/NoDataAvailable";
import  { GET_API } from "../../../Services/apiheader";
import {
  Product,
  accessToken
} from "../../../types";
import axios from "axios";
import { RowContext } from "../../../App";
import { getGridFields } from "../../../DynamicGrid/headerConfig";
import useGridConfig from "../../../DynamicGrid/useGridConfig";
import { getProductPhaseId } from "../../../apis/apiFunctions";
import { useTranslation } from "react-i18next";
import { useDataGridLocalText } from "../../../Audit/useDataGridLocalText";
import CloseIcon from '@mui/icons-material/Close'; // Import close icon
import AlertIcon from "../../../assets/Alert Icon.png"



interface ComponentsProps {
  rowSelectionModel: GridRowSelectionModel;
  setRowSelectionModel: (rowSelectionModel: GridRowSelectionModel) => void;
}

type LinkProductsRef = {
  validateSelection: () => boolean;
};

export const sortFn = (a: any, b: any) => {
  return a.order - b.order;
};

  const LinkProducts = forwardRef<LinkProductsRef, ComponentsProps>((props, ref) => {
  const { setSelectedRow } = useContext(RowContext);
  const { rowSelectionModel, setRowSelectionModel } = props;
  const [productData, setProductData] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [gridFields,setGridFields]=useState([]);
  const {t}=useTranslation();
  const {localeText} = useDataGridLocalText();
  const [alertVisible, setAlertVisible] = useState(false);
  const [openValidationDialog, setOpenValidationDialog] = useState(false);



  const checkSelectedRecords = () => {
    if (rowSelectionModel.length>1) {
      const selectedRows: Product[] = productData.filter((row: Product) =>
        rowSelectionModel.includes(row.id)
      );

      const firstRow = selectedRows[0];
      const allMatch = selectedRows.every((row: Product) =>
        row.productPhase === firstRow.productPhase &&
        row.productCategory === firstRow.productCategory &&
        row.productFamily === firstRow.productFamily &&
        (row.pharmaceuticalDoseForm === firstRow.pharmaceuticalDoseForm && row.combinedPharmaceuticalDoseForm === firstRow.combinedPharmaceuticalDoseForm && row.combinationPackage===firstRow.combinationPackage) 
      );

      if (!allMatch) {
        setAlertVisible(true);
        return false;
      }
    }
    return true;
  };

  useImperativeHandle(ref, () => ({
    validateSelection: () => {
      if (!checkSelectedRecords()) {
        setOpenValidationDialog(true);
        return false;
      }
      return true;
    },
  }));



  const fetchProducts = async () => {
    const response = await axios.post(
      GET_API + `product/products/page`,
      { 
        pageNum: 1,
        pageSize: 999999,
        showActive: true,
        showDisable: false,
        showInactive: false,
      },
      {
        headers: {
          Authorization: `Bearer ${accessToken}`,
          "Accept":"*/*",
          'Accept-Language': ""
        },
      }
    );



    const products = response.data;
    setIsLoading(false);
    setProductData(products.data.data);
  };

  const fetchGridConfig = async () => {
    const params={
      module: "product",
      gridName: "Product Information",
    }
    const gridfields = await getGridFields(setIsLoading,params);
    setIsLoading(false);
    setGridFields(gridfields);
  };

  const { columnVisibilityModel, columns, setColumnVisibilityModel } = useGridConfig(
    [],
    gridFields
  );

  useEffect(() => {
    fetchProducts();
    fetchGridConfig();
  }, []);



return (
  <Box className="link-product">
   
      <Typography variant="body2" color="textSecondary" gutterBottom sx={{ marginTop: 2, fontWeight: "bold" }}>
        <strong>{t("Note")}:</strong> {t("noteMessageInAdd")}
      </Typography>
  
    <Box data-testid="product-grid">


    
    <br/>
    {/* Render DataGridPremium regardless of multiProduct value */}
    <DataGridPremium
      disableVirtualization
      disableAggregation
      sx={{
        "& .MuiDataGrid-columnHeaderCheckbox .MuiDataGrid-columnHeaderTitleContainer": {
          display: "none"
        }
      }}
      rows={productData} // Use filtered data
      columns={columns}
      columnVisibilityModel={columnVisibilityModel}
      columnHeaderHeight={32}
      className="react-table table_size-has--row1 product-link-table add-application_table"
      rowHeight={38}
      pageSizeOptions={[10, 20, 50]}
      pagination
      slots={{
        toolbar: GridToolbar,
        noRowsOverlay: () => <NoDataAvailable />,
      }}
      initialState={{
        pagination: {
          paginationModel: { pageSize: 10, page: 0 },
        },
      }}
      slotProps={{
        toolbar: {
          filterModel: true,
          showQuickFilter: true,
          utf8WithBom: true,
          csvOptions: {
            utf8WithBom: true,
          },
        },
      }}
      localeText={localeText}
      checkboxSelection={true} 
      isRowSelectable={(params: GridRowParams) => {
        const stringId = `${params.id}`;
        return !stringId.includes('auto-generated-row')
      }}
      rowSelectionModel={rowSelectionModel}
      onColumnVisibilityModelChange={(newModel) =>
        setColumnVisibilityModel(newModel)
      }
      onRowSelectionModelChange={async (newSelection) => {
        // If multiProduct is true, allow multiple selections
        setRowSelectionModel(newSelection);
    
        // Get data for all selected rows
        const selectedRowsData = productData
          .filter((row: Product) => newSelection.includes(row.id))
          .map(async (row: any) => ({
            ...row,
            productPhaseId: row.productPhase
              ? await getProductPhaseId(t(row.productPhase))
              : "",
          }));
    
        // Wait for all productPhaseId resolutions
        const resolvedRowsData = await Promise.all(selectedRowsData);
        console.log(resolvedRowsData, " ", rowSelectionModel);
        // Store all selected rows
        setSelectedRow(resolvedRowsData);
      }}
    />
    </Box>
    <Loading open={isLoading} />

<Dialog
  open={openValidationDialog}
  onClose={() => setOpenValidationDialog(false)}
  aria-labelledby="validation-dialog-title"
  aria-describedby="validation-dialog-description"
  maxWidth="md"
  fullWidth
  sx={{ '& .MuiDialog-paper': { minHeight: '400px', minWidth: '600px' } }} // Increase size
  data-testId="dialog"
>
  <DialogTitle id="validation-dialog-title" sx={{ position: 'relative' }}>
    <Typography variant="h6">{t("Product Selection")}</Typography>
    <IconButton
      onClick={() => setOpenValidationDialog(false)}
      sx={{ position: 'absolute', right: 8, top: 8 }}
    >
      <CloseIcon />
    </IconButton>
  </DialogTitle>
  <DialogContent sx={{ textAlign: 'center' }}>
    <Box
    component="img"
    src={AlertIcon}
    alt="Warning"
    sx={{ marginTop: 5 }} // Set the size of the image
    // sx={{ width: 250, height: 120, marginBottom: 5 }} // Set the size of the image
  />
    <Typography variant="body1" sx={{ fontSize: '24px', marginTop: 5}}>
      {t('cautionWarningMessage')}
    </Typography>
  </DialogContent>
  <DialogActions>
    <Button onClick={() => setOpenValidationDialog(false)} color="primary" variant="contained">
      {t('Close')}
    </Button>
  </DialogActions>
</Dialog>
  </Box>
);
  
});

export default LinkProducts;