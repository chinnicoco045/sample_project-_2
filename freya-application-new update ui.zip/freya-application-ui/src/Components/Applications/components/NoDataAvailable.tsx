import React from "react";
import { Box } from "@mui/material";
import { useTranslation } from "react-i18next";
import "../../../assets/no-data-anim2.webp"
const NoDataAvailable: React.FC<{
  text?: string;
  bgColor?: string;
}> = ({ text, bgColor = "" }) => {
  const { t } = useTranslation();
  return (
    <Box
      data-testid="boxb"
      sx={{
        height: "100%",
        width: "100%",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        maxWidth: "100%",
        maxHeight: "100%",
        overflow: "hidden",
        boxSizing: "border-box",
      }}
    >
      <Box
        data-testid="box"
        className="no-data"
        sx={{
          position: "relative",
          width: "100%",
          textAlign: "center",
          margin: "var(--ff-space-littlecomfort) var(--ff-space-nospace)",
        }}
      >
         <img
          src={require("../../../assets/no-data-anim2.webp")}
          alt="No Data Available"
          style={{ width: "200px", opacity: 1 }}
        ></img>
        
        <br></br>
        <span
        data-testid="no-data-available"
        role="progressbar"
        style={{
          fontWeight: "var(--ff-font-weight-500)",
          color: "var(--ff-black-700)",
          position: "absolute",
          width: "100%",
          textAlign: "center",
          left: 0,
          top: "115px", // Adjust top position as needed
          fontSize: "var(--ff-font-size-body-verysmall)", // Font size from variables
        }}
        >{text ?? t('noDataAvailable')}</span>
      </Box>
    </Box>
  );
};

export default NoDataAvailable;
