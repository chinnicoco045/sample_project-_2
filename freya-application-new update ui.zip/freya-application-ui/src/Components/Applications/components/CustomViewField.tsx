import { Box, Tooltip, FormLabel, FormControl, Grid } from "@mui/material";

export interface fieldItem {
  label: string; value: any; xs?: number
}
interface CustomViewProps {
  fields: fieldItem[];
}
function CustomViewField(props: CustomViewProps) {
  const { fields } = props;
  return (
    <Grid
      container
      spacing={0}
      columnGap={0}
      style={{ marginTop: "10px", marginBottom: "20px" }}
    >
      {fields.map((item, index: number) => {
        return (
          <Grid item={true} xs={item.xs || 12} key={index}>
            <Box className="form-group field field-string">
              <FormControl>
                <Box>
                  <FormLabel
                    required={false}
                    className="text-ellipsis"
                    sx={{
                      textAlign: "left",
                      my: 1,
                      display: "flex",
                      alignItems: "center",
                      color: "initial",
                      position: "relative",
                    }}
                  >
                    <Box flex={1} overflow={"hidden"} display={"flex"}>
                      {" "}
                      <Tooltip title={item.label}>
                        <span className="text-ellipsis">{item.label}</span>
                      </Tooltip>
                    </Box>
                  </FormLabel>
                  <Tooltip placement="bottom-start" title={item.value}>
                    <Box marginTop={"10px"}>{item.value || "-"}</Box>
                  </Tooltip>
                </Box>
              </FormControl>
            </Box>
          </Grid>
        );
      })}
    </Grid>
  );
}

export default CustomViewField;
