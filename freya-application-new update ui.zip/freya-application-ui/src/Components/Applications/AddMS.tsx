import { Autocomplete, Box, Button, Chip, Dialog, DialogActions, DialogContent, DialogTitle, FormControl, Grid, MenuItem, Switch, TextField, Tooltip } from '@mui/material'
import React, { useEffect, useMemo, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { StyledMenu } from './AddApplication';
import { Link } from 'react-router-dom';
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import { fetchCountryOptions, fetchRepeatUserwaves } from '../../apis/apiFunctions';
import { forEach } from 'lodash';
import service from '../../Services/apiheader';
import Cookies from 'js-cookie';
import TagIcon from '@mui/icons-material/LocalOfferOutlined'; // Icon for the tag
import { useSnackbar } from 'notistack';


interface AddMSProps {
  mode:any;
    memberState:any;
    data: any;
    applicationDetails:any; 
    setTrigger: (value: boolean) => void;
    checked:boolean;
    setChecked: (value:boolean)=>void;
    productName: string; 
    countryName: string;  
// Replace 'any' with the actual type if known
  }

  interface WaveType{
    name:string;
    code:string;
    id:string;
  }

function AddMS({ mode,data,applicationDetails,setTrigger ,checked,setChecked,memberState,productName,
  countryName,}: AddMSProps) {
const {t}=useTranslation();

 const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null);
 const [comments, setComments] = useState("");
 const[countryOptions,setCountryOptions]=useState([]);
 const [waveOptions,setWaveOptions]=useState([]);
 const [dialogOpen,setDialogOpen]=useState(false);
 const cellData = sessionStorage.getItem('CellData');
 const parsedCellData = cellData ? JSON.parse(cellData) : null;
 const region = parsedCellData?.applicationData?.region;
 const leadCountry=parsedCellData?.applicationData?.country;
 const cell = JSON.parse(sessionStorage.getItem('CellData') || '{}');
 const [selectedCountries,setSelectedCountries]=useState([]);
 const[selectedWave,setSelectedWave]=useState<WaveType | undefined>(undefined);
 const [countryError, setCountryError] = useState(false);
  const [waveError, setWaveError] = useState(false);
  const [isSaving, setIsSaving] = useState(false); 
  const {enqueueSnackbar}=useSnackbar();



  const open = Boolean(anchorEl);
  const handleClick = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };
  const handleChange=(event: React.ChangeEvent<HTMLInputElement>)=>{
    const isChecked = event.target.checked;
    setChecked(isChecked);
  }
  const addMemberState=()=>{
    setDialogOpen(true);
  }
  const onClose=()=>{

  }
  const onClickNo=()=>{
    setCountryError(false);
    setWaveError(false);
     setDialogOpen(false);
     setSelectedCountries([]);
     setSelectedWave(undefined);
  }
  const additionConfirm = async () => {
     if (isSaving) return;
    let valid = true;

    if (selectedCountries.length === 0) {
        setCountryError(true);
        valid = false;
    } else {
        setCountryError(false);
    }

    if (!selectedWave) {
        setWaveError(true);
        valid = false;
    } else {
        setWaveError(false);
    }

    if (!valid) {
        return;
    }
    setIsSaving(true); 
    const newWaveInfo = selectedCountries.map((country:any) => ({
      countryCode: country.value,
      countryName:country.label,
      waveName: selectedWave?.name || "",
      waveCode: selectedWave?.code || "",
      comments:comments
    }));
  
    // Check if waveInfo exists and merge it with newWaveInfo
    const existingWaveInfo = applicationDetails.applicationdata.waveInfo || [];
    const updatedWaveInfo = [
      ...existingWaveInfo,
      ...newWaveInfo
    ];
  
    const updatedRow = {
      application_identifier: applicationDetails.application_identifier,
      groupid: applicationDetails.groupid,
      applicationdata: {

        ...applicationDetails.applicationdata,
        memberStates: [
          ...applicationDetails.applicationdata.msCountryCode,
          ...selectedCountries.map((country:any) => country.value)
        ],
        msCountryCode: [
          ...applicationDetails.applicationdata.msCountryCode,
          ...selectedCountries.map((country:any) => country.value)
        ],
        waveInfo: updatedWaveInfo, // Update the waveInfo here
      },
      created_by: applicationDetails?.created_by,
      updated_by: Cookies.get("USER_EMAIL"),
      domain_id: Cookies.get("DOMAIN")
    };
    const existingMemberStates = JSON.parse(sessionStorage.getItem("memberStates") || "[]");

const updatedMemberStates = [
  ...existingMemberStates, 
  ...selectedCountries.map((country: any) => country.label)
];
sessionStorage.setItem("memberStates", JSON.stringify(updatedMemberStates));
  
try {
  const response = await service.put(`application/v1/modification/${cell.id}`, updatedRow, {
    headers: {
      "X-TenantID": Cookies.get('USER_TENANT_ID')
    }
  });
  console.log(response);
  setTrigger(true);
  setDialogOpen(false);
  enqueueSnackbar(t('AddMSSuccessTip'), { variant: "success", anchorOrigin: { vertical: 'top', horizontal: 'center' } });
  setComments("");
  setSelectedCountries([]);
  setSelectedWave(undefined);
} catch (error) {
  console.error("Error saving data:", error);
  enqueueSnackbar(t('AddMSErrorTip'), { variant: "error", anchorOrigin: { vertical: 'top', horizontal: 'center' } });
} finally {
  setIsSaving(false); // Re-enable the save button
}
};
  
  
  
  useEffect(() => {
    const fetchData = async () => {
      try {
        const options = await fetchCountryOptions(region);
  
        // Ensure msCountryCode is always an array to avoid spread issues
        const msCountryCodeArray = Array.isArray(applicationDetails?.applicationdata?.msCountryCode) 
          ? applicationDetails.applicationdata.msCountryCode 
          : [];
  
        const filteredOptions = options?.filter(
          (option: any) => ![leadCountry, ...msCountryCodeArray].includes(option.value)
        );
  
        setCountryOptions(filteredOptions);
  
        const WOptions = await fetchRepeatUserwaves();
        setWaveOptions(WOptions);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };
  
    fetchData();
  }, [data]);
  
  

  const productnames = productName.length > 6 ? `${productName.slice(0, 6)}...` : productName;
  const countrynames = countryName.length > 6 ? `${countryName.slice(0, 6)}...` : countryName;
  
  return (
    <div>
      <Box className="main-page-title">
      <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
        <h4 className="list-header-title">{t("Member States")}</h4>
      <Tooltip title={productName} placement="bottom-start">
          <Chip
            icon={<TagIcon style={{ fontSize: 16, color: '#2e5aac', transform: 'rotate(133deg)', }} />}  
            label={productnames}                      
            style={{
              backgroundColor: '#EAF0FB',                    
              color: '#3F51B5',                              
              fontWeight: '500',                             
              borderRadius: '16px',                          
              fontSize: '2.25rem',                              
              padding: '2px 6px',                            
              height: '22px',  
              width : "100px",
              display: 'flex',                               
              alignItems: 'center',                         
            }}
          />
      </Tooltip>
      <Tooltip title={countryName} placement="bottom-start">
        <Chip
            icon={<TagIcon style={{ fontSize: 16, color: '#2e5aac', transform: 'rotate(133deg)', }} />}  
            label={countrynames}                              
            style={{
              width : "100px",
              backgroundColor: '#EAF0FB',                    
              color: '#3F51B5',                              
              fontWeight: '500',                             
              borderRadius: '16px',                          
              fontSize: '2.25rem',                              
              padding: '2px 6px',                            
              height: '22px',                                
              display: 'flex',                               
              alignItems: 'center',                         
            }}
          />
      </Tooltip>
        
        </div>
        <Box sx={{ flex: "1" }} />
        <FormControl>
          <Button
            id="demo-customized-button"
            aria-controls={open ? "demo-customized-menu" : undefined}
            aria-haspopup="true"
            aria-expanded={open ? "true" : undefined}
            variant="contained"
            color="secondary"
            disableElevation
            onClick={handleClick}
            endIcon={<KeyboardArrowDownIcon />}
          >
            {t("actions")}
          </Button>
          <StyledMenu
            id="demo-customized-menu"
            MenuListProps={{ "aria-labelledby": "demo-customized-button" }}
            anchorEl={anchorEl}
            open={open}
            onClose={handleClose}
          >
            <MenuItem onClick={handleClose} disableRipple>
              {t("show_dis")}{" "}
              <Switch checked={checked} onChange={handleChange} />
            </MenuItem>
          </StyledMenu> 
        </FormControl>
       
      {mode==="edit" && <Button variant="contained" onClick={addMemberState}>{t("add_ms")}</Button>}
        
      </Box>
      <Dialog
  className="popup-dialog"
  open={dialogOpen}
  onClose={(event, reason) => {
    if (reason !== 'backdropClick') {
      onClose();
    }
  }}
  disableEscapeKeyDown
  maxWidth="md"
  sx={{
    '.MuiDialog-paper': { width: '600px' }
  }}
>
  <DialogTitle>
   {t('addMemberStates')}
  </DialogTitle>
  <Box component="form" sx={{ display: 'flex', flexDirection: 'column' }}>
    <DialogContent className="form-group popup-content">
      <Grid container direction="column" spacing={2}>
        {/* First Dropdown */}
        <Grid item>
          <Autocomplete
            sx={{
              "& .MuiOutlinedInput-root": { padding: 0, "flex-wrap": "nowrap" },
              "& .MuiTextField-root": {
                marginLeft: 0,
                marginTop: 0,
                marginBottom: 0,
              },
              "& .MuiOutlinedInput-root .MuiAutocomplete-input": { border: "none" },
              "& .MuiFormControl-root .MuiInputBase-root input:focus": {
                outline: "none !important",
              },
              "& .MuiAutocomplete-inputRoot": { paddingLeft: "10px" },
              flex: 1,
            }}
            className="custom-autocomplete"
            options={countryOptions}
            multiple
            getOptionLabel={(option: any) => option.label || ""}
            renderTags={(selectedOptions: any) => {
                const selectedLabels = selectedOptions
                  .map((option: any) => option.label)
                  .join(", ");
                return (
                  <Tooltip title={selectedLabels}>
                    <Chip label={selectedOptions.length + " selected"} />
                  </Tooltip>
                );
              }}
              disableCloseOnSelect
            renderInput={(params: any) => (
              <TextField
                {...params}
                required
                label={t("country")}
                error={countryError}
                helperText={countryError ? t("Please select at least one country.") : ""}
                inputProps={{
                  ...params.inputProps,
                  onKeyDown: (e) => {
                    if (e.keyCode === 13) {
                      e.preventDefault();
                    }
                  },
                }}
              />
            )}
            onChange={(event: any, value: any) => {
            //   setDropdown1Value(value);
            setSelectedCountries(value);
            setCountryError(false);
            }}
          />
        </Grid>

        {/* Second Dropdown */}
        <Grid item>
          <Autocomplete
            sx={{
              "& .MuiOutlinedInput-root": { padding: 0, "flex-wrap": "nowrap" },
              "& .MuiTextField-root": {
                marginLeft: 0,
                marginTop: 0,
                marginBottom: 0,
              },
              "& .MuiOutlinedInput-root .MuiAutocomplete-input": { border: "none" },
              "& .MuiFormControl-root .MuiInputBase-root input:focus": {
                outline: "none !important",
              },
              "& .MuiAutocomplete-inputRoot": { paddingLeft: "10px" },
              flex: 1,
            }}
            className="custom-autocomplete"
            options={waveOptions}
            getOptionLabel={(option: any) => option.name || ""}
            renderInput={(params: any) => (
              <TextField
                {...params}
                required
                label={t("wave")}
                error={waveError}
                helperText={waveError ? t("Please select a wave.") : ""}
                inputProps={{
                  ...params.inputProps,
                  onKeyDown: (e) => {
                    if (e.keyCode === 13) {
                      e.preventDefault();
                    }
                  },
                }}
              />
            )}
            onChange={(event: any, value: any) => {
              setSelectedWave(value);
              setWaveError(false);
            }}
          />
        </Grid>

        {/* Comments Textarea */}
        <Grid item sx={{ marginTop: "24px", marginBottom: "20px" }}>
          <TextField
            size="small"
            label={t("comments")}

            inputProps={{ maxLength: 5000 }}
            multiline
            rows={4}
            value={comments}
            onChange={(event) => setComments(event.target.value)}
          />
          <span className="rtq-number-tips comment-count-right">
            {comments ? comments.length : 0} / 5000
          </span>
        </Grid>
      </Grid>
    </DialogContent>
    <DialogActions>
      <Button variant="text" size="small" onClick={onClickNo}>
        {t('cancel')}
      </Button>
      <Button
        variant="contained"
        size="small"
        onClick={additionConfirm}
        disabled={isSaving}
      >
        {t('save')}
      </Button>
    </DialogActions>
  </Box>
</Dialog>
    </div>
  )
}

export default AddMS
