// src/components/ApplicationDataGrid.tsx

import Box from "@mui/material/Box";
import { useCookies } from "react-cookie";
import "../../App.scss";
import * as React from "react";
import {
  DataGridPremium,
  GridToolbar,
  GridActionsCellItem,
  GridCloseIcon,
  GridColDef,
  GridRenderCellParams,
  GridColumnVisibilityModel,
  GridPaginationModel,
  GridToolbarQuickFilter,
} from "@mui/x-data-grid-premium";

import {  Grid, Tooltip, TableContainer, Table, TableHead, TableRow, TableBody, TableCell, Paper, Typography } from "@mui/material";
import EditIcon from "@mui/icons-material/Edit";
import EditNoteIcon from '@mui/icons-material/EditNote';
import RemoveRedEyeIcon from "@mui/icons-material/RemoveRedEye";
import AddApplication from "./AddApplication";
import NotInterestedIcon from "@mui/icons-material/NotInterested";
import { useState, useContext, useEffect } from "react";
import Row from "../../types";
import { useTranslation } from "react-i18next";
import { RowContext } from "../../App";
import { useNavigate } from "react-router-dom";
import service from "../../Services/apiheader";
import { getGridFields } from "../../DynamicGrid/headerConfig"; // Importing grid headers
import NoDataAvailable from "./components/NoDataAvailable";
import { GridColCommon } from "../../DynamicGrid/useGridConfig";
import Loading from "./components/Loading";
import DisableDialog from "./DisableDialog";
import { useSnackbar } from "notistack";
import { sortFn } from "./wizard/LinkedProducts";
import { GridManagerFieldItem } from "../../apis/api";
import Cookies from "js-cookie";
import { useUrfReceiveEvents } from "../../hooks/urfEvents";
import { useDataGridLocalText } from "../../Audit/useDataGridLocalText";
import { fetchCookies } from "../../apis/apiFunctions";
import CommonDialog from "./components/CommonDialog";
import axios from "axios";

export const validateUserPrivileges = (
  userPrivileges: string[],
  privilegeId: string
) => {
  return userPrivileges.includes(privilegeId);
};

const ApplicationDataGrid: React.FC = () => {
  const { rows, setRows, setIsDisabled, setIsAddPrivileged, showDisabled, setIsEditPrivilege,setPaginationobject,paginationTotalRecord ,gridstatus} =
    useContext(RowContext);
  const { t } = useTranslation();
  const {localeText}=useDataGridLocalText();
  const [disableConfirmationOpen, setDisableConfirmationOpen] = useState(false);
  const [selectedId, setSelectedId] = useState<number>();
  const [gridFields, setGridFields] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const { enqueueSnackbar } = useSnackbar();
  useUrfReceiveEvents();
  const [userPrivileges, setUserPrivileges] = useState<string[]>([]);
  const [disabledRecords, setDisabledRecords] = useState<Row[]>([]);
  const [openRecordDialog, setOpenRecordDialog] = useState<any>(false);
  const [relatedRecords, setRelatedRecords] = useState<any>([]);
  const [paginationModel, setPaginationModel] = useState<GridPaginationModel>({
    page: 0,       
    pageSize: 50, 
  });
  const [showPaginationMessage,setShowPaginationMessage] = useState<boolean>(false);

  const handleKeyDown = async (event: React.KeyboardEvent<HTMLInputElement>) => {
    const enteredValue = (event.target as HTMLInputElement).value;
    if (event.key === "Enter") {
      setPaginationModel({ page: 0,       
        pageSize: paginationTotalRecord, });
    }
    if(enteredValue.length>0){
      setShowPaginationMessage(true);
    }if(enteredValue.length<2){
      setShowPaginationMessage(false);
    }
  };

  useEffect(() => {
    const fetchPrivileges = async () => {
      try {
        const cookiesData = await fetchCookies();
        const privileges = cookiesData.map((cookie: any) => cookie.name);
        setUserPrivileges(privileges);
        setIsAddPrivileged(validateUserPrivileges(privileges, "add_application"));
        setIsEditPrivilege(validateUserPrivileges(privileges, "edit_application"));
      } catch (error) {
        console.error("Error fetching privileges:", error);
      }
    };
    fetchPrivileges();
  }, []);
  

  const linkTo = useNavigate();

  const staticColumn: GridColDef<GridColCommon>[] = [
    {
      field: "actions",
      type: "actions" as const,
      width: 70,
      headerName: t("actions"),
      getActions: (cell: any) => {
        const actions:any[] = [];

        if (String(cell.id).includes("auto-generated-row")) {
          return actions; // Return empty actions if condition is met
        }
        if(cell.row.status !== "Disable")
        if (userPrivileges && validateUserPrivileges(userPrivileges, "edit_application")) {
          actions.push(
            <GridActionsCellItem
              showInMenu
              label={t("edit")}
              onClick={() => handleEdit(cell.row.id, cell)}
              icon={<EditIcon />}
              data-testid="edit-icon" 
            />
          );
        }
        if (userPrivileges && validateUserPrivileges(userPrivileges, "view_application")) {
          actions.push(
            <GridActionsCellItem
              showInMenu
              label={t("view")}
              onClick={() => handleView(cell.id, cell)}
              icon={<RemoveRedEyeIcon />}
              data-testid="view-icon"
            />
          );
        }

        if(cell.row.status !== "Disable")
        if (userPrivileges &&
          validateUserPrivileges(userPrivileges, "delete_application")
        ) {
          actions.push(
            <GridActionsCellItem
              showInMenu
              label={t("disable")}
              onClick={() => handleDisableAction(cell.id)}
              icon={<NotInterestedIcon />}
              data-testid="disable-icon"
            />
          );
        }

        if(cell.row.status !== "Disable")
          if (userPrivileges && validateUserPrivileges(userPrivileges, "edit_application")) {
        actions.push(<GridActionsCellItem
          label={t("edit") + ' ' + t('product')}
          icon={<EditNoteIcon />}
          onClick={() => {
            handleEditProduct(cell.id,cell);
          }}
          showInMenu
          closeMenuOnClick={true}
        />)
          }
        return actions;
      },
    },
  ];

  
  const fetchGridConfig = async () => {
    const params={
      module:"applications",
      gridName:"Application"
    }
    let gridfields = await getGridFields(setIsLoading,params);
    gridfields.push(
      {
        "id": "statusid",
        "column": "Status",
        "type": "Mandatory",
        "gridAvailability": true,
        "visibility": true,
        "fieldName": "status",
        "order": gridfields.length + 1
    });
    setGridFields(gridfields);
  };

  useEffect(() => {
    fetchGridConfig();
  }, []);

  const [columnVisibilityModel, setColumnVisibilityModel] =
  useState<GridColumnVisibilityModel>({});

useEffect(() => {
  if (!gridFields) return;
  const gridColumnKey = {
    ...columnVisibilityModel,
  };
  gridFields
    ?.filter((item:GridManagerFieldItem) => item.gridAvailability)
    ?.forEach((item:GridManagerFieldItem) => {
      const key: string = item.fieldName;
      gridColumnKey[key] = item.visibility;
    });
  setColumnVisibilityModel({
    ...gridColumnKey,
  });
}, [gridFields,showDisabled]);

// Update the dynamicColumns mapping to handle recordId click
const columns: GridColDef[] = React.useMemo(() => {
  const dynamicColumns =
    gridFields
      ?.sort(sortFn)
      ?.filter((item: GridManagerFieldItem) => 
        item.gridAvailability && 
        !['lmsName', 'rmsName', 'cmsName', 'mscName', 'countryIdentifier'].some(name => item.fieldName.includes(name))
      )
      ?.map((item: GridManagerFieldItem) => {
        const headerName = t(item.fieldName, { defaultValue: item.column });

        return {
          field: item.fieldName,
          headerName,
          minWidth: 150,
          flex: 1,
          renderCell: (cellValues: GridRenderCellParams) => {
            if (String(cellValues.id).includes("auto-generated-row"))
              return cellValues.value;

            const value = cellValues.value;

            if (item.fieldName === 'recordID') {
              return value ? (
                <a 
                  href="#" 
                  onClick={(e) => {
                    e.preventDefault();
                    handleView(cellValues.id, cellValues);
                  }}
                  style={{ textDecoration: 'none', cursor: 'pointer' }}
                  rel="noopener noreferrer"
                >
                  {value}
                </a>
              ) : '-';
            }

            const formattedValue =
              value === null || value === undefined || value === ""
                ? "-"
                : isISODateString(value)
                ? formatDate(value)
                : Array.isArray(value)
                ? value.join(", ")
                : value;

            return (
              <Tooltip title={formattedValue} placement="right">
                <div>{formattedValue}</div>
              </Tooltip>
            );
          },
        };
      }) || [];
  return [...dynamicColumns, ...staticColumn];
}, [gridFields, staticColumn, showDisabled, !showDisabled]);




const isISODateString = (value: any): boolean => {
  // Regex pattern for ISO 8601 date format
  const isoDatePattern = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{3})?Z$/;
  return typeof value === 'string' && isoDatePattern.test(value);
};

 function formatDate(datestring: string){
  const currentDate = new Date(datestring);
  const day = currentDate.getDate().toString().padStart(2, '0');
  const monthName = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const month = monthName[currentDate.getMonth()];
  const year = currentDate.getFullYear();
  return `\t${day}/${month}/${year}`;
}

const getCellData = (cell: any) => {
  console.log(cell);
  sessionStorage.setItem("productName", cell.row.productName);
  
  const {
    id,
    mark_fordelete,
    created_by,
    created_date,
    updated_by,
    updated_date,
    domain_id,
    application_identifier,
    inactiveFlg,
    ...filteredRow // This keeps all other properties except the ones listed above
  } = cell.row;

  return {
    id: cell.row.id,
    application_identifier: cell.row.application_identifier,
    productName: cell.row.productName,
    applicationType: cell.row.applicationType,
    procedureType: cell.row.procedureType,
    region: cell.row.region,
    country: cell.row.country,
    productId: cell.row.productId,
    applicationData: {
      inactiveFlg:inactiveFlg?.toLowerCase()==="yes",
      ...filteredRow, 
    },
    mark_fordelete: cell.row.mark_fordelete,
      created_by: cell.row.created_by,
      created_date: cell.row.created_date,
      updated_by: cell.row.updated_by,
      updated_date: cell.row.updated_date,
      domain_id:cell.row.domain_id

  };
};

const checkDependencies = async (id: any, callback: Function) => {
  setIsLoading(true);
  const submissionsResponse = await axios.get(
    `https://submissionsapi.devsecops.freyafusion.com/gateWay/Submissions/GetAllSubmissions?tenantID=${Cookies.get("USER_TENANT_ID")}&userName=${Cookies.get("USER_EMAIL") || ""}`,
    {
      headers: {
        Authorization: `Bearer ${Cookies.get("ACCESS_TOKEN")}`,
        "Accept":"*/*",
        'Accept-Language': ""
      },
    }
  );
  const lcmResponse = await axios.post(
    `https://api.devsecops.freyafusion.com/lcm/lcms/page`,
    { 
      menuName: "LCM",
      pageNum: 1,
      pageSize: 999999,
      showActive: true,
      showDisable: false,
      showInactive: false,
    },
    {
      headers: {
        Authorization: `Bearer ${Cookies.get("ACCESS_TOKEN")}`,
        "Accept":"*/*",
        'Accept-Language': ""
      },
    }
  );
  // console.log(submissionsResponse.data.result)
  const lcmData = lcmResponse.data.data.data;
  const submissions = submissionsResponse.data.result;

    // Extract sequenceIDs for matching applicationID
    const dependencies :  any[] = submissions
      .filter((submission:any) => submission.applicationID === id)
      .map((submission:any) => ({
        type: "Submissions",
        recordName: submission.sequenceID.toString(),
      }))

    lcmData.forEach((lcmItem:any) => {
      if (lcmItem.category === "Initial Application" && lcmItem.productId.includes(id)) {
        dependencies.push({
          type: lcmItem.lcm,
          recordName: lcmItem.recordID,
        });
      }
    });

      
    console.log("Filtered Record IDs:", dependencies);
    if (dependencies.length === 0){
      callback()
    }
    else{
      setRelatedRecords(dependencies);
      setOpenRecordDialog(true)
    }
  setIsLoading(false);
}

  const handleEdit = (id: number, cell: any) => {
    const cellData = getCellData(cell);
    sessionStorage.setItem("id", id.toString());
    sessionStorage.setItem("CellData", JSON.stringify(cellData));
    sessionStorage.setItem("memberStates",JSON.stringify(cell.row.memberStates));
    linkTo("/editApplication",{state:{mode:"edit"}});
  };

  const handleView = async (id: any, cell: any) => {
    const cellData = getCellData(cell);
    sessionStorage.setItem("id", id.toString());
    sessionStorage.setItem("CellData", JSON.stringify(cellData));
    sessionStorage.setItem("memberStates",JSON.stringify(cell.row.memberStates));
    linkTo("/viewApplication",{state:{mode:"view"}});
  };

  const handleDisableAction = (idToRemove: number) => {
    setSelectedId(idToRemove);
    checkDependencies(idToRemove, () => {
      setDisableConfirmationOpen(true);
    })
  };

  const handleEditProduct = (id: any,cell:any) => {
    const cellData = getCellData(cell);
    sessionStorage.setItem("CellData", JSON.stringify(cellData));
    linkTo(`/addApplication/${id}`)
 
};
  const handleDisable = async (reason: any, comments: string) => {
    const params = new URLSearchParams({
      reason: reason.id,
      comments: comments,
      domain_id:Cookies.get("DOMAIN") || "",
      updated_by:Cookies.get("USER_EMAIL") || ""
    });

    
  
    const response = await service.put(
      `application/v1/status-disable/${selectedId}`,  null,  // No request body is being sent, so this should be null or an empty object
      {
        params: params,
        headers:{
          "X-TenantID":Cookies.get('USER_TENANT_ID')
        }
      }
    );
    const disabledRecord = response.data;
    if(disabledRecord.status===200){
      enqueueSnackbar(t('disableProductSuccessTip'), { variant: "success", anchorOrigin: { vertical: 'top', horizontal: 'center' } });
    }
    else if(disabledRecord.status===401){
      return;
    }
    else{
      enqueueSnackbar(t('disabledFailureToolTip'), { variant: "error", anchorOrigin: { vertical: 'top', horizontal: 'center' } });
    }
    const recordToDisable = rows.find(
      (row) => row.id === disabledRecord.data.application_id
    );

    if (recordToDisable) {
      setDisabledRecords((prevDisabledRecords) => [
        ...prevDisabledRecords,
        recordToDisable,
      ]);
      setRows((prevRows) =>
        prevRows.filter((row) => row.id !== disabledRecord.data.application_id)
      );
      setIsDisabled(true);
    }
    setDisableConfirmationOpen(false);
    //linkTo(0);
  };
  useEffect(() => {
    setPaginationobject({page:paginationModel.page,pageSize:paginationModel.pageSize});
  }, [paginationModel]);

  useEffect(() => {
    setPaginationModel({ page: 0,       
      pageSize: 50, });
  }, [gridstatus]);

  

  return (
    <div>
      <Grid container className="grid-page">
        <Grid className=" grid-left">
          <AddApplication />
          {rows && rows.length > 0 &&
          <Box data-testid="grid-table" className="application-table">
            <DataGridPremium
              checkboxSelection = {false}
              columns={columns}
              rows={rows}
              className="react-table table_size-has--row2"
              slots={{
                toolbar: GridToolbar,
                noRowsOverlay: () => <NoDataAvailable></NoDataAvailable>,
              }}
              columnVisibilityModel={columnVisibilityModel}
              initialState={{
                pinnedColumns: {
                  right: ["actions"],
                },
              }}
              slotProps={{
                toolbar: {
                  filterModel: true,
                  showQuickFilter: true,
                  quickFilterProps: {
                    onKeyDown: handleKeyDown,                   
                  },
                  sx: {
                    display: "flex",
                    alignItems: "center",
                    gap: "10px",
                    position: "relative", // Required for absolute positioning of the label
                  }
                },
              }}
              disableAggregation
              localeText={localeText}
              onColumnVisibilityModelChange={(newModel) =>
                setColumnVisibilityModel(newModel)
              }
              pagination
                paginationMode="server"
                rowCount={paginationTotalRecord}
                paginationModel={paginationModel}
                onPaginationModelChange={setPaginationModel}
                pageSizeOptions={[50, 100, 200, 500,paginationTotalRecord]}
            />
              {showPaginationMessage && (
                <Typography
                variant="body2"
                sx={{
                  position: "absolute",
                  top: "80px", 
                  left: "266px", 
                  fontWeight: "bold", 
                  padding: "6px 12px", 
                  border: "2px solid red", 
                  borderRadius: "4px", 
                  backgroundColor: "white", 
                  color: "black", 
                }}
              >
                Press Enter to load more records.
              </Typography>
              )}
          </Box> 
          }
          <Box>
            {
              (!rows || rows.length === 0) && !isLoading && <Box sx={{ height: 'calc(100vh - 350px)', width: '100%' }}>
                <Box className='no-data'>
                <NoDataAvailable></NoDataAvailable>
                </Box>
              </Box>
            }
          </Box>
          <Loading open={isLoading}></Loading>
          <DisableDialog
            open={disableConfirmationOpen}
            onClose={() => setDisableConfirmationOpen(false)}
            onDisable={handleDisable}
            selectedId={selectedId ?? 0}
          />
          <CommonDialog
          openDialog={openRecordDialog} dialogPaperWidth="600px"
          title={`${t('Delete')} ${t(`app`)} `}
          content={'<p style="text-align: left; margin-top: -16px;">' + t('The Application cannot be deleted as it has dependency. Below is the dependency list:')}
          isDeleteDialog={false} handleCloseBtn={() => { setOpenRecordDialog(false) }}>
          <TableContainer component={Paper}>
            <Table size="small" sx={{ "& .MuiTableCell-root": { border: "1px solid rgba(224, 224, 224, 1)" } }}>
              <TableHead sx={{ background: '#fbfbfb' }}>
                <TableRow>
                  <TableCell>{t('Type of Association')}</TableCell>
                  <TableCell align="left">{t('Record Name')}</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {relatedRecords.map((row: any) => (
                  <TableRow
                    sx={{
                      '&:last-child td, &:last-child th': { borderBottom: 'none' },
                      '&:nth-of-type(even)': { backgroundColor: 'white' }
                    }}>
                    <TableCell align="left" style={{ width: '170px' }}>
                      {row.type}
                    </TableCell>
                    <TableCell align="left"><Tooltip title={row.recordName}><Typography className="text-ellipsis" style={{ width: '330px' }} >{row.recordName}</Typography></Tooltip></TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </CommonDialog>
        </Grid>
      </Grid>
    </div>
  );
};

export default ApplicationDataGrid;