// import React from "react";
// const GlobalSearchList: React.FC = () => {
//     return (
//         <div>
//             <p>Global Search Page</p>
//         </div>)

// }

// export default GlobalSearchList;


import React, { useEffect, useRef, useState } from 'react';
import {
  Box,
  Typography,
  Grid,
  Paper,
  Chip,
  Tooltip,
  Pagination,
  Select,
  MenuItem,
  FormControl,
  Stack
} from '@mui/material';
import LanguageIcon from '@mui/icons-material/Language';
import RoomIcon from '@mui/icons-material/Room';
import { useSearchStore } from '../../Audit/config';
import { isEqual } from 'lodash';

const mockData = Array.from({ length: 25 }).map((_, i) => ({
  id: `APP${436 - i}`,
  title: `Nicorette 2mg chewing gum, Nicotine 4 mg (Nicotine Resinate ${5 + i * 5} mg) Chewing Gum, Nicorette 1 mg / Spray, Oromu...`,
  procedure: 'MRP (P001)',
  productFamily: 'Nicorette',
  country: 'Germany',
  phase: 'Marketable',
  workflowStatus: 'Draft',
  applicationType: 'MAA',
  region: 'European Union',
}));
type DateFilterParams = {
  dateFlag: boolean;
  fieldId: number;
  le?: number;
  ge?: number;
};
 type SelectFilterParams = {
  field: string;
  value: (string | number)[];
};
type SelectConditionParams = { field: string; value: (string | number)[] };

type DateConditionParams = { field: string; gte?: string; lte?: string };

type ConditionItem = SelectConditionParams | DateConditionParams;

 type FilterParamsItem = SelectFilterParams | DateFilterParams;

 export interface GlobalSearchParams {
  query: string;
  semantic_search: boolean;
  conditions: ConditionItem[];
}

const GlobalSearchList = () => {
  const [page, setPage] = useState(1);
  const [rowsPerPage, setRowsPerPage] = useState(3);

  const handlePageChange = (_: any, value: number) => {
    setPage(value);
  };

  const handleRowsPerPageChange = (event: any) => {
    setRowsPerPage(event.target.value);
    setPage(1);
  };

  const [search] = useSearchStore((state) => [state.search]);
  const prevSearchRef = useRef<GlobalSearchParams | null>();
  useEffect(() => {
    console.log("Searchdata = ",search);
    if (isEqual(search, prevSearchRef.current)) return;
    prevSearchRef.current = search;
    //getData();
  }, [search]);

  const startIndex = (page - 1) * rowsPerPage;
  const endIndex = startIndex + rowsPerPage;
  const currentItems = mockData.slice(startIndex, endIndex);

  return (
    <Box p={3}>
      <Grid container spacing={2}>
        {currentItems.map((item, index) => (
          <Grid item xs={12} key={index}>
            <Paper elevation={1} sx={{ p: 2 }}>
              <Grid container spacing={2}>
                <Grid item xs={12} md={9}>
                  <Box display="flex" alignItems="center" gap={1} flexWrap="wrap">
                    <Tooltip title={`Application ID: ${item.id}`} arrow>
                      <Typography color="primary" fontWeight="bold">
                        {item.id}
                      </Typography>
                    </Tooltip>
                    <Tooltip title={item.title} arrow>
                      <Typography fontWeight="500" noWrap maxWidth="calc(100% - 100px)">
                        - {item.title}
                      </Typography>
                    </Tooltip>
                    <Chip label="Approved" color="success" size="small" />
                  </Box>

                  <Box mt={1}>
                    <Typography variant="body2">
                      Procedure: <strong>{item.procedure}</strong>
                    </Typography>
                    <Box display="flex" alignItems="center" gap={1} mt={0.5}>
                      <LanguageIcon fontSize="small" />
                      <Typography variant="body2">{item.region}</Typography>
                      <RoomIcon fontSize="small" />
                      <Typography variant="body2">{item.country}</Typography>
                    </Box>
                    <Typography variant="body2" mt={0.5}>
                      Product Family: <strong>{item.productFamily}</strong>
                    </Typography>
                  </Box>
                </Grid>

                <Grid item xs={12} md={3}>
                  <Typography variant="body2">
                    Phase: <strong>{item.phase}</strong>
                  </Typography>
                  <Typography variant="body2">
                    Workflow Status: <strong>{item.workflowStatus}</strong>
                  </Typography>
                  <Typography variant="body2">
                    Application Type: <strong>{item.applicationType}</strong>
                  </Typography>
                </Grid>
              </Grid>
            </Paper>
          </Grid>
        ))}
      </Grid>

      {/* Pagination Controls */}
      <Grid container justifyContent="space-between" alignItems="center" mt={3}>
        <Grid item>
          <Stack direction="row" alignItems="center" spacing={1}>
            <Typography variant="body2">Rows per page:</Typography>
            <FormControl size="small">
              <Select value={rowsPerPage} onChange={handleRowsPerPageChange}>
                {[3, 5, 10].map((count) => (
                  <MenuItem key={count} value={count}>
                    {count}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
            <Typography variant="body2">
              {startIndex + 1}–{Math.min(endIndex, mockData.length)} of {mockData.length}
            </Typography>
          </Stack>
        </Grid>
        <Grid item>
          <Pagination
            count={Math.ceil(mockData.length / rowsPerPage)}
            page={page}
            onChange={handlePageChange}
            color="primary"
            shape="rounded"
          />
        </Grid>
      </Grid>
    </Box>
  );
};

export default GlobalSearchList;



