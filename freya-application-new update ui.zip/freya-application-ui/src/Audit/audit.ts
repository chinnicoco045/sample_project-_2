import axios from "axios"; 
import service, { GET_API } from "../Services/apiheader";
import { accessToken } from "../types";
import Cookies from "js-cookie";
const prefix = `${GET_API}audit/log-record`;
// const localhost = "http://localhost:8098"
// const prefix = localhost + `/audit/log-record`;

// ACL
// export const fetchAuditList = (params: any) => service.post(`${prefix}/list`, params);
const header={
    Authorization: `Bearer ${accessToken}`,
    "X-Tenant-Id": Cookies.get("USER_TENANT_ID"),
    // "X-Session-User-Info": Cookies.get("USER_INFO"),
    "Accept":"*/*",
      'Accept-Language': ""
    
};
// `http://localhost:8098`+ 

export const fetchAuditFieldModification = (auditId: string) => 
    service.get(`${prefix}/one/modification-info`, {
        headers: header,
        params: { auditId } // Keep it as query parameter
    });


export const fetchOperationListByEntityId = async (params: { entityId: string, moduleName: string, pageNum: number, pageSize: number }) => {
    const prefixedEntityId = `APP${params.entityId}`;
    const modifiedParams = {
        ...params,
        entityId: prefixedEntityId,
    };

    // Initial request with prefixed entityId
    const response = await service.post(`${prefix}/entity/operation-list`, modifiedParams, {
        headers: header,
    });

    // Check if data is empty, retry with the original entityId
    if (response?.data?.data?.data?.length === 0) {
        const originalParams = {
            ...params,
            entityId: params.entityId, // Use the original entityId without the prefix
        };

        return service.post(`${prefix}/entity/operation-list`, originalParams, {
            headers: header,
        });
    }

    return response;
};


export const EXPORT_AUDIT_LOG_URL = `${prefix}/export`

export const EXPORT_AUDIT_ENTITY_IDENTIFIER_URL = `${prefix}/export/entity/operation-list`