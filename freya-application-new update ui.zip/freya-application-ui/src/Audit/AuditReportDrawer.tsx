import React, { useState, useEffect, useRef } from "react";
import { Drawer, Box, Button, Typography } from "@mui/material";
import { DataGridPremium, getGridStringOperators, GridCallbackDetails, GridColDef, GridColumnVisibilityModel, GridFilterModel, GridPinnedColumns, GridSortModel, GridToolbar } from "@mui/x-data-grid-premium";
import CloseIcon from "@mui/icons-material/Close";
import { useNavigate, useLocation } from "react-router-dom";
import { useTranslation } from "react-i18next";
import {  EXPORT_AUDIT_ENTITY_IDENTIFIER_URL, fetchAuditFieldModification, fetchOperationListByEntityId } from './audit'; // Adjust path as needed
import eventBus from "../Audit/eventBus";
import { RTQ_EVENTS } from "../constants";
import { useSnackbar } from "notistack";
import { canParseToJson, firstWordCase, getAllIds, getFieldValue } from "./utils";
import { TreeItem, TreeView } from "@mui/lab";
import Loading from "../Components/Applications/components/Loading";
import { Close, FilterAlt } from "@mui/icons-material";
import { useDataGridLocalText } from "./useDataGridLocalText";
import { fetchEditFormJson, fetchReasons, fetchSectionProductTree } from "../apis/apiFunctions";
import service, { GET_API } from "../Services/apiheader";
import dayjs from 'dayjs';
import Tooltip, { TooltipProps, tooltipClasses } from '@mui/material/Tooltip';
import { styled } from '@mui/material/styles';


interface SectionTreeRow {
  id: string;
  fieldName: string;
  oldValue: string;
  newValue: string;
}
interface IdentifierItem {
  id: number;
  entityIdentifier: string;
  entityName: string;
}

const AuditReportDrawer = (props: any): JSX.Element => {
  const { handleCancel,  identifierData,setIdentifierData, setOpenAddPopup, setReportDrawerList, setIsEntityReport, Audit_Id,productId,setOpenDrawer,sectionTreeDataProps} = props;
  const [open, setOpen] = useState(true);
  const [pageNum, setPageNum] = useState(0);
  const [pageSize, setPageSize] = useState(10);
  const [identifierList, setIdentifierList] = useState<IdentifierItem[]>([]);
  const [operationList, setOperationList] = useState([]);
  const { t } = useTranslation();
  const [fieldModifications, setFieldModifications] = useState<SectionTreeRow[]>([]);
  const [entityData, setEntityData] = useState<any>([]);
  const [rowCount, setRowCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const { enqueueSnackbar } = useSnackbar();
  const [isCategoryData, setIsCategoryData] = useState(false);
  const [columnVisibilityModel, setColumnVisibilityModel] =
    useState<GridColumnVisibilityModel>({});
    const [relatedRecords, setRelatedRecords] = useState([{
        recordId: '0000001',
        queryTitle: 'testtest'
    }]);
  const [filterModel, setFilterModel] = useState<GridFilterModel>()
  const [pinnedColumns, setPinnedColumns] = React.useState<GridPinnedColumns>({
    // left: ['productName'],
    right: ['action']
  });
  const handlePinnedColumnsChange = React.useCallback(
    (updatedPinnedColumns: GridPinnedColumns) => {
      setPinnedColumns(updatedPinnedColumns);
    },
    [],
  );
  const [sortModel, setSortModel] = useState<GridSortModel>()



  
  const {localeText}=useDataGridLocalText();
  useEffect(()=>{
       if(sectionTreeDataProps)
          setLoading(false);
  },[sectionTreeDataProps])

  let rows: any = [];
  const pageNumRef = useRef(pageNum)
  pageNumRef.current = pageNum
  const pageSizeRef = useRef(pageSize)
  pageSizeRef.current = pageSize

  const renderTree = (nodes: any, firstId?: string) => {
    return nodes.map((el: any) => {
      console.log(el, el.id)
        return (
            <TreeItem key={el.id} nodeId={el.id.toString()} label={el.name} disabled
                sx={{
                    '& .MuiTreeItem-content .MuiTreeItem-label': { fontWeight: el.id.toString().indexOf('##') < 0 ? 'bold' : 'normal' },
                    '& .MuiTreeItem-content.Mui-disabled': { opacity: 1, padding: 0, marginLeft: '-24px' }
                }}>
                {Array.isArray(el.children) && el.children.length > 0
                    ? renderTree(el.children)
                    : null}
            </TreeItem>
        );
    });
    };
    
    const transformTreeData = (data: any) => {
      const isDataJson = canParseToJson(data)
      if (data && isDataJson) {
          return JSON.parse(data)
      } else {
          return false
      }
    }

    const isValueCategory = (data: any) => {
      data.map((item: any) => {
          setIsCategoryData(transformTreeData(item.newValue))
      })
  }
  useEffect(() => {
      isValueCategory(fieldModifications)
  }, [fieldModifications])

  const [numericPart, setnumericPart] = useState('');
  const [isAuditIdentifierClicked, setIsAuditIdentifierClicked] = useState(false);
  const [responseData, setResponseData] = useState([]);
  const [gridColumnVisibility, setGridColumnVisibility] = useState(columnVisibilityModel)



    const handleClickAuditIdentifier = (value: any) => {
      const num = value.formattedValue.match(/\d+/)[0]
      setnumericPart(num);
      console.log(num)
      setIsAuditIdentifierClicked(true);
      console.log("clicking")
      setOpenAddPopup(true);
      setIdentifierData(value)
      setReportDrawerList(value)
      setIsEntityReport(false)
    }

  const auditUpColumns: GridColDef[] = [
    {
        field: 'entityIdentifier',
        headerName: t('entityIdentifier'),
        minWidth: 105,
        flex: 1,
        renderCell: (cellValues: any) => {
            return (
                <Tooltip title={cellValues.value} placement="left-start" ><div>{cellValues.value}</div></Tooltip>
            );
        },
        filterOperators: getGridStringOperators().filter((operator) => operator.value !== "isAnyOf"),
    },
    {
      field: 'entityName',
      headerName: t('entityName'),
      flex: 1,
      minWidth: 110,
      renderCell: (cellValues: any) => {
          return (
              <Tooltip title={cellValues.value} placement="left-start" ><div>{cellValues.value}</div></Tooltip>
          );
      },
      filterOperators: getGridStringOperators().filter((operator) => operator.value !== "isAnyOf"),
  },
  {
      field: 'entityCreatedByName',
      headerName: t('createdBy'),
      minWidth: 100,
      flex: 1,
      renderCell: (cellValues: any) => {
        return (
            <Tooltip title={cellValues.value} placement="left-start" ><div>{cellValues.value}</div></Tooltip>
        );
      },
      filterOperators: getGridStringOperators().filter((operator) => operator.value !== "isAnyOf"),
  },
  {
      field: 'entityCreatedDate',
      headerName: t('entityCreatedDate'),
      minWidth: 170,
      flex: 1,
      renderCell: (cellValues: any) => {
        return (
            <Tooltip title={cellValues.value} placement="left-start" ><div>{cellValues.value}</div></Tooltip>
        );
      },
      filterOperators: getGridStringOperators().filter((operator) => operator.value !== "isAnyOf"),
  },
  {
      field: 'entityModifiedByName',
      headerName: t('modifiedBy'),
      minWidth: 100,
      flex: 1,
      renderCell: (cellValues: any) => {
        return (
            <Tooltip title={cellValues.value} placement="left-start" ><div>{cellValues.value}</div></Tooltip>
        );
      },
      filterOperators: getGridStringOperators().filter((operator) => operator.value !== "isAnyOf"),
  },
  {
      field: 'entityModifiedDate',
      headerName: t('entityModifiedDate'),
      minWidth: 155,
      flex: 1,
      renderCell: (cellValues: any) => {
        return (
            <Tooltip title={cellValues.value} placement="left-start" ><div>{cellValues.value}</div></Tooltip>
        );
      },
      filterOperators: getGridStringOperators().filter((operator) => operator.value !== "isAnyOf"),
  },
  ]

  const auditDownColumns: GridColDef[] = [
    {
        field: 'fieldName',
        headerName: t('fieldName'),
        width: 380,
        // disableColumnMenu: true,
        // sortable: false,
        renderCell: (cellValues: any) => {
            return (
                <Tooltip title={cellValues.value} placement="left-start" ><div>{!cellValues.value ? ' ' : cellValues.value}</div></Tooltip>
            );
        },
        filterOperators: getGridStringOperators().filter((operator) => operator.value !== "isAnyOf"),
    },
    {
        field: 'oldValue',
        headerName: t('beforeModification'),
        flex: 1,
        minWidth: 220,
        disableColumnMenu: true,
        sortable: false,
        renderCell: (cellValues: any) => {
            const cellData = transformTreeData(cellValues.value)
            const expandedId = getAllIds(cellData, [])
            return (
                <>
                    {cellData.length > 0 ? <TreeView
                        defaultExpanded={["root"]}
                        expanded={expandedId}
                    >
                        {/* {renderTree(cellData, expandedId[0])} */}
                    </TreeView> :
                        <Tooltip title={cellValues.value} placement="left-start"><div>{!cellValues.value ? '-' : (cellData.length === 0 ? '-' : cellValues.value)}</div></Tooltip>}
                </>
            );
        },
        filterOperators: getGridStringOperators().filter((operator) => operator.value !== "isAnyOf"),
    },
    {
        field: 'newValue',
        headerName: t('afterModification'),
        width: 245,
        disableColumnMenu: true,
        sortable: false,
        renderCell: (cellValues: any) => {
            const cellData = transformTreeData(cellValues.value)
            const expandedId = getAllIds(cellData, [])
            return (
                <>
                    {cellData.length > 0 ? <TreeView
                        defaultExpanded={["root"]}
                        expanded={expandedId}
                        style={{ height: '100%' }}
                    >
                        {/* {renderTree(cellData, expandedId[0])} */}
                    </TreeView> :
                        <Tooltip title={cellValues.value} placement="left-start"><div>{!cellValues.value ? '-' : (cellData.length === 0 ? '-' : cellValues.value)}</div></Tooltip>}
                </>
            );
        },
        filterOperators: getGridStringOperators().filter((operator) => operator.value !== "isAnyOf"),
    },
    ];

    const entityUpColumns: GridColDef[] = [
      {
          field: 'entityIdentifier',
          headerName: t('entityIdentifier'),
          minWidth: 300,
          flex: 1,
          // disableColumnMenu: true,
          // sortable: false,
          filterOperators: getGridStringOperators().filter((operator) => operator.value !== "isAnyOf"),
      },
      {
          field: 'entityName',
          headerName: t('entityName'),
          minWidth: 400,
          flex: 1,
          // disableColumnMenu: true,
          // sortable: false,
          renderCell: (cellValues: any) => {
              return (
                  <Tooltip title={cellValues.value} placement="left-start"><div>{cellValues.value}</div></Tooltip>
              );
          },
          filterOperators: getGridStringOperators().filter((operator) => operator.value !== "isAnyOf"),
      }
  ];

  const entityDownColumns: GridColDef[] = [
    {
        field: 'recordId',
        headerName: t('auditIdentifier'),
        width: 183,
        // disableColumnMenu: true,
        sortable: true,
        renderCell: (cellValues: any) => {
            return (<a href='javascript:void(0);' onClick={() => handleClickAuditIdentifier(cellValues)}>{cellValues.value}</a>);
        },
        filterOperators: getGridStringOperators().filter((operator) => operator.value !== "isAnyOf"),
    },
    {
        field: 'operationType',
        headerName: t('operationType'),
        // disableColumnMenu: true,
        // sortable: false,
        width: 170,
        filterOperators: getGridStringOperators().filter((operator) => operator.value !== "isAnyOf"),
    },
    {
        field: 'operatorUsername',
        headerName: t('user'),
        width: 190,
        // disableColumnMenu: true,
        // sortable: false,
        filterOperators: getGridStringOperators().filter((operator) => operator.value !== "isAnyOf"),
    },
    {
      field: 'operationDate',
      headerName: t('operationDate'),
      width: 180,
      // disableColumnMenu: true,
      // sortable: false,
      filterOperators: getGridStringOperators().filter((operator) => operator.value !== "isAnyOf"),
      
  },
  ];

  const fetchIdentifierData = async() => {
    setLoading(true);
    console.log("Fetching data for numeric part:", numericPart);
    const json = JSON.parse(await fetchEditFormJson("",t))
    console.log(json)


    const fieldLookup = json.reduce((acc: Record<string, { label: string, type: string }>, item: any) => {
      acc[item.field] = {
        label: item.label,
        type: item.type
      };
      return acc;
    }, {});

    fieldLookup["reasonToDisable"] = { label: "Reason for Disable", type: "text" };
    fieldLookup["commentsOnDisable"] = { label: "Disable Comments", type: "text" };

    fieldLookup['sectionTree'] = 'Section Tree';

    const reasons=await fetchReasons();

    fetchAuditFieldModification(numericPart).then((res: any) => {
        if (res.status === 200) {
            const data = res.data.data|| {};
            console.log("Audit logsssssss",data)

            
            // Data for the first grid
            const entityData = [{
                id:0,
                entityIdentifier: data.entityIdentifier,
                entityName: data.entityName,
                entityCreatedByName: data.entityCreatedByName,
                entityCreatedDate: data.entityCreatedDate,
                entityModifiedByName: data.entityModifiedByName,
                entityModifiedDate: data.entityModifiedDate,
            }];
            
            console.log("Entity Data for Grid 1:", entityData);
            setEntityData(entityData); // Assuming you have a state or method to set this data

            // Utility function to format date
            const formatDate = (dateString: string) => {
              if (!dateString) return '-';
              const dateObj = new Date(dateString);
              const day = dateObj.getDate().toString().padStart(2, '0');
              const month = dateObj.toLocaleString('en-GB', { month: 'short' });
              const year = dateObj.getFullYear();
              const hours = dateObj.getHours().toString().padStart(2, '0');
              const minutes = dateObj.getMinutes().toString().padStart(2, '0');
              const seconds = dateObj.getSeconds().toString().padStart(2, '0');
              
              return `${day}/${month}/${year} ${hours}:${minutes}:${seconds}`;
          };
          function deepEqual(obj1:any, obj2:any) {
            if (obj1 === obj2) return true; // Same reference
            if (typeof obj1 !== "object" || typeof obj2 !== "object" || obj1 === null || obj2 === null) {
              return false; // One is not an object or one is null
            }
          
            const keys1 = Object.keys(obj1);
            const keys2 = Object.keys(obj2);
          
            if (keys1.length !== keys2.length) return false; // Different number of keys
          
            for (const key of keys1) {
              if (!keys2.includes(key) || !deepEqual(obj1[key], obj2[key])) {
                return false; // Key missing or value mismatch
              }
            }
          
            return true;
          }
            // Data for the second grid
            const fieldModifications: SectionTreeRow[] = data.fieldModifications.flatMap((item: SectionTreeRow) => {
              console.log(data)
              if (item.fieldName === "applicationdata") {
                // Parse the JSON strings into objects
                const oldValues = item.oldValue ? JSON.parse(item.oldValue) : {};
                const newValues = item.newValue ? JSON.parse(item.newValue) : {};
                
                const modifications: any[] = [];

                
                // Compare each key in the JSON object
                Object.keys(newValues).forEach(async(key) => {

                  const formatValue = (value: any): string => {
                    if (value === undefined || value === null || value === '') {
                      return '-';
                    } else if (Array.isArray(value)) {
                      return value.length > 0 ? value.join(', ') : '-';
                    } else if (typeof value === 'object') {
                      return JSON.stringify(value);
                    } else {
                      return String(value);
                    }
                  };

                  const disabledMSArray=newValues['disabledMS'];
                  const oldWaveInfo=oldValues['waveInfo'];
                      const newWaveInfo=newValues['waveInfo'];
                      console.log("WaveINFOOOOOO",oldWaveInfo,newWaveInfo);
                  let oldValue = formatValue(oldValues[key])
                  let newValue = formatValue(newValues[key])
                  if (key === "waveInfo" && !deepEqual(oldWaveInfo, newWaveInfo)) {
                    // Create a map of oldWaveInfo using countryCode as the key
                    const oldWaveMap = oldWaveInfo?.reduce((map:any, item:any) => {
                      map[item.countryCode] = item;
                      return map;
                    }, {});
                  
                    // If oldWaveInfo is empty, consider all newWaveInfo as additions
                    if (Object.keys(oldWaveMap ?? {}).length === 0) {
                      newWaveInfo.forEach((newItem:any) => {
                        modifications.push({
                          id: `waveName`,
                          fieldName: t("wave"),
                          oldValue: "-", // No old value
                          newValue: newItem.waveName,
                        });
                        if (newItem.comments !== "") {
                          modifications.push({
                            id: `comments-${newItem.countryCode}`,
                            fieldName: t("comments"),
                            oldValue: "-", // No old value
                            newValue: newItem.comments,
                          });
                        }
                      });
                      return;
                    }
                  
                    // Compare newWaveInfo with oldWaveInfo
                    newWaveInfo.forEach((newItem:any) => {
                      const oldItem = oldWaveMap[newItem.countryCode]; // Lookup by countryCode
                      if (!oldItem) {
                        // If no matching oldItem exists, treat the newItem as an addition
                        modifications.push({
                          id: `waveName-${newItem.countryCode}`,
                          fieldName: t("wave"),
                          oldValue: "-",
                          newValue: newItem.waveName,
                        });
                        if (newItem.comments !== "") {
                          modifications.push({
                            id: `comments-${newItem.countryCode}`,
                            fieldName: t("comments"),
                            oldValue: "-",
                            newValue: newItem.comments,
                          });
                        }
                      } else {
                        // Check if waveName has changed
                        if (oldItem.waveName !== newItem.waveName) {
                          modifications.push({
                            id: `waveName`,
                            fieldName: t("wave"),
                            oldValue: oldItem.waveName || "-",
                            newValue: newItem.waveName,
                          });
                        }
                  
                        // Check if comments have changed
                        if (oldItem.comments !== newItem.comments) {
                          modifications.push({
                            id: `comments`,
                            fieldName: t("comments"),
                            oldValue: oldItem.comments || "-",
                            newValue: newItem.comments,
                          });
                        }
                      }
                    });
                  }
                  

                  if (fieldLookup[key] && oldValue !== newValue) {
                    console.log(key, fieldLookup[key], oldValue, newValue)

                    if (key === 'memberStates' && typeof oldValue === 'string' && typeof newValue === 'string') {
                      // Convert oldValue and newValue from comma-separated strings to arrays
                      const oldValueArray = oldValue.split(',').map(value => value.trim());
                      const newValueArray = newValue.split(',').map(value => value.trim());
                  
                      if (oldValueArray.length > newValueArray.length) {
                          // Find values in oldValueArray that are missing from newValueArray
                          const missingValues = oldValueArray.filter(value => !newValueArray.includes(value));
                          const foundMS = disabledMSArray.find((ms: any) => ms.countryName === missingValues[0]);

                          const { reasonForDisableLabel, commentsForDisable } = foundMS || {};

                          console.log(reasonForDisableLabel, commentsForDisable);
                          if (missingValues.length > 0) {
                              modifications.push({
                                  id: key + "disabled" + missingValues,
                                  fieldName: t("Disabled Member State"),
                                  oldValue: "No",
                                  newValue: "Yes"
                              });
                              modifications.push({
                                id:'reasonForDisableMS'+missingValues,
                                fieldName:t("Reason"),
                                oldValue:"-",
                                newValue:reasonForDisableLabel 
                              })
                              if(commentsForDisable)
                              modifications.push({
                                id:'commentsForDisableMS'+missingValues,
                                fieldName:t("comments"),
                                oldValue:"-",
                                newValue:commentsForDisable 
                              })
                          }
                      }
                      else if(oldValueArray.length < newValueArray.length){
                        // const addedValue = newValueArray.filter(value => !oldValueArray.includes(value));

                        const code=newValues['msCountryCode'][newValueArray.length-1]; 
                        const {waveName,comments} = newValues['waveInfo'].find((wave:any)=> wave.countryCode===code);
                        
                        console.log(waveName," ",comments); 
                        if (!modifications.some(mod => mod.fieldName === "Wave")) {
                          modifications.push({
                            id: 'waveName',
                            fieldName: t("wave"),
                            oldValue: "-",
                            newValue: waveName,
                          });
                        }
                        if (comments) {
                          const hasCommentsField = modifications.some(
                            modification => modification.fieldName === "Comments"
                          );
                        
                          if (!hasCommentsField) {
                            modifications.push({
                              id: 'comments',
                              fieldName: t("comments"),
                              oldValue: "-",
                              newValue: comments
                            });
                          }
                        }
                      }  
                  }
                  
                    if(key!=='sectionTree'){
                    if (fieldLookup[key].type === 'date'){
                      oldValue = oldValue!=='-' ? dayjs(oldValue).format('DD/MMM/YYYY') : oldValue;
                      newValue = newValue!=='-' ? dayjs(newValue).format('DD/MMM/YYYY') : newValue;
                    }
                    if (fieldLookup[key].type === 'checkbox'){
                      oldValue = oldValue === 'true' ? 'Yes' : oldValue === 'false' ? 'No' : oldValue;
                      newValue = newValue === 'true' ? 'Yes' : newValue === 'false' ? 'No' : newValue;
                    }
                    if (key === 'reasonToDisable'){
                      const matchedReason = reasons.find((reason: any) => reason.id === newValue);
                      newValue = matchedReason.name;
                    }
                    modifications.push({
                      id: key,
                      fieldName: t(key),
                      oldValue: oldValue,
                      newValue: newValue,
                    });}else
                    { 
                      console.log("Audit section tree", oldValue, newValue);

                      if(oldValue==="-")
                          oldValue="{}";
                      if(newValue==="-")
                          newValue="{}"; 
                      
                      if(oldValue && newValue){
                      const oldArray=JSON.parse(oldValue);
                      const newArray=JSON.parse(newValue);
                      rows = await handleSectionTreeComparison(oldArray, newArray);
                      }
                      
                      console.log("ROwssss",rows);
                      modifications.push(rows);
                
                    }
                  }
               
                });
            
                return modifications;
              } else  {
                const fieldLabelMap: Record<string, string> = {
                  created_by: "created_by",
                  created_date: "created_date",
                  updated_by: "updated_by",
                  updated_date: "updated_date",
                  identifier: "Identifier",
                  markfor_delete: "Disabled",
                  groupid: "groupid"
              };
          
              const fieldName = fieldLabelMap[item.fieldName] || item.fieldName; // Use mapped label if available
              let oldValue = item.oldValue;
                let newValue = item.newValue;

                // Format dates if the field is created_date or updated_date
                if (item.fieldName === "created_date" || item.fieldName === "updated_date") {
                    oldValue = oldValue ? formatDate(oldValue) : '-';
                    newValue = newValue ? formatDate(newValue) : '-';
                }
                if (item.fieldName === "markfor_delete"){
                  oldValue = oldValue === '0' ? 'No' : oldValue === '1' ? 'Yes' : oldValue;
                  newValue = newValue === '0' ? 'No' : newValue === '1' ? 'Yes' : newValue;
                }
                return [{
                  id: item.fieldName ? item.fieldName : item.fieldName + '-',
                  fieldName: t(fieldName),
                  oldValue: oldValue,
                  newValue: newValue,
                }];
              }
            });

            console.log("Field Modifications for Grid 2:", fieldModifications);
            setFieldModifications(fieldModifications); // Assuming you have a state or method to set this data
            
        }
    }).catch((err: any) => {
        if (err?.response?.status === 401 || err?.response?.data?.message === "unauthorized") {
            return;
        }
        enqueueSnackbar(firstWordCase(err.response.data.message), { variant: "error", anchorOrigin: { vertical: 'top', horizontal: 'center' } });
    }).finally(() => {
      if(sectionTreeDataProps)
      setLoading(false);
    });
  }

  const arraysEqual = (a: any[], b: any[]): boolean => {
    if (a.length !== b.length) return false;
    for (let i = 0; i < a.length; i++) {
      if (!a.includes(b[i])) return false;
    }
    return true;
  };

  const handleSectionTreeComparison = async (oldTree: any, newTree: any) => {
   

    
    const fieldNames = new Set([...Object.keys(oldTree), ...Object.keys(newTree)]);
    const rows: Array<{ id: string; fieldName: string; oldValue: string; newValue: string }> = [];

    for (const field of fieldNames) {
        const oldSubparent = oldTree[field] || {};
        const newSubparent = newTree[field] || {};

        const subfieldNames = new Set([...Object.keys(oldSubparent), ...Object.keys(newSubparent)]);

        for (const subfield of subfieldNames) {
            let beforeMods = oldSubparent[subfield] || [];
            let afterMods = newSubparent[subfield] || [];


            const oldSubParentKeys =Object.keys(oldSubparent)
            const newSubparentKeys = Object.keys(newSubparent); 

           let areChildAndSubchildSame=false;
            if(afterMods.length===1){
              if(newSubparentKeys.includes(afterMods[0])){
                areChildAndSubchildSame=true;
                }
            }
           
            if(beforeMods.length===1){
              if(oldSubParentKeys.includes(beforeMods[0])){
                areChildAndSubchildSame=true;
              }
            }

            if (areChildAndSubchildSame) {
               
                beforeMods = await getDisplayValue(field,"", beforeMods) || [];
                afterMods = await getDisplayValue(field, "",afterMods) || [];
            } else {
                beforeMods = await getDisplayValue(field,subfield, beforeMods) || [];
                afterMods = await getDisplayValue(field,subfield, afterMods) || [];
            }
           
            let fieldName=areChildAndSubchildSame ? field : subfield;
           
            if (!arraysEqual(beforeMods, afterMods)) {

                rows.push({
                    id: `${field}-${subfield}`,
                    fieldName: t(fieldName), 
                    oldValue: beforeMods.join(", "),
                    newValue: afterMods.join(", "),
                });
            }
        }
    }

    const field_Names = new Set(rows.map(row => row.fieldName));

// Filter out rows where oldValue exists as a fieldName
const filteredRows = rows.filter(row => !field_Names.has(row.oldValue));
console.log(filteredRows);
    console.log("Modified rows:", rows);

    setFieldModifications((prevModifications) => [...filteredRows, ...prevModifications]);
    return rows;
};

  useEffect(() => {
    if (numericPart) {
      fetchIdentifierData();
    }
  }, [numericPart]);


  const getDisplayValue = async (field: string, subfield:string,ids: any[]) => {
    if(!productId){
      enqueueSnackbar("The Product is not available", { variant: "error", anchorOrigin: { vertical: 'top', horizontal: 'center' } });
      setOpenDrawer(false);
      return;
    }
    try {
       if(!sectionTreeDataProps){
         return;
       }
        console.log("Fetched section tree response:",sectionTreeDataProps);
        const fieldDataTemp = sectionTreeDataProps.find((item: any) => item.name === field);
        const fieldData = subfield ? fieldDataTemp.children?.find((item: any) => item.name === subfield) : fieldDataTemp;
          
        let names: string[] = [];

        if(subfield){
        const children = fieldData.data;
        const fieldValue= getFieldValue(subfield);
        console.log(fieldValue);
        for (const child of children) {
          if (ids.includes(child.id)) {
            if (fieldValue && child[fieldValue]) {
              names.push(child[fieldValue]); // Dynamically access the property
            }
            ids = ids.filter((id: any) => id !== child.id);
          }
        }
      }
      else
      {
        const children = fieldData.children;
        for (const child of children) {
          if (ids.includes(child.id)) {
            names.push(child.displayName);
            ids = ids.filter((id: any) => id !== child.id);
          }
        }
  
        const displayNames = new Set([...names, ...ids]);
        names = [];
        for (const item of Array.from(displayNames)) {
          names.push(item);
        }
      }
        return names;
      
    } catch (error) {
      console.error("Error fetching section tree:", error);
      return ids; // Return ids as fallback
    }
  };


  
 


      const fetchOperationData = (pageNum: number, pageSize: number) => {
        setLoading(true);
        // fetchOperationListByEntityId(Audit_Id,"Application", pageNum + 1, pageSize).then((res: any) => {
        fetchOperationListByEntityId({ entityId: Audit_Id, moduleName: 'Application', pageNum: pageNum + 1, pageSize: pageSize}).then((res: any) => {
          console.log(Audit_Id)
          if (res.status === 200) {
            const data = res.data.data.data || [];
            setRowCount(Number(res.data.data.total));
            console.log("Audit logsssssss",data)

            if (res.data.data.data[0]) {
              //@ts-ignore
              setResponseData([res.data.data.data[0]])
              console.log("hybridfellow",res.data.data.data[0])
            } else{
              setResponseData([])
            }
          

            // Filter for the latest unique records based on entityIdentifier
            const latestRecords = new Map();
            data.forEach((item: any) => {
              const key = item.entityIdentifier; // Use entityIdentifier as the unique key
              const existingRecord = latestRecords.get(key);
    
              if (
                !existingRecord ||
                new Date(item.operationDate).getTime() >
                  new Date(existingRecord.operationDate).getTime()
              ) {
                // Replace if no record exists or if the current record is more recent
                latestRecords.set(key, item);
              }
            });
    
            // Convert the Map values to an array and format the result
            const identifierList = Array.from(latestRecords.values()).map(
              (item: any, index: number) => ({
                id: index, // Unique id
                entityIdentifier: item.entityIdentifier,
                entityName: item.entityName,
              })
            );

            console.log(identifierList);
            setIdentifierList(identifierList);

            // Extract recordId, operationType, operatorUsername, and operationDate for setOperationList
            const operationList = data.map((item: any, index: number) => ({
              id: index, // Add unique id here
                recordId: item.recordId,
                operationType: item.operationType,
                operatorUsername: item.operatorUsername,
                operationDate: item.operationDate,
            }));
            console.log(operationList)
            setOperationList(operationList);

        }
      }).catch((err: any) => {
        if (err?.response?.status === 401 || err?.response?.data?.message === "unauthorized") {
            return;
        };
        enqueueSnackbar(firstWordCase(err.response.data.message), { variant: "error", anchorOrigin: { vertical: 'top', horizontal: 'center' } });
      }).finally(() => {
        if(sectionTreeDataProps)
        setLoading(false);
      })
      }


    const downloadFileCommon = (url: string, data = {}, enqueueSnackbar: any, type = '') => {
      const dataLength = Object.keys(data).length
      let executePolling = setTimeout(
        () => {
          service({
            method: dataLength ? 'post' : 'get',
            url: url,
            responseType: 'arraybuffer',
            data: data
          }).then((res: any) => {
            if (res.headers['export-status'] == 3 || type === 'download template') {
              eventBus.emit(RTQ_EVENTS.COMMON.EXPORT_FILE_END)
              eventBus.emit(RTQ_EVENTS.ADMIN.DOWNLOAD_TEMPLATE_END) // download template file
              clearTimeout(executePolling);
              let fileName = res.headers['content-disposition'].split(';')[1].split('filename=')[1];
              if (!res.data) { return }
              let url = window.URL.createObjectURL(new Blob([res.data]));
              let element = document.createElement('a');
              element.style.display = 'none';
              element.href = url;
              element.setAttribute('download', decodeURIComponent(fileName));
              document.body.appendChild(element);
              element.click();
            } else {
              downloadFileCommon(url, data, enqueueSnackbar);
            }
          }).catch((err: any) => {
            clearTimeout(executePolling);
            eventBus.emit(RTQ_EVENTS.COMMON.EXPORT_FILE_END)
            eventBus.emit(RTQ_EVENTS.ADMIN.DOWNLOAD_TEMPLATE_END) // download template file
            if (err?.response?.status == 401 || err?.response?.data?.message === "unauthorized") {
              return;
            };
            if (enqueueSnackbar) {
              const unit8Msg: any = new Uint8Array(err.response.data)
              const error_msg = JSON.parse(String.fromCharCode.apply(null, unit8Msg))
              enqueueSnackbar(error_msg.message, { variant: "error", anchorOrigin: { vertical: 'top', horizontal: 'center' } });
              // enqueueSnackbar('Failed to download the PDF, Please try again later', { variant: "error", anchorOrigin: { vertical: 'top', horizontal: 'center' } });
            }
          })
        }, 2000)
  
    }

    //@ts-ignore
     const moduleName = responseData.length > 0 && responseData[0].moduleName;
     console.log ("response",responseData)
 

    // @ts-ignore
    const downLoadEntityList = () => {
      console.log("entering")
      let timeZone = -new Date().getTimezoneOffset() / 60;
      let params = {
              entityId: `APP${Audit_Id}`,
              // entityId: Audit_Id,
              moduleName: moduleName,
              timeZone:timeZone
      };
      downloadFileCommon(EXPORT_AUDIT_ENTITY_IDENTIFIER_URL, params, enqueueSnackbar)
      console.log('Downloading', params);
    }


    useEffect(() => {
          setPageNum(0)
          setPageSize(10)
        fetchOperationData(0, 1000000);
      },[]);
    

    const changePageInfo = async () => {
      setTimeout(() => {
          const pageNum = pageNumRef.current
          const pageSize = pageSizeRef.current
          fetchOperationData(pageNum, pageSize)
      }, 0)
    }

    const handleClose = () => {
      handleCancel();
    }

    return (
        <Drawer
          anchor={'right'}
          open={open}
          onClose={handleClose}
        >
            <Box sx={{ width: '100%', display: 'flex', flexDirection: 'row', alignItems: 'center', padding: '13px', borderBottom: '1px solid #ccc' }}>
              <Typography variant="h6" sx={{ flexGrow: 1 }}>
                {isAuditIdentifierClicked
                  ? `${t('auditIdentifier')} - (${identifierData.formattedValue})` : t('entityIdentifier')}  
              </Typography>

              <Button onClick={() => { handleClose() }} className="close">
                <CloseIcon />
              </Button>
            </Box>
            
            <Box sx={{ padding: '16px' }}>
              {!isAuditIdentifierClicked && (
                <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
                    <Button variant="outlined" size="small" onClick={downLoadEntityList} disabled={moduleName === ''} className="download-button">{t('downloadPDF')}</Button>
                </div>
              )}
            </Box>
            {loading ? (
    <Loading open={loading}></Loading>
    ) : (
      <>
        {!isAuditIdentifierClicked && (
          <>
            <Box sx={{ display: 'flex', flexDirection: 'column' }}>
              <Box sx={{ flexGrow: 1 }}>
                <DataGridPremium
                  columns={entityUpColumns}
                  rows={identifierList}
                  columnHeaderHeight={32}
                  slots={{
                    toolbar: GridToolbar,
                  }}
                  className="react-table report-table"
                  slotProps={{
                    toolbar: {
                      showQuickFilter: true,
                    },
                  }}
                  disableRowSelectionOnClick
                      hideFooterPagination={true}
                      sx={{
                        '& .MuiDataGrid-toolbarContainer': { flexDirection: 'row-reverse' },
                        '& div[role=presentation].MuiDataGrid-virtualScroller' : { minHeight: identifierList.length > 0 ? '61px' : '150px' }
                      }}
                  localeText={localeText}
                  disableAggregation
                />
              </Box>

              <Box sx={{ flexGrow: 2 }}>
              <DataGridPremium               
                    rows={operationList}
                    columnVisibilityModel={gridColumnVisibility}
                    columns={entityDownColumns} columnHeaderHeight={32}
                    className="react-table table_size-has--row1"
                    rowHeight={38}
                    disableRowSelectionOnClick
                    filterModel={filterModel}
                    onFilterModelChange={(
                        filterModel: GridFilterModel,
                        details: GridCallbackDetails<'filter'>
                    ) => {
                        setFilterModel(filterModel)
                    }}
                    localeText={localeText}
                    paginationModel={{ page: pageNum, pageSize: pageSize }}
                    onPaginationModelChange={(paginationModel: any) => { setPageSize(paginationModel.pageSize); setPageNum(paginationModel.page)}}
                    pageSizeOptions={[10, 20, 50]}
                    pagination
                    components={{
                        ColumnMenuIcon: () => { return (<FilterAlt></FilterAlt>) },
                    }}
                    slots={{ toolbar: GridToolbar }}
                    slotProps={{
                        toolbar: {
                        showQuickFilter: true,
                        utf8WithBom: true,
                        csvOptions: {
                            utf8WithBom: true,
                        }
                        },
                    }}
                    pinnedColumns={pinnedColumns}
                    onPinnedColumnsChange={handlePinnedColumnsChange}
                    onColumnVisibilityModelChange={(newModel: any) =>
                        setGridColumnVisibility(newModel)
                    }
                    sortModel={sortModel}
                    disableAggregation
                    />
              </Box>
            </Box>
          </>
        )}
        {isAuditIdentifierClicked && (
          <>
            <div>
              <Box sx={{ flexGrow: 1 }}>
                <DataGridPremium
                  rows={entityData}
                  columns={auditUpColumns}
                  columnHeaderHeight={32}
                  className="react-table report-table"
                  rowHeight={38}
                  disableRowSelectionOnClick
                  hideFooterPagination={true}
                  slotProps={{ toolbar: { showQuickFilter: true } }}
                  localeText={localeText}
                  sx={{
                    '& .MuiDataGrid-toolbarContainer': { flexDirection: 'row-reverse' },
                    '& div[role=presentation].MuiDataGrid-virtualScroller' : { minHeight: '61px' }
                  }}
                  components={{
                    ColumnMenuIcon: () => { return (<FilterAlt></FilterAlt>) }
                  }}
                  slots={{ toolbar: GridToolbar }}
                  disableAggregation
                />
              </Box>
            </div>
            <div className="reportTips">
              {t('auditNote')}
            </div>

            <Box sx={{ flexGrow: 1 }}>
              <DataGridPremium
                rows={fieldModifications}
                columns={auditDownColumns}
                columnHeaderHeight={32}
                className="react-table table_size-has--row1"
                localeText={localeText}
                getRowHeight={() => isCategoryData ? 'auto' : 38}
                disableRowSelectionOnClick
                hideFooterPagination={true}
                slots={{ toolbar: GridToolbar }}
                slotProps={{ toolbar: { showQuickFilter: true } }}
                sx={{
                  '& .MuiDataGrid-toolbarContainer': { flexDirection: 'row-reverse' },
                  '& div[role=presentation].MuiDataGrid-virtualScroller' : { minHeight: '61px' }
                }}
                disableAggregation
              />
            </Box>
          </>
        )}
      </>
    )}
    <Loading open={loading}></Loading>
  </Drawer>
);
};
export default AuditReportDrawer;