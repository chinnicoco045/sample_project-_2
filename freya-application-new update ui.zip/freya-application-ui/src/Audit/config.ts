import { create } from "zustand";
import { persist, subscribeWithSelector } from "zustand/middleware";
import { immer } from "zustand/middleware/immer";
import { GlobalSearchParams } from "../Components/Applications/GlobalSearchList";

export interface FilterParamsItem {
  field: string;
  value: (string | number)[];
}
type ConfigStore = {
  language: string;
  updateLanguage: (data: string) => void;
};
type SelectConditionParams = { field: string; value: (string | number)[] };

type DateConditionParams = { field: string; gte?: string; lte?: string };

export type ConditionItem = SelectConditionParams | DateConditionParams;


type NonConfigStore = {
  filter: FilterParamsItem[] | null;
  updateFilter: (data: FilterParamsItem[]) => void;
  search: GlobalSearchParams | null;
  updateSearch: (data: GlobalSearchParams) => void;
};

export const useConfigStore = create<ConfigStore>()(
  persist(
    subscribeWithSelector(
      immer((set, get) => ({
        language: "en",
        updateLanguage(data) {
          set((state) => {
            state.language = data;
          });
        },
      }))
    ),

    {
      name: "global-config-store",
    }
  )
);

export const useNonPersistentFilterItemsStore = create<Partial<NonConfigStore>>()(
  persist(
    subscribeWithSelector(
      immer((set, get) => ({
        filter: [],
        updateFilter(data) {
          set((state) => {
            state.filter = data;
          });
        },
      })),
    ),
    {
      name: "global-filter-data", // Key for local storage
    }
  )
);
export const useSearchStore = create<Partial<NonConfigStore>>()(
  persist(
    subscribeWithSelector(
      immer((set,get) => ({
        search: null,
        updateSearch(data) {
          set((state) => {
            state.search = data;
          });
        },
      }))
    ),
    {
      name: "global-search-store", // LocalStorage key for search
    }
  )
);

