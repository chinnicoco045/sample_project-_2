import { Navigate, createBrowserRouter } from "react-router-dom";
import React, { Suspense } from "react";
import Layouts from "../layouts";
import EditApplication from "../Components/Applications/EditApplication";
import ViewApplication from "../Components/Applications/ViewApplication";
// import AddApplicationsGrid from "../Components/Applications/wizard/AddApplicationsGrid";
import SideNavTable from "../Components/Applications/SideNavTable";
import SideNavView from "../Components/Applications/SideNavView";
import AuditReportDrawer from "../Audit/AuditReportDrawer";
import GlobalSearchList from "../Components/Applications/GlobalSearchList";

// Use React.lazy for ApplicationDataGrid
const ApplicationDataGrid = React.lazy(() => import("../Components/Applications/ApplicationDataGrid"));
const AddApplicationsGrid = React.lazy(()=>import("../Components/Applications/wizard/AddApplicationsGrid"));

const routesForm = [
  {
    path: "/*",
    element: <Navigate to="/applicationdetails" />,
  },
  {
    path: "/applicationdetails",
    element: (
      <Suspense>
        <ApplicationDataGrid />
      </Suspense>
    ),
  },
  {
    path: "/AuditReportDrawer",
    element: <AuditReportDrawer />,
  },
  {
    path: "/editApplication",
    element: <Layouts />,
    children: [
      {
        path: "",
        element: <EditApplication />,
      },
      {
        path: "viewApplication",
        element: <ViewApplication />,
      },
      {
        path: "sidenavTable",
        element: <SideNavTable />,
      },
    ],
  },
  {
    path: "/addApplication",
    element: <AddApplicationsGrid />,
    children: [
      {
        path: ":id",
        element: <AddApplicationsGrid />,
      },
    ],
  },
  {
    path: "sidenavTable",
    element: <Layouts />,
    children: [
      {
        path: "",
        element: <SideNavTable />,
      },
    ],
  },
  {
    path: "sidenavView",
    element: <Layouts />,
    children: [
      {
        path: "",
        element: <SideNavView />,
      },
    ],
  },
  {
    path: "/viewApplication",
    element: <Layouts />,
    children: [
      {
        path: "",
        element: <ViewApplication />,
      },
      {
        path: "editApplication",
        element: <EditApplication />,
      },
      {
        path: "sidenavTable",
        element: <SideNavTable />,
      },
    ],
  },
  {
    path: "/ApplicationSearchResult",
    //element: <Layouts />,
    children: [
      {
        path: "/ApplicationSearchResult",
        element: <GlobalSearchList />,
      },
    ],
  },
];

const Router = createBrowserRouter(routesForm);
export { Router };
