export const RIMS_CONSTANTS = {

}

export const RIMS_LOCAL_STG_CONSTANTS = {
    LOGIN_TOKEN: 'LOGIN_TOKEN',
    USER_INFO: 'USER_INFO',
    MENU_AUTH_LIST: 'MENU_AUTH_LIST',
    DATA_AUTH_LIST: 'DATA_AUTH_LIST',
    SESSION_TIME_OUT: 'SESSION_TIME_OUT',
    PRIVILEGES: 'PRIVILEGES',
    DATEFORMAT: 'DATEFORMAT',
    EMAIL: 'EMAIL',
    DISABLE_BACK_PREVIOUS: 'DISABLE_BACK_PREVIOUS',
}

export const RIMS_COOKIE_CONSTANTS = {
    TENANT_ID: 'TENANT_ID',
    USER_TENANT_ID: "USER_TENANT_ID",
    LOGIN_TOKEN: "ACCESS_TOKEN",
    USER_ID: "USER_ID",
    URL_DOMAIN: "URL_DOMAIN",
    DOMAIN: "DOMAIN",
    USER_NAME: "USER_NAME",
    USER_EMAIL: "USER_EMAIL",
    USER_PRIVILEGES: "USER_PRIVILEGES",
    USER_INFO: "USER_INFO"
  };

export const RIMS_SESSION_STG_CONSTANTS = {
    MODULE_NAME: 'MODULE_NAME',
    PATH_NAME: 'PATH_NAME'
}

export const REGEXP = {
    accountNo: /^[0-9A-Za-z]{4,10}$/,
    desPhoneNum: /(\d{3})\d*(\d{4})/
}

export const RTQ_EVENTS = {
    ADMIN: {
        CLOSE_EXPORT_LIST_MODAL: 'CLOSE_EXPORT_LIST_MODAL',
        CLOSE_STATUS_UPDATE_MODAL: 'CLOSE_STATUS_UPDATE_MODAL',
        CLOSE_UPDATE_STATUS_HISTORY_MODAL: 'CLOSE_UPDATE_STATUS_HISTORY_MODAL',
        CLOSE_AUDIT_MODAL: 'CLOSE_AUDIT_MODAL',
        DOWNLOAD_TEMPLATE_START: 'DOWNLOAD_TEMPLATE_START',
        DOWNLOAD_TEMPLATE_END: 'DOWNLOAD_TEMPLATE_END'
    },
    PAGINATION: {
        CHANGE_VALUE: 'CHANGE_VALUE'
    },
    RTQ: {
        CLOSE_QUESTION_MODAL: 'CLOSE_QUESTION_MODAL',
        CLOSE_RESPONSE_MODAL: 'CLOSE_RESPONSE_MODAL',
        CLOSE_SIDE_SEARCH_DRAWER: 'CLOSE_SIDE_SEARCH_DRAWER'
    },
    COMMON: {
        EXPORT_FILE_START: 'EXPORT_FILE_START',
        EXPORT_FILE_END: 'EXPORT_FILE_END'
    },
    HEADER: {
        TOGGLE_MENU_EXTEND: 'TOGGLE_MENU_EXTEND',
        TOGGLE_MENU_COLLAPSED: 'TOGGLE_MENU_COLLAPSED'
    }
}


export const enum ModeEnum {
    READ = 'read',
    UPDATE = 'update',
    CREATE = 'create'
}

export const pathAuthMapping = new Map([
    ["/products", "products_view"],
    ["/products/add-product", "products_add"],
    ["/products/edit-product", "products_edit"],
    ["/products/view-product", "products_view"],
])

export const pathAuthWhiteList = [
    '/admin/system-setting',
    '/home',
    '/admin/auditList',
]

export const MFA_QR_URL = 'otpauth://totp/RTQ:{email}?secret={secret}&issuer=RTQ'

export const UAM_MENU_LIST = [
    {
        name: "Users",
        link: "/user-access-management/users",
    },
    {
        name: "Roles",
        link: "/user-access-management/roles",
    },
    {
        name: "User Groups",
        link: "/user-access-management/user-groups",
    },
    {
        name: "Access Control",
        link: "/user-access-management/acl",
    },
];


export const COOKIE_SETUP = {
    path: "/",
    domain: "freyrsolutions.com",
}

export const MENU_MODULE_NAME_MAP = new Map([
    ["aiAssistant", ["/home"]],
    [
        "products",
        [
            "/products",
            "/products/add-product",
            "/products/edit-product",
            "/products/view-product",
        ],
    ],
    ["rtqs", ["/rtqs", "/rtqs/add-rtq", "/rtqs/edit-rtq", "/rtqs/view-rtq"]],
    ["component", ["/component"]],
    ["component-contents", ["/component-contents"]],
    ["settings", ["/settings"]],
    ["document-types", ["/document-types"]],
    ["document-records", ["/document-records"]],
    ["published-documents", ["/published-documents"]],
]);

export const LANGUAGEMAP: { [key: string]: any } = {
    wangeditor: {
        en: "en",
        zh: "zh-CN",
        jp: "jaJP",
    },
    mui: {
        en: "enUS",
        zh: "zhCN",
        jp: "jaJP",
    },
};