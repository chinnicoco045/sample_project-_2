// types.ts

import { Dispatch, SetStateAction, useEffect, useState } from "react";
import Cookies from 'js-cookie';



export default interface Row {
  id: number;
  application_identifier: string;
  productName: string;
  productId: number;  // Add productId to Row definition
  applicationType: string;
  procedureType: string;
  regionName: string;
  countryNames: string[];
  groupid:string;
  cms:string[];
  rms:string[];
  countryIdentifier:string[];
  regionCode:string;
    ms: string;
    lms: string;
    msc: string;
    eIdentifier: string;
    productCategory: string;
    productPhase: string;
    productType: string;
    producerType: string;
    applicationName: string;
    applicationNumber: string;
    procedureNumber: string,
    dossierIdentifier: string,
    application_id: string,
    eSubmissionIdentifier: string,
    registrationNumberId: string,
    applicationStatus: string,
    language: string,
    subjectToArbitration: boolean,
    description: string,
    comments: string,
  mark_fordelete?: number;
  created_by: string;
  created_date: string;
  updated_by: string;
  updated_date: string;
  inactiveFlg:string;
  status:string;
}

type TabItem = {
  id: number | string;
  label: string;
};

export const useLazyTabs = (tabs: TabItem[], initStep?: number) => {
  const [activeStep, setActiveStep] = useState(initStep ?? 0);
  const [renderedTabs, setRenderedTabs] = useState(
    Array(tabs.length).fill(false)
  );

  const handleTabClick = (index: number) => {
    setActiveStep(index);
  };

  useEffect(() => {
    setRenderedTabs((prevTabs) => {
      const newRenderedTabs = [...prevTabs];
      newRenderedTabs[activeStep] = true;
      return newRenderedTabs;
    });
  }, [activeStep, tabs]);

  return { activeStep, handleTabClick, renderedTabs };
};

declare namespace API {
  // menu manager

  export interface PageRequest {
    pageNum: number;
    pageSize: number;
    [key: string]: any;
  }
  interface ProductPageParams extends API.PageRequest {
    showActive: boolean;
    showDisable: boolean;
    showInactive: boolean;
    productPhase?: string;
  }

  export interface DataResponse<T> {
    code: number;
    message: string;
    data: T;
  }

  export interface PageResult<T> {
    pageSize: number;
    pageNum: number;
    total: number;
    data: T;
  }

  interface GridManagerFieldItem {
    id: string;
    column: string;
    type: string;
    gridAvailability: boolean;
    visibility: boolean;
    fieldName: string;
    order: number;
  }
}

export interface Product {
  comments: string;
  productName: string;
  productType: string;
  productPhase: string;
  productFamily: string;
  productCategory: string;
  productFamilyCode: string;
  administrableDoseForm: string;
  pharmaceuticalDoseForm: string;
  combinedPharmaceuticalDoseForm: string;
  combinationPackage: string;
  dynamicFieldJson: string;
  recordId: string;
  id: string;
  dosageForm: string;
  strengths: string;
  units: string;
  status: string;
  productCode: string;
  productPhaseId:string;
}



export const accessToken = Cookies.get('ACCESS_TOKEN');
export const apiToken= Cookies.get('API_TOKEN');






export interface IApplicationData {
  productId:string
  productType: string;
  productName: string;
  producerType: string;
  productPhase:string;
  productCategory:string;
  formatType:string;
  // region: string;
  // country: string[]|string;
  regionName:string;
  countryNames: string[];
  rms?: string;
  rmsName?:string;
  lms?: string;
  lmsName?:string;
  cms?: string[];
  cmsName?:string[];
  msc?: string[];
  mscName?:string[];
  ms?: string[];
  msName?:string[];
  [key: string]: string | string[] | undefined | undefined[];
  applicationNumber:string;
  procedureNumber:string;
  applicationType:string;
  registrationId:string;
  countryIdentifier:string|undefined;
  applicationId:string;
}

