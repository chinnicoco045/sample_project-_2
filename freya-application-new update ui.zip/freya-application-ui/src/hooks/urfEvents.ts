import { useEffect } from "react";
import { useLocation } from "react-router-dom";
import { ConditionItem, FilterParamsItem, useConfigStore, useNonPersistentFilterItemsStore, useSearchStore } from "../Audit/config";

interface AfterHistoryChangeMessage {
  type: "afterHistoryChange";
  data: { pathname: string; moduleName?: string };
}
interface GlobalSearchParams {
  query: string;
  semantic_search: boolean;
  conditions: ConditionItem[];
}
type PostMessage = AfterHistoryChangeMessage;
interface GlobalSearchChangeMessage {
  type: "globalSearchChange";
  data: GlobalSearchParams;
}
interface GlobalLanguageChangeMessage {
  type: "globalLanguageChange";
  data: "en" | "zh" | "jp";
}
interface GlobalFilterChangeMessage {
  type: "globalFilterChange";
  data: FilterParamsItem[];
}
type ReceiveMessageEvent = {
  data: GlobalLanguageChangeMessage | GlobalFilterChangeMessage | GlobalSearchChangeMessage;
};

export const useUrfPostEvents = () => {
  const location = useLocation();
  const postMessage = (message: PostMessage) => {
    if (window.parent !== window) {
      window.parent.postMessage(
        message,
        `https://${process.env.REACT_APP_STG_DOMAIN}` //"https://app.devscopes.freyafusion.com/"
      );
    }
  };

  useEffect(() => {
    postMessage({
      type: "afterHistoryChange",
      data: {
        pathname: location.pathname,
        moduleName: "",
      },
    });
  }, [location.pathname]);
};

export const useUrfReceiveEvents = () => {
  const [updateLanguage] = useConfigStore((state:any) => [state.updateLanguage]);

  const [updateFilter] = useNonPersistentFilterItemsStore((state:any) => [
    state.updateFilter,
  ]);

  const [updateSearch] = useSearchStore(
    (state:any) => [state.updateSearch]
  );

  //Scenes：If the subapplication's route uses asynchronous loading and a request is made during loading.
  //Problem：Relying solely on the iframe's onLoad event may not ensure that the subapplication loads fully.
  //Solution: Put this hook in App.tsx
  const receiveMessage = (event: ReceiveMessageEvent) => {
    // need to use environment variables
    // if (event.origin !== "https://app.devsecops.freyafusion.com") return;
    switch (event.data?.type) {
      case "globalLanguageChange": {
        console.log("globalLanguageChange event.data: ", event.data);
        updateLanguage(event.data.data);
        break;
      }
      case "globalFilterChange": {
        console.log("globalFilterChange event.data: ", event.data);
        //@ts-ignore
        updateFilter(event.data.data);
        // TODO
        break;
      }
      case "globalSearchChange": {
        console.log("globalSearchChange event.data: ", event.data);
        // TODO
        updateSearch(event.data.data);
        break;
      }
      default:
        break;
    }
  };
  useEffect(() => {
    window.addEventListener("message", receiveMessage, false);
    return () => window.removeEventListener("message", receiveMessage);
  }, []);
};
