import {
    GridColDef,
    GridColumnVisibilityModel,
    GridRenderCellParams,
  } from "@mui/x-data-grid-premium";
  import { useState, useEffect, useMemo, useTransition } from "react";

  import { Tooltip } from "@mui/material";
import { sortFn } from "../Components/Applications/wizard/LinkedProducts";
import { useTranslation } from "react-i18next";
  



export interface GridColCommon {
    id: string;
    [key: string]: any;
  }

interface GridManagerFieldItem {
    id: string;
    column: string;
    type: string;
    gridAvailability: boolean;
    visibility: boolean;
    fieldName: string;
    order: number;
  }
  const useGridConfig = (
    staticColumn: GridColDef<GridColCommon>[],
    gridsFields?: GridManagerFieldItem[]
  ) => {
    const [columnVisibilityModel, setColumnVisibilityModel] =
      useState<GridColumnVisibilityModel>({});
      const {t}=useTranslation();
    useEffect(() => {
      if (!gridsFields) return;
      const gridColumnKey = {
        ...columnVisibilityModel,
      };
      gridsFields
        ?.filter((item) => item.gridAvailability)
        ?.forEach((item) => {
          const key: string = item.fieldName;
          gridColumnKey[key] = item.visibility;
        });
      setColumnVisibilityModel({
        ...gridColumnKey,
      });
    }, [gridsFields]);
  
    const columns: GridColDef[] = useMemo(() => {
      const dynamicColumns =
        gridsFields
          ?.sort(sortFn)
          ?.filter((item) => item.gridAvailability)
          ?.map((item) => {
            return {
              field: item.fieldName,
              headerName: t(item.fieldName, { defaultValue: item.column }),
              minWidth: 150,
              flex: 1,
              renderCell: (cellValues: GridRenderCellParams) => {
                return (
                  <Tooltip title={cellValues.value} placement="top">
                    <div> {cellValues.value}</div>
                  </Tooltip>
                );
              },
            };
          }) || [];
      return [...dynamicColumns, ...staticColumn];
    }, [gridsFields]);
  
    return { columnVisibilityModel, columns, setColumnVisibilityModel };
  };
  
  export default useGridConfig;
  